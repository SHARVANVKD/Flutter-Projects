import 'package:selfie_mobile_flutter/mds_controller.dart/mds_model.dart/instrument.dart';

List<Instrument> getsortlist(List<Instrument> list, int index) {
  switch (index) {
    case 0:
      list.sort(((a, b) => (a.securityName).compareTo(b.securityName)));
      break;
    case 1:
      list.sort(((a, b) => (a.securityName).compareTo(b.securityName)));
      list = list.reversed.toList();
      break;
    case 2:
      list.sort(((a, b) => (a.lastTrdPrice).compareTo(b.lastTrdPrice)));
      break;
    case 3:
      list.sort(((a, b) => (a.lastTrdPrice).compareTo(b.lastTrdPrice)));
      list = list.reversed.toList();
      break;
    case 4:
      list.sort(((a, b) => (a.changePrice).compareTo(b.changePrice)));
      break;
    case 5:
      list.sort(((a, b) => (a.changePrice).compareTo(b.changePrice)));
      list = list.reversed.toList();
      break;
    case 6:
      break;
    case 7:
      break;
  }
  return list;
}

maskStringWithStar(
    {required String inputString, int startIndex = 0, int EndIndex = 1}) {
  if (inputString.isNotEmpty)
    return inputString.replaceRange(startIndex, EndIndex, '*' * EndIndex);
}

// stringSeparationToList(
//     {required String inputString, required String separatoinValue}) {
//   return inputString.split(separatoinValue);
// }
