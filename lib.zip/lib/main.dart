import 'dart:async';
import 'dart:developer';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/restart_widget.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';
import 'package:selfie_mobile_flutter/theme/custom_theme.dart';
import 'app.dart';

void main() {
  const environment = String.fromEnvironment('FLAVOR', defaultValue: 'staging');
  const debuggable = bool.fromEnvironment('DEBUGGABLE', defaultValue: true);
  const loggable = bool.fromEnvironment('LOGGABLE', defaultValue: true);

  const baseUrl = String.fromEnvironment('BASE_URL',
      defaultValue: "http://selfiedev.geojittechnologies.com:8080");

  const initialRoute = String.fromEnvironment('INITIAL_ROUTE',
      defaultValue: debuggable ? '/login' : '/login'); //calanderPage //login

  // SystemChrome.setSystemUIOverlayStyle(
  //   SystemUiOverlayStyle.light.copyWith(
  //     systemNavigationBarColor: Colors.white,
  //     systemNavigationBarDividerColor: Colors.white,
  //     statusBarColor: Colors.white,
  //     statusBarIconBrightness: Brightness.light,
  //     systemNavigationBarIconBrightness: Brightness.light,
  //   )
  // );
  runZonedGuarded<void>(() {
    if (kReleaseMode) {
      //TODO: uncomment to record errors
      // FlutterError.onError = FirebaseCrashlytics.instance.recordFlutterError;
    }

    final locator = ServiceLocator(baseUrl, debuggable: loggable)..config();
    if (debuggable) {
      runApp(ChangeNotifierProvider<CustomTheme>(
          create: (BuildContext context) =>
              CustomTheme(themeMode: CustomMode.Light),
          child: RestartWidget(
            child: TradingApp(
              serviceLocator: locator,
              initialRoute: initialRoute,
            ),
          )));
    } else {
      runApp(ChangeNotifierProvider<CustomTheme>(
          create: (BuildContext context) {
            return CustomTheme(themeMode: CustomMode.Light);
          },
          child: RestartWidget(
            child: TradingApp(
              serviceLocator: locator,
              initialRoute: initialRoute,
            ),
          )));
    }
  }, (error, stackTrace) {
    if (kReleaseMode) {
      //TODO: uncomment to record errors
      // FirebaseCrashlytics.instance.recordError(error, stackTrace);
    }
    log('TradingAppError', error: error, stackTrace: stackTrace);
  });
}
