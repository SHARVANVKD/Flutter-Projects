import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/navigation/navigation.dart';
import 'package:selfie_mobile_flutter/services/api_gateway.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';

extension AppPageInjectable on BuildContext {
  NavigationService get gNavigationService =>
      read<ServiceLocator>().navigationService;

  TradingApiGateway get gTradingApiGateway => read<ServiceLocator>().tradingApi;

  void resetCubits() {
    read<ServiceLocator>().resetCubits();
  }
}
