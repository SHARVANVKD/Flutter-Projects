part of 'navigation.dart';

Route<dynamic>? Function(RouteSettings settings) onGenerateAppRoute(
    RoutesFactory routesFactory) {
  return (RouteSettings settings) {
    switch (settings.name) {
      case _loginPageRouteName:
        return routesFactory.createLoginPageRoute();
      case _tfaPageRouteName:
        final args = settings.arguments as MapArguments;
        return routesFactory.createTfaPageRoute(args.data);
      case _workspacePageRouteName:
        return routesFactory.createWorkspacePageRoute();
      case _individualStockPage:
        return routesFactory.createIndividualStockPage();
      case _watchlistEditPageRouteName:
        final args = settings.arguments as Map<String, dynamic>;
        return routesFactory.createWatchlistEditPageRoute(args);
      case _symbolSearchPageRouteName:
      final args = settings.arguments as MapArguments;
        return routesFactory.createSymbolSearchPageRoute(args.data);
      case _watchlistManagePageRouteName:
        final args = settings.arguments as MapArguments;
        return routesFactory.createWatchlistManagePageRoute(args.data);
      case _watchlistAllPageRouteName:
        return routesFactory.createAllWatchlistPageRoute();
      case _positionLongPressRouteName:
      final args = settings.arguments as MapArguments;
        return routesFactory.createPostionLongPressPageRoute(args.data);
      case _holdingRouteName:
        return routesFactory.createHoldingPageRoute();
      case _holdingTabRouteName:
        final args = settings.arguments as MapArguments;
        return routesFactory.createEquityPageRoute(args.data);
      case _orderWindowRouteName:
        final args = settings.arguments as MapArguments;
        return routesFactory.createOrderWindowPageRoute(args.data);
      case _rollOrderPageRouteName:
        final args = settings.arguments as MapArguments;
        return routesFactory.createRollOrderPageRoute(args.data);
      case _OCO_orderWindowRouteName:
        final args = settings.arguments as MapArguments;
        return routesFactory.createOCOOrderPageRoute(args.data);
      case _individualDealsPageRouteName:
        return routesFactory.createIndividualDealsPage();
      case _defaultOrderSettingsPageRouteName:
        return routesFactory.createOrderSettingsPageRoute();
      case _calanderPage:
        return routesFactory.createCalanderPageRoute();
      case _profilePage:
        return routesFactory.createProfilePageRoute();
      case _stockChartPage:
        return routesFactory.createStockChartPageRoute();
      case _indexDetailPage:
        return routesFactory.createIndexDetailPageRoute();
      case _reviewOrderRoutePageName:
        return routesFactory.createReviewOrderPageRoute();
      case _remarkPageRouteName:
        return routesFactory.createRemarkPageRoute();
      case _confirmPageRouteName:
        return routesFactory.createConfirmPageRoute();
      case _moreAlertsPageRouteName:
        return routesFactory.createMoreAlertsPageRoute();
      case _rollOrderReviewPageRouteName:
        return routesFactory.createRollOrderReviewPage();
      case _optionAndFuturePageRouteName:
        return routesFactory.createOptionAndFutureRoute();
      case _spreadPageRouteName:
        return routesFactory.createSpreadPageRoute();
      case _orderopenlongpressRouteName:
       final args = settings.arguments as OpenCancelPage;
        return routesFactory.createOrderOpenLongpressRoute(args.data);
      case _createAlertPageRouteName:
        final args = settings.arguments as AlertPages;
        return routesFactory.createAlertPageRoute(
            args.title, args.Symbol, args.ltp);
      case _contactGeojitPageRouteName:
        return routesFactory.createContactGeojitPage();
      case _getACallbackRouteName:
        return routesFactory.createGetACallbackPage();
      case _raiseATicketPageRouteName:
        return routesFactory.createRaiseATicketPage();

      case _dashBoardPageRouteName:
        return routesFactory.createDashBoardPage();
      case _helpPageRouteName:
        return routesFactory.createHelpPageRoute();
      case _supportRouteName:
        return routesFactory.createSupportPageRoute();
      case _aboutusRouteName:
        return routesFactory.createAboutUsPage();
      case _licencesRouteName:
        return routesFactory.createLicencePage();
      case _inviteFriendRouteName:
        return routesFactory.createInviteFriend();
      case _becomePartnerRouteName:
        return routesFactory.createBecomePartnerPage();
      case _notificationRouteName:
        return routesFactory.createNotificationPageRoute();
      case _marketSimulatorRouteName:
        return routesFactory.createMarketSimulatorPageRoute();
      case _myAppsRouteName:
        return routesFactory.createMyAppsPageRoute();
      case _suggestRouteName:
        return routesFactory.createSuggestPageRoute();
      case _settingsRouteName:
        return routesFactory.createSettingsPageRoute();
      case _settingNotification:
        return routesFactory.createSettingsNotificationPageRoute();
      case _settingOthersNotification:
        return routesFactory.createSettingOtherspageRoute();
      case _feedBackRouteName:
        return routesFactory.createFeedBackPageRoute();
      case _optionRemarkRouteName:
        return routesFactory.createOptionRemarkPageRoute();
      case _ipoRouteName:
        return routesFactory.createIpoPageRoute();
      case _basketInnerPageRouteName:
        return routesFactory.createBasketInnerPageRouteName();
      case _ipoDetailPageRouteName:
        return routesFactory.createIpoDetailPageRouteName();
      case _ipoAppliedDetailPageRouteName:
        return routesFactory.createIpoAppliedDetailpageRoutename();
      case _orderConfirmbasket:
        return routesFactory.createBasketOrderConfirmPageRouteName();
      case _editbasketInnerPageRouteName:
        return routesFactory.createEditBasketInner();
      case _editmybasket:
        return routesFactory.createEditMyBasket();
      case _ipoApplicationSubmission:
        return routesFactory.createIpoApplicationSubmissionPageRouteName();
      case _ipoDetailPageFinalPageRoute:
        return routesFactory.createIpoDetailPageFinalPageRouteBuilder();
      case _fundsPageRouteName:
        return routesFactory.createFundsPageRoute();
      default:
        return null;
    }
  };
}
