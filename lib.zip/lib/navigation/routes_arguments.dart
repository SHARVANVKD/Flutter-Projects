part of 'navigation.dart';

class MapArguments {
  final Map<String, dynamic> data;
  MapArguments(this.data);
}

class AlertPages {
  String title;
  String Symbol;
  String ltp;
  AlertPages(this.title, this.Symbol, this.ltp);
}

class OpenCancelPage {
  final List<Map<String, dynamic>> data;
  OpenCancelPage(this.data);
}
