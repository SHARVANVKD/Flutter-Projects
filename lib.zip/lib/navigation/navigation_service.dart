part of 'navigation.dart';

class NavigationService {
  Future<void> openLoginPage(BuildContext context) {
    return Navigator.of(context).pushNamed(_loginPageRouteName);
  }

  Future<void> openTfaAuthPage(
      BuildContext context, Map<String, dynamic> data) {
    return Navigator.of(context)
        .pushNamed(_tfaPageRouteName, arguments: MapArguments(data));
  }

  Future<void> openSpreadPage(BuildContext context) {
    return Navigator.of(context).pushNamed(_spreadPageRouteName);
  }

  Future<void> openIndexDetailPage(BuildContext context) {
    return Navigator.of(context).pushNamed(_indexDetailPage);
  }

  Future<void> openOptionAndFuturePage(BuildContext context) {
    return Navigator.of(context).pushNamed(_optionAndFuturePageRouteName);
  }

  Future<void> openStockChartPage(BuildContext context) {
    return Navigator.of(context).pushNamed(_stockChartPage);
  }

  Future<void> openIndividualStockPage(
      BuildContext context, Map<String, dynamic> data) {
    return Navigator.of(context)
        .pushNamed(_individualStockPage, arguments: MapArguments(data));
  }

  Future<void> openEquityPage(BuildContext context, Map<String, dynamic> data) {
    return Navigator.of(context)
        .pushNamed(_holdingTabRouteName, arguments: MapArguments(data));
  }

  Future<void> openHoldingPage(BuildContext context) {
    return Navigator.of(context).pushNamed(_holdingRouteName);
  }

  Future<void> openSymbolSearch(
      BuildContext context, Map<String, dynamic> fromPage) {
    return Navigator.of(context).pushNamed(_symbolSearchPageRouteName,
        arguments: MapArguments(fromPage));
  }

  Future<void> openReviewOrder(BuildContext context) {
    return Navigator.of(context).pushNamed(_reviewOrderRoutePageName);
  }

  Future<void> OpenRemarkPage(BuildContext context) {
    return Navigator.of(context).pushNamed(_remarkPageRouteName);
  }

  Future<void> OpenConfirmPage(BuildContext context) {
    return Navigator.of(context).pushNamed(_confirmPageRouteName);
  }

  Future<void> openRollOrderReview(BuildContext context) {
    return Navigator.of(context).pushNamed(_rollOrderReviewPageRouteName);
  }

//
  Future<void> openWorkspacePage(BuildContext context) {
    return Navigator.of(context).popAndPushNamed(_workspacePageRouteName);
  }

  Future<dynamic> openWatchlistManagePage(
      BuildContext context, Map<String, dynamic> data) {
    return Navigator.of(context).pushNamed(_watchlistManagePageRouteName,
        arguments: MapArguments(data));
  }

  Future<dynamic> openAllWatchlistPage(BuildContext context) async {
    return await Navigator.of(context).pushNamed(_watchlistAllPageRouteName);
  }

  Future<dynamic> openEditWatchlistPage(
      BuildContext context, Map<String, dynamic> data) {
    return Navigator.of(context)
        .pushNamed(_watchlistEditPageRouteName, arguments: data);
  }

  Future<void> openPositionLongPress(BuildContext context) {
    return Navigator.of(context).pushNamed(_positionLongPressRouteName);
  }

  Future<void> openProfilePage(BuildContext context) {
    return Navigator.of(context).pushNamed(_profilePage);
  }

  Future<void> openMyAppsPage(BuildContext context) {
    return Navigator.of(context).pushNamed(_myAppsRouteName);
  }

  Future<void> openFeedbackPage(BuildContext context) {
    return Navigator.of(context).pushNamed(_feedBackRouteName);
  }

  Future<void> openCalanderPage(BuildContext context) {
    return Navigator.of(context).pushNamed(_calanderPage);
  }

  Future<void> openOrderWindowPage(
      BuildContext context, Map<String, dynamic> data) {
    return Navigator.of(context)
        .pushNamed(_orderWindowRouteName, arguments: MapArguments(data));
  }

  Future<void> openRollOrderPage(
      BuildContext context, Map<String, dynamic> data) {
    return Navigator.of(context)
        .pushNamed(_rollOrderPageRouteName, arguments: MapArguments(data));
  }

  Future<void> openOCOOrderPage(
      BuildContext context, Map<String, dynamic> data) {
    return Navigator.of(context)
        .pushNamed(_OCO_orderWindowRouteName, arguments: MapArguments(data));
  }

  Future<void> openDefaultOrderSettingsPage(BuildContext context) {
    return Navigator.of(context).pushNamed(_defaultOrderSettingsPageRouteName);
  }

  Future<void> openMoreAlertsPage(BuildContext context) {
    return Navigator.of(context).pushNamed(_moreAlertsPageRouteName);
  }

  Future<void> openOrderOpenLongpressPage(
      BuildContext context, List<Map<String, dynamic>> data) {
    return Navigator.of(context).pushNamed(_orderopenlongpressRouteName,
        arguments: OpenCancelPage(data));
  }

  Future<void> openCreateAlertPage(
      BuildContext context, String title, String Symbol, String ltp) {
    return Navigator.of(context).pushNamed(_createAlertPageRouteName,
        arguments: AlertPages(title, Symbol, ltp));
  }

  Future<void> openDashBoardPage(BuildContext context) {
    return Navigator.of(context).pushNamed(_dashBoardPageRouteName);
  }

  dynamic back(BuildContext context, {Map<String, dynamic>? arg}) {
    return Navigator.pop(context, arg);
  }

  void backWithResult(BuildContext context, dynamic result) {
    return Navigator.of(context).pop(result);
  }

  Future<void> openContactGeojitPage(BuildContext context) {
    return Navigator.of(context).pushNamed(_contactGeojitPageRouteName);
  }

  Future<void> openRaiseATicketPage(BuildContext context) {
    return Navigator.of(context).pushNamed(_raiseATicketPageRouteName);
  }

  Future<void> openGetACallbackPage(BuildContext context) {
    return Navigator.of(context).pushNamed(_getACallbackRouteName);
  }

  Future<void> openHelpPage(BuildContext context) {
    return Navigator.of(context).pushNamed(_helpPageRouteName);
  }

  Future<void> openSupportPage(BuildContext context) {
    return Navigator.of(context).pushNamed(_supportRouteName);
  }

  Future<void> openAboutUsPage(BuildContext context) {
    return Navigator.of(context).pushNamed(_aboutusRouteName);
  }

  Future<void> openLicencePage(BuildContext context) {
    return Navigator.of(context).pushNamed(_licencesRouteName);
  }

  Future<void> openInviteFriendPage(BuildContext context) {
    return Navigator.of(context).pushNamed(_inviteFriendRouteName);
  }

  Future<void> openBecomePartnerPage(BuildContext context) {
    return Navigator.of(context).pushNamed(_becomePartnerRouteName);
  }

  Future<void> openNotificationPage(BuildContext context) {
    return Navigator.of(context).pushNamed(_notificationRouteName);
  }

  Future<void> openMarketSimulatorPage(BuildContext context) {
    return Navigator.of(context).pushNamed(_marketSimulatorRouteName);
  }

  Future<void> openSuggestPage(BuildContext context) {
    return Navigator.of(context).pushNamed(_suggestRouteName);
  }

  Future<void> openSettingsPage(BuildContext context) {
    return Navigator.of(context).pushNamed(_settingsRouteName);
  }

  Future<void> openSettingsNotifactionPage(BuildContext context) {
    return Navigator.of(context).pushNamed(_settingNotification);
  }

  Future<void> openSettingOthersPage(BuildContext context) {
    return Navigator.of(context).pushNamed(_settingOthersNotification);
  }

  Future<void> openOptionRemarkPage(BuildContext context) {
    return Navigator.of(context).pushNamed(_optionRemarkRouteName);
  }

  Future<void> openIpoPage(BuildContext context) {
    return Navigator.of(context).pushNamed(_ipoRouteName);
  }

  Future<void> openBaketInnerPage(BuildContext context) {
    return Navigator.of(context).pushNamed(_basketInnerPageRouteName);
  }

  Future<void> openIpoDetailPage(BuildContext context) {
    return Navigator.of(context).pushNamed(_ipoDetailPageRouteName);
  }

  Future<void> openIpoAppliedDetailPage(BuildContext context) {
    return Navigator.of(context).pushNamed(_ipoAppliedDetailPageRouteName);
  }

  Future<void> openOrderConfirmPage(BuildContext context) {
    return Navigator.of(context).pushNamed(_orderConfirmbasket);
  }

  Future<void> openBasketInnerEdit(BuildContext context) {
    return Navigator.of(context).pushNamed(_editbasketInnerPageRouteName);
  }

  Future<void> openMyBasketEdit(BuildContext context) {
    return Navigator.of(context).pushNamed(_editmybasket);
  }

  Future<void> openIpoApplicationSubmissionPage(BuildContext context) {
    return Navigator.of(context).pushNamed(_ipoApplicationSubmission);
  }

  Future<void> openIpoDetailFinalPage(BuildContext context) {
    return Navigator.of(context).pushNamed(_ipoDetailPageFinalPageRoute);
  }

  Future<void> openDealsPage(BuildContext context) {
    return Navigator.of(context).pushNamed(_individualDealsPageRouteName);
  }
  Future<void> openFundPage(BuildContext context) {
    return Navigator.of(context).pushNamed(_fundsPageRouteName);
  }
}
