import 'package:flutter/material.dart';

part 'routes_arguments.dart';

part 'routes_factory.dart';

part 'routes_mapper.dart';

part 'routes_names.dart';

part 'navigation_service.dart';
