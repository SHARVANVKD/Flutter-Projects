import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class IpoAppliedListTile extends StatelessWidget {
  Map<String, dynamic> listItem;

  IpoAppliedListTile({Key? key, required this.listItem}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 9, bottom: 9),
      child: Container(
        height: 128,
        width: MediaQuery.of(context).size.width,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(4),
          border: Border.all(color: customColors().backgroundTertiary),
        ),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                listItem["status"].toString().isEmpty
                    ? const SizedBox(
                        height: 18,
                        width: 87,
                      )
                    : Container(
                        height: 18,
                        width: 87,
                        decoration: BoxDecoration(
                          borderRadius: const BorderRadius.only(
                            bottomLeft: Radius.circular(4),
                          ),
                          color: customColors().success.withOpacity(.15),
                        ),
                        child: Center(
                          child: Text(
                            listItem["status"],
                            style: customTextStyle(
                              fontStyle: FontStyle.TagNameL_SemiBold,
                              color: FontColor.Success,
                            ),
                          ),
                        ),
                      ),
              ],
            ),
            Padding(
              padding: const EdgeInsets.only(left: 16),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Container(
                    height: 40,
                    width: 40,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(4),
                        color: customColors().backgroundSecondary),
                    child: Center(
                      child: Image.asset(listItem["imgPath"]),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left: 16),
                    child: SizedBox(
                      width: MediaQuery.of(context).size.width * 0.4,
                      child: Text(
                        listItem["symbol"],
                        maxLines: 2,
                        style: customTextStyle(
                          fontStyle: FontStyle.BodyL_SemiBold,
                          color: FontColor.FontPrimary,
                        ),
                      ),
                    ),
                  )
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "Applied On",
                        style: customTextStyle(
                            fontStyle: FontStyle.BodyM_Regular,
                            color: FontColor.FontTertiary),
                      ),
                      const SizedBox(
                        height: 6,
                      ),
                      Text(
                        listItem["applied_date"],
                        style: customTextStyle(
                            fontStyle: FontStyle.BodyM_SemiBold,
                            color: FontColor.FontPrimary),
                      )
                    ],
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text(
                        "Status",
                        style: customTextStyle(
                            fontStyle: FontStyle.BodyM_Regular,
                            color: FontColor.FontTertiary),
                      ),
                      const SizedBox(
                        height: 6,
                      ),
                      Row(
                        children: [
                          Padding(
                            padding: const EdgeInsets.only(right: 3),
                            child: Text(
                              listItem["applied_status_1"],
                              style: customTextStyle(
                                  fontStyle: FontStyle.BodyM_SemiBold,
                                  color: listItem["applied_status_1_color"]),
                            ),
                          ),
                          listItem["applied_status_2"].toString().isEmpty
                              ? const SizedBox()
                              : Padding(
                                  padding: const EdgeInsets.only(right: 3),
                                  child: Container(
                                    height: 11,
                                    width: 1,
                                    color: customColors().backgroundTertiary,
                                  ),
                                ),
                          listItem["applied_status_2"].toString().isEmpty
                              ? const SizedBox()
                              : Text(
                                  listItem["applied_status_2"],
                                  style: customTextStyle(
                                      fontStyle: FontStyle.BodyM_SemiBold,
                                      color:
                                          listItem["applied_status_2_color"]),
                                ),
                        ],
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
