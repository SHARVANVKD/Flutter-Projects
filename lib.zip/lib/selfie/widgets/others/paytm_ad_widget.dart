import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class PaytmAdWidget extends StatefulWidget {
  String icon, heading, discription, clickabeText;
  double height;

  PaytmAdWidget(
      {required this.icon,
      required this.height,
      required this.discription,
      required this.heading,
      required this.clickabeText});

  @override
  State<PaytmAdWidget> createState() => _PaytmAdWidgetState();
}

class _PaytmAdWidgetState extends State<PaytmAdWidget> {
  bool isClosed = true;
  @override
  Widget build(BuildContext context) {
    return Visibility(
      visible: isClosed,
      child: Center(
        child: Stack(
          alignment: AlignmentDirectional.topEnd,
          children: [
            SizedBox(
              height: widget.height,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const SizedBox(height: 10),
                  Container(
                    width: double.maxFinite,
                    height: 1,
                    color: customColors().backgroundTertiary,
                  ),
                  const Expanded(child: SizedBox()),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: Row(
                      children: [
                        Image.asset(widget.icon),
                        const SizedBox(width: 10),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.center,
                          verticalDirection: VerticalDirection.down,
                          textBaseline: TextBaseline.alphabetic,
                          textDirection: TextDirection.ltr,
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(
                              widget.heading,
                              style: customTextStyle(
                                  fontStyle: FontStyle.BodyM_Bold,
                                  color: FontColor.FontPrimary),
                            ),
                            const SizedBox(height: 8),
                            Text(widget.discription,
                                style: customTextStyle(
                                    fontStyle: FontStyle.BodyS_Regular,
                                    color: FontColor.FontSecondary))
                          ],
                        ),
                        const Expanded(child: SizedBox()),
                        Text(
                          widget.clickabeText,
                          style: customTextStyle(
                              fontStyle: FontStyle.BodyM_Bold,
                              color: FontColor.Primary),
                        )
                      ],
                    ),
                  ),
                  const Expanded(child: SizedBox()),
                ],
              ),
            ),
            GestureDetector(
              onTap: () => setState(() {
                isClosed == true ? isClosed = false : isClosed = false;
              }),
              child: Container(
                margin: const EdgeInsets.only(right: 10),
                padding: const EdgeInsets.all(3),
                width: 24,
                height: 24,
                decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: customColors().backgroundPrimary),
                child: Icon(
                  Icons.close,
                  color: customColors().fontPrimary,
                  size: 12,
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}
