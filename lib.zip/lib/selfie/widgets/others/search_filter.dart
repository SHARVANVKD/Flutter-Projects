import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class SearchFilter extends StatefulWidget {
  List<String> category;
  Color? bagroundColor;

  SearchFilter(
      {required this.category,
      required this.buttonHandler,
      this.bagroundColor});
  final Function buttonHandler;

  State<StatefulWidget> createState() => SearchFilterState();
}

class SearchFilterState extends State<SearchFilter> {
  int selectedIndex = 0;
  @override
  Widget build(BuildContext context) {
    return Container(
      color: customColors().backgroundSecondary,
      height: 56,
      child: ListView.builder(
        itemCount: widget.category.length,
        scrollDirection: Axis.horizontal,
        itemBuilder: (context, position) {
          return InkWell(
            child: Column(
              children: [
                const Expanded(child: SizedBox()),
                Center(
                  child: Container(
                      padding: const EdgeInsets.only(
                          bottom: 18.0, right: 18, left: 18),
                      decoration: BoxDecoration(
                          border: Border(
                              bottom: BorderSide(
                                  color: selectedIndex == position
                                      ? customColors().primary
                                      : transparent,
                                  width: 2))),
                      child: Text(
                        widget.category.elementAt(position),
                        style: customTextStyle(
                            fontStyle: FontStyle.BodyL_SemiBold,
                            color: selectedIndex == position
                                ? FontColor.Primary
                                : FontColor.FontSecondary),
                      )),
                ),
              ],
            ),
            onTap: () {
              setState(() {
                selectedIndex = position;
                widget.buttonHandler(selectedIndex); //
              });
            },
          );
        },
      ),
    );
  }
}
