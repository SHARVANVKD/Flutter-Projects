import 'package:flutter/material.dart';

import '../../../theme/styles.dart';

class IndiavidualStockListItem extends StatefulWidget {
  IndiavidualStockListItem(
      {Key? key,
      required this.date,
      required this.days,
      required this.tagname,
      required this.ivdata,
      required this.tagdate,
      required this.pldata,
      this.indicators})
      : super(key: key);
  String date, days, tagname, ivdata, tagdate, pldata;
  List<String>? indicators;
  @override
  State<IndiavidualStockListItem> createState() =>
      _IndiavidualStockListItemState();
}

class _IndiavidualStockListItemState extends State<IndiavidualStockListItem> {
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 16),
      decoration: BoxDecoration(
          border: Border(
        bottom: BorderSide(color: customColors().backgroundTertiary),
      )),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  Text(
                    widget.date,
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyL_SemiBold,
                        color: FontColor.FontPrimary),
                  ),
                  SizedBox(
                    width: 4,
                  ),
                  Text(
                    "(" + widget.days + ")",
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyM_SemiBold,
                        color: FontColor.FontSecondary),
                  ),
                  Row(
                    children: widget.indicators != null
                        ? showindicators(widget.indicators!)
                        : [],
                  ),
                ],
              ),
              Text(
                widget.ivdata,
                style: customTextStyle(
                    fontStyle: FontStyle.BodyL_SemiBold,
                    color: FontColor.FontPrimary),
              )
            ],
          ),
          SizedBox(
            height: 4,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.only(
                        left: 7.0, right: 7.0, top: 2.0, bottom: 3.0),
                    decoration: BoxDecoration(
                      color: getbackcolor(widget.tagname),
                      borderRadius: const BorderRadius.all(Radius.circular(2)),
                    ),
                    child: Center(
                        child: Text(
                      widget.tagname,
                      style: customTextStyle(
                        fontStyle: FontStyle.BodyS_SemiBold,
                        color: getfontcolor(widget.tagname),
                      ),
                    )),
                  ),
                  SizedBox(
                    width: 8,
                  ),
                  Text(
                    widget.tagdate,
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyM_Regular,
                        color: FontColor.FontPrimary),
                  ),
                ],
              ),
              Text(
                widget.pldata,
                style: customTextStyle(
                  fontStyle: FontStyle.BodyM_Regular,
                  color: FontColor.FontSecondary,
                ),
              )
            ],
          ),
        ],
      ),
    );
  }

  showindicators(List<String> items) {
    List<Widget> indictors = [];
    for (var i = 0; i < items.length; i++) {
      switch (items[i]) {
        case "W":
          indictors.add(Padding(
            padding: const EdgeInsets.only(left: 4.0),
            child: Container(
                width: 14,
                height: 14,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                    color: customColors().wTokenBackground,
                    borderRadius: BorderRadius.circular(14)),
                child: Align(
                  alignment: Alignment.center,
                  child: Text(
                    "W",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                        fontFamily: "OpenSansRegular",
                        fontSize: 8,
                        fontWeight: FontWeight.w600,
                        color: customColors().wTokenFontColor),
                  ),
                )),
          ));
          break;
        case "P":
          indictors.add(Padding(
            padding: const EdgeInsets.only(left: 4.0),
            child: Container(
                width: 14,
                height: 14,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                    color: customColors().pTokenBackground,
                    borderRadius: BorderRadius.circular(14)),
                child: Align(
                  alignment: Alignment.center,
                  child: Text(
                    "P",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                        fontFamily: "OpenSansRegular",
                        fontSize: 8,
                        fontWeight: FontWeight.w600,
                        color: customColors().pTokenFontColor),
                  ),
                )),
          ));
          break;
        default:
      }
    }
    return indictors;
  }

  getfontcolor(String status) {
    switch (status) {
      case "RESULT":
        return FontColor.DodgerBlue;
      case "DIVIDEND":
        return FontColor.Dividentcolor;
      case "SPLIT":
        return FontColor.PacificBlue;
      default:
    }
  }

  getbackcolor(String status) {
    switch (status) {
      case "RESULT":
        return customColors().dodgerBlue.withOpacity(0.15);
      case "DIVIDEND":
        return customColors().dividentColor.withOpacity(0.15);
      case "SPLIT":
        return customColors().pacificBlue.withOpacity(0.15);
      default:
    }
  }
}
