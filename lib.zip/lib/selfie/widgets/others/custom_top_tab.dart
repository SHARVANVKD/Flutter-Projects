import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class CustomTabBar extends StatefulWidget {
  final List<String> tabContent;
  final List<Widget> tabBarViewChildern;
  final int selected;
  final TabBarIndicatorSize indicatorSize;
  final bool isScrollable;
  final Function(int)? onTap;
  CustomTabBar({
    Key? key,
    required this.tabContent,
    required this.tabBarViewChildern,
    this.selected = 0,
    this.indicatorSize = TabBarIndicatorSize.label,
    this.isScrollable = false,
    this.onTap,
  }) : super(key: key);

  @override
  State<CustomTabBar> createState() => _CustomTabBarState();
}

class _CustomTabBarState extends State<CustomTabBar>
    with TickerProviderStateMixin {
  List<Widget> tabs = [];
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    tabs = [];
    _tabController = TabController(
        length: widget.tabContent.length,
        vsync: this,
        initialIndex: widget.selected);
  }

  @override
  void dispose() {
    // TODO: implement dispose
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        PreferredSize(
          preferredSize: const Size.fromHeight(0),
          child: Align(
            alignment: Alignment.center,
            child: Container(
                width: MediaQuery.of(context).size.width,
                child: TabBarHeader()),
          ),
        ),
        Container(
          height: 1,
          color: customColors().backgroundTertiary,
        ),
        Expanded(
          child: TabBarView(
              controller: _tabController, children: widget.tabBarViewChildern),
        )
      ],
    );
  }

  Widget TabBarHeader() {
    return TabBar(
      controller: _tabController,
      isScrollable: widget.isScrollable,
      onTap: widget.onTap,
      tabs: [for (var item in widget.tabContent) Tab(text: item)],
      labelStyle: customTextStyle(
          fontStyle: FontStyle.BodyL_SemiBold, color: FontColor.Primary),
      unselectedLabelStyle: customTextStyle(
          fontStyle: FontStyle.BodyL_Regular, color: FontColor.FontSecondary),
      unselectedLabelColor: customColors().fontSecondary,
      labelColor: customColors().primary,
      indicatorColor: customColors().primary,
      indicatorSize: widget.indicatorSize,
      padding: const EdgeInsets.all(0),
      indicatorPadding: const EdgeInsets.all(0),
      enableFeedback: true,
    );
  }
}
