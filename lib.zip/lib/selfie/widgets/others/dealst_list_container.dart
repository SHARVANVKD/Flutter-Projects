import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/options_widget.dart';

import '../../../theme/styles.dart';

class DealsListContainer extends StatelessWidget {
  final List<Map<String, dynamic>> dealsList;
  DealsListContainer({Key? key, required this.dealsList}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.topCenter,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
        decoration: BoxDecoration(
            color: customColors().backgroundPrimary,
            borderRadius: BorderRadius.circular(4),
            border: Border.all(color: customColors().backgroundTertiary)),
        child: ListView.builder(
            primary: false,
            shrinkWrap: true,
            itemCount: dealsList.length,
            itemBuilder: (context, index) {
              return InkWell(
                child: DealsListItem(
                  lastitem: index == 2,
                  dealsItem: dealsList.elementAt(index),
                ),
                onTap: () {},
              );
            }),
      ),
    );
  }
}

class DealsListItem extends StatelessWidget {
  bool lastitem;
  Map<String, dynamic> dealsItem;
  DealsListItem({Key? key, required this.lastitem, required this.dealsItem})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
          border: Border(
        bottom: BorderSide(
            color: lastitem ? transparent : customColors().backgroundTertiary),
      )),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 16),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  dealsItem["name"],
                  style: customTextStyle(
                      fontStyle: FontStyle.BodyL_Bold,
                      color: FontColor.FontPrimary),
                ),
                Row(
                  children: [
                    getProductTypeWidget(dealsItem["bulkorblock"]),
                    const SizedBox(width: 6),
                    getProductTypeWidget(dealsItem["Buyorsell"]),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 22),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                SizedBox(
                  width: 80,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "Qty",
                        style: customTextStyle(
                            fontStyle: FontStyle.BodyM_Regular,
                            color: FontColor.FontTertiary),
                      ),
                      const SizedBox(height: 5),
                      Text(
                        dealsItem["qty"],
                        style: customTextStyle(
                            fontStyle: FontStyle.BodyM_SemiBold,
                            color: FontColor.FontSecondary),
                      ),
                    ],
                  ),
                ),
                SizedBox(
                  width: 80,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Text(
                        "Date",
                        style: customTextStyle(
                            fontStyle: FontStyle.BodyM_Regular,
                            color: FontColor.FontTertiary),
                      ),
                      const SizedBox(height: 5),
                      Text(
                        dealsItem["date"],
                        style: customTextStyle(
                            fontStyle: FontStyle.BodyM_SemiBold,
                            color: FontColor.FontSecondary),
                      ),
                    ],
                  ),
                ),
                SizedBox(
                  width: 80,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text(
                        "Avg Price",
                        style: customTextStyle(
                            fontStyle: FontStyle.BodyM_Regular,
                            color: FontColor.FontTertiary),
                      ),
                      const SizedBox(height: 5),
                      Text(
                        dealsItem["avgprice"],
                        style: customTextStyle(
                            fontStyle: FontStyle.BodyM_SemiBold,
                            color: FontColor.FontSecondary),
                      ),
                    ],
                  ),
                )
              ],
            )
          ],
        ),
      ),
    );
  }
}
