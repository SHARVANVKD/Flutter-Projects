import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class StcokPageTab extends StatefulWidget {
  StcokPageTab(this.buttonHandler, this.height);
  final Function buttonHandler;
  double height;

  State<StatefulWidget> createState() => StockPageTabState();
}

class StockPageTabState extends State<StcokPageTab> {
  int selectedPosition = 0;
  var textcolor = customColors().primary;

  @override
  Widget build(BuildContext context) {
    double width = MediaQuery.of(context).size.width;
    List<String> items = [
      "Overview",
      "Reaserch",
      "Analisys",
      "Positions",
    ];
    return Container(
      color: customColors().backgroundSecondary,
      height: widget.height,
      margin: const EdgeInsets.symmetric(vertical: 20.0),
      child: ListView.builder(
        itemCount: items.length,
        scrollDirection: Axis.horizontal,
        shrinkWrap: false,
        itemBuilder: (context, position) {
          return InkWell(
            child: Container(
              constraints: BoxConstraints(minWidth: width / items.length),
              child: Center(
                child: Padding(
                  padding: const EdgeInsets.only(left: 8, right: 8, top: 8),
                  child: Container(
                    padding: EdgeInsets.only(bottom: 18.0),
                    decoration: BoxDecoration(
                        border: Border(
                            bottom: BorderSide(
                                color: selectedPosition == position
                                    ? customColors().primary
                                    : transparent,
                                width: 1))),
                    child: Text(
                      items.elementAt(position),
                      style: customTextStyle(
                          fontStyle: FontStyle.BodyL_Regular,
                          color: selectedPosition == position
                              ? FontColor.Primary
                              : FontColor.FontSecondary),
                    ),
                  ),
                ),
              ),
            ),
            onTap: () {
              setState(() {
                selectedPosition = position;
                widget.buttonHandler(items.elementAt(selectedPosition)); //
                textcolor = customColors().primary;
              });
            },
          );
        },
      ),
    );
  }
}
