import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/repository_layer/list_data.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class AnnouncementListConatiner extends StatelessWidget {
  const AnnouncementListConatiner({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
      decoration: BoxDecoration(
          color: customColors().backgroundPrimary,
          borderRadius: BorderRadius.circular(4),
          border: Border.all(color: customColors().backgroundTertiary)),
      child: ListView.separated(
          separatorBuilder: (BuildContext context, int index) => Container(
                color: customColors().backgroundTertiary,
                height: 1,
              ),
          primary: false,
          shrinkWrap: true,
          itemCount: announcementlist.length,
          itemBuilder: (context, index) {
            return InkWell(
              child: AnnouncementListItem(
                  announcementItem: announcementlist.elementAt(index)),
              onTap: () {},
            );
          }),
    );
  }
}

class AnnouncementListItem extends StatelessWidget {
  Map<String, dynamic> announcementItem;
  AnnouncementListItem({Key? key, required this.announcementItem})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 16),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Container(
                  color: announcementItem["itemColor"],
                  padding: const EdgeInsets.all(11),
                  margin: const EdgeInsets.only(right: 15.0),
                  child: Image.asset(announcementItem["icon"])),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    announcementItem["name"],
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyL_Bold,
                        color: FontColor.FontPrimary),
                  ),
                  const SizedBox(height: 5),
                  Text(
                    announcementItem["disc"],
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyM_Regular,
                        color: FontColor.FontSecondary),
                  ),
                ],
              ),
            ],
          ),
          const SizedBox(height: 20),
          announcementItem["isAnounced"]
              ? Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        Text("Ex Date ",
                            style: customTextStyle(
                                fontStyle: FontStyle.BodyM_Regular,
                                color: FontColor.FontSecondary)),
                        Text(
                          announcementItem["expdate"],
                          style: customTextStyle(
                              fontStyle: FontStyle.BodyM_SemiBold,
                              color: FontColor.FontPrimary),
                        ),
                      ],
                    ),
                    Row(
                      children: [
                        Text("Record Date ",
                            style: customTextStyle(
                                fontStyle: FontStyle.BodyM_Regular,
                                color: FontColor.FontSecondary)),
                        Text(
                          announcementItem["recdate"],
                          style: customTextStyle(
                              fontStyle: FontStyle.BodyM_SemiBold,
                              color: FontColor.FontPrimary),
                        ),
                      ],
                    )
                  ],
                )
              : Row(
                  children: [
                    Text("Announcement  Date ",
                        style: customTextStyle(
                            fontStyle: FontStyle.BodyM_Regular,
                            color: FontColor.FontSecondary)),
                    Text(
                      announcementItem["recdate"],
                      style: customTextStyle(
                          fontStyle: FontStyle.BodyM_SemiBold,
                          color: FontColor.FontPrimary),
                    ),
                  ],
                )
        ],
      ),
    );
  }
}
