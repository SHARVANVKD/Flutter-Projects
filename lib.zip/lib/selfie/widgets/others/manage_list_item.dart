import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_watchlist/page_watchlist_edit/bloc/watchlistedit_cubit.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';
import 'package:trading_api/responses/get_cloud_watch_response.dart';

class MansageWatchListItems extends StatelessWidget {
  final List<SymbolData> items;
  final List<bool> selectedItems;

  MansageWatchListItems({required this.items, required this.selectedItems});

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<WatchlisteditCubit, WatchlisteditState>(
      builder: (context, state) {
        return ReorderableListView(
            shrinkWrap: true,
            buildDefaultDragHandles: false,
            dragStartBehavior: DragStartBehavior.down,
            children: <Widget>[
              for (var i = 0; i < items.length; i++)
                Container(
                  height: 84,
                  color: customColors().backgroundPrimary,
                  key: ValueKey(items[i]),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 20),
                      decoration: BoxDecoration(
                          border: Border(
                              bottom: BorderSide(
                                  color: customColors().backgroundTertiary))),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            children: [
                              Padding(
                                padding: const EdgeInsets.only(right: 8),
                                child: ReorderableDragStartListener(
                                  index: i,
                                  child: InkResponse(
                                      child: Image.asset("assets/reoder.png",
                                          color: customColors().fontTertiary),
                                      onTap: () {}),
                                ),
                              ),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    children: [
                                      Text(
                                        items[i].symbolname,
                                        style: TextStyle(
                                            fontFamily: "OpenSansSemiBold",
                                            fontSize: 14,
                                            color: customColors().fontPrimary),
                                      ),
                                      const SizedBox(
                                        width: 5,
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: 8),
                                  Text(
                                    items[i].venuecode,
                                    style: TextStyle(
                                        fontFamily: "OpenSansSemiBold",
                                        fontWeight: FontWeight.w400,
                                        fontSize: 12,
                                        color: customColors().fontTertiary),
                                  ),
                                ],
                              )
                            ],
                          ),
                          selectedItems[i]
                              ? InkWell(
                                  splashColor: customColors().primary,
                                  onTap: () => BlocProvider.of<
                                          WatchlisteditCubit>(context)
                                      .selectItem(index: i, selected: false),
                                  child: Image.asset("assets/checkedicon.png"),
                                )
                              : InkWell(
                                  splashColor: customColors().primary,
                                  onTap: () =>
                                      BlocProvider.of<WatchlisteditCubit>(
                                              context)
                                          .selectItem(index: i, selected: true),
                                  child:
                                      Image.asset("assets/emptycheckbox.png"))
                        ],
                      ),
                    ),
                  ),
                ),
            ],
            onReorder: BlocProvider.of<WatchlisteditCubit>(context).onReoder);
      },
    );
  }
}
