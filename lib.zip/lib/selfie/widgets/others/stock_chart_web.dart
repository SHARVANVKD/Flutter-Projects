import 'dart:io';

import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';
import 'package:webview_flutter/webview_flutter.dart';

class StockChartWeb extends StatelessWidget {
  String urlString;
  StockChartWeb({Key? key, required this.urlString}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    if (Platform.isAndroid) WebView.platform = AndroidWebView();

    return Container(
      width: MediaQuery.of(context).size.width,
      height: MediaQuery.of(context).size.height,
      decoration: BoxDecoration(color: customColors().backgroundSecondary),
      child: urlString == ""
          ? Container()
          : WebView(
              javascriptMode: JavascriptMode.unrestricted,
              initialUrl: urlString,
            ),
    );
  }
}
