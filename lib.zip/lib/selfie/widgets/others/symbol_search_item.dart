import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';
class SymbolSearchItem extends StatefulWidget {
  final String exchangeName;
  final String symbol;
  final String details;
  final Function addSymbol;
  const SymbolSearchItem({
    Key? key, 
    required this.exchangeName, 
    required this.symbol, 
    required this.details, 
    required this.addSymbol
  }) : super(key: key);

  @override
  State<SymbolSearchItem> createState() => _SymbolSearchItemState();
}

class _SymbolSearchItemState extends State<SymbolSearchItem> {
  bool selected = false;
  Color colourSelector(String exchange) {
    switch (exchange) {
      case 'NSE':
        return customColors().crisps;
      case 'BSE':
        return customColors().islandAqua;
      default:
        return customColors().mattPurple;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      alignment: Alignment.center,
      padding: const EdgeInsets.symmetric(vertical: 12),
      decoration: BoxDecoration(
          border: Border(
              bottom: BorderSide(color: customColors().backgroundTertiary))),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                widget.symbol,
                maxLines: 1,
                style: customTextStyle(
                    fontStyle: FontStyle.BodyL_SemiBold,
                    color: FontColor.FontPrimary),
              ),
              const SizedBox(height: 6),
              Row(
                children: [
                  Container(
                    alignment: Alignment.center,
                    padding:
                        const EdgeInsets.symmetric(horizontal: 7, vertical: 4),
                    decoration: BoxDecoration(
                        color: colourSelector(widget.exchangeName)
                            .withOpacity(0.15),
                        borderRadius: BorderRadius.circular(2)),
                    child: Text(widget.exchangeName,
                        maxLines: 1,
                        style: customTextStyle(
                                fontStyle: FontStyle.TagNameL_SemiBold,
                                color: FontColor.FontSecondary)
                            .copyWith(
                                color: colourSelector(widget.exchangeName))),
                  ),
                  const SizedBox(width: 6),
                  Text(widget.details,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: customTextStyle(
                          fontStyle: FontStyle.BodyS_Regular,
                          color: FontColor.FontSecondary)),
                ],
              )
            ],
          ),
           InkWell(
                  splashColor: customColors().primary,
                  onTap: (){
                    setState(() {
                      selected = !selected;
                      widget.addSymbol(selected);
                    });
                  },
                  child: Image.asset(selected
              ? "assets/checkedicon.png" : "assets/uncheckicon.png"),
                )
        ],
      ),
    );
  }
}

// class SymbolSearchItem extends StatefulWidget {
//   final String exchangeName;
//   final String symbol;
//   final String details;
//   final Function addSymbol;

//   SymbolSearchItem(
//       {required this.details,
//       required this.addSymbol,
//       required this.exchangeName,
//       required this.symbol});
//   @override
//   _SymbolSearchItemState createState() => _SymbolSearchItemState();
// }

// class _SymbolSearchItemState extends State<SymbolSearchItem> {
//   bool isChecked = false;
//   ontap() {
//     setState(() {
//       isChecked ? isChecked = false : isChecked = true;
//       widget.addSymbol(isChecked);
//     });
//   }

//   Color colourSelector(String exchange) {
//     switch (exchange) {
//       case 'NSE':
//         return customColors().crisps;
//       case 'BSE':
//         return customColors().islandAqua;
//       default:
//         return customColors().mattPurple;
//     }
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Container(
//       alignment: Alignment.center,
//       padding: const EdgeInsets.symmetric(vertical: 12),
//       decoration: BoxDecoration(
//           border: Border(
//               bottom: BorderSide(color: customColors().backgroundTertiary))),
//       child: Row(
//         mainAxisAlignment: MainAxisAlignment.spaceBetween,
//         children: [
//           Column(
//             crossAxisAlignment: CrossAxisAlignment.start,
//             children: [
//               Text(
//                 widget.symbol,
//                 maxLines: 1,
//                 style: customTextStyle(
//                     fontStyle: FontStyle.BodyL_SemiBold,
//                     color: FontColor.FontPrimary),
//               ),
//               const SizedBox(height: 6),
//               Row(
//                 children: [
//                   Container(
//                     alignment: Alignment.center,
//                     padding:
//                         const EdgeInsets.symmetric(horizontal: 7, vertical: 4),
//                     decoration: BoxDecoration(
//                         color: colourSelector(widget.exchangeName)
//                             .withOpacity(0.15),
//                         borderRadius: BorderRadius.circular(2)),
//                     child: Text(widget.exchangeName,
//                         maxLines: 1,
//                         style: customTextStyle(
//                                 fontStyle: FontStyle.TagNameL_SemiBold,
//                                 color: FontColor.FontSecondary)
//                             .copyWith(
//                                 color: colourSelector(widget.exchangeName))),
//                   ),
//                   const SizedBox(width: 6),
//                   Text(widget.details,
//                       maxLines: 1,
//                       overflow: TextOverflow.ellipsis,
//                       style: customTextStyle(
//                           fontStyle: FontStyle.BodyS_Regular,
//                           color: FontColor.FontSecondary)),
//                 ],
//               )
//             ],
//           ),
//           isChecked
//               ? InkWell(
//                   splashColor: customColors().primary,
//                   onTap: ontap,
//                   child: Image.asset("assets/checkedicon.png"),
//                 )
//               : InkWell(
//                   splashColor: customColors().primary,
//                   onTap: ontap,
//                   child: Image.asset("assets/uncheckicon.png"))
//         ],
//       ),
//     );
//   }
// }
