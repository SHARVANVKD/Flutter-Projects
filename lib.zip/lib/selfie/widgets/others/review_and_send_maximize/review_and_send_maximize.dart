import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/review_and_send_maximize/custom_qty_counter.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/review_and_send_maximize/review_and_send_maximizedbutton.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/review_and_send_maximize/textFormField.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class ReviewAndSendMaximize extends StatefulWidget {
  Function()? onRefresh;
  Function()? onDelete;
  Function()? onMinimize;

  ReviewAndSendMaximize({
    Key? key,
    this.onDelete,
    this.onMinimize,
    this.onRefresh,
  }) : super(key: key);

  @override
  State<ReviewAndSendMaximize> createState() => _ReviewAndSendMaximizeState();
}

class _ReviewAndSendMaximizeState extends State<ReviewAndSendMaximize>
    with TickerProviderStateMixin {
  TextStyle detailStyle = customTextStyle(
    fontStyle: FontStyle.BodyM_Regular,
    color: FontColor.FontSecondary,
  );

  TextStyle labelStyle = customTextStyle(
    fontStyle: FontStyle.TagNameL_SemiBold,
    color: FontColor.FontSecondary,
  );

  // TextEditingController _textfieldcontroller =
  final List<TextEditingController> _controllers = [];

  bool maximize = false;

  AnimationController? _controller;
  late Animation<double> _animation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(milliseconds: 300),
      vsync: this,
    );
    _animation = CurvedAnimation(
      parent: _controller!,
      curve: Curves.easeInOutQuad,
    );
  }

  _toggleContainer() {
    if (_animation.status != AnimationStatus.completed) {
      _controller!.forward();
    } else {
      _controller!.animateBack(0, duration: Duration(milliseconds: 300));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 9),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              maximize
                  ? const SizedBox()
                  : Text(
                      "2 Option legs added",
                      style: customTextStyle(
                          fontStyle: FontStyle.TagNameL_SemiBold,
                          color: FontColor.Info),
                    ),
              SizedBox(height: maximize ? 0 : 8),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      maximize
                          ? const SizedBox()
                          : RichText(
                              text: TextSpan(
                                text: 'Net Premium: ',
                                style: customTextStyle(
                                  fontStyle: FontStyle.BodyL_Regular,
                                  color: FontColor.FontSecondary,
                                ),
                                children: [
                                  TextSpan(
                                    text: '1,00,000',
                                    style: customTextStyle(
                                      fontStyle: FontStyle.BodyL_SemiBold,
                                      color: FontColor.FontPrimary,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                      Visibility(
                        visible: maximize,
                        child: Text(
                          'Order Details',
                          style: customTextStyle(
                            fontStyle: FontStyle.HeaderXS_SemiBold,
                            color: FontColor.FontPrimary,
                          ),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 10),
                        child: InkWell(
                          onTap: widget.onRefresh,
                          child: Image.asset(
                            "assets/refresh.png",
                            height: 20,
                            width: 20,
                          ),
                        ),
                      ),
                    ],
                  ),
                  Row(
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(right: 22),
                        child: InkWell(
                          onTap: widget.onDelete,
                          child: Image.asset(
                            "assets/delete.png",
                            height: 24,
                            width: 24,
                          ),
                        ),
                      ),
                      InkWell(
                        onTap: () {
                          setState(() {
                            maximize = !maximize;
                            _toggleContainer();
                          });
                        },
                        child: Container(
                          height: 32,
                          width: 32,
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(4),
                              border: Border.all(
                                color: customColors().backgroundTertiary,
                              )),
                          child: Image.asset(
                            "assets/maximize.png",
                            color: customColors().fontPrimary,
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
              SizedBox(height: maximize ? 0 : 8),
            ],
          ),
        ),
        Visibility(
          visible: maximize,
          child: Divider(
            thickness: 1.0,
            color: customColors().backgroundTertiary,
          ),
        ),
        SizeTransition(
          sizeFactor: _animation,
          axis: Axis.vertical,
          child: Visibility(
            visible: maximize,
            child: Column(
              children: [
                details(
                  context: context,
                  maxProfit: "24,300",
                  maxLoss: "Unlimited",
                  marginEffect: "1,66,981",
                ),
                Container(
                  height: 32,
                  color: customColors().backgroundSecondary,
                  child: Padding(
                    padding: const EdgeInsets.only(
                      left: 16,
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Text(
                          "STRIKE",
                          style: labelStyle,
                        ),
                        SizedBox(
                          width: MediaQuery.of(context).size.width * 0.29,
                        ),
                        Text(
                          "PRICE",
                          style: labelStyle,
                        ),
                        SizedBox(
                          width: MediaQuery.of(context).size.width * 0.2,
                        ),
                        Row(
                          children: [
                            Text(
                              "LOTS",
                              style: labelStyle,
                            ),
                          ],
                        )
                      ],
                    ),
                  ),
                ),
                ListView.builder(
                    physics: const NeverScrollableScrollPhysics(),
                    itemCount: 4,
                    shrinkWrap: true,
                    itemBuilder: (context, index) {
                      _controllers.add(TextEditingController(text: "123.45"));
                      return Padding(
                        padding: const EdgeInsets.symmetric(
                            vertical: 12, horizontal: 16),
                        child: Row(
                          children: [
                            Row(
                              children: [
                                Container(
                                  height: 36,
                                  width: 2,
                                  color: index == 1 || index == 0
                                      ? green200
                                      : red200,
                                ),
                                const Padding(
                                  padding: EdgeInsets.only(
                                    left: 17,
                                  ),
                                  child: Text("16400 CE"),
                                )
                              ],
                            ),
                            Row(
                              children: [
                                Padding(
                                  padding: const EdgeInsets.only(
                                      left: 68, right: 30),
                                  child: SizedBox(
                                    width: 75,
                                    height: 36,
                                    child: QtyTextFormField(
                                      keyboardType: TextInputType.number,
                                      labelBottomPadding: 0,
                                      controller: _controllers[index],
                                      fieldName: "",
                                      bordercolor:
                                          customColors().backgroundTertiary,
                                    ),
                                  ),
                                ),
                                CustomQuantityCounter(),
                              ],
                            )
                          ],
                        ),
                      );
                    }),
                ReviewAndSendFixedButton(
                  elevation: true,
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget details({
    required BuildContext context,
    required String maxProfit,
    required String maxLoss,
    required String marginEffect,
  }) =>
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Max Profit",
                  style: detailStyle,
                ),
                const SizedBox(
                  height: 4,
                ),
                Text(
                  maxProfit,
                  style: customTextStyle(
                    fontStyle: FontStyle.BodyL_Bold,
                    color: FontColor.Success,
                  ),
                )
              ],
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Max Loss",
                  style: detailStyle,
                ),
                const SizedBox(
                  height: 4,
                ),
                Text(
                  maxLoss,
                  style: customTextStyle(
                    fontStyle: FontStyle.BodyL_Bold,
                    color: FontColor.Danger,
                  ),
                )
              ],
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Margin Effect",
                  style: detailStyle,
                ),
                const SizedBox(
                  height: 4,
                ),
                Text(
                  marginEffect,
                  style: customTextStyle(
                    fontStyle: FontStyle.BodyL_Bold,
                    color: FontColor.FontPrimary,
                  ),
                )
              ],
            )
          ],
        ),
      );
}
