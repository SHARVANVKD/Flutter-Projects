import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class CustomQuantityCounter extends StatefulWidget {
  CustomQuantityCounter({Key? key}) : super(key: key);

  @override
  State<CustomQuantityCounter> createState() => _CustomQuantityCounterState();
}

class _CustomQuantityCounterState extends State<CustomQuantityCounter> {
  int counter = 1;
  bool minimumCounter = true;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 36,
      width: 105,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(4),
        border: Border.all(
          color: customColors().backgroundTertiary,
        ),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(4, 4, 0, 4),
            child: InkWell(
              onTap: () {
                if (counter == 1) {
                  setState(() {
                    counter = 1;
                  });
                } else {
                  setState(() {
                    counter--;
                  });
                }
              },
              child: Container(
                height: 28,
                width: 28,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(4),
                  color: customColors().backgroundSecondary,
                ),
                child: Image.asset(
                  "assets/line.png",
                  color: counter == 1
                      ? customColors().fontTertiary
                      : customColors().fontPrimary,
                ),
              ),
            ),
          ),
          Text(
            counter.toString(),
            style: customTextStyle(
                fontStyle: FontStyle.BodyM_SemiBold,
                color: FontColor.FontPrimary),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(0, 4, 4, 4),
            child: InkWell(
              onTap: () {
                setState(() {
                  minimumCounter = false;
                  counter++;
                });
              },
              child: Container(
                height: 28,
                width: 28,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(4),
                  color: customColors().backgroundSecondary,
                ),
                child: Image.asset(
                  "assets/plus.png",
                ),
              ),
            ),
          )
        ],
      ),
    );
  }
}
