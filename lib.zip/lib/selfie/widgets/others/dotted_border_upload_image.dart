import 'package:dotted_border/dotted_border.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class DottedBorderUploadImage extends StatefulWidget {
  DottedBorderUploadImage({
    Key? key,
  }) : super(key: key);

  @override
  State<DottedBorderUploadImage> createState() =>
      _DottedBorderUploadImageState();
}

class _DottedBorderUploadImageState extends State<DottedBorderUploadImage> {
  final ImagePicker imagePicker = ImagePicker();

  List<XFile>? imageFileList = [];

  void selectImages() async {
    final List<XFile>? selectedImages = await imagePicker.pickMultiImage();
    if (selectedImages!.isNotEmpty) {
      imageFileList!.addAll(selectedImages);
    }
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return DottedBorder(
      dashPattern: const [6, 4],
      strokeWidth: 0.7,
      color: customColors().secretGarden,
      borderType: BorderType.RRect,
      radius: const Radius.circular(4),
      child: ClipRRect(
        borderRadius: const BorderRadius.all(Radius.circular(4)),
        child: Container(
          height: 70,
          width: MediaQuery.of(context).size.width,
          color: customColors().backgroundSecondary,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Upload Reference Images",
                      style: customTextStyle(
                          fontStyle: FontStyle.BodyL_SemiBold,
                          color: FontColor.FontPrimary),
                    ),
                    const SizedBox(
                      height: 4,
                    ),
                    Text(
                      "Image size limit - 1 MB",
                      style: customTextStyle(
                          fontStyle: FontStyle.BodyS_Regular,
                          color: FontColor.FontSecondary),
                    ),
                  ],
                ),
                InkWell(
                  onTap: () {
                    selectImages();
                  },
                  child: Container(
                    height: 36,
                    width: 83,
                    decoration: BoxDecoration(
                        color: customColors().primary,
                        borderRadius: BorderRadius.circular(4.0)),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          "Upload",
                          style: customTextStyle(
                              fontStyle: FontStyle.BodyL_Bold,
                              color: FontColor.White),
                        )
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
