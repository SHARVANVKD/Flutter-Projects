import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/order_book/custom_bottom_strip.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/options_widget.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/orders_smartfolio_sheet/smartFolio_fixed_button.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class SmartFolioSheet extends StatefulWidget {
  const SmartFolioSheet({Key? key}) : super(key: key);

  @override
  State<SmartFolioSheet> createState() => _SmartFolioSheetState();
}

class _SmartFolioSheetState extends State<SmartFolioSheet> {
  List<Map<String, dynamic>> items = [
    {
      "name": "HDFCBANK",
      "orderType": "BUY",
      "orderType_color": FontColor.SecretGarden,
      "orderType_backgroundColor": customColors().secretGarden.withOpacity(.15),
      "QUANTITY": 230,
      "Ltp": "1,452.98",
      "no_of_days_back": 3,
      "date": "22/03/22",
    },
    {
      "name": "ITC",
      "orderType": "SELL",
      "orderType_color": FontColor.CarnationRed,
      "orderType_backgroundColor": customColors().carnationRed.withOpacity(.15),
      "QUANTITY": 50,
      "Ltp": "1,452.98",
      "no_of_days_back": 9,
      "date": "15/03/22",
    },
    {
      "name": "SUZLON",
      "orderType": "SELL",
      "orderType_color": FontColor.CarnationRed,
      "orderType_backgroundColor": customColors().carnationRed.withOpacity(.15),
      "QUANTITY": 100,
      "avg": 300.12,
      "Ltp": "1,452.98",
      "no_of_days_back": 3,
      "date": "13/03/22",
    },
  ];
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Padding(
          padding:
              const EdgeInsets.only(left: 16, right: 16, top: 6, bottom: 12),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Image.asset(
                "assets/ace.png",
                height: 32,
                width: 32,
              ),
              const SizedBox(width: 8),
              Text(
                "Ace",
                style: customTextStyle(
                  fontStyle: FontStyle.HeaderXS_Bold,
                  color: FontColor.FontPrimary,
                ),
              ),
            ],
          ),
        ),
        Divider(
          height: 0,
          thickness: 1,
          color: customColors().backgroundTertiary,
        ),
        Column(
          children: [
            for (int i = 0; i < items.length; i++)
              Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.symmetric(
                        vertical: 16, horizontal: 16),
                    child: Column(
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                Text(
                                  items[i]["name"],
                                  style: customTextStyle(
                                    fontStyle: FontStyle.BodyL_SemiBold,
                                    color: FontColor.FontPrimary,
                                  ),
                                ),
                                const SizedBox(width: 6),
                                // Container(
                                //   padding: const EdgeInsets.only(
                                //       left: 7.0,
                                //       right: 7.0,
                                //       top: 2.0,
                                //       bottom: 3.0),
                                //   decoration: BoxDecoration(
                                //     color: items[i]
                                //         ["orderType_backgroundColor"],
                                //     borderRadius: const BorderRadius.all(
                                //         Radius.circular(2)),
                                //   ),
                                //   child: Center(
                                //     child: Text(
                                //       items[i]["orderType"],
                                //       textAlign: TextAlign.start,
                                //       style: customTextStyle(
                                //         fontStyle: FontStyle.TagNameS_SemiBold,
                                //         color: items[i]["orderType_color"],
                                //       ),
                                //     ),
                                //   ),
                                // )
                                getProductTypeWidget(
                                  items[i]["orderType"],
                                ),
                              ],
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                Text(
                                  "LTP",
                                  style: customTextStyle(
                                    fontStyle: FontStyle.BodyL_Regular,
                                    color: FontColor.FontSecondary,
                                  ),
                                ),
                                const SizedBox(
                                  width: 8,
                                ),
                                Text(
                                  items[i]["Ltp"],
                                  style: customTextStyle(
                                    fontStyle: FontStyle.BodyL_SemiBold,
                                    color: FontColor.FontPrimary,
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                        const SizedBox(
                          height: 6,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                Text(
                                  items[i]["QUANTITY"].toString(),
                                  style: customTextStyle(
                                    fontStyle: FontStyle.BodyM_SemiBold,
                                    color: FontColor.FontSecondary,
                                  ),
                                ),
                                const SizedBox(width: 2),
                                Text(
                                  "Qty",
                                  style: customTextStyle(
                                    fontStyle: FontStyle.BodyM_Regular,
                                    color: FontColor.FontTertiary,
                                  ),
                                )
                              ],
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                RichText(
                                  text: TextSpan(
                                    text:
                                        items[i]["no_of_days_back"].toString(),
                                    style: customTextStyle(
                                        fontStyle: FontStyle.BodyM_SemiBold,
                                        color: FontColor.FontTertiary),
                                    children: <TextSpan>[
                                      TextSpan(
                                        text: ' days back',
                                        style: customTextStyle(
                                            fontStyle: FontStyle.BodyM_Regular,
                                            color: FontColor.FontTertiary),
                                      )
                                    ],
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(
                                      left: 8, right: 8, bottom: 3),
                                  child: Container(
                                    height: 4,
                                    width: 4,
                                    decoration: BoxDecoration(
                                        color: customColors().fontTertiary,
                                        shape: BoxShape.circle),
                                  ),
                                ),
                                Text(
                                  items[i]["date"].toString(),
                                  style: customTextStyle(
                                    fontStyle: FontStyle.BodyM_SemiBold,
                                    color: FontColor.FontSecondary,
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  i == items.length - 1
                      ? const SizedBox()
                      : Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 16),
                          child: Divider(
                            height: 0,
                            thickness: 1,
                            color: customColors().backgroundTertiary,
                          ),
                        ),
                ],
              ),
          ],
        ),
        const CustomBottomStrip(
          fundOrMargin: FundOrMargin.FUND,
          required: "15,000",
          available: "21,000",
        ),
        SmartFolioFixedButton(
          elevation: true,
        ),
      ],
    );
  }
}
