import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/buttons/BasketButton.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class SmartFolioFixedButton extends StatelessWidget {
  bool elevation;
   SmartFolioFixedButton({ Key? key,this.elevation = false, }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
        decoration: BoxDecoration(
          border: elevation
              ? Border(
                  top: BorderSide(color: customColors().backgroundTertiary),
                )
              : null,
        ),
        // height: MediaQuery.of(context).size.height * 0.17,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          child: Row(
            children: [
              Expanded(
                child: BasketButton(
                  bordercolor: customColors().green4,
                  text: "Open Smartfolio",
                  textStyle: customTextStyle(
                      fontStyle: FontStyle.BodyL_Bold,
                      color: FontColor.Primary),
                  onpress: () {
                    Navigator.of(context).pop(true);
                  },
                ),
              ),
              const SizedBox(
                width: 8,
              ),
              Expanded(
                child: BasketButton(
                  bordercolor: transparent,
                  bgcolor: customColors().primary,
                  text: "Accept Orders",
                  textStyle: customTextStyle(
                      fontStyle: FontStyle.BodyL_Bold, color: FontColor.White),
                  onpress: () {
                    Navigator.of(context).pop(true);
                  },
                ),
              )
            ],
          ),
        ));
  }
}