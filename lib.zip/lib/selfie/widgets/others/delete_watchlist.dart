import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/constants/enums.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/buttons/BasketButton.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class WatchListAction extends StatelessWidget {
  Enum actionType;
  final Function() negativeOnPres;
  final Function() positiveOnPress;
  WatchListAction(
      {Key? key,
      required this.positiveOnPress,
      required this.negativeOnPres,
      required this.actionType})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return actionType == ActionType.delete
        ? deleteWatchlist(context)
        : saveWatchlist(context);
  }

  Padding deleteWatchlist(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 16, right: 16, bottom: 9),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.only(top: 20),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Image.asset(
                  "assets/caution.png",
                  height: 24,
                ),
                const SizedBox(
                  width: 10,
                ),
                Text(
                  "Delete Watchlist?",
                  style: customTextStyle(
                      fontStyle: FontStyle.HeaderS_SemiBold,
                      color: FontColor.FontPrimary),
                )
              ],
            ),
          ),
          SizedBox(height: MediaQuery.of(context).size.height / 35),
          Text(
            "By continuing, you will delete your watchlist ",
            style: customTextStyle(
                fontStyle: FontStyle.BodyL_SemiBold,
                color: FontColor.FontSecondary),
          ),
          const SizedBox(height: 3),
          Text(
            "“My Watchlist 1”",
            style: customTextStyle(
                fontStyle: FontStyle.BodyL_SemiBold,
                color: FontColor.FontSecondary),
          ),
          SizedBox(height: MediaQuery.of(context).size.height / 30),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Expanded(
                child: BasketButton(
                  bordercolor: customColors().primary,
                  text: "Delete",
                  textStyle: customTextStyle(
                      fontStyle: FontStyle.BodyL_SemiBold,
                      color: FontColor.Primary),
                  onpress: negativeOnPres,
                ),
              ),
              const SizedBox(
                width: 8,
              ),
              Expanded(
                child: BasketButton(
                  bordercolor: transparent,
                  bgcolor: customColors().primary,
                  text: "Cancel",
                  textStyle: customTextStyle(
                    fontStyle: FontStyle.BodyL_SemiBold,
                    color: FontColor.White,
                  ),
                  onpress: positiveOnPress,
                ),
              )
            ],
          ),
        ],
      ),
    );
  }

  Padding saveWatchlist(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 16, right: 16, bottom: 9),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.only(top: 20),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Image.asset(
                  "assets/caution.png",
                  height: 24,
                ),
                const SizedBox(
                  width: 10,
                ),
                Text(
                  "Unsaved changes",
                  style: customTextStyle(
                      fontStyle: FontStyle.HeaderS_SemiBold,
                      color: FontColor.FontPrimary),
                )
              ],
            ),
          ),
          SizedBox(height: MediaQuery.of(context).size.height / 35),
          Text(
            "There are unsaved changes on this page. Do you want to discard the changes and close the page?",
            style: customTextStyle(
                fontStyle: FontStyle.BodyL_SemiBold,
                color: FontColor.FontSecondary),
          ),
          SizedBox(height: MediaQuery.of(context).size.height / 30),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Expanded(
                child: BasketButton(
                  bordercolor: customColors().primary,
                  text: "Discard",
                  textStyle: customTextStyle(
                      fontStyle: FontStyle.BodyL_SemiBold,
                      color: FontColor.Primary),
                  onpress: negativeOnPres,
                ),
              ),
              const SizedBox(
                width: 8,
              ),
              Expanded(
                child: BasketButton(
                  bordercolor: transparent,
                  bgcolor: customColors().primary,
                  text: "Save",
                  textStyle: customTextStyle(
                    fontStyle: FontStyle.BodyL_SemiBold,
                    color: FontColor.White,
                  ),
                  onpress: positiveOnPress,
                ),
              )
            ],
          ),
        ],
      ),
    );
  }
}
