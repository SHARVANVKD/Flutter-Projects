import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

Widget getProductTypeWidget(String value) {
  switch (value.toUpperCase()) {
    case "":
      return SizedBox();
    case "CASH":
      return ProductTypeWidget(
          text: value.toUpperCase(),
          textColor: FontColor.PacificBlue,
          boxColor: customColors().info);
    case "BTST":
      return ProductTypeWidget(
          text: value.toUpperCase(),
          textColor: FontColor.Ultraviolet,
          boxColor: customColors().ultraviolet);
    case "INTRADAY":
      return ProductTypeWidget(
          text: value.toUpperCase(),
          textColor: FontColor.PacificBlue,
          boxColor: customColors().pacificBlue);
    case "MTF":
      return ProductTypeWidget(
          text: value.toUpperCase(),
          textColor: FontColor.Purple,
          boxColor: customColors().mattPurple);
    case "SMARTFOLIO":
      return ProductTypeWidget(
          text: value.toUpperCase(),
          textColor: FontColor.Ultraviolet,
          boxColor: customColors().ultraviolet);
    case "BUY":
      return ProductTypeWidget(
          text: value.toUpperCase(),
          textColor: FontColor.SecretGarden,
          boxColor: customColors().success);
    case "SELL":
      return ProductTypeWidget(
          text: value.toUpperCase(),
          textColor: FontColor.CarnationRed,
          boxColor: customColors().danger);
    case "NSE":
      return ProductTypeWidget(
          text: value.toUpperCase(),
          textColor: FontColor.Purple,
          boxColor: customColors().mattPurple);
    case "BSE":
      return ProductTypeWidget(
          text: value.toUpperCase(),
          textColor: FontColor.Ultraviolet,
          boxColor: customColors().ultraviolet);
    case "NFO":
      return ProductTypeWidget(
          text: value.toUpperCase(),
          textColor: FontColor.PacificBlue,
          boxColor: customColors().pacificBlue);
    case "NSECD":
      return ProductTypeWidget(
          text: value.toUpperCase(),
          textColor: FontColor.Purple,
          boxColor: customColors().mattPurple);
    case "NSEMF":
      return ProductTypeWidget(
          text: value.toUpperCase(),
          textColor: FontColor.Ultraviolet,
          boxColor: customColors().ultraviolet);
    case "MF":
      return ProductTypeWidget(
          text: value.toUpperCase(),
          textColor: FontColor.Purple,
          boxColor: customColors().mattPurple);
    case "BFO":
      return ProductTypeWidget(
          text: value.toUpperCase(),
          textColor: FontColor.DodgerBlue,
          boxColor: customColors().dodgerBlue);
    case "MCX":
      return ProductTypeWidget(
          text: value.toUpperCase(),
          textColor: FontColor.Crisps,
          boxColor: customColors().crisps);
    case "CDS":
      return ProductTypeWidget(
          text: value.toUpperCase(),
          textColor: FontColor.Purple,
          boxColor: customColors().mattPurple);
    case "DEFAULT":
      return ProductTypeWidget(
          text: value.toUpperCase(),
          textColor: FontColor.DodgerBlue,
          boxColor: customColors().dodgerBlue);
    case "BONUS":
      return ProductTypeWidget(
          text: value.toUpperCase(),
          textColor: FontColor.Purple,
          boxColor: customColors().mattPurple);
    case "DIVIDENT":
      return ProductTypeWidget(
          text: value.toUpperCase(),
          textColor: FontColor.Crisps,
          boxColor: customColors().crisps);
    case "HOLD":
      return ProductTypeWidget(
          text: value.toUpperCase(),
          textColor: FontColor.SilverDust,
          boxColor: customColors().silverDust);
    case "SPLIT":
      return ProductTypeWidget(
          text: value.toUpperCase(),
          textColor: FontColor.PacificBlue,
          boxColor: customColors().pacificBlue);
    case "INDEX":
      return ProductTypeWidget(
          text: value.toUpperCase(),
          textColor: FontColor.FontSecondary,
          boxColor: customColors().silverDust);
    case "BULK":
      return ProductTypeWidget(
          text: value.toUpperCase(),
          textColor: FontColor.Purple,
          boxColor: customColors().mattPurple);
    case "BLOCK":
      return ProductTypeWidget(
          text: value.toUpperCase(),
          textColor: FontColor.DodgerBlue,
          boxColor: customColors().dodgerBlue);
    case "POSITIVE":
      return ProductTypeWidget(
          text: value.toUpperCase(),
          textColor: FontColor.SecretGarden,
          boxColor: customColors().success);
    case "NEGATIVE":
      return ProductTypeWidget(
          text: value.toUpperCase(),
          textColor: FontColor.CarnationRed,
          boxColor: customColors().danger);
    case "NUETRAL":
      return ProductTypeWidget(
          text: value.toUpperCase(),
          textColor: FontColor.FontSecondary,
          boxColor: customColors().silverDust);
    case "MY GEOJIT":
      return ProductTypeWidget(
          text: value.toUpperCase(),
          textColor: FontColor.Purple,
          boxColor: customColors().mattPurple);
    case "SELFIE APP":
      return ProductTypeWidget(
          text: value.toUpperCase(),
          textColor: FontColor.Crisps,
          boxColor: customColors().crisps);
    case "BOUGHT":
      return ProductTypeWidget(
          text: value.toUpperCase(),
          textColor: FontColor.SecretGarden,
          boxColor: Color.fromRGBO(25, 175, 85, 0.15));

    case "SOLD":
      return ProductTypeWidget(
          text: value.toUpperCase(),
          textColor: FontColor.CarnationRed,
          boxColor: Color.fromRGBO(255, 59, 48, 0.15));

    case "UPCOMING":
      return ProductTypeWidget(
          text: value.toUpperCase(),
          textColor: FontColor.SecretGarden,
          boxColor: Color.fromRGBO(25, 175, 85, 0.15));

    case "ANNOUNCEMENTS":
      return ProductTypeWidget(
          text: value.toUpperCase(),
          textColor: FontColor.MattPurple,
          boxColor: Color.fromRGBO(151, 104, 225, 0.15));

    // case "BONUS":
    //   return ProductTypeWidget(
    //       text: "Bonus".toUpperCase(),
    //       textColor: FontColor.Crisps,
    //       boxColor: Color.fromRGBO(231, 166, 64, 0.15));

    case "CLOSED":
      return ProductTypeWidget(
          text: value.toUpperCase(),
          textColor: FontColor.CarnationRed,
          boxColor: customColors().carnationRed.withOpacity(0.15));

    case "OPEN":
      return ProductTypeWidget(
          text: value.toUpperCase(),
          textColor: FontColor.Success,
          boxColor: Color.fromRGBO(25, 175, 85, 0.15));

    // case "UPcoming":
    // return ProductTypeWidget(
    // text: "UPcoming".toUpperCase(),
    // textColor: FontColor.DodgerBlue,
    // boxColor: Color.fromRGBO(59, 124, 243, 1));

    default:
      return ProductTypeWidget(
          text: value.toUpperCase(),
          textColor: FontColor.DodgerBlue,
          boxColor: customColors().dodgerBlue);
  }
}

class ProductTypeWidget extends StatelessWidget {
  final String text;
  final FontColor textColor;
  final Color boxColor;
  const ProductTypeWidget(
      {Key? key,
      required this.text,
      required this.textColor,
      required this.boxColor})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return FittedBox(
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 7.0, vertical: 4.0),
        decoration: BoxDecoration(
          color: boxColor.withOpacity(0.15),
          borderRadius: BorderRadius.circular(2),
        ),
        child: Center(
            child: Text(
          "$text",
          textAlign: TextAlign.center,
          style: customTextStyle(
              fontStyle: FontStyle.TagNameS_SemiBold, color: textColor),
        )),
      ),
    );
  }
}

// Widget getOrderTypeWidget(String value) {
//   switch (value.toUpperCase()) {
//     case "BUY":
//       return OrderTypeWiget(
//           text: "BUY",
//           textColor: FontColor.SecretGarden,
//           boxColor: customColors().success);
//     case "SELL":
//       return OrderTypeWiget(
//           text: "SELL",
//           textColor: FontColor.CarnationRed,
//           boxColor: customColors().danger);

//     default:
//       return OrderTypeWiget(
//           text: "BUY",
//           textColor: FontColor.SecretGarden,
//           boxColor: customColors().danger);
//   }
// }

// class OrderTypeWiget extends StatelessWidget {
//   final String text;
//   final FontColor textColor;
//   final Color boxColor;
//   const OrderTypeWiget(
//       {Key? key,
//       required this.text,
//       required this.textColor,
//       required this.boxColor})
//       : super(key: key);

//   @override
//   Widget build(BuildContext context) {
//     return Container(
//       padding: const EdgeInsets.symmetric(horizontal: 7.0, vertical: 4.0),
//       decoration: BoxDecoration(
//         color: boxColor.withOpacity(0.15),
//         borderRadius: BorderRadius.circular(2),
//       ),
//       child: Center(
//           child: Text(
//         "$text",
//         textAlign: TextAlign.center,
//         style: customTextStyle(
//             fontStyle: FontStyle.TagNameS_SemiBold, color: textColor),
//       )),
//     );
//   }
// }

Widget getOrderStatusWidget(String value) {
  switch (value.toUpperCase()) {
    case "ACTIVE":
      return const OrderStatusWidget(
          text: "ACTIVE", textColor: FontColor.Success);
    case "CONFIRMED":
      return const OrderStatusWidget(
          text: "CONFIRMED", textColor: FontColor.Success);
    case "UPCOMING":
      return const OrderStatusWidget(
          text: "UPCOMING", textColor: FontColor.Success);
    case "PENDING":
      return const OrderStatusWidget(
          text: "PENDING", textColor: FontColor.Warning);
    case "SAVED":
      return const OrderStatusWidget(text: "SAVED", textColor: FontColor.Info);
    case "EXECUTED":
      return const OrderStatusWidget(
          text: "EXECUTED", textColor: FontColor.Success);
    case "REJECTED":
      return const OrderStatusWidget(
          text: "REJECTED", textColor: FontColor.Danger);
    case "CANCELLED":
      return const OrderStatusWidget(
          text: "CANCELLED", textColor: FontColor.Danger);
    case "PEXE":
      return const OrderStatusWidget(
          text: "PEXE", textColor: FontColor.Warning);
    case "RECEIVED":
      return const OrderStatusWidget(
          text: "RECEIVED", textColor: FontColor.Info);
    default:
      return OrderStatusWidget(
          text: value.toUpperCase(), textColor: FontColor.Success);
  }
}

class OrderStatusWidget extends StatelessWidget {
  final String text;
  final FontColor textColor;
  const OrderStatusWidget(
      {Key? key, required this.text, required this.textColor})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Text(
      "$text",
      style: customTextStyle(
          fontStyle: FontStyle.BodyS_SemiBold, color: textColor),
    );
  }
}

// Widget getExchangeWidget(String value) {
//   switch (value.toUpperCase()) {
//     case "NSE":
//       return ExchangeWidget(
//           text: "NSE",
//           textColor: FontColor.Crisps,
//           boxColor: customColors().crisps);
//     case "BSE":
//       return ExchangeWidget(
//           text: "BSE",
//           textColor: FontColor.Ultraviolet,
//           boxColor: customColors().ultraviolet);
//     case "NFO":
//       return ExchangeWidget(
//           text: "NFO",
//           textColor: FontColor.PacificBlue,
//           boxColor: customColors().pacificBlue);
//     case "NSECD":
//       return ExchangeWidget(
//           text: "NSECD",
//           textColor: FontColor.Purple,
//           boxColor: customColors().mattPurple);
//     case "NSEMF":
//       return ExchangeWidget(
//           text: "SMARTFOLIO",
//           textColor: FontColor.Ultraviolet,
//           boxColor: customColors().ultraviolet);
//     default:
//       return ExchangeWidget(
//           text: "NSE",
//           textColor: FontColor.PacificBlue,
//           boxColor: customColors().info);
//   }
// }

// class ExchangeWidget extends StatelessWidget {
//   final String text;
//   final FontColor textColor;
//   final Color boxColor;
//   const ExchangeWidget(
//       {Key? key,
//       required this.text,
//       required this.textColor,
//       required this.boxColor})
//       : super(key: key);

//   @override
//   Widget build(BuildContext context) {
//     return Container(
//       padding: const EdgeInsets.symmetric(horizontal: 7.0, vertical: 4.0),
//       decoration: BoxDecoration(
//         color: boxColor.withOpacity(0.15),
//         borderRadius: BorderRadius.circular(2),
//       ),
//       child: Center(
//           child: Text(
//         "$text",
//         textAlign: TextAlign.center,
//         style: customTextStyle(
//             fontStyle: FontStyle.TagNameS_SemiBold, color: textColor),
//       )),
//     );
//   }
// }