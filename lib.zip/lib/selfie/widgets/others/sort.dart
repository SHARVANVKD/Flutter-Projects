import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/constants/enums.dart';
import 'package:selfie_mobile_flutter/selfie/repository_layer/portfolio_content.dart';
import 'package:selfie_mobile_flutter/selfie/repository_layer/watchlist_content.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/custom_radio_button.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class SortList extends StatefulWidget {
  final Function(int)? onchange_effect;
  int? currentindex;
  VoidCallback onresetPress;
  SortList(
      {Key? key,
      this.onchange_effect,
      this.currentindex,
      required this.onresetPress})
      : super(key: key);

  @override
  State<SortList> createState() => _SortListState();
}

class _SortListState extends State<SortList> {
  List<String> sortchecklist = [
    'A - Z',
    'Z - A',
    'Price: Low - High',
    'Price: High - Low',
    '% Change: Low - High',
    '% Change: High - Low',
  ];

  @override
  Widget build(BuildContext context) {
    return StatefulBuilder(
      builder: (context, StateSetter setState) => Column(
        children: [
          Padding(
            padding:
                const EdgeInsets.only(left: 12, right: 12, top: 12, bottom: 8),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  "Sort",
                  style: customTextStyle(
                    fontStyle: FontStyle.HeaderXS_SemiBold,
                    color: FontColor.FontPrimary,
                  ),
                ),
                InkWell(
                  onTap: widget.onresetPress,
                  child: Text(
                    "Reset",
                    style: customTextStyle(
                      fontStyle: FontStyle.BodyL_SemiBold,
                      color: FontColor.Primary,
                    ),
                  ),
                ),
              ],
            ),
          ),
          Divider(
            height: 0,
            thickness: 1,
            color: customColors().backgroundTertiary,
          ),
          Padding(
            padding: const EdgeInsets.only(left: 10),
            child: Column(
              children: [
                ListView.builder(
                    shrinkWrap: true,
                    itemCount: sortchecklist.length,
                    itemBuilder: (context, index) {
                      return MyRadioListTile<int>(
                        value: index,
                        groupValue: currentindex,
                        title: Text(
                          sortchecklist[index],
                          style: customTextStyle(
                            fontStyle: FontStyle.BodyL_Regular,
                            color: FontColor.FontPrimary,
                          ),
                        ),
                        onChanged: (value) {
                          setState(() {
                            currentindex = value!;
                            widget.onchange_effect!(value);
                          });
                        },
                      );
                    })
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class PortfolioSortList extends StatefulWidget {
  SortFilterLocation selectedLocation;
  int selectedTabIndex;
  List<String>? filterlist;
  final void Function(List<String>) onPressFilter;
  final void Function(int index) onPressSort;
  final void Function() onPressReset;
  int currentval;
  PortfolioSortList(
      {Key? key,
      this.selectedTabIndex = 0,
      required this.selectedLocation,
      required this.onPressFilter,
      required this.onPressReset,
      required this.onPressSort,
      required this.currentval,
      this.filterlist})
      : super(key: key);

  @override
  State<PortfolioSortList> createState() => _PortfolioSortListState();
}

class _PortfolioSortListState extends State<PortfolioSortList>
    with SingleTickerProviderStateMixin {
  final List<Tab> myTabs = <Tab>[
    new Tab(text: 'Filter'),
    new Tab(text: 'Sort'),
  ];
  int selectedTabIndex = 0;
  List<Widget> tabbarViewHoldingList = [];
  List<Widget> tabbarViewPositionList = [];
  late TabController _tabController =
      new TabController(length: myTabs.length, vsync: this);

  @override
  void initState() {
    super.initState();
    setState(() {
      _tabController.index = widget.selectedTabIndex;
      selectedTabIndex = widget.selectedTabIndex;
    });
  }

  @override
  Widget build(BuildContext context) {
    tabbarViewHoldingList = [
      HoldingFilterWidget(
        onPressFilter: widget.onPressFilter,
      ),
      SortWidget(
        onfilterpress: widget.onPressSort,
        currentval: widget.currentval,
      )
    ];
    tabbarViewPositionList = [
      FilterWidget(
        onfilterpress: widget.onPressFilter,
      ),
      SortWidget(
        onfilterpress: widget.onPressSort,
        currentval: widget.currentval,
      )
    ];

    return DefaultTabController(
        length: myTabs.length,
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  child: TabBar(
                      controller: _tabController,
                      isScrollable: true,
                      indicatorPadding:
                          EdgeInsets.symmetric(horizontal: 16, vertical: 0),
                      onTap: (index) {
                        setState(() {
                          selectedTabIndex = index;
                        });
                      },
                      unselectedLabelStyle: customTextStyle(
                          fontStyle: FontStyle.BodyL_Regular,
                          color: FontColor.FontSecondary),
                      unselectedLabelColor: customColors().fontSecondary,
                      indicatorColor: customColors().primary,
                      indicatorSize: TabBarIndicatorSize.tab,
                      indicatorWeight: 2,
                      // indicatorPadding: const EdgeInsets.all(10),
                      labelColor: customColors().primary,
                      tabs: myTabs),
                ),
                Padding(
                  padding: const EdgeInsets.only(right: 16.0),
                  child: Align(
                    alignment: Alignment.centerRight,
                    child: InkWell(
                      onTap: () {
                        setState(() {
                          sortval = "All";
                        });
                        widget.onPressReset();
                      },
                      child: Text(
                        "Reset",
                        style: customTextStyle(
                          fontStyle: FontStyle.BodyL_SemiBold,
                          color: FontColor.Primary,
                        ).copyWith(color: customColors().primary as Color),
                      ),
                    ),
                  ),
                )
              ],
            ),
            if (widget.selectedLocation == SortFilterLocation.holding)
              tabbarViewHoldingList[selectedTabIndex]
            else if (widget.selectedLocation == SortFilterLocation.position)
              tabbarViewPositionList[selectedTabIndex],
            SizedBox(
              height: 15.0,
            )
          ],
        ));
  }
}

class SortWidget extends StatefulWidget {
  final void Function(int) onfilterpress;
  int currentval;
  SortWidget({Key? key, required this.onfilterpress, required this.currentval})
      : super(key: key);

  @override
  State<SortWidget> createState() => _SortWidgetState();
}

class _SortWidgetState extends State<SortWidget> {
  List<String> Radiolistitem = [
    'A - Z',
    'Z - A',
    'Profit: Low - High',
    'Profit: High - Low',
    '% Profit Change: Low - High',
    '% Profit Change: High - Low',
    'Invested Value (Min - Max)',
    'Invested Value (Max - Min)',
  ];
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Divider(
          height: 0,
          thickness: 1,
          color: customColors().backgroundTertiary,
        ),
        Container(
          child: Padding(
            padding: const EdgeInsets.only(left: 10),
            child: Column(
              children: [
                ListView.builder(
                    shrinkWrap: true,
                    itemCount: Radiolistitem.length,
                    itemBuilder: (context, index) {
                      return MyRadioListTile<int>(
                        value: index,
                        groupValue: widget.currentval,
                        title: Text(
                          Radiolistitem[index],
                          style: customTextStyle(
                            fontStyle: FontStyle.BodyL_Regular,
                            color: FontColor.FontPrimary,
                          ),
                        ),
                        onChanged: (value) {
                          setState(() {
                            widget.currentval = value!;
                          });
                          widget.onfilterpress(value!);
                        },
                      );
                    }),
              ],
            ),
          ),
        )
      ],
    );
  }
}

class FilterWidget extends StatelessWidget {
  final void Function(List<String>) onfilterpress;
  const FilterWidget({Key? key, required this.onfilterpress}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Divider(
          height: 0,
          thickness: 1,
          color: customColors().backgroundTertiary,
        ),
        Padding(
          padding: const EdgeInsets.only(left: 16.0, top: 16, bottom: 12),
          child: Align(
              alignment: Alignment.centerLeft,
              child: Text(
                "Position Type",
                style: customTextStyle(
                    fontStyle: FontStyle.BodyM_SemiBold,
                    color: FontColor.FontPrimary),
              )),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16.0),
          child: FilterItemListWidget(
            onfilterpress: onfilterpress,
            itemsList: const [
              {"text": "Open"},
              {"text": "Close"},
              {"text": "Todays Trade"}
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.all(16.0),
          child: Align(
              alignment: Alignment.centerLeft,
              child: Text("Product Type",
                  style: customTextStyle(
                      fontStyle: FontStyle.BodyM_SemiBold,
                      color: FontColor.FontPrimary))),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16.0),
          child: FilterItemListWidget(
            onfilterpress: onfilterpress,
            itemsList: const [
              {"text": "Cash"},
              {"text": "BTST"},
              {"text": "Intraday"},
              {"text": "MTF"},
              {"text": "Smartfolio"}
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.only(left: 16.0, top: 16, bottom: 12),
          child: Align(
              alignment: Alignment.centerLeft,
              child: Text("Segment Type",
                  style: customTextStyle(
                      fontStyle: FontStyle.BodyM_SemiBold,
                      color: FontColor.FontPrimary))),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16.0),
          child: FilterItemListWidget(
            onfilterpress: onfilterpress,
            itemsList: const [
              {"text": "Stock"},
              {"text": "Commodity"},
              {"text": "Currency"},
              {"text": "F&O"}
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.only(left: 16.0, top: 16, bottom: 12),
          child: Align(
              alignment: Alignment.centerLeft,
              child: Text("Color",
                  style: customTextStyle(
                      fontStyle: FontStyle.BodyM_SemiBold,
                      color: FontColor.FontPrimary))),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16.0),
          child: FilterItemColorListWidget(colorList: [
            {"color": customColors().primary},
            {"color": customColors().ultraviolet},
            {"color": customColors().warning},
            {"color": customColors().info},
          ]),
        )
      ],
    );
  }
}

class FilterItemColorListWidget extends StatefulWidget {
  List<Map<String, dynamic>> colorList;
  FilterItemColorListWidget({
    required this.colorList,
    Key? key,
  }) : super(key: key);

  @override
  State<FilterItemColorListWidget> createState() =>
      _FilterItemColorListWidgetState();
}

class _FilterItemColorListWidgetState extends State<FilterItemColorListWidget> {
  int selectedColorIndex = 0;
  @override
  Widget build(BuildContext context) {
    return Wrap(
      alignment: WrapAlignment.start,
      children: [
        for (int index = 0; index < widget.colorList.length; index++)
          Padding(
            padding: const EdgeInsets.only(right: 12.0),
            child: GestureDetector(
              onTap: () => setState(() {
                selectedColorIndex = index;
              }),
              child: Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.all(Radius.circular(25)),
                  border: Border.all(
                    color: selectedColorIndex == index
                        ? customColors().primary
                        : customColors()
                            .backgroundTertiary, // red as border color
                  ),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(6.0),
                  child: Container(
                    padding: EdgeInsets.all(0),
                    width: 20,
                    height: 20,
                    decoration: BoxDecoration(
                        color: widget.colorList[index]["color"],
                        borderRadius: BorderRadius.all(Radius.circular(50))),
                  ),
                ),
              ),
            ),
          ),
      ],
    );
  }
}

class FilterItemListWidget extends StatefulWidget {
  final List<Map<String, dynamic>> itemsList;
  final void Function(List<String>) onfilterpress;
  FilterItemListWidget(
      {Key? key, required this.itemsList, required this.onfilterpress})
      : super(key: key);

  @override
  State<FilterItemListWidget> createState() => _FilterItemListWidgetState();
}

class _FilterItemListWidgetState extends State<FilterItemListWidget> {
  int? selectedButton;

  @override
  Widget build(BuildContext context) {
    if (sortval != "ALL") {
      final mmindex = widget.itemsList
          .indexWhere((element) => element.containsValue(sortval));
      selectedButton = mmindex;
    }

    return Wrap(
      runSpacing: 8,
      spacing: 8,
      children: [
        for (int index = 0; index < widget.itemsList.length; index++)
          Padding(
            // padding: const EdgeInsets.only(right: 8.0, bottom: 8),
            padding: const EdgeInsets.only(right: 0, bottom: 0),
            child: GestureDetector(
                onTap: () {
                  setState(() {
                    if (filterarrayposition
                        .contains(widget.itemsList[index]['text'])) {
                      selectedButton = index - 1;
                      filterarrayposition
                          .remove(widget.itemsList[index]['text']);
                    } else {
                      selectedButton = index;
                      filterarrayposition.add(widget.itemsList[index]['text']);
                    }
                  });
                  sortval = widget.itemsList[index]["text"];
                  widget.onfilterpress(filterarrayposition);
                },
                child: Container(
                  height: 32,
                  // alignment: Alignment.center,
                  // width: widget.itemsList[index]["text"].toString().length * 15,
                  padding: const EdgeInsets.only(left: 15, right: 15, top: 6.5),
                  decoration: BoxDecoration(
                    color: filterarrayposition
                            .contains(widget.itemsList[index]['text'])
                        ? customColors().primary
                        : customColors().backgroundPrimary,
                    borderRadius: const BorderRadius.all(Radius.circular(25)),
                    border: Border.all(
                      color: filterarrayposition
                              .contains(widget.itemsList[index]['text'])
                          ? customColors().primary
                          : customColors().backgroundTertiary,
                    ),
                  ),
                  child: Text("${widget.itemsList[index]["text"]}",
                      style: filterarrayposition
                              .contains(widget.itemsList[index]['text'])
                          ? customTextStyle(
                              fontStyle: FontStyle.BodyM_Bold,
                              color: FontColor.White)
                          : customTextStyle(
                              fontStyle: FontStyle.BodyM_Regular,
                              color: FontColor.FontPrimary)),
                )
                // : Container(
                //     padding:
                //         EdgeInsets.symmetric(horizontal: 20, vertical: 7),
                //     decoration: BoxDecoration(
                //       color: customColors().backgroundPrimary,
                //       borderRadius: BorderRadius.all(Radius.circular(25)),
                //       border: Border.all(
                //         color: customColors().backgroundTertiary,
                //       ),
                //     ),
                //     child: Text("${widget.itemsList[index]["text"]}",
                //         style: customTextStyle(
                //             fontStyle: FontStyle.BodyM_Regular,
                //             color: FontColor.FontPrimary)),
                //   ),
                ),
          ),
      ],
    );
  }
}

class TagColorWidget extends StatefulWidget {
  final List<Map<String, dynamic>> colorList;

  final VoidCallback colorSelection;
  final Function(Color) onCountChanged;

  TagColorWidget(
      {Key? key,
      required this.colorList,
      required this.colorSelection,
      required this.onCountChanged})
      : super(key: key);

  @override
  State<TagColorWidget> createState() => _TagColorWidgetState();
}

class _TagColorWidgetState extends State<TagColorWidget> {
  int select = 0;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.all(16.0),
          child: Text("Select Tag Color",
              style: customTextStyle(
                  fontStyle: FontStyle.HeaderXS_SemiBold,
                  color: FontColor.FontPrimary)),
        ),
        Divider(
          height: 0,
          thickness: 1,
          color: customColors().backgroundTertiary,
        ),
        for (int index = 0; index < widget.colorList.length; index++)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: Column(
              children: [
                InkWell(
                  onTap: () {
                    setState(() {
                      select = index;
                      widget.colorSelection();
                      widget.onCountChanged(widget.colorList[index]["color"]);
                    });

                    Navigator.of(context).pop(true);
                  },
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Container(
                        width: 20,
                        height: 20,
                        decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: widget.colorList[index]["color"]),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(
                            left: 8.0, bottom: 14, top: 14),
                        child: Text(
                          widget.colorList[index]["name"],
                          style: customTextStyle(
                              fontStyle: FontStyle.BodyL_Regular,
                              color: FontColor.FontPrimary),
                        ),
                      )
                    ],
                  ),
                ),
                if (index != widget.colorList.length - 1)
                  Divider(
                    height: 0,
                    thickness: 1,
                    color: customColors().backgroundTertiary,
                  ),
              ],
            ),
          ),
      ],
    );
  }
}

class SmartfolioHoldingListWidget extends StatefulWidget {
  final List<Map<String, dynamic>> holdingList;
  const SmartfolioHoldingListWidget({Key? key, required this.holdingList})
      : super(key: key);

  @override
  State<SmartfolioHoldingListWidget> createState() =>
      _SmartfolioHoldingListWidgetState();
}

class _SmartfolioHoldingListWidgetState
    extends State<SmartfolioHoldingListWidget> {
  int selectedHolding = 0;
  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Padding(
        //   padding: const EdgeInsets.all(16.0),
        //   child: Text("Select Tag Color",
        //       style: customTextStyle(
        //           context: context,
        //           fontStyle: FontStyle.HeaderXS_SemiBold,
        //           color: FontColor.FontPrimary)),
        // ),
        // Divider(
        //   height: 0,
        //   thickness: 1,
        //   color: customColors().backgroundTertiary,
        // ),
        for (int index = 0; index < widget.holdingList.length; index++)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: InkWell(
              onTap: () => setState(() {
                selectedHolding = index;
              }),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Image.asset(
                            "${widget.holdingList[index]["icon"]}",
                            height: 24,
                            width: 24,
                          ),
                          Padding(
                            padding: const EdgeInsets.only(
                                left: 8.0, bottom: 14, top: 14),
                            child: Text(
                              widget.holdingList[index]["name"],
                              style: customTextStyle(
                                  fontStyle: FontStyle.BodyL_SemiBold,
                                  color: FontColor.FontPrimary),
                            ),
                          ),
                        ],
                      ),
                      if (selectedHolding == index)
                        Image.asset("assets/tick_circle.png")
                    ],
                  ),
                  if (index != widget.holdingList.length - 1)
                    Divider(
                      height: 0,
                      thickness: 1,
                      color: customColors().backgroundTertiary,
                    ),
                ],
              ),
            ),
          ),
      ],
    );
  }
}

class NormalListwidget extends StatefulWidget {
  final List<Map<String, dynamic>> holdingList;
  String header;
  NormalListwidget({Key? key, required this.holdingList, required this.header})
      : super(key: key);

  @override
  State<NormalListwidget> createState() => _NormalListwidgetState();
}

class _NormalListwidgetState extends State<NormalListwidget> {
  int selectedHolding = 0;
  @override
  void initState() {
    if (widget.holdingList[widget.holdingList.length - 1].containsValue("All"))
      selectedHolding = widget.holdingList.length - 1;
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Padding(
        //   padding: const EdgeInsets.all(16.0),
        //   child: Text("Select Tag Color",
        //       style: customTextStyle(
        //           context: context,
        //           fontStyle: FontStyle.HeaderXS_SemiBold,
        //           color: FontColor.FontPrimary)),
        // ),
        // Divider(
        //   height: 0,
        //   thickness: 1,
        //   color: customColors().backgroundTertiary,
        // ),
        Padding(
          padding: const EdgeInsets.only(left: 16.0, bottom: 12, top: 14),
          child: Text(
            widget.header,
            style: customTextStyle(
                fontStyle: FontStyle.HeaderXS_SemiBold,
                color: FontColor.FontPrimary),
          ),
        ),
        Divider(
          height: 0,
          thickness: 1,
          color: customColors().backgroundTertiary,
        ),
        for (int index = 0; index < widget.holdingList.length; index++)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: InkWell(
              onTap: () => setState(() {
                selectedHolding = index;
              }),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(bottom: 6, top: 22),
                        child: Text(
                          widget.holdingList[index]["name"],
                          style: customTextStyle(
                              fontStyle: FontStyle.BodyL_SemiBold,
                              color: FontColor.FontPrimary),
                        ),
                      ),
                      if (selectedHolding == index)
                        Image.asset("assets/tick_circle.png"),
                    ],
                  ),
                ],
              ),
            ),
          ),
        SizedBox(
          height: 16,
        )
      ],
    );
  }
}

class HoldingFilterWidget extends StatelessWidget {
  final void Function(List<String>) onPressFilter;
  const HoldingFilterWidget({Key? key, required this.onPressFilter})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Divider(
          height: 0,
          thickness: 1,
          color: customColors().backgroundTertiary,
        ),
        Padding(
          padding: const EdgeInsets.only(left: 16.0, top: 16, bottom: 12),
          child: Align(
              alignment: Alignment.centerLeft,
              child: Text("Product Type",
                  style: customTextStyle(
                      fontStyle: FontStyle.BodyM_SemiBold,
                      color: FontColor.FontPrimary))),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16.0),
          child: FilterItemListWidget(
            onfilterpress: onPressFilter,
            itemsList: const [
              {"text": "Cash"},
              {"text": "BTST"},
              {"text": "Intraday"},
              {"text": "MTF"},
              {"text": "Smartfolio"}
            ],
          ),
        ),
      ],
    );
  }
}

List<String> filterarrayposition = [];
// enum SortFilterLocation {position,holding}

// customShowModalBottomSheet(context: context,inputWidget: PortfolioSortList());
// customShowModalBottomSheet(context: context,inputWidget: PortfolioSortList(selectedTabIndex: 1,selectedLocation: "position",));
// customShowModalBottomSheet(context: context,inputWidget: PortfolioSortList(selectedLocation: "position",));
// customShowModalBottomSheet(context: context,inputWidget: PortfolioSortList(selectedTabIndex: 1,));
// customShowModalBottomSheet(context: context,inputWidget:  TagColorWidget(colorList: [
//   {"name":"Red","color":customColors().danger},
//   {"name":"Green","color":customColors().success},
//   {"name":"Yellow","color":customColors().warning},
//   {"name":"Blue","color":customColors().info}
// ],));
// customShowModalBottomSheet(context: context,inputWidget:  SmartfolioHoldingListWidget(holdingList: [
//   {"name":"Ace","icon":"assets/icon_ace.png"},
//   {"name":"24K","icon":"assets/icon_24k.png"},
//   {"name":"Prime","icon":"assets/icon_prime.png"}
// ],));
