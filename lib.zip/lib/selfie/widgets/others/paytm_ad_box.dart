// import 'package:flutter/material.dart';
// import 'package:flutter/widgets.dart';
// import 'package:carousel_slider/carousel_slider.dart';

// class PaytmAdBox extends StatelessWidget {
//   List<Widget> widget;
//   PaytmAdBox(this.widget);
//   @override
//   Widget build(BuildContext context) {
//     // TODO: implement build

//     return CarouselSlider(
//       options: CarouselOptions(
//         height: 100.0,
//       ),
//       items: widget,
//     );
//   }
// }
