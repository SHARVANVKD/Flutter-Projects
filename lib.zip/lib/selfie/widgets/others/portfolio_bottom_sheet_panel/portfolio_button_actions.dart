import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class PortFolioActionButton extends StatefulWidget {
  bool? toggle;
  bool tag;
  final Function()? addtag;
  final Function() setAlert;
  bool showBubble;
  bool positionSheet;
  PortFolioActionButton(
      {Key? key,
      required this.tag,
      this.addtag,
      required this.setAlert,
      this.showBubble = false,
      this.positionSheet = false,
      this.toggle = false})
      : super(key: key);

  @override
  State<PortFolioActionButton> createState() => _PortFolioActionButtonState();
}

class _PortFolioActionButtonState extends State<PortFolioActionButton> {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 9),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Image.asset(
                "assets/inbox.png",
                color: customColors().fontPrimary,
              ),
              const SizedBox(
                width: 7,
              ),
              Text(
                widget.positionSheet ? "Convert" : "Pledge",
                style: customTextStyle(
                    fontStyle: FontStyle.BodyL_SemiBold,
                    color: FontColor.FontPrimary),
              )
            ],
          ),
          if (widget.tag == true)
            InkWell(
              onTap: widget.addtag,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  widget.toggle!
                      ? Image.asset(
                          "assets/purple.png",
                        )
                      : Image.asset(
                          "assets/tag.png",
                          color: customColors().fontPrimary,
                        ),
                  const SizedBox(
                    width: 7,
                  ),
                  Text(
                    widget.toggle! ? "Remove" : "Add Tag",
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyL_SemiBold,
                        color: FontColor.FontPrimary),
                  )
                ],
              ),
            ),
          InkWell(
            onTap: widget.setAlert,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Stack(
                  alignment: Alignment.topRight,
                  children: [
                    Image.asset("assets/vector.png",
                        color: customColors().fontPrimary),
                    if (widget.showBubble)
                      Container(
                          width: 6,
                          height: 6,
                          decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: customColors().accent))
                  ],
                ),
                const SizedBox(
                  width: 7,
                ),
                Text(
                  "Set Alert",
                  style: customTextStyle(
                      fontStyle: FontStyle.BodyL_SemiBold,
                      color: FontColor.FontPrimary),
                )
              ],
            ),
          ),
        ],
      ),
    );
  }
}
