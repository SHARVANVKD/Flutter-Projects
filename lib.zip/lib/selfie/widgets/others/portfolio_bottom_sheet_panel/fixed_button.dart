import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/buttons/BasketButton.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class FixedButton extends StatelessWidget {
  Function()? ocoOnTap;
  Function()? rollOnTap;
  Function()? addMoreOnTap;
  Function()? squareOffOnTap;
  bool future;
  bool elevation;

  FixedButton(
      {Key? key,
      required this.future,
      required this.addMoreOnTap,
      required this.ocoOnTap,
      this.elevation = false,
      this.rollOnTap,
      required this.squareOffOnTap})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        border: elevation
            ? Border(
                top: BorderSide(color: customColors().backgroundTertiary),
              )
            : null,
      ),
      // height: MediaQuery.of(context).size.height * 0.17,
      height: 128,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Row(
              children: [
                Expanded(
                  child: BasketButton(
                    bordercolor: customColors().green4,
                    text: future ? "Roll" : "OCO Order",
                    textStyle: customTextStyle(
                        fontStyle: FontStyle.BodyL_Bold,
                        color: FontColor.Primary),
                    onpress: future ? rollOnTap : ocoOnTap,
                  ),
                ),
              ],
            ),
            const SizedBox(
              height: 8,
            ),
            Row(
              children: [
                Expanded(
                  child: BasketButton(
                    bordercolor: transparent,
                    bgcolor: customColors().success,
                    text: "Add More",
                    textStyle: customTextStyle(
                        fontStyle: FontStyle.BodyL_Bold,
                        color: FontColor.White),
                    onpress: addMoreOnTap,
                  ),
                ),
                const SizedBox(
                  width: 8,
                ),
                Expanded(
                  child: BasketButton(
                    bordercolor: transparent,
                    bgcolor: customColors().danger,
                    text: "Square Off",
                    textStyle: customTextStyle(
                        fontStyle: FontStyle.BodyL_Bold,
                        color: FontColor.White),
                    onpress: squareOffOnTap,
                  ),
                )
              ],
            ),
          ],
        ),
      ),
    );
  }
}
