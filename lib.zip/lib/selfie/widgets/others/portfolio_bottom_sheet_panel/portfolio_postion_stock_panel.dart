import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';
import 'package:selfie_mobile_flutter/utils/common_prop.dart';
import 'package:trading_api/responses/portfolio_responce.dart';

class PortFolioPositionPanel extends StatelessWidget {
  final Intradaydatum reportData;
  String total_pl;
  String total_pl_percentage;
  String todays_pl;
  String todays_pl_percentage;
  PortFolioPositionPanel({
    required this.reportData,
    required this.total_pl,
    required this.todays_pl,
    required this.total_pl_percentage,
    required this.todays_pl_percentage,
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Divider(
            thickness: 1,
            color: customColors().backgroundTertiary,
          ),
          SizedBox(
            height: MediaQuery.of(context).size.height * 0.02,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Expanded(
                child: SizedBox(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            "Total P&L",
                            style: customTextStyle(
                                fontStyle: FontStyle.BodyM_Regular,
                                color: FontColor.FontSecondary),
                          ),
                          Text(
                            double.parse(total_pl)
                                .toStringAsFixed(2)
                                .toString(),
                            style: customTextStyle(
                                fontStyle: FontStyle.BodyM_SemiBold,
                                color: getFeedColor(double.parse(total_pl))),
                          ),
                        ],
                      ),
                      const SizedBox(
                        height: 16,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            "Total P&L % ",
                            style: customTextStyle(
                                fontStyle: FontStyle.BodyM_Regular,
                                color: FontColor.FontSecondary),
                          ),
                          Text(
                            total_pl_percentage,
                            style: customTextStyle(
                                fontStyle: FontStyle.BodyM_SemiBold,
                                color: getFeedColor(
                                    double.parse(total_pl_percentage))),
                          ),
                        ],
                      )
                    ],
                  ),
                ),
              ),
              const SizedBox(
                width: 20,
              ),
              Expanded(
                child: SizedBox(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            "Day’s P&L ",
                            style: customTextStyle(
                                fontStyle: FontStyle.BodyM_Regular,
                                color: FontColor.FontSecondary),
                          ),
                          Text(
                            todays_pl,
                            style: customTextStyle(
                                fontStyle: FontStyle.BodyM_SemiBold,
                                color: FontColor.Danger),
                          ),
                        ],
                      ),
                      const SizedBox(
                        height: 16,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            "Day’s P&L % ",
                            style: customTextStyle(
                                fontStyle: FontStyle.BodyM_Regular,
                                color: FontColor.FontSecondary),
                          ),
                          Text(
                            todays_pl_percentage.toString(),
                            style: customTextStyle(
                                fontStyle: FontStyle.BodyM_SemiBold,
                                color: getFeedColor(
                                    double.parse(total_pl_percentage))),
                          ),
                        ],
                      )
                    ],
                  ),
                ),
              )
            ],
          ),
          SizedBox(
            height: MediaQuery.of(context).size.height * 0.02,
          ),
          Divider(
            thickness: 1,
            color: customColors().backgroundTertiary,
          ),
          SizedBox(
            height: MediaQuery.of(context).size.height * 0.02,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Expanded(
                child: SizedBox(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            "Buy Qty",
                            style: customTextStyle(
                                fontStyle: FontStyle.BodyM_Regular,
                                color: FontColor.FontSecondary),
                          ),
                          Text(
                            reportData.boughtqty,
                            style: customTextStyle(
                                fontStyle: FontStyle.BodyM_SemiBold,
                                color: FontColor.FontPrimary),
                          ),
                        ],
                      ),
                      const SizedBox(
                        height: 16,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            "Buy Rate",
                            style: customTextStyle(
                                fontStyle: FontStyle.BodyM_Regular,
                                color: FontColor.FontSecondary),
                          ),
                          Text(
                            reportData.buy_rate.toStringAsFixed(2).toString(),
                            style: customTextStyle(
                                fontStyle: FontStyle.BodyM_SemiBold,
                                color: FontColor.FontPrimary),
                          ),
                        ],
                      ),
                      const SizedBox(
                        height: 16,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            "Buy Value",
                            style: customTextStyle(
                                fontStyle: FontStyle.BodyM_Regular,
                                color: FontColor.FontSecondary),
                          ),
                          Text(
                            double.parse(reportData.buyvalnew)
                                .toStringAsFixed(2)
                                .toString(),
                            style: customTextStyle(
                                fontStyle: FontStyle.BodyM_SemiBold,
                                color: FontColor.FontPrimary),
                          ),
                        ],
                      )
                    ],
                  ),
                ),
              ),
              const SizedBox(
                width: 20,
              ),
              Expanded(
                child: SizedBox(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            "Sell Qty",
                            style: customTextStyle(
                                fontStyle: FontStyle.BodyM_Regular,
                                color: FontColor.FontSecondary),
                          ),
                          Text(
                            reportData.soldqty,
                            style: customTextStyle(
                                fontStyle: FontStyle.BodyM_SemiBold,
                                color: FontColor.FontPrimary),
                          ),
                        ],
                      ),
                      const SizedBox(
                        height: 16,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            "Sell Rate",
                            style: customTextStyle(
                                fontStyle: FontStyle.BodyM_Regular,
                                color: FontColor.FontSecondary),
                          ),
                          Text(
                            reportData.sell_rate.toStringAsFixed(2).toString(),
                            style: customTextStyle(
                                fontStyle: FontStyle.BodyM_SemiBold,
                                color: FontColor.FontPrimary),
                          ),
                        ],
                      ),
                      const SizedBox(
                        height: 16,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            "Sell Value",
                            style: customTextStyle(
                                fontStyle: FontStyle.BodyM_Regular,
                                color: FontColor.FontSecondary),
                          ),
                          Text(
                            double.parse(reportData.sellvalnew)
                                .toStringAsFixed(2)
                                .toString(),
                            style: customTextStyle(
                                fontStyle: FontStyle.BodyM_SemiBold,
                                color: FontColor.FontPrimary),
                          ),
                        ],
                      )
                    ],
                  ),
                ),
              )
            ],
          ),
          SizedBox(
            height: MediaQuery.of(context).size.height * 0.01,
          ),
        ],
      ),
    );
  }
}
