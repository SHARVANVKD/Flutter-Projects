import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/buttons/BasketButton.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class OdrderBookFixedButton extends StatelessWidget {
  bool elevation;
  bool modify;
  OdrderBookFixedButton({
    Key? key,
    this.modify = false,
    this.elevation = false,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
        decoration: BoxDecoration(
          border: elevation
              ? Border(
                  top: BorderSide(color: customColors().backgroundTertiary),
                )
              : null,
        ),
        // height: MediaQuery.of(context).size.height * 0.17,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12.0),
          child: modify
              ? Row(
                  children: [
                    Expanded(
                      child: BasketButton(
                        bordercolor: customColors().green4,
                        text: "Cancel Order",
                        textStyle: customTextStyle(
                            fontStyle: FontStyle.BodyL_Bold,
                            color: FontColor.Primary),
                        onpress: () {
                          Navigator.of(context).pop(true);
                        },
                      ),
                    ),
                    const SizedBox(
                      width: 8,
                    ),
                    Expanded(
                      child: BasketButton(
                        bordercolor: transparent,
                        bgcolor: customColors().primary,
                        text: "Modify",
                        textStyle: customTextStyle(
                            fontStyle: FontStyle.BodyL_Bold,
                            color: FontColor.White),
                        onpress: () {
                          Navigator.of(context).pop(true);
                        },
                      ),
                    )
                  ],
                )
              : Row(
                  children: [
                    Expanded(
                      child: BasketButton(
                        bordercolor: transparent,
                        bgcolor: customColors().primary,
                        text: "Reorder",
                        textStyle: customTextStyle(
                            fontStyle: FontStyle.BodyL_Bold,
                            color: FontColor.White),
                        onpress: () {
                          Navigator.of(context).pop(true);
                        },
                      ),
                    )
                  ],
                ),
        ));
  }
}
