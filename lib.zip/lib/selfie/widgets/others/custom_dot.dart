import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class CustomDot extends StatelessWidget {
  final Color? color;
  const CustomDot({Key? key, this.color}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 3),
      child: Container(
        height: 5,
        width: 5,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: color ?? customColors().fontTertiary,
        ),
      ),
    );
  }
}