import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/buttons/BasketButton.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

const List<String> months = [
  "Jan",
  "Feb",
  "Mar",
  "Apr",
  "May",
  "Jun",
  "Jul",
  "Aug",
  "Sep",
  "Oct",
  "Nov",
  "Dec",
];

int multipleLessThan(int year){
  return year - (year % 15);
}

int multipleMoreThan(int year){
  return ((year / 15).toInt()+1)*15;
}

List<int> generateYearList(int currentYear){
  List<int> yearList = [];
  int year15x = multipleLessThan(currentYear);
  if(year15x>currentYear){
    yearList = List.generate(15, (i) => year15x-i);
  }else{
    yearList = List.generate(15, (i) => i+year15x);
  }
  return yearList;
}

class MonthAndYearPicker extends StatefulWidget {
  int? month;
  int? year;
  Function onCancel;
  Function(int, int) onDone;
  MonthAndYearPicker({ 
    Key? key , 
    this.month, 
    this.year,
    required this.onCancel,
    required this.onDone,
  }) : super(key: key);

  @override
  State<MonthAndYearPicker> createState() => _MonthAndYearPickerState();
}

class _MonthAndYearPickerState extends State<MonthAndYearPicker> {
  int selectedMonth = 0;
  int selectedYear = 0;

  List<int> years = [];

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    selectedMonth = widget.month ?? DateTime.now().month;
    selectedYear = widget.year ?? DateTime.now().year;
    setState(() {
      years = generateYearList(selectedYear);
    });
  }
  
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16.0),
      child: Column(
                children: [
                  Center(
                    child: Text(
                      "Month",
                      style: customTextStyle(fontStyle: FontStyle.HeaderXS_Bold, color: FontColor.FontPrimary),
                    ),
                  ),
                  GridView.count(
                    childAspectRatio: 1.8,
                    crossAxisCount: 5,
                    shrinkWrap: true,
                    padding: const EdgeInsets.all(0.0),
                    children: List.generate(months.length, (index) {
                      return index == selectedMonth-1 ? 
                      Center(
                        child: Container(
                          decoration: BoxDecoration(
                            color: customColors().primary,
                            borderRadius: BorderRadius.circular(4),
                          ),
                          padding: const EdgeInsets.symmetric(horizontal: 12.0, vertical: 4.0),
                          child: Text(
                            months[index],
                            style: customTextStyle(fontStyle: FontStyle.BodyL_SemiBold, color: FontColor.White),
                          ),
                        ),
                      ) : 
                      GestureDetector(
                        onTap: () {
                          setState(() {
                            selectedMonth = index+1;
                          });
                        },
                        child: Center(
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 12.0, vertical: 4.0),
                          child: Text(
                            months[index],
                            style: customTextStyle(fontStyle: FontStyle.BodyL_Regular, color: FontColor.FontTertiary),
                          ),
                        ),
                      ),
                      );
                    }),
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      IconButton(
                        onPressed: () {
                          setState(() {
                            years = generateYearList(selectedYear-15);
                            selectedYear = selectedYear - 15;
                          });
                        }, 
                        icon: Icon(Icons.arrow_back_ios, size: 14, color: customColors().fontPrimary,)
                      ),
                      Text(
                      "Year",
                      style: customTextStyle(fontStyle: FontStyle.HeaderXS_Bold, color: FontColor.FontPrimary),
                    ),
                      RotatedBox(
                        quarterTurns: 2,
                        child: IconButton(
                          onPressed: () {
                            setState(() {
                            years = generateYearList(selectedYear+15);
                            selectedYear = selectedYear + 15;
                          });
                          }, 
                          icon: Icon(Icons.arrow_back_ios, size: 14, color: customColors().fontPrimary,)
                        ),
                      )
                    ],
                  ),
                  GridView.count(
                    childAspectRatio: 1.8,
                    crossAxisCount: 5,
                    shrinkWrap: true,
                    padding: const EdgeInsets.all(0.0),
                    children: List.generate(years.length, (index) {
                      return years[index] == selectedYear ? 
                      Center(
                        child: Container(
                          decoration: BoxDecoration(
                            color: customColors().primary,
                            borderRadius: BorderRadius.circular(4),
                          ),
                          padding: const EdgeInsets.symmetric(horizontal: 8.0, vertical: 4.0),
                          child: Text(
                            years[index].toString(),
                            style: customTextStyle(fontStyle: FontStyle.BodyL_SemiBold, color: FontColor.White),
                          ),
                        ),
                      ) : 
                      GestureDetector(
                        onTap: () {
                          setState(() {
                            selectedYear = years[index];
                          });
                        },
                        child: Center(
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 12.0, vertical: 4.0),
                          child: Text(
                            years[index].toString(),
                            style: customTextStyle(fontStyle: FontStyle.BodyL_Regular, color: FontColor.FontTertiary),
                          ),
                        ),
                      ),
                      );
                    }),
                  ),
                  Container(
                    margin: const EdgeInsets.only(top: 12),
                    padding: const EdgeInsets.symmetric(vertical: 12.0),
                    child: Row(
                      children: [
                        Expanded(
                          child: BasketButton(
                            text: "Cancel",
                            textStyle: customTextStyle(fontStyle: FontStyle.BodyL_SemiBold, color: FontColor.Primary),
                            bordercolor: customColors().primary,
                            onpress: (){
                              widget.onCancel();
                            },
                            ),
                        ),
                        const SizedBox(width: 8,),
                        Expanded(
                          child: BasketButton(
                            text: "Done",
                            textStyle: customTextStyle(fontStyle: FontStyle.BodyL_Bold, color: FontColor.White),
                            bgcolor: customColors().primary,
                            onpress: (){
                              widget.onDone(selectedMonth, selectedYear);
                            },
                            ),
                        )
                      ],
                    ),
                  )
                ],
              ),
    );
  }
}

Widget MonthAndYearPickerBottomSheet({required BuildContext context, required Function() onCancel, required Function(int, int) onDone}) {
  return Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      MonthAndYearPicker(
        onCancel: onCancel, 
        onDone: onDone
      ),
    ],
  );
}
