import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/scrollable_bottomsheet/scrollable_bottomsheet.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/custom_calander/calender_style.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/custom_calander/calender_year_picker.dart';
import 'package:selfie_mobile_flutter/utils/calander.dart';
import 'package:table_calendar/table_calendar.dart';

class TableRangeSelection extends StatefulWidget {
  final DateTime? firstDay;
  TableRangeSelection({Key? key, this.firstDay}) : super(key: key);
  @override
  _TableRangeSelectionState createState() => _TableRangeSelectionState();
}

DateTime today = DateTime.now();
class _TableRangeSelectionState extends State<TableRangeSelection>  with TickerProviderStateMixin {
  AnimationController? _controller;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _controller = BottomSheet.createAnimationController(this);
    _controller!.duration = const Duration(milliseconds: 400);
  }

  @override
  void dispose() {
    _controller!.dispose();
    super.dispose();
  }
  
  CalendarFormat _calendarFormat = CalendarFormat.month;
  RangeSelectionMode _rangeSelectionMode = RangeSelectionMode
      .toggledOn; // Can be toggled on/off by longpressing a date
  DateTime _focusedDay = DateTime(DateTime.now().year, DateTime.now().month + 1, DateTime.now().day );
  DateTime? _selectedDay;
  DateTime? _rangeStart;
  DateTime? _rangeEnd;
  int selectedMonth = DateTime.now().month;
  int selectedYear = DateTime.now().year;

  @override
  Widget build(BuildContext context) {
    return TableCalendar(
    sixWeekMonthsEnforced: false,
     headerStyle: headerStyle,
     daysOfWeekStyle: daysOfWeekStyle,
     calendarStyle: calendarStyle,
     firstDay: widget.firstDay ?? kFirstDay,
     lastDay: kLastDay,
     focusedDay: _focusedDay,
     calendarFormat: _calendarFormat,
     selectedDayPredicate: (day) => isSameDay(_selectedDay, day),
     rangeStartDay: _rangeStart,
     rangeEndDay: _rangeEnd,
     rangeSelectionMode: _rangeSelectionMode,
     onDaySelected: (selectedDay, focusedDay) {
       if (!isSameDay(_selectedDay, selectedDay)) {
         setState(() {
           _selectedDay = selectedDay;
           _focusedDay = focusedDay;
           _rangeStart = null; // Important to clean those
           _rangeEnd = null;
           _rangeSelectionMode = RangeSelectionMode.toggledOff;
         });
       }
     },
     onRangeSelected: (start, end, focusedDay) {
       setState(() {
         _selectedDay = null;
         _focusedDay = focusedDay;
         _rangeStart = start;
         _rangeEnd = end;
         _rangeSelectionMode = RangeSelectionMode.toggledOn;
       });
     },
     onFormatChanged: (format) {
       if (_calendarFormat != format) {
         setState(() {
           _calendarFormat = format;
         });
       }
     },
     onPageChanged: (focusedDay) {
       _focusedDay = focusedDay;
     },
     onHeaderTapped: (DateTime time){
       customShowModalBottomSheet(
       context: context,
       inputWidget: MonthAndYearPicker(
           month: selectedMonth,
            year: selectedYear,
           onCancel: () {
             Navigator.of(context).pop(true);
           },
           onDone: (int month, int year) {
             setState(() {
               _focusedDay = DateTime(
                 year,
                 month,
                 _focusedDay.day,
                 _focusedDay.hour,
               );
               selectedMonth = month;
               selectedYear = year;
             });
             Navigator.of(context).pop(true);
           }),
     );
     },
      );
  }
}