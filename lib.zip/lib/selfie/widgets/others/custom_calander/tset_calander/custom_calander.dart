import 'dart:math';

import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/mds_controller.dart/mds_controller.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/custom_top_tab.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

List<Map<String, dynamic>> streamData = [
  {"id": 1, "name": "abc", "ltp": 0.00},
  {"id": 2, "name": "def", "ltp": 0.00},
  {"id": 3, "name": "ghi", "ltp": 0.00},
  {"id": 4, "name": "jkl", "ltp": 0.00},
  {"id": 5, "name": "mno", "ltp": 0.00}
];

class CustomCalanderPage extends StatefulWidget {
  @override
  _CustomCalanderPageState createState() => _CustomCalanderPageState();
}

class _CustomCalanderPageState extends State<CustomCalanderPage> {
  // late List<Instrument> feedData;
  // late Stream<List<Instrument>> _stream = MDS_Controller().stream;
  @override
  void initState() {
    // TODO: implement initState
    // feedData = MDS_Controller().feedData.values.toList();
    // _stream.listen((List<Instrument> event) {
    //   setState(() {
    //     feedData = event;
    //   });
    // });

    initalData();
    setState(() {});
    super.initState();
  }

  initalData() async {
    // await MDS_Controller().mdsLogin();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
          preferredSize: const Size.fromHeight(0.0),
          child: AppBar(
            elevation: 0,
            backgroundColor: customColors().backgroundPrimary,
          )),
      body: Container(
        padding: const EdgeInsets.all(12.0),
        alignment: Alignment.center,
        child: Center(
          child: Column(children: [
            TextFormField(
              controller: TextEditingController(),
              onChanged: (val) {},
            ),
            // const Expanded(child: TabComponent())
            // ElevatedButton(
            //         style: ButtonStyle(
            //           backgroundColor: MaterialStateProperty.all(blue600)
            //         ),
            //         onPressed: () {
            //           feedData = MDS_Controller().feedData.values.toList();
            //         },
            //         child: const Padding(
            //           padding: EdgeInsets.all(8.0),
            //           child: Text("Get Data", style: TextStyle(color: Colors.white),),
            //         ),
            //         ),
            Row(
              children: [
                Expanded(
                    child: ElevatedButton(
                  style: ButtonStyle(
                      backgroundColor: MaterialStateProperty.all(green600)),
                  onPressed: () {
                    MDS_Controller()
                        .batchSubscrbe(MDS_Controller().feedData.keys.toList());
                  },
                  child: const Padding(
                    padding: EdgeInsets.all(8.0),
                    child: Text(
                      "Subscribe",
                      style: TextStyle(color: Colors.white),
                    ),
                  ),
                )),
                SizedBox(
                  width: 12,
                ),
                Expanded(
                    child: ElevatedButton(
                  style: ButtonStyle(
                      backgroundColor: MaterialStateProperty.all(red600)),
                  onPressed: () {
                    MDS_Controller().batchUnsubscribe(
                        MDS_Controller().feedData.keys.toList());
                  },
                  child: const Padding(
                    padding: EdgeInsets.all(8.0),
                    child: Text(
                      "Unsubscribe",
                      style: TextStyle(color: Colors.white),
                    ),
                  ),
                ))
              ],
            ),
            Expanded(
                child: StreamBuilder(
              initialData: "0.00",
              stream: feedValue(),
              builder: (context, snapshot) {
                int change = Random().nextInt(2) - 1;
                return Center(
                  child: Column(
                    children: [
                      // FeedRate(
                      //   snapshot.data.toString(),
                      //   key: Key(snapshot.data.toString()),
                      //   change: change,
                      // ),
                      AnimatedSwitcher(
                        duration: const Duration(milliseconds: 300),
                        transitionBuilder:
                            (Widget child, Animation<double> animation) {
                          return SlideTransition(
                            child: child,
                            position: Tween<Offset>(
                                    begin: const Offset(0.0, 0.5),
                                    end: const Offset(0.0, 0.0))
                                .animate(animation),
                          );
                        },
                        layoutBuilder: (Widget? currentChild,
                            List<Widget> previousChildren) {
                          return currentChild!;
                        },
                        switchInCurve: Curves.ease,
                        switchOutCurve: Curves.ease,
                        child: Text(
                          snapshot.data.toString(),
                          key: ValueKey<String>(
                            snapshot.data.toString(),
                          ),
                          style: TextStyle(
                              fontWeight: FontWeight.w600,
                              color: (change > 0)
                                  ? customColors().success
                                  : customColors().danger),
                        ),
                      ),
                      Text(
                        "+0.00(0.00%)",
                        style: customTextStyle(
                            fontStyle: FontStyle.BodyS_SemiBold,
                            color: change == 0
                                ? FontColor.FontSecondary
                                : change == 1
                                    ? FontColor.Success
                                    : FontColor.Danger),
                      )
                    ],
                  ),
                );
              },
            )
                // ListView.builder(
                //     itemCount: feedData.length,
                //     itemBuilder: (context, index) {
                //       return Container(
                //         padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
                //         child: Column(
                //           children: [
                //             Row(
                //               mainAxisAlignment: MainAxisAlignment.spaceBetween,
                //               children: [
                //                 Wrap(
                //                   crossAxisAlignment: WrapCrossAlignment.center,
                //                   children: [
                //                     Text(
                //                       feedData[index].symbol +
                //                           " " +
                //                           feedData[index].series,
                //                       style: customTextStyle(
                //                           fontStyle: FontStyle.BodyL_SemiBold,
                //                           color: FontColor.FontPrimary),
                //                     ),
                //                   ],
                //                 ),
                //                 Text(
                //                   feedData[index].lastTrdPrice.toString(),
                //                   style: TextStyle(
                //                       fontWeight: FontWeight.w600,
                //                       color: (feedData[index].change > 0)
                //                           ? customColors().success
                //                           : (feedData[index].change < -0)
                //                               ? customColors().danger
                //                               : customColors().fontPrimary),
                //                 ),
                //               ],
                //             ),
                //             SizedBox(
                //               height: 8,
                //             ),
                //             Row(
                //               mainAxisAlignment: MainAxisAlignment.end,
                //               crossAxisAlignment: CrossAxisAlignment.center,
                //               children: [
                //                 Text(
                //                     feedData[index].changePrice.toString() +
                //                         "  (" +
                //                         feedData[index].percChange.toString() +
                //                         "%)",
                //                     style: customTextStyle(
                //                         fontStyle: FontStyle.BodyM_Regular,
                //                         color: FontColor.FontSecondary)),
                //               ],
                //             ),
                //             Padding(
                //               padding: const EdgeInsets.only(top: 16),
                //               child: Container(
                //                 color: customColors().backgroundTertiary,
                //                 height: 1,
                //               ),
                //             )
                //           ],
                //         ),
                //       );
                //     }),
                ),
          ]),
        ),
      ),
    );
  }
}

Stream<Map<String, dynamic>> getStreamData() async* {
  while (1 > 0) {
    await Future.delayed(Duration(seconds: 1));
    Map<String, dynamic> item =
        streamData[Random().nextInt(streamData.length - 1)];
    item["ltp"] = Random().nextInt(200) * Random().nextDouble();
    yield (item);
  }
}

class TabComponent extends StatelessWidget {
  const TabComponent({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12.0),
      decoration: BoxDecoration(
          border:
              Border.all(width: 1, color: customColors().backgroundTertiary),
          borderRadius: BorderRadius.circular(4)),
      child: CustomTabBar(tabContent: const [
        "one",
        "two"
      ], tabBarViewChildern: const [
        Center(child: Text('one')),
        Center(child: Text('two')),
      ]),
    );
  }
}

Stream<String> feedValue() async* {
  while (true) {
    await Future.delayed(Duration(milliseconds: 1000));
    yield ((Random().nextInt(200) * Random().nextDouble()).toString());
  }
}

Widget defaultLayoutBuilder(
    Widget currentChild, List<Widget> previousChildren) {
  List<Widget> children = previousChildren;
  if (currentChild != null) children = children.toList()..add(currentChild);
  return Stack(
    children: children,
    alignment: Alignment.center,
  );
}
