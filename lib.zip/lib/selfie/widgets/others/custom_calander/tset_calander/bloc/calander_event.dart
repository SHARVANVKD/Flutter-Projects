part of 'calander_bloc.dart';

@immutable
abstract class CalanderEvent {}
