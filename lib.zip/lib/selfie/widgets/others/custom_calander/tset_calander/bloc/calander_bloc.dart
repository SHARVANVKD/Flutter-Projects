import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:meta/meta.dart';

part 'calander_event.dart';
part 'calander_state.dart';

class CalanderBloc extends Bloc<CalanderEvent, CalanderState> {
  CalanderBloc() : super(CalanderInitial());

  @override
  Stream<CalanderState> mapEventToState(
    CalanderEvent event,
  ) async* {
    // TODO: implement mapEventToState
  }
}
