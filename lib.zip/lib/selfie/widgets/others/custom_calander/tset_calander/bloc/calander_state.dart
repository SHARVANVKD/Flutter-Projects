part of 'calander_bloc.dart';

@immutable
abstract class CalanderState {}

class CalanderInitial extends CalanderState {
  final String date;
  CalanderInitial({this.date = ""});
}

class CalanderLoading extends CalanderState {}

class CalanderLoaded extends CalanderState {
  final String date;
  final String name;
  final int id;
  CalanderLoaded({required this.id, required this.name, required this.date});
}

class CalanderError extends CalanderState {
  final int errorCode;
  final String errorMessage;
  CalanderError({this.errorCode = 0, this.errorMessage = ""});
}
