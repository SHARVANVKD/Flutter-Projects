import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';
import 'package:table_calendar/table_calendar.dart';

HeaderStyle headerStyle = HeaderStyle(
          formatButtonVisible: false,
          titleCentered: true,
          titleTextStyle: customTextStyle(fontStyle: FontStyle.HeaderXS_SemiBold, color: FontColor.Primary),
          titleTextFormatter: (date, locale) {
                    return DateFormat.MMMM(locale).format(date)+", "+DateFormat.y(locale).format(date);
                  },
        );

DaysOfWeekStyle daysOfWeekStyle = DaysOfWeekStyle(
          dowTextFormatter: (date, locale) => DateFormat.E(locale).format(date)[0],
          weekdayStyle: customTextStyle(fontStyle: FontStyle.BodyL_SemiBold, color: FontColor.FontTertiary),
          weekendStyle: customTextStyle(fontStyle: FontStyle.BodyL_SemiBold, color: FontColor.FontTertiary)
        );
        
CalendarStyle calendarStyle = CalendarStyle(
          // outsideDaysVisible: false,
          defaultTextStyle: customTextStyle(fontStyle: FontStyle.BodyL_Regular, color: FontColor.FontPrimary),
          selectedTextStyle: customTextStyle(fontStyle: FontStyle.BodyL_Bold, color: FontColor.White),
          disabledTextStyle: customTextStyle(fontStyle: FontStyle.BodyL_Bold, color: FontColor.FontTertiary),
          weekendTextStyle: customTextStyle(fontStyle: FontStyle.BodyL_Regular, color: FontColor.FontPrimary),
          todayTextStyle: customTextStyle(fontStyle: FontStyle.BodyL_Regular, color: FontColor.Primary),
          outsideTextStyle: customTextStyle(fontStyle: FontStyle.BodyL_Regular, color: FontColor.FontTertiary),
          holidayTextStyle: customTextStyle(fontStyle: FontStyle.BodyL_Regular, color: FontColor.FontPrimary),
          rangeEndTextStyle: customTextStyle(fontStyle: FontStyle.BodyL_Regular, color: FontColor.White),
          rangeStartTextStyle: customTextStyle(fontStyle: FontStyle.BodyL_Regular, color: FontColor.White),
          withinRangeTextStyle: customTextStyle(fontStyle: FontStyle.BodyL_Regular, color: FontColor.FontPrimary),

          markerDecoration: BoxDecoration(
            color: customColors().primary
          ),
          selectedDecoration: BoxDecoration(
            color: customColors().primary,
            shape: BoxShape.circle,
          ),
          todayDecoration: BoxDecoration(
            color: customColors().primary.withOpacity(0.15),
            shape: BoxShape.circle,
          ),
          rangeStartDecoration: BoxDecoration(
            color: customColors().primary,
            shape: BoxShape.circle,
          ),
          rangeEndDecoration: BoxDecoration(
            color: customColors().primary,
            shape: BoxShape.circle,
          ),
          rangeHighlightColor: customColors().primary.withOpacity(0.2)
        );