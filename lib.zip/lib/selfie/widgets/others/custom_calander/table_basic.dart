import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:table_calendar/table_calendar.dart';

import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/scrollable_bottomsheet/scrollable_bottomsheet.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/custom_calander/calender_style.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/custom_calander/calender_year_picker.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';
import 'package:selfie_mobile_flutter/utils/calander.dart';

class TableBasicSelection extends StatefulWidget {
  final void Function(DateTime) onDateSelected;
  TableBasicSelection({
    Key? key,
    required this.onDateSelected,
  }) : super(key: key);
  @override
  _TableBasicSelectionState createState() => _TableBasicSelectionState();
}

class _TableBasicSelectionState extends State<TableBasicSelection>
    with TickerProviderStateMixin {
  AnimationController? _controller;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _controller = BottomSheet.createAnimationController(this);
    _controller!.duration = const Duration(milliseconds: 400);
  }

  @override
  void dispose() {
    _controller!.dispose();
    super.dispose();
  }

  CalendarFormat _calendarFormat = CalendarFormat.month;
  DateTime _focusedDay = DateTime.now();
  DateTime? _selectedDay;
  int selectedMonth = DateTime.now().month;
  int selectedYear = DateTime.now().year;

  @override
  Widget build(BuildContext context) {
    return TableCalendar(
      headerStyle: headerStyle,
      daysOfWeekStyle: daysOfWeekStyle,
      calendarStyle: CalendarStyle(
          // outsideDaysVisible: false,
          defaultTextStyle: customTextStyle(fontStyle: FontStyle.BodyL_Regular, color: FontColor.FontPrimary),
          selectedTextStyle: customTextStyle(fontStyle: FontStyle.BodyL_Bold, color: FontColor.White),
          disabledTextStyle: customTextStyle(fontStyle: FontStyle.BodyL_Bold, color: FontColor.FontTertiary),
          weekendTextStyle: customTextStyle(fontStyle: FontStyle.BodyL_Regular, color: FontColor.FontPrimary),
          todayTextStyle: customTextStyle(fontStyle: FontStyle.BodyL_Regular, color: FontColor.Primary),
          outsideTextStyle: customTextStyle(fontStyle: FontStyle.BodyL_Regular,).copyWith(color: transparent),
          holidayTextStyle: customTextStyle(fontStyle: FontStyle.BodyL_Regular, color: FontColor.FontPrimary),
          rangeEndTextStyle: customTextStyle(fontStyle: FontStyle.BodyL_Regular, color: FontColor.White),
          rangeStartTextStyle: customTextStyle(fontStyle: FontStyle.BodyL_Regular, color: FontColor.White),
          withinRangeTextStyle: customTextStyle(fontStyle: FontStyle.BodyL_Regular, color: FontColor.FontPrimary),

          markerDecoration: BoxDecoration(
    color: customColors().primary
          ),
          selectedDecoration: BoxDecoration(
    color: customColors().primary,
    shape: BoxShape.circle,
          ),
          todayDecoration: BoxDecoration(
    color: customColors().primary.withOpacity(0.15),
    shape: BoxShape.circle,
          ),
          rangeStartDecoration: BoxDecoration(
    color: customColors().primary,
    shape: BoxShape.circle,
          ),
          rangeEndDecoration: BoxDecoration(
    color: customColors().primary,
    shape: BoxShape.circle,
          ),
          rangeHighlightColor: customColors().primary.withOpacity(0.2)
        ),
        
      pageAnimationEnabled: false,
      firstDay: kFirstDay,
      lastDay: kLastDay,
      focusedDay: _focusedDay,
      calendarFormat: _calendarFormat,
      availableCalendarFormats: const {
        CalendarFormat.month : 'Month'
      },
      selectedDayPredicate: (day) {
        return isSameDay(_selectedDay, day);
      },
      onDaySelected: (selectedDay, focusedDay) {
        if (!isSameDay(_selectedDay, selectedDay)) {
          setState(() {
    _selectedDay = selectedDay;
    _focusedDay = focusedDay;
          });
          widget.onDateSelected(selectedDay);
        }
      },
      onFormatChanged: (format) {
        if (_calendarFormat != format) {
          setState(() {
    _calendarFormat = format;
          });
        }
      },
      onPageChanged: (focusedDay) {
        _focusedDay = focusedDay;
      },
      onHeaderTapped: (DateTime time) {
        customShowModalBottomSheet(
          context: context,
          inputWidget: 
          MonthAndYearPicker(
      month: selectedMonth,
      year: selectedYear,
      onCancel: () {
        Navigator.of(context).pop(true);
      },
      onDone: (int month, int year) {
        setState(() {
          _focusedDay = DateTime(
            year,
            month,
            _focusedDay.day,
            _focusedDay.hour,
          );
          selectedMonth = month;
          selectedYear = year;
        });
        Navigator.of(context).pop(true);
      }),
        );
      },
    );
  }
}
