import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/options_widget.dart';
import '../../../theme/styles.dart';

class ComapnyNewsListItem extends StatefulWidget {
  ComapnyNewsListItem({
    Key? key,
    required this.image,
    required this.newshead,
    required this.source,
    required this.time,
    required this.status,
  }) : super(key: key);
  String image, newshead, source, time, status;
  @override
  State<ComapnyNewsListItem> createState() => _ComapnyNewsListItemState();
}

class _ComapnyNewsListItemState extends State<ComapnyNewsListItem> {
  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      decoration: BoxDecoration(
        color: customColors().backgroundSecondary,
        borderRadius: BorderRadius.circular(4),
      ),
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Row(
          children: [
            Image.asset(widget.image),
            const SizedBox(width: 13),
            Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                getProductTypeWidget(widget.status),
                const SizedBox(height: 8),
                SizedBox(
                  width: 200,
                  child: Text(
                    widget.newshead,
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyM_SemiBold,
                        color: FontColor.FontPrimary),
                    maxLines: 2,
                  ),
                ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Text(
                      widget.source + " | ",
                      style: customTextStyle(
                          fontStyle: FontStyle.BodyS_Regular,
                          color: FontColor.FontSecondary),
                    ),
                    Text(
                      widget.time,
                      style: customTextStyle(
                          fontStyle: FontStyle.BodyS_Regular,
                          color: FontColor.FontSecondary),
                    )
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
