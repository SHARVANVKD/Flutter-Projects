import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';
import 'dart:math' as math;

Widget MessageTile(BuildContext context, String message, String endString){
  double width = MediaQuery.of(context).size.width;
  return Container(
                    color: customColors().backgroundSecondary,
                    padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Expanded(
                          child: Padding(
                            padding: const EdgeInsets.only(right: 24),
                            child: Text(message, textDirection: TextDirection.ltr, maxLines: 5, textAlign: TextAlign.start, style: customTextStyle( fontStyle: FontStyle.BodyM_Regular, color: FontColor.FontSecondary)),
                          ),
                        ),
                        Text(endString, style: customTextStyle( fontStyle: FontStyle.BodyM_SemiBold, color: FontColor.FontPrimary)),
                      ],
                    ),
                  );
}

Widget skipButton(BuildContext context, String count, Function() previous, Function() next){
  return Card(
              color: black.withOpacity(0.6),
              shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20.0),
              ),
              elevation: 4,
              child: Container(
              height: 40,
              width: 120,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  IconButton(icon: const Icon(Icons.arrow_back_ios, color: white), onPressed: previous),
                  Text(count, style: customTextStyle( fontStyle: FontStyle.TagNameL_SemiBold, color: FontColor.FontPrimary).copyWith(color: white),),
                  Transform.rotate(
                    angle: 180 * math.pi/180,
                    child: IconButton(icon: Icon(Icons.arrow_back_ios, color: white), onPressed: next),
                    )
              ]),
              ),
            );
}
