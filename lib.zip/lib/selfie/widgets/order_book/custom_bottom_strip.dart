import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

enum FundOrMargin {FUND, MARGIN}

class CustomBottomStrip extends StatelessWidget {
  final FundOrMargin fundOrMargin;
  final String required;
  final String available;
  final bool refreshIcon;
  const CustomBottomStrip({Key? key, required this.fundOrMargin, this.required = "0", this.available = "0", this.refreshIcon = false, }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      color: customColors().backgroundSecondary,
      padding: const EdgeInsets.symmetric(horizontal: 12.0, vertical: 7.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Row(
            children: [
              RichText(
                text: TextSpan(
                    text: fundOrMargin == FundOrMargin.MARGIN ? 'Req Margin: ' : 'Fund Required: ',
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyM_Regular,
                        color: FontColor.FontSecondary),
                    children: <TextSpan>[
                      TextSpan(
                          text: "₹",
                          style: customTextStyle(
                              fontStyle: FontStyle.BodyL_SemiBold,
                              color: FontColor.FontPrimary)),
                      TextSpan(
                          text: required,
                          style: customTextStyle(
                              fontStyle: FontStyle.BodyM_SemiBold,
                              color: FontColor.FontPrimary))
                    ]),
              ),
              const SizedBox(width: 8.0,),
              if(refreshIcon) InkWell(
                child: Image.asset("assets/refresh.png"),
              )
            ],
          ),
          RichText(
                text: TextSpan(
                    text: fundOrMargin == FundOrMargin.MARGIN ? 'Available Margin: ' : 'Fund Available: ',
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyM_Regular,
                        color: FontColor.FontSecondary),
                    children: <TextSpan>[
                      TextSpan(
                          text: "₹",
                          style: customTextStyle(
                              fontStyle: FontStyle.BodyL_SemiBold,
                              color: FontColor.FontPrimary)),
                      TextSpan(
                          text: available,
                          style: customTextStyle(
                              fontStyle: FontStyle.BodyM_SemiBold,
                              color: FontColor.FontPrimary))
                    ]),
              ),
        ],
      ),
    );
  }
}

/*
const CustomBottomStrip(
              fundOrMargin: FundOrMargin.FUND,
              required: "15,000",
              available: "21,000",
            )
*/
