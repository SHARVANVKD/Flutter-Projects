import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/constants/formaters.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/order_book/open/open_list_item.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/options_widget.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';
import 'package:trading_api/responses/order_status_item_response.dart';

import '../../others/custom_dot.dart';

class ClosedListTile extends StatefulWidget {
  // Map<String, dynamic> closedList;
  VoidCallback? onLongPressAction;
  int index;
  List<OrderStatusReportData> closedList;
  VoidCallback? onTap;
  ClosedListTile(
      {Key? key,
      this.onLongPressAction,
      this.onTap,
      required this.closedList,
      required this.index})
      : super(key: key);

  @override
  State<ClosedListTile> createState() => _ClosedListTileState();
}

class _ClosedListTileState extends State<ClosedListTile> {
  var paint1 = Paint()
    ..color = customColors().success
    ..strokeCap = StrokeCap.round //rounded points
    ..strokeWidth = 10;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onLongPress: widget.onLongPressAction,
      onTap: widget.onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 16),
          decoration: BoxDecoration(
              border: Border(
            bottom:
                BorderSide(color: customColors().backgroundTertiary, width: 1),
          )),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Visibility(
                // visible: widget.closedList.containsKey("topview"),
                visible: true,
                child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Row(
                        children: [
                          Padding(
                            padding:
                                const EdgeInsets.symmetric(horizontal: 0.0),
                            child: getProductTypeWidget(widget
                                .closedList[widget.index].buyorsell
                                .toString()),
                          ),
                          SizedBox(
                            width: 6,
                          ),
                          Padding(
                            padding:
                                const EdgeInsets.symmetric(horizontal: 0.0),
                            child: getProductTypeWidget(widget
                                .closedList[widget.index].producttype
                                .toString()),
                          ),
                        ],
                      ),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Text(
                            // "${widget.closedList["last_update"]}",
                            "",
                            style: customTextStyle(
                                fontStyle: FontStyle.BodyS_SemiBold,
                                color: FontColor.FontTertiary),
                          ),
                          const Padding(
                            padding: EdgeInsets.only(left: 6.0, right: 6.0),
                            child: CustomDot(),
                          ),
                          // CustomDotSeparator(),
                          getOrderStatusWidget(widget
                              .closedList[widget.index].statussubcategory
                              .toString())
                        ],
                      )
                    ]),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 10),
                child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        widget.closedList[widget.index].securitycode.toString(),
                        style: customTextStyle(
                            fontStyle: FontStyle.BodyL_SemiBold,
                            color: FontColor.FontPrimary),
                      ),
                      RichText(
                          text: TextSpan(
                              text: "Avg. ",
                              style: customTextStyle(
                                  fontStyle: FontStyle.BodyL_Regular,
                                  color: FontColor.FontPrimary),
                              children: [
                            TextSpan(
                              text: double.parse(widget
                                      .closedList[widget.index].execavgrate
                                      .toString())
                                  .toStringAsFixed(2),
                              style: customTextStyle(
                                  fontStyle: FontStyle.BodyL_SemiBold,
                                  color: FontColor.FontPrimary),
                            )
                          ])),
                    ]),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 4.0),
                child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        "${widget.closedList[widget.index].execqty}/${widget.closedList[widget.index].quantity}",
                        style: customTextStyle(
                            fontStyle: FontStyle.BodyM_SemiBold,
                            color: FontColor.FontSecondary),
                      ),
                      Text(
                        "${widget.closedList[widget.index].clienttype}",
                        style: customTextStyle(
                            fontStyle: FontStyle.BodyM_SemiBold,
                            color: FontColor.FontSecondary),
                      ),
                    ]),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
