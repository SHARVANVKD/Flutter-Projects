import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/constants/formaters.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class BasketListItem extends StatefulWidget {
  Map<String, dynamic> basketList;
  VoidCallback? onLongPressAction;
  VoidCallback? onTap;
  BasketListItem(
      {Key? key, required this.basketList, this.onLongPressAction, this.onTap})
      : super(key: key);

  @override
  State<BasketListItem> createState() => _BasketListItemState();
}

class _BasketListItemState extends State<BasketListItem> {
  var paint1 = Paint()
    ..color = customColors().success
    ..strokeCap = StrokeCap.round //rounded points
    ..strokeWidth = 10;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onLongPress: widget.onLongPressAction,
      onTap: widget.onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 16),
          decoration: BoxDecoration(
              border: Border(
            bottom:
                BorderSide(color: customColors().backgroundTertiary, width: 1),
          )),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Visibility(
                // visible: widget.basketList.containsKey("topview"),
                visible: true,
                child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Text(
                        "${widget.basketList["name"]}",
                        style: customTextStyle(
                            fontStyle: FontStyle.BodyL_SemiBold,
                            color: FontColor.FontPrimary),
                      ),
                    ]),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 10),
                child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        "${widget.basketList["date"]}",
                        style: customTextStyle(
                            fontStyle: FontStyle.BodyM_SemiBold,
                            color: FontColor.FontSecondary),
                      ),
                      RichText(
                          text: TextSpan(
                              text:
                                  "${Formats.valueFormat.format(widget.basketList["value"])}/${Formats.valueFormat.format(widget.basketList["total_value"])}",
                              style: customTextStyle(
                                  fontStyle: FontStyle.BodyM_SemiBold,
                                  color: FontColor.FontPrimary),
                              children: [
                            TextSpan(
                              text: " Items",
                              style: customTextStyle(
                                  fontStyle: FontStyle.BodyL_SemiBold,
                                  color: FontColor.FontSecondary),
                            )
                          ])),
                    ]),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
