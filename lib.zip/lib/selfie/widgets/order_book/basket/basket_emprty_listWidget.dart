import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/buttons/BasketButton.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/empty_container.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class OrderbookBasketEmptyContainer extends StatelessWidget {
  final String title;
  final String subTitle;
  const OrderbookBasketEmptyContainer({ Key? key,required this.title,required this.subTitle }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
    mainAxisAlignment: MainAxisAlignment.center,
    children: [
      EmptyContainer(
          height: 160, width: 160, color: customColors().backgroundSecondary),
      Padding(
        padding: const EdgeInsets.only(top: 20.0),
        child: Align(
            alignment: Alignment.center,
            child: Text(
              title,
              style: customTextStyle(
                  fontStyle: FontStyle.BodyL_SemiBold,
                  color: FontColor.FontPrimary),
            )),
      ),
      Padding(
        padding: const EdgeInsets.only(top: 4,bottom: 16),
        child: Align(
            alignment: Alignment.center,
            child: Text(
              subTitle,
              style: customTextStyle(
                  fontStyle: FontStyle.BodyM_Regular,
                  color: FontColor.FontSecondary),
            )),
      ),
      BasketButton(
        bordercolor: customColors().primary,
        bgcolor: customColors().primary,
        text: "Create Basket",
        textStyle: customTextStyle(
            fontStyle: FontStyle.BodyL_Bold, color: FontColor.White),
        onpress: () {},
        buttonwidth: 160,
      ),
    ],
  );
  }
}