import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/constants/formaters.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/custom_image_icon.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/options_widget.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class SmartfolioListItem extends StatefulWidget {
  Map<String, dynamic> smartfolioList;
  VoidCallback? onLongPressAction;
  VoidCallback? onTap;
  SmartfolioListItem(
      {Key? key,
      required this.smartfolioList,
      this.onLongPressAction,
      this.onTap})
      : super(key: key);

  @override
  State<SmartfolioListItem> createState() => _PortfolioListItemState();
}

class _PortfolioListItemState extends State<SmartfolioListItem> {
  var paint1 = Paint()
    ..color = customColors().success
    ..strokeCap = StrokeCap.round //rounded points
    ..strokeWidth = 10;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
    padding: const EdgeInsets.only(bottom: 8, left: 16, right: 16, top: 8),
    child: Container(
      // height: 160,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
          color: customColors().backgroundPrimary,
          borderRadius: BorderRadius.circular(4),
          border: Border.all(color: customColors().backgroundTertiary)),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [

                  Image.asset("assets/ace.png"),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text(
                          "${widget.smartfolioList["name"]}",
                          style: customTextStyle(
                              fontStyle: FontStyle.HeaderXS_Bold,
                              color: FontColor.FontPrimary),
                        ),
                  ),
                ],
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  RichText(text: TextSpan(
                    text: "Apox Amt ",style: customTextStyle(
                            fontStyle: FontStyle.BodyM_Regular,
                            color: FontColor.FontSecondary),
                    children: [
                      TextSpan(
                        text: "${Formats.valueFormat.format(widget.smartfolioList["aprox_amt"])}",style: customTextStyle(
                            fontStyle: FontStyle.BodyM_SemiBold,
                            color: FontColor.FontPrimary),
                      ),
                      
                    ]
                  )),
                  RichText(text: TextSpan(
                    text: "Rec Date ",style: customTextStyle(
                            fontStyle: FontStyle.BodyM_Regular,
                            color: FontColor.FontSecondary),
                    children: [
                      TextSpan(
                        text: "${widget.smartfolioList["date"]}",style: customTextStyle(
                            fontStyle: FontStyle.BodyM_SemiBold,
                            color: FontColor.FontPrimary),
                      ),
                      
                    ]
                  ))
                ],
              )
            ],
          ),
      // child: Column(
      //   children: [
      //     Container(
      //         height: 75,
      //         decoration: BoxDecoration(
      //             border: Border(
      //           bottom:
      //               BorderSide(color: customColors().backgroundTertiary),
      //         )),
      //         child: Column(
      //           children: [
      //             Row(
      //               mainAxisAlignment: MainAxisAlignment.spaceBetween,
      //               children: [
      //                 Row(
      //                   children: [

      //                     // Image.asset(
      //                     //   widget.smartfolioList["icon"],
      //                     //   color: widget.smartfolioList["iconcolor"],
      //                     //   height: 32,
      //                     //   width: 32,
      //                     // ),
      //                 Image.asset("assets/filled_arrow.png"),
      //                     Padding(
      //                       padding: const EdgeInsets.only(left: 8),
      //                       child: Text(
      //                         "${widget.smartfolioList["name"]}",
      //                         style: customTextStyle(
      //                             fontStyle: FontStyle.HeaderXS_Bold,
      //                             color: FontColor.FontPrimary),
      //                       ),
      //                     ),
      //                   ],
      //                 ),
      //               ],
      //             ),
      //             Padding(
      //               padding: const EdgeInsets.only(top: 8),
      //               child: Row(
      //                 children: [
      //                   Text(
      //                     "${widget.smartfolioList["QUANTITY"]}",
      //                     style: customTextStyle(
      //                         fontStyle: FontStyle.BodyM_SemiBold,
      //                         color: FontColor.FontSecondary),
      //                   ),
      //                   Text(
      //                     " Stocks",
      //                     style: customTextStyle(
      //                         fontStyle: FontStyle.BodyM_Regular,
      //                         color: FontColor.FontSecondary),
      //                   ),
      //                   Padding(
      //                     padding:
      //                         const EdgeInsets.only(left: 6.0, right: 6.0),
      //                     child: Container(
      //                       width: 4,
      //                       height: 4,
      //                       alignment: Alignment.center,
      //                       decoration: BoxDecoration(
      //                           color: customColors().fontSecondary,
      //                           borderRadius: BorderRadius.circular(17)),
      //                     ),
      //                   ),
      //                   Text(
      //                     "${widget.smartfolioList["holdingper"]}",
      //                     style: customTextStyle(
      //                         fontStyle: FontStyle.BodyM_SemiBold,
      //                         color: FontColor.FontSecondary),
      //                   ),
      //                   Text(
      //                     " of holdings",
      //                     style: customTextStyle(
      //                         fontStyle: FontStyle.BodyM_Regular,
      //                         color: FontColor.FontSecondary),
      //                   ),
      //                 ],
      //               ),
      //             ),
      //           ],
      //         )),
      //     Container(
      //       padding: const EdgeInsets.only(top: 12),
      //       child: Column(
      //         children: [
      //           Row(
      //             mainAxisAlignment: MainAxisAlignment.spaceBetween,
      //             children: [
      //               Column(
      //                 crossAxisAlignment: CrossAxisAlignment.start,
      //                 children: [
      //                   Text(widget.smartfolioList["label1"],
      //                       style: customTextStyle(
      //                           fontStyle: FontStyle.BodyM_Regular,
      //                           color: FontColor.FontSecondary)),
      //                   Padding(
      //                     padding: const EdgeInsets.only(top: 4),
      //                     child: Text(
      //                       widget.smartfolioList["value1"],
      //                       style: customTextStyle(
      //                           fontStyle: FontStyle.BodyL_SemiBold,
      //                           color: FontColor.FontPrimary),
      //                     ),
      //                   ),
      //                 ],
      //               ),
      //               Column(
      //                 crossAxisAlignment: CrossAxisAlignment.center,
      //                 children: [
      //                   Text(
      //                     widget.smartfolioList["label2"],
      //                     style: customTextStyle(
      //                         fontStyle: FontStyle.BodyM_Regular,
      //                         color: FontColor.FontSecondary),
      //                   ),
      //                   Padding(
      //                     padding: const EdgeInsets.only(top: 4),
      //                     child: Text(
      //                       widget.smartfolioList["value2"],
      //                       style: customTextStyle(
      //                           fontStyle: FontStyle.BodyL_SemiBold,
      //                           color: FontColor.FontPrimary),
      //                     ),
      //                   ),
      //                 ],
      //               ),
      //               Column(
      //                 crossAxisAlignment: CrossAxisAlignment.end,
      //                 children: [
      //                   Text(
      //                     widget.smartfolioList["label3"],
      //                     style: customTextStyle(
      //                         fontStyle: FontStyle.BodyM_Regular,
      //                         color: FontColor.FontSecondary),
      //                   ),
      //                   Padding(
      //                     padding: const EdgeInsets.only(top: 4),
      //                     child: Text(
      //                       widget.smartfolioList["value3"],
      //                       style: customTextStyle(
      //                           fontStyle: FontStyle.BodyL_SemiBold,
      //                           color: FontColor.Success),
      //                     ),
      //                   ),
      //                 ],
      //               ),
      //             ],
      //           ),
      //         ],
      //       ),
      //     )
      //   ],
      // ),
    ),
    );
  }
}


