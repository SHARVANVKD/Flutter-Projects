import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/options_widget.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class OpenListItemSelected extends StatefulWidget {
  Map<String, dynamic> openSamples;
  List<String> checklist;
  final Function(int) upcount;
  OpenListItemSelected(
      {Key? key,
      required this.openSamples,
      required this.checklist,
      required this.upcount})
      : super(key: key);

  @override
  State<OpenListItemSelected> createState() => _PortfolioListItemState();
}

class _PortfolioListItemState extends State<OpenListItemSelected> {
  int index = 0;

  // int getindex(String value) {
  //   if (value == "MTF") {
  //     return 0;
  //   } else if (value == "INTRADAY") {
  //     return 1;
  //   } else if (value == "CASH") {
  //     return 2;
  //   }
  //   return 0;
  // }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    // index = getindex(widget.openSamples["OrderType"]);
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 16.0),
      child: Column(
        children: [
          Container(
            width: MediaQuery.of(context).size.width,
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: 9.0),
              child: Container(
                padding: const EdgeInsets.only(left: 8.0),
                width: 2.0,
                decoration: BoxDecoration(
                    border: Border(
                  left: BorderSide(
                      color: getbackcolor(widget.openSamples["BUYORSELL"]),
                      width: 2),
                )),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Column(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Padding(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 0.0),
                              child: getProductTypeWidget(
                                  widget.openSamples["BUYORSELL"]),
                            ),
                            SizedBox(
                              width: 6,
                            ),
                            Padding(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 0.0),
                              child: getProductTypeWidget(
                                  widget.openSamples["PRODUCTTYPE"]),
                            ),
                            SizedBox(
                              width: 8,
                            ),
                            // if (widget.openList["basket"] != null &&
                            //     widget.openList["basket"])
                            //   CustomImageIcon(
                            //     imagPath: "assets/shopping-bag.png",
                            //     imageColor: customColors().fontTertiary,
                            //   )
                          ],
                        ),
                        Padding(
                          padding: const EdgeInsets.only(top: 10),
                          child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Row(
                                  children: [
                                    Text(
                                      widget.openSamples["SECURITYCODE"],
                                      style: customTextStyle(
                                          fontStyle: FontStyle.BodyL_SemiBold,
                                          color: FontColor.FontPrimary),
                                    ),
                                  ],
                                )
                              ]),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(top: 4.0),
                          child: Row(
                            children: [
                              Text(
                                "${widget.openSamples["QUANTITY"]}/${widget.openSamples["MARKETLOT"]}",
                                style: customTextStyle(
                                    fontStyle: FontStyle.BodyM_SemiBold,
                                    color: FontColor.FontSecondary),
                              )
                            ],
                          ),
                        )
                      ],
                    ),
                    Checkbox(
                      activeColor: customColors().primary,
                      onChanged: (value) {
                        checkinlist(widget.openSamples["SECURITYCODE"]);
                      },
                      value: widget.checklist
                              .contains(widget.openSamples["SECURITYCODE"])
                          ? true
                          : false,
                    ),
                  ],
                ),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(right: 16.0),
            child: Divider(
              thickness: 2.0,
              color: customColors().backgroundTertiary,
            ),
          )
        ],
      ),
    );
  }

  void checkinlist(String name) {
    setState(() {
      if (widget.checklist.contains(name)) {
        widget.checklist.remove(name);
      } else {
        widget.checklist.add(name);
      }
      widget.upcount(widget.checklist.length);
    });
  }
}

getbackcolor(String status) {
  switch (status) {
    case "NSE":
      return customColors().crisps.withOpacity(0.15);
    case "SELL":
      return customColors().danger.withOpacity(0.15);
    case "BUY":
      return customColors().success.withOpacity(0.15);
    case "NSEFO":
      return customColors().mattPurple.withOpacity(0.15);
    default:
  }
}
