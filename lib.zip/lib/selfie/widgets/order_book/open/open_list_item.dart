import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/constants/formaters.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order/tab_controller_order_book/open/components/time_cal.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/custom_image_icon.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/custom_dot.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/options_widget.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';
import 'package:trading_api/responses/order_status_item_response.dart';

class OpenListItem extends StatefulWidget {
  // Map<String, dynamic> openList;
  int index;
  List<OrderStatusReportData> openList;
  VoidCallback? onLongPressAction;
  VoidCallback? onTap;
  OpenListItem({
    Key? key,
    // required this.openList,
    this.onLongPressAction,
    required this.openList,
    this.onTap,
    required this.index,
  }) : super(key: key);

  @override
  State<OpenListItem> createState() => _OpenItemState();
}

class _OpenItemState extends State<OpenListItem> {
  var paint1 = Paint()
    ..color = customColors().success
    ..strokeCap = StrokeCap.round //rounded points
    ..strokeWidth = 10;

  triggerSection(String orderType, int index) {
    switch (orderType) {
      case "MKT":
        {
          return "N/A";
        }
      case "LMT":
        {
          return widget.openList[index].price ?? "";
        }
      case "STL":
        {
          return " ${widget.openList[index].price ?? ""} / T-${widget.openList[index].triggerprice ?? ""}";
        }
      case "STLM":
        {
          return "T-${widget.openList[index].triggerprice ?? ""}";
        }
    }
  }

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onLongPress: widget.onLongPressAction,
      onTap: widget.onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 16),
          decoration: BoxDecoration(
              border: Border(
            bottom:
                BorderSide(color: customColors().backgroundTertiary, width: 1),
          )),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 8),
            decoration: const BoxDecoration(
                border: Border(
              left: BorderSide(color: green200, width: 2),
            )),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Visibility(
                  // visible: widget.openList.containsKey("topview"),
                  visible: true,
                  child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Row(
                          children: [
                            Padding(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 0.0),
                              child: getProductTypeWidget(widget
                                  .openList[widget.index].buyorsell
                                  .toString()),
                            ),
                            const SizedBox(
                              width: 6,
                            ),
                            Padding(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 0.0),
                              child: getProductTypeWidget(widget
                                  .openList[widget.index].producttype
                                  .toString()),
                            ),
                            const SizedBox(
                              width: 8,
                            ),
                          ],
                        ),
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Text(
                              
                              timeAgo(
                                DateTime.parse(
                                  widget.openList[widget.index].lastupdatedon
                                      .toString(),
                                ),
                              ),

                              style: customTextStyle(
                                  fontStyle: FontStyle.BodyS_SemiBold,
                                  color: FontColor.FontTertiary),
                            ),
                            const Padding(
                              padding: EdgeInsets.only(left: 6.0, right: 6.0),
                              child: CustomDot(),
                            ),
                            getOrderStatusWidget(widget
                                .openList[widget.index].statussubcategory
                                .toString())
                          ],
                        )
                      ]),
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 10),
                  child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          widget.openList[widget.index].securitycode.toString(),
                          // widget.open![widget.index].securitycode.toString(),
                          style: customTextStyle(
                              fontStyle: FontStyle.BodyL_SemiBold,
                              color: FontColor.FontPrimary),
                        ),
                        Text(
                          // "${Formats.valueFormat.format(widget.openList["PRICE"])} / T-${Formats.valueFormat.format(widget.openList["STOPLOSSTRIGGERED"])}",
                          // "${widget.openList["PRICE"]} / T-${widget.openList["TRIGGERPRICE"]}",
                          triggerSection(
                                  widget.openList[widget.index].pricecondition
                                      .toString(),
                                  widget.index)
                              .toString(),

                          style: customTextStyle(
                              fontStyle: FontStyle.BodyL_SemiBold,
                              color: FontColor.FontPrimary),
                        ),
                      ]),
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 4.0),
                  child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          "${widget.openList[widget.index].execqty}/${widget.openList[widget.index].quantity}",
                          style: customTextStyle(
                              fontStyle: FontStyle.BodyM_SemiBold,
                              color: FontColor.FontSecondary),
                        ),
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Text(
                              "${widget.openList[widget.index].clienttype}",
                              style: customTextStyle(
                                  fontStyle: FontStyle.BodyM_SemiBold,
                                  color: FontColor.FontSecondary),
                            ),
                            const Padding(
                              padding: EdgeInsets.only(left: 6.0, right: 6.0),
                              child: CustomDot(),
                            ),
                            Text(
                              "${widget.openList[widget.index].pricecondition}",
                              style: customTextStyle(
                                  fontStyle: FontStyle.BodyM_SemiBold,
                                  color: FontColor.FontSecondary),
                            ),
                          ],
                        ),
                      ]),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
