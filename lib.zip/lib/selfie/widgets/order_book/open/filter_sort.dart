import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/constants/enums.dart';
import 'package:selfie_mobile_flutter/selfie/repository_layer/portfolio_content.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/custom_radio_button.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/sort.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class OpenSortFilterList extends StatefulWidget {
  // SortFilterLocation selectedLocation;
  // int selectedTabIndex;
  final void Function(List<String>) onPressFilter;
  final void Function(String) onPressSort;
  final void Function() onPressReset;
  int currentval;
  OpenSortFilterList(
      {Key? key,
      // this.selectedTabIndex = 0,
      // required this.selectedLocation,
      required this.onPressFilter,
      required this.onPressReset,
      required this.onPressSort,
      required this.currentval})
      : super(key: key);

  @override
  State<OpenSortFilterList> createState() => _OpenSortFilterListState();
}

class _OpenSortFilterListState extends State<OpenSortFilterList>
    with SingleTickerProviderStateMixin {
  final List<Tab> myTabs = <Tab>[
    new Tab(text: 'Filter'),
    new Tab(text: 'Sort'),
  ];
  int selectedTabIndex = 0;
  // List<Widget> tabbarViewHoldingList = [];
  List<Widget> tabbarViewList = [];
  late TabController _tabController =
      new TabController(length: myTabs.length, vsync: this);

  @override
  void initState() {
    super.initState();
    setState(() {
      // _tabController.index = widget.selectedTabIndex;
      // selectedTabIndex = widget.selectedTabIndex;
    });
  }

  @override
  Widget build(BuildContext context) {
    tabbarViewList = [
      FilterWidget(
        onfilterpress: widget.onPressFilter,
      ),
      SortWidget(
        onfilterpress: widget.onPressSort,
        currentval: widget.currentval,
      )
    ];

    return DefaultTabController(
        length: myTabs.length,
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  child: TabBar(
                      controller: _tabController,
                      isScrollable: true,
                      indicatorPadding:
                          EdgeInsets.symmetric(horizontal: 16, vertical: 0),
                      onTap: (index) {
                        setState(() {
                          selectedTabIndex = index;
                        });
                      },
                      unselectedLabelStyle: customTextStyle(
                          fontStyle: FontStyle.BodyL_Regular,
                          color: FontColor.FontSecondary),
                      unselectedLabelColor: customColors().fontSecondary,
                      indicatorColor: customColors().primary,
                      indicatorSize: TabBarIndicatorSize.tab,
                      indicatorWeight: 2,
                      // indicatorPadding: const EdgeInsets.all(10),
                      labelColor: customColors().primary,
                      tabs: myTabs),
                ),
                Padding(
                  padding: const EdgeInsets.only(right: 16.0),
                  child: Align(
                    alignment: Alignment.centerRight,
                    child: InkWell(
                      onTap: () {
                        setState(() {
                          sortval = "All";
                        });
                        widget.onPressReset();
                      },
                      child: Text(
                        "Reset",
                        style: customTextStyle(
                          fontStyle: FontStyle.BodyL_SemiBold,
                          color: FontColor.Primary,
                        ).copyWith(color: customColors().primary as Color),
                      ),
                    ),
                  ),
                )
              ],
            ),
            tabbarViewList[selectedTabIndex]
          ],
        ));
  }
}

class FilterWidget extends StatelessWidget {
  final void Function(List<String>) onfilterpress;
  const FilterWidget({Key? key, required this.onfilterpress}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Divider(
          height: 0,
          thickness: 1,
          color: customColors().backgroundTertiary,
        ),
        Padding(
          padding: const EdgeInsets.only(left: 16.0, top: 16, bottom: 12),
          child: Align(
              alignment: Alignment.centerLeft,
              child: Text(
                "Position Type",
                style: customTextStyle(
                    fontStyle: FontStyle.BodyM_SemiBold,
                    color: FontColor.FontPrimary),
              )),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16.0),
          child: FilterItemListWidget(
            onfilterpress: onfilterpress,
            itemsList: const [
              {"text": "Open"},
              {"text": "Close"},
              {"text": "Todays Trade"}
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.all(16.0),
          child: Align(
              alignment: Alignment.centerLeft,
              child: Text("Product Type",
                  style: customTextStyle(
                      fontStyle: FontStyle.BodyM_SemiBold,
                      color: FontColor.FontPrimary))),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16.0),
          child: FilterItemListWidget(
            onfilterpress: onfilterpress,
            itemsList: const [
              {"text": "Cash"},
              {"text": "BTST"},
              {"text": "Intraday"},
              {"text": "MTF"},
              {"text": "Smartfolio"}
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.only(left: 16.0, top: 16, bottom: 12),
          child: Align(
              alignment: Alignment.centerLeft,
              child: Text("Segment Type",
                  style: customTextStyle(
                      fontStyle: FontStyle.BodyM_SemiBold,
                      color: FontColor.FontPrimary))),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16.0),
          child: FilterItemListWidget(
            onfilterpress: onfilterpress,
            itemsList: const [
              {"text": "Stock"},
              {"text": "Commodity"},
              {"text": "Currency"},
              {"text": "F&O"}
            ],
          ),
        ),
      ],
    );
  }
}

class SortWidget extends StatefulWidget {
  final void Function(String) onfilterpress;
  int currentval;
  SortWidget({Key? key, required this.onfilterpress, required this.currentval})
      : super(key: key);

  @override
  State<SortWidget> createState() => _SortWidgetState();
}

class _SortWidgetState extends State<SortWidget> {
  int _value = -1;
  List<String> Radiolistitem = [
    'A - Z',
    'Z - A',
    'Profit: Low - High',
    'Profit: High - Low',
    '% Profit Change: Low - High',
    '% Profit Change: High - Low',
    'Invested Value (Min - Max)',
    'Invested Value (Max - Min)',
  ];
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Divider(
          height: 0,
          thickness: 1,
          color: customColors().backgroundTertiary,
        ),
        Container(
          child: Padding(
            padding: const EdgeInsets.only(left: 10),
            child: Column(
              children: [
                ListView.builder(
                    shrinkWrap: true,
                    itemCount: Radiolistitem.length,
                    itemBuilder: (context, index) {
                      return MyRadioListTile<int>(
                        value: index,
                        groupValue: _value,
                        title: Text(
                          Radiolistitem[index],
                          style: customTextStyle(
                            fontStyle: FontStyle.BodyL_Regular,
                            color: FontColor.FontPrimary,
                          ),
                        ),
                        onChanged: (value) {
                          setState(() {
                            _value = value!;
                          });
                          widget.onfilterpress(value.toString());
                        },
                      );
                    }),
              ],
            ),
          ),
        )
      ],
    );
  }
}
