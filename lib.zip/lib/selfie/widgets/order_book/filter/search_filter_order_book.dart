import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/repository_layer/portfolio_content.dart';
// import 'package:selfie_mobile_flutter/constants/enums.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/custom_radio_button.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/sort.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class OrderSortFilter extends StatefulWidget {
  int selectedTabIndex;
  final void Function(List<String>) onPressFilter;
  final void Function(int index) onPresssort;
  final void Function() onPressReset;
  int currentval;
  OrderSortFilter(
      {Key? key,
      this.selectedTabIndex = 0,
      // required this.selectedLocation,
      required this.onPressFilter,
      required this.onPressReset,
      required this.onPresssort,
      required this.currentval})
      : super(key: key);

  @override
  State<OrderSortFilter> createState() => _OrderSortFilterState();
}

class _OrderSortFilterState extends State<OrderSortFilter>
    with SingleTickerProviderStateMixin {
  final List<Tab> myTabs = <Tab>[
    const Tab(text: 'Filter'),
    const Tab(text: 'Sort'),
  ];
  int selectedTabIndex = 0;
  List<Widget> tabbarViewHoldingList = [];
  List<Widget> tabbarViewPositionList = [];
  late TabController _tabController =
      new TabController(length: myTabs.length, vsync: this);

  @override
  void initState() {
    super.initState();
    setState(() {
      _tabController.index = widget.selectedTabIndex;
      selectedTabIndex = widget.selectedTabIndex;
    });
  }

  @override
  Widget build(BuildContext context) {
    tabbarViewPositionList = [
      FilterWidget(
        onfilterpress: widget.onPressFilter,
      ),
      SortWidget(
        onfilterpress: widget.onPresssort,
        currentval: widget.currentval,
      )
    ];

    return DefaultTabController(
        length: myTabs.length,
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  child: TabBar(
                      controller: _tabController,
                      isScrollable: true,
                      indicatorPadding:
                          EdgeInsets.symmetric(horizontal: 16, vertical: 0),
                      onTap: (index) {
                        setState(() {
                          selectedTabIndex = index;
                        });
                      },
                      unselectedLabelStyle: customTextStyle(
                          fontStyle: FontStyle.BodyL_Regular,
                          color: FontColor.FontSecondary),
                      unselectedLabelColor: customColors().fontSecondary,
                      indicatorColor: customColors().primary,
                      indicatorSize: TabBarIndicatorSize.tab,
                      indicatorWeight: 2,
                      labelColor: customColors().primary,
                      tabs: myTabs),
                ),
                Padding(
                  padding: const EdgeInsets.only(right: 16.0),
                  child: Align(
                    alignment: Alignment.centerRight,
                    child: InkWell(
                      onTap: () {
                        setState(() {
                          sortval = "All";
                        });
                        widget.onPressReset();
                        Navigator.pop(context);
                      },
                      child: Text(
                        "Reset",
                        style: customTextStyle(
                          fontStyle: FontStyle.BodyL_SemiBold,
                          color: FontColor.Primary,
                        ).copyWith(color: customColors().primary as Color),
                      ),
                    ),
                  ),
                )
              ],
            ),
            tabbarViewPositionList[selectedTabIndex]
          ],
        ));
  }
}

class SortWidget extends StatefulWidget {
  final void Function(int) onfilterpress;
  int currentval;
  SortWidget({Key? key, required this.onfilterpress, required this.currentval})
      : super(key: key);

  @override
  State<SortWidget> createState() => _SortWidgetState();
}

class _SortWidgetState extends State<SortWidget> {
  int? currentval;
  List<String> radiolistitem = [
    'A - Z',
    'Z - A',
  ];
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Divider(
          height: 0,
          thickness: 1,
          color: customColors().backgroundTertiary,
        ),
        Container(
          child: Padding(
            padding: const EdgeInsets.only(left: 10),
            child: Column(
              children: [
                ListView.builder(
                    shrinkWrap: true,
                    itemCount: radiolistitem.length,
                    itemBuilder: (context, index) {
                      return MyRadioListTile<int>(
                        value: index,
                        groupValue: widget.currentval,
                        title: Text(
                          radiolistitem[index],
                          style: customTextStyle(
                            fontStyle: FontStyle.BodyL_Regular,
                            color: FontColor.FontPrimary,
                          ),
                        ),
                        onChanged: (value) {
                          setState(() {
                            widget.currentval = value!;
                          });
                          widget.onfilterpress(value!);
                          Navigator.pop(context);
                        },
                      );
                    }),
              ],
            ),
          ),
        )
      ],
    );
  }
}

class FilterWidget extends StatelessWidget {
  final void Function(List<String>) onfilterpress;
  const FilterWidget({Key? key, required this.onfilterpress}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Divider(
          height: 0,
          thickness: 1,
          color: customColors().backgroundTertiary,
        ),
        Padding(
          padding: const EdgeInsets.only(left: 16.0, top: 16, bottom: 12),
          child: Align(
              alignment: Alignment.centerLeft,
              child: Text(
                "Trade Type",
                style: customTextStyle(
                    fontStyle: FontStyle.BodyM_SemiBold,
                    color: FontColor.FontPrimary),
              )),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16.0),
          child: FilterItemListWidget(
            onfilterpress: onfilterpress,
            itemsList: const [
              {"text": "Buy"},
              {"text": "Sell"},
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.all(16.0),
          child: Align(
              alignment: Alignment.centerLeft,
              child: Text("Product Type",
                  style: customTextStyle(
                      fontStyle: FontStyle.BodyM_SemiBold,
                      color: FontColor.FontPrimary))),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16.0),
          child: FilterItemListWidget(
            onfilterpress: onfilterpress,
            itemsList: const [
              {"text": "Cash"},
              {"text": "BTST"},
              {"text": "Intraday"},
              {"text": "MTF"},
              {"text": "Smartfolio"}
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.all(16.0),
          child: Align(
              alignment: Alignment.centerLeft,
              child: Text("Order Type",
                  style: customTextStyle(
                      fontStyle: FontStyle.BodyM_SemiBold,
                      color: FontColor.FontPrimary))),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16.0),
          child: FilterItemListWidget(
            onfilterpress: onfilterpress,
            itemsList: const [
              {"text": "Market"},
              {"text": "Limit"},
              {"text": "SL-Lmt"},
              {"text": "Basket Order"}
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.all(16.0),
          child: Align(
              alignment: Alignment.centerLeft,
              child: Text("Order Status",
                  style: customTextStyle(
                      fontStyle: FontStyle.BodyM_SemiBold,
                      color: FontColor.FontPrimary))),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16.0),
          child: FilterItemListWidget(
            onfilterpress: onfilterpress,
            itemsList: const [
              {"text": "Confirmed"},
              {"text": "Pending"},
              {"text": "Saved"},
            ],
          ),
        ),
      ],
    );
  }
}
