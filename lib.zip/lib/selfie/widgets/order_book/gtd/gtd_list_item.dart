import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/constants/formaters.dart';
import 'package:selfie_mobile_flutter/selfie/repository_layer/order_book_content.dart';
import 'package:selfie_mobile_flutter/selfie/repository_layer/order_book_content.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/order_book/open/open_list_item.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/custom_dot.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/options_widget.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class GTDListItem extends StatefulWidget {
  Map<String, dynamic> gtdList;
  GTDListItem({Key? key, required this.gtdList}) : super(key: key);

  @override
  State<GTDListItem> createState() => _GTDListTileState();
}

class _GTDListTileState extends State<GTDListItem> {
  var paint1 = Paint()
    ..color = customColors().success
    ..strokeCap = StrokeCap.round //rounded points
    ..strokeWidth = 10;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }

  triggerSection(String orderType) {
    switch (orderType) {
      case "1":
        {
          return "N/A";
        }
      case "2":
        {
          return "${widget.gtdList["PRICE"]}";
        }
      case "3":
        {
          return "${widget.gtdList["PRICE"]} / T-${widget.gtdList["TRIGGERPRICE"]}";
        }
      case "6":
        {
          return "T-${widget.gtdList["TRIGGERPRICE"]}";
        }
    }
  }

  @override
  Widget build(BuildContext context) {
    return InkWell(
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 16),
          decoration: BoxDecoration(
              border: Border(
            bottom:
                BorderSide(color: customColors().backgroundTertiary, width: 1),
          )),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Visibility(
                visible: true,
                child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Row(
                        children: [
                          Padding(
                            padding:
                                const EdgeInsets.symmetric(horizontal: 0.0),
                            child: getProductTypeWidget(
                                widget.gtdList["BUYORSELL"]),
                          ),
                          SizedBox(
                            width: 6,
                          ),
                          Padding(
                            padding:
                                const EdgeInsets.symmetric(horizontal: 0.0),
                            child: getProductTypeWidget(
                                widget.gtdList["PRODUCTTYPE"]),
                          ),
                        ],
                      ),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          // Text(
                          //   "${widget.gtdList["amo"] ?? ""}",
                          //   style: customTextStyle(
                          //       fontStyle: FontStyle.BodyS_SemiBold,
                          //       color: FontColor.FontSecondary),
                          // ),
                          // if (widget.gtdList["amo"] != null)
                          //   const Padding(
                          //     padding: EdgeInsets.only(left: 6.0, right: 6.0),
                          //     child: CustomDot(),
                          //   ),
                          // getOrderStatusWidget(widget.gtdList["status"]),
                          Text(
                            "AMO",
                            style: customTextStyle(
                                fontStyle: FontStyle.BodyS_SemiBold,
                                color: FontColor.FontSecondary),
                          ),
                          // if (widget.gtdList["amo"] != null)
                          const Padding(
                            padding: EdgeInsets.only(left: 6.0, right: 6.0),
                            child: CustomDot(),
                          ),
                          getOrderStatusWidget("ACTIVE"),
                        ],
                      )
                    ]),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 10),
                child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        widget.gtdList["SECURITYCODE"],
                        style: customTextStyle(
                            fontStyle: FontStyle.BodyL_SemiBold,
                            color: FontColor.FontPrimary),
                      ),
                      Text(
                        // "${Formats.valueFormat.format(widget.gtdList["value"])} / T-${Formats.valueFormat.format(widget.gtdList["total_value"])}",
                        triggerSection(widget.gtdList["PRICECONDITION"])
                            .toString(),
                        style: customTextStyle(
                            fontStyle: FontStyle.BodyL_SemiBold,
                            color: FontColor.FontPrimary),
                      ),
                    ]),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 4.0),
                child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          RichText(
                              text: TextSpan(
                                  text: "${widget.gtdList["QUANTITY"]}",
                                  style: customTextStyle(
                                      fontStyle: FontStyle.BodyM_SemiBold,
                                      color: FontColor.FontSecondary),
                                  children: [
                                TextSpan(
                                  text: " Qty",
                                  style: customTextStyle(
                                      fontStyle: FontStyle.BodyM_Regular,
                                      color: FontColor.FontTertiary),
                                )
                              ])),
                          const Padding(
                            padding: EdgeInsets.only(left: 6.0, right: 6.0),
                            child: CustomDot(),
                          ),
                          // CustomDotSeparator(),
                          Text(
                            widget.gtdList["ORDERTIME"]
                                .toString()
                                .substring(0, 11),
                            style: customTextStyle(
                                fontStyle: FontStyle.BodyM_SemiBold,
                                color: FontColor.FontSecondary),
                          ),
                        ],
                      ),
                      RichText(
                          text: TextSpan(
                              text: "LTP : ",
                              style: customTextStyle(
                                  fontStyle: FontStyle.BodyM_Regular,
                                  color: FontColor.FontTertiary),
                              children: [
                            TextSpan(
                              text: "0.00",
                              style: customTextStyle(
                                  fontStyle: FontStyle.BodyM_SemiBold,
                                  color: FontColor.FontSecondary),
                            )
                          ])),
                    ]),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
