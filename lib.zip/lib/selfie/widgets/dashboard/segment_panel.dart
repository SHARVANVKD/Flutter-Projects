import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class SegmentPanel extends StatefulWidget {
  String title;
  String endTitle;

  SegmentPanel({Key? key, required this.title, this.endTitle = ""})
      : super(key: key);

  @override
  State<SegmentPanel> createState() => _SegmentPanelState();
}

class _SegmentPanelState extends State<SegmentPanel> {
  @override
  Widget build(BuildContext context) {
    return Container(
      height: 48.0,
      width: MediaQuery.of(context).size.width,
      decoration: BoxDecoration(
          border: Border.all(color: customColors().backgroundTertiary),
          borderRadius: BorderRadius.circular(4.0)),
      child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        Padding(
          padding: const EdgeInsets.only(left: 12.0),
          child: Text(
            widget.title,
            style: customTextStyle(
                fontStyle: FontStyle.BodyL_SemiBold,
                color: FontColor.FontPrimary),
          ),
        ),
        Padding(
          padding: const EdgeInsets.only(right: 20.8),
          child: Row(
            children: [
              Text(
                widget.endTitle,
                style: customTextStyle(
                    fontStyle: FontStyle.BodyL_Bold, color: FontColor.Primary),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 10.0),
                child: Image.asset(
                  "assets/arrow_down.png",
                ),
              )
            ],
          ),
        )
      ]),
    );
  }
}
