import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/dashboard/my_dashboard_container.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';
import 'package:syncfusion_flutter_charts/charts.dart';

class RadialBarChart extends StatefulWidget {
  List<ChartData> chartData;
  double height;
  double toppadd;
  String centerval;
  RadialBarChart(
      {Key? key,
      required this.chartData,
      required this.height,
      required this.toppadd,
      required this.centerval})
      : super(key: key);

  @override
  State<RadialBarChart> createState() => _RadialBarChartState();
}

class _RadialBarChartState extends State<RadialBarChart> {
  @override
  Widget build(BuildContext context) {
    return Container(
      height: widget.height,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          Expanded(
            child: Stack(
              children: [
                MediaQuery.removePadding(
                  context: context,
                  removeTop: true,
                  child: SfCircularChart(
                    palette: <Color>[Color.fromRGBO(246, 78, 75, 0.2)],
                    series: <CircularSeries>[
                      RadialBarSeries<ChartData, String>(
                          dataSource: widget.chartData,
                          maximumValue: 360,
                          xValueMapper: (ChartData data, _) => data.content,
                          yValueMapper: (ChartData data, _) => data.gdp,
                          pointColorMapper: (ChartData data, _) =>
                              data.pointcolor,
                          radius: '105%',
                          gap: '15%',
                          name: "15",
                          innerRadius: '40%',
                          cornerStyle: CornerStyle.bothCurve),
                    ],
                  ),
                ),
                Positioned.fill(
                    child: Align(
                        alignment: Alignment.center,
                        child: Text(
                          widget.centerval,
                          style: customTextStyle(
                              fontStyle: FontStyle.HeaderM_Bold,
                              color: FontColor.FontPrimary),
                        )))
              ],
            ),
          ),
          Expanded(
            child: Padding(
              padding: EdgeInsets.only(left: 35.0, top: widget.toppadd),
              child: Column(
                children: [
                  Row(
                    children: [
                      Container(
                        height: 44,
                        width: 44,
                        decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            border: Border.all(
                                width: 4.0,
                                color: widget.chartData[2].pointcolor)),
                        child: Center(
                            child: Text(
                          widget.chartData[2].gdpcount,
                          style: customTextStyle(
                              fontStyle: FontStyle.BodyL_SemiBold,
                              color: FontColor.FontPrimary),
                        )),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 10.0),
                        child: Text(
                          widget.chartData[2].content,
                          style: customTextStyle(
                              fontStyle: FontStyle.BodyM_SemiBold,
                              color: FontColor.FontPrimary),
                        ),
                      )
                    ],
                  ),
                  Row(
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(top: 10.0),
                        child: Container(
                          height: 44,
                          width: 44,
                          decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              border: Border.all(
                                  width: 4.0,
                                  color: widget.chartData[1].pointcolor)),
                          child: Center(
                              child: Text(
                            widget.chartData[1].gdpcount,
                            style: customTextStyle(
                              fontStyle: FontStyle.BodyL_SemiBold,
                              color: FontColor.FontPrimary,
                            ),
                          )),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 10.0),
                        child: Text(
                          widget.chartData[1].content,
                          style: customTextStyle(
                              fontStyle: FontStyle.BodyM_SemiBold,
                              color: FontColor.FontPrimary),
                        ),
                      )
                    ],
                  ),
                  Row(
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(top: 10.0),
                        child: Container(
                          height: 44,
                          width: 44,
                          decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              border: Border.all(
                                  width: 4.0,
                                  color: widget.chartData[0].pointcolor)),
                          child: Center(
                              child: Text(
                            widget.chartData[0].gdpcount,
                            style: customTextStyle(
                                fontStyle: FontStyle.BodyL_SemiBold,
                                color: FontColor.FontPrimary),
                          )),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 10.0),
                        child: Text(
                          widget.chartData[0].content,
                          style: customTextStyle(
                              fontStyle: FontStyle.BodyM_SemiBold,
                              color: FontColor.FontPrimary),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
          SizedBox(),
          SizedBox()
        ],
      ),
    );
  }
}

class ChartData2 {
  ChartData2(this.xVal, this.yVal, this.pointShader);
  final String xVal;
  final int yVal;
  final Shader pointShader;
}
