import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order_window/order_window_components/order_window_title_component.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class SegmentSheetInner extends StatefulWidget {
  int selected;
  final Function(int) onChanged;
  SegmentSheetInner({Key? key, required this.selected, required this.onChanged})
      : super(key: key);

  @override
  State<SegmentSheetInner> createState() => _SegmentSheetInnerState();
}

class _SegmentSheetInnerState extends State<SegmentSheetInner> {
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 12.0, horizontal: 16.0),
          child: Row(
            children: [
              Text(
                "Segment",
                style: customTextStyle(
                    fontStyle: FontStyle.HeaderXS_SemiBold,
                    color: FontColor.FontPrimary),
              )
            ],
          ),
        ),
        Container(
          height: 1,
          color: customColors().backgroundTertiary,
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: ListView.builder(
              itemCount: segmentoptions.length,
              shrinkWrap: true,
              itemBuilder: (context, index) {
                return InkWell(
                  onTap: () {
                    setState(() {
                      widget.selected = index;
                    });
                    widget.onChanged(index);
                    Navigator.of(context).pop();
                  },
                  child: Container(
                    padding: const EdgeInsets.symmetric(vertical: 16.0),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        CustomRadioButton(
                            noLabel: true,
                            value: index,
                            groupValue: widget.selected,
                            onChanged: (int val) {
                              setState(() {
                                widget.selected = val;
                              });
                              widget.onChanged(index);
                              Navigator.of(context).pop();
                            }),
                        Expanded(
                          child: Padding(
                            padding: const EdgeInsets.only(left: 12.0),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(segmentoptions[index]["name"],
                                    style: customTextStyle(
                                        fontStyle: FontStyle.BodyL_Regular,
                                        color: FontColor.FontPrimary)),
                              ],
                            ),
                          ),
                        )
                      ],
                    ),
                  ),
                );
              }),
        )
      ],
    );
  }
}

List<Map<String, dynamic>> segmentoptions = [
  {
    "name": "All",
    "option": false,
  },
  {
    "name": "Equity",
    "option": true,
  },
  {
    "name": "Futured & Options",
    "option": false,
  },
  {
    "name": "Currency",
    "option": false,
  },
  {
    "name": "Commodity",
    "option": false,
  },
];
