import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/constants/formaters.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class PsitionProfitCard extends StatefulWidget {
  double amount;
  String title;
  double width;
  double height;
  PsitionProfitCard(
      {Key? key,
      required this.amount,
      required this.title,
      this.height = double.maxFinite,
      this.width = double.maxFinite})
      : super(key: key);

  @override
  State<PsitionProfitCard> createState() => _PsitionProfitCardState();
}

class _PsitionProfitCardState extends State<PsitionProfitCard> {
  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: const BorderRadius.all(Radius.circular(4)),
        color: customColors().backgroundSecondary,
      ),
      height: widget.height,
      width: widget.width,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Text(
            widget.title.toUpperCase(),
            style: customTextStyle(
                fontStyle: FontStyle.BodyM_SemiBold,
                color: FontColor.FontSecondary),
          ),
          const SizedBox(height: 4),
          Text(
            widget.amount.toString().contains("-")
                ? Formats.valueFormat.format(widget.amount)
                : "+${Formats.valueFormat.format(widget.amount)}",
            style: customTextStyle(
                fontStyle: FontStyle.HeaderXS_Bold,
                color: widget.amount.toString().contains("-")
                    ? FontColor.Danger
                    : FontColor.Success),
          ),
        ],
      ),
    );
  }
}
