import 'package:flutter/material.dart';

import '../../../theme/styles.dart';

class FoFilterListItem extends StatelessWidget {
  int index;
  Map<String, dynamic> list;
  FoFilterListItem({Key? key, required this.index, required this.list})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.only(left: 12.0, right: 12.0),
            width: MediaQuery.of(context).size.width,
            height: 40.0,
            child: Row(
              children: [
                Expanded(
                    child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Text(
                          list['option'],
                          style: customTextStyle(
                              fontStyle: FontStyle.BodyM_SemiBold,
                              color: FontColor.FontPrimary),
                        )
                      ],
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Text(
                          list['sub'],
                          style: customTextStyle(
                              fontStyle: FontStyle.BodyS_Regular,
                              color: FontColor.FontSecondary),
                        )
                      ],
                    ),
                  ],
                )),
                Expanded(
                    child: Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    Text(
                      list['13th'],
                      style: list['13th'].toString().contains('+')
                          ? customTextStyle(
                              fontStyle: FontStyle.BodyM_SemiBold,
                              color: FontColor.Success)
                          : customTextStyle(
                              fontStyle: FontStyle.BodyM_SemiBold,
                              color: FontColor.Danger),
                    )
                  ],
                )),
                Expanded(
                    child: Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    Text(
                      list['change'],
                      style: list['change'].toString().contains('+')
                          ? customTextStyle(
                              fontStyle: FontStyle.BodyM_SemiBold,
                              color: FontColor.Success)
                          : customTextStyle(
                              fontStyle: FontStyle.BodyM_SemiBold,
                              color: FontColor.Danger),
                    )
                  ],
                )),
                Expanded(
                    child: Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    Text(
                      list['14th'],
                      style: list['14th'].toString().contains('+')
                          ? customTextStyle(
                              fontStyle: FontStyle.BodyM_SemiBold,
                              color: FontColor.Success)
                          : customTextStyle(
                              fontStyle: FontStyle.BodyM_SemiBold,
                              color: FontColor.Danger),
                    )
                  ],
                )),
              ],
            ),
          )
        ],
      ),
    );
  }
}
