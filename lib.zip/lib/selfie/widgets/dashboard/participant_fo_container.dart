import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/dashboard/all_options.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/dashboard/fofilter_fii.dart';

import '../../../theme/styles.dart';

class ParticipantFOContainer extends StatefulWidget {
  const ParticipantFOContainer({Key? key}) : super(key: key);

  @override
  State<ParticipantFOContainer> createState() => _ParticipantFOContainerState();
}

class _ParticipantFOContainerState extends State<ParticipantFOContainer>
    with SingleTickerProviderStateMixin {
  late TabController _controller;

  int initialIndex = 0;
  String tabName = "Fll";
  int index = 0;
  List<Tab> tablist = [
    Tab(
      text: "Fll",
    ),
    Tab(
      text: "Pro",
    ),
    Tab(
      text: 'Clients',
    ),
    Tab(
      text: 'Dll',
    ),
    Tab(
      text: 'All%',
    )
  ];

  List<Widget> fofilterwidgets = [];
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    initialIndex = 0;
    tabName = "Fll";
    _controller = TabController(length: tablist.length, vsync: this);

    _controller.addListener(() {
      setState(() {
        initialIndex = _controller.index;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    fofilterwidgets = [
      FoFilterFill(),
      FoFilterFill(),
      FoFilterFill(),
      FoFilterFill(),
      FoFilterFill(),
    ];

    return Column(
      children: [
        Container(
          width: MediaQuery.of(context).size.width,
          decoration: BoxDecoration(
              border: Border(
                  bottom: BorderSide(
                      width: 1.0, color: customColors().backgroundTertiary))),
          child: TabBar(
            controller: _controller,
            tabs: tablist,
            isScrollable: true,
            labelStyle: customTextStyle(
                fontStyle: FontStyle.BodyL_SemiBold, color: FontColor.Primary),
            labelColor: customColors().primary,
            indicatorSize: TabBarIndicatorSize.label,
            indicatorColor: customColors().primary,
            unselectedLabelStyle: customTextStyle(
                fontStyle: FontStyle.BodyL_Regular,
                color: FontColor.FontSecondary),
            unselectedLabelColor: customColors().fontSecondary,
          ),
        ),
        Builder(builder: (_) {
          if (_controller.index == 0) {
            return FoFilterFill(); //1st custom tabBarView
          } else if (_controller.index == 1) {
            return FoFilterFill(); //2nd tabView
          } else if (_controller.index == 2) {
            return FoFilterFill(); //3rd tabView
          } else if (_controller.index == 3) {
            return FoFilterFill(); //3rd tabView
          } else {
            return AllOptions(); //3rd tabView
          }
        }),
      ],
    );
  }
}
