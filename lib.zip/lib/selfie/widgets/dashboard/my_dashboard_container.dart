import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order_window/order_window_components/order_window_title_component.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/scrollable_bottomsheet/scrollable_bottomsheet.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/dashboard/action_tile.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/dashboard/bar_chart_details.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/dashboard/margin_details.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/dashboard/position_profit_card.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/dashboard/radial_bar_chart.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/dashboard/recomendation_window.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/dashboard/segment_panel.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/dashboard/segment_sheet_inner.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/portfolio/portfolio_card/invetment_card.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';
import 'package:syncfusion_flutter_datepicker/datepicker.dart';

class MyDashBoardContainer extends StatefulWidget {
  const MyDashBoardContainer({Key? key}) : super(key: key);

  @override
  State<MyDashBoardContainer> createState() => _MyDashBoardContainerState();
}

class _MyDashBoardContainerState extends State<MyDashBoardContainer> {
  int groupval = 0;
  int segmenttype = 1;
  bool isSelected = true;
  final events = [
    Event(DateTime.now(), 'test1'),
    Event(DateTime.now(), 'test2'),
    Event(DateTime.now(), 'test3'),
    Event(DateTime.now(), 'test4'),
  ];
  List<DateTime> datelist = [];
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(
          top: 20.0, bottom: 23.0, left: 16.0, right: 16.0),
      child: SingleChildScrollView(
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  "Margin",
                  style: customTextStyle(
                      fontStyle: FontStyle.HeaderXS_Bold,
                      color: FontColor.FontPrimary),
                ),
                Row(
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(right: 6.0),
                      child: Text(
                        "Add Funds",
                        style: customTextStyle(
                            fontStyle: FontStyle.BodyL_SemiBold,
                            color: FontColor.Primary),
                      ),
                    ),
                    Image.asset('assets/strokeright.png')
                  ],
                )
              ],
            ),
            Padding(
              padding: const EdgeInsets.only(top: 8.0),
              child: MarginDetails(
                title1: "Margin Available",
                title2: "Used Margin",
                todaymarginused: 974.45,
                totalmarginavail: 574.45,
                totalPercentage: "",
                todayPercentage: "",
                height: 84.0,
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 8.0),
              child: Container(
                height: 84.0,
                width: MediaQuery.of(context).size.width,
                decoration: BoxDecoration(
                  borderRadius: const BorderRadius.all(Radius.circular(4)),
                  color: customColors().backgroundSecondary,
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Text(
                      "Provisional Cash Balance".toUpperCase(),
                      style: customTextStyle(
                          fontStyle: FontStyle.BodyM_SemiBold,
                          color: FontColor.FontSecondary),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(top: 8.0),
                      child: RichText(
                        text: TextSpan(
                            text: "₹ ",
                            style: customTextStyle(
                                fontStyle: FontStyle.HeaderS_Bold,
                                color: FontColor.FontPrimary),
                            children: <TextSpan>[
                              TextSpan(
                                text: "${1574.45}",
                                style: customTextStyle(
                                    fontStyle: FontStyle.HeaderS_Bold,
                                    color: FontColor.FontPrimary),
                              ),
                            ]),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 40.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    "Portfolio",
                    style: customTextStyle(
                        fontStyle: FontStyle.HeaderXS_Bold,
                        color: FontColor.FontPrimary),
                  ),
                  Row(
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(right: 6.0, bottom: 3),
                        child: Text(
                          "View Portfolio",
                          style: customTextStyle(
                              fontStyle: FontStyle.BodyL_SemiBold,
                              color: FontColor.Primary),
                        ),
                      ),
                      Image.asset('assets/strokeright.png')
                    ],
                  )
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 12.0),
              child: Container(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      child: InvestmentDetailCard(
                        amount: 2802325,
                        title: "INVESTED",
                        height: 78.0,
                      ),
                    ),
                    SizedBox(
                      width: 12,
                    ),
                    Expanded(
                      child: InvestmentDetailCard(
                        amount: 3002325,
                        title: "CURRENT",
                        height: 78.0,
                      ),
                    )
                  ],
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 12.0),
              child: MarginDetails(
                verticalDividerPadding: 16,
                title1: "Total P&L",
                title2: "Today’s P&L",
                todaymarginused: 200000,
                totalmarginavail: 100000,
                totalPercentage: "32.10",
                todayPercentage: "7.87",
                height: 98.0,
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 20.0),
              child: Container(
                height: 40.0,
                width: MediaQuery.of(context).size.width,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(4.0),
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Expanded(
                      flex: 70,
                      child: Container(
                        decoration: BoxDecoration(
                            color: customColors().islandAqua,
                            borderRadius: BorderRadius.only(
                                topLeft: Radius.circular(4.0),
                                bottomLeft: Radius.circular(5.0))),
                      ),
                    ),
                    Expanded(
                      flex: 100,
                      child: Container(
                        color: customColors().dodgerBlue,
                      ),
                    ),
                    Expanded(
                      flex: 86,
                      child: Container(
                        color: customColors().accent,
                      ),
                    ),
                    Expanded(
                        flex: 72,
                        child: Container(
                          decoration: BoxDecoration(
                              color: customColors().ultraviolet,
                              borderRadius: BorderRadius.only(
                                  bottomRight: Radius.circular(6.0),
                                  topRight: Radius.circular(5.0))),
                        ))
                  ],
                ),
              ),
            ),
            BarChartDetails(),
            Padding(
              padding: const EdgeInsets.only(top: 40.0),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Monthly P&L",
                    style: customTextStyle(
                        fontStyle: FontStyle.HeaderXS_Bold,
                        color: FontColor.FontPrimary),
                  )
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 20.0),
              child: Row(
                children: [
                  Row(
                    children: [
                      CustomRadioButton(
                          noLabel: true,
                          value: 0,
                          groupValue: groupval,
                          onChanged: (int val) {
                            setState(() {
                              groupval = val;
                            });
                            // widget.onChanged(index);
                          }),
                      Padding(
                        padding: const EdgeInsets.only(left: 8.0),
                        child: InkWell(
                          onTap: () {
                            setState(() {
                              groupval = 0;
                            });
                          },
                          child: Text(
                            "Current Month",
                            style: customTextStyle(
                                fontStyle: FontStyle.BodyL_Regular,
                                color: FontColor.FontPrimary),
                          ),
                        ),
                      )
                    ],
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left: 24.0),
                    child: Row(
                      children: [
                        CustomRadioButton(
                            noLabel: true,
                            value: 1,
                            groupValue: groupval,
                            onChanged: (int val) {
                              setState(() {
                                groupval = val;
                              });
                              // widget.onChanged(index);
                            }),
                        Padding(
                          padding: const EdgeInsets.only(left: 8.0),
                          child: InkWell(
                            onTap: () {
                              setState(() {
                                groupval = 1;
                              });
                            },
                            child: Text(
                              "Last Month",
                              style: customTextStyle(
                                  fontStyle: FontStyle.BodyL_Regular,
                                  color: FontColor.FontPrimary),
                            ),
                          ),
                        )
                      ],
                    ),
                  )
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 20.0, bottom: 4.0),
              child: Row(
                children: [
                  Text(
                    "Segment",
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyL_Regular,
                        color: FontColor.FontPrimary),
                  )
                ],
              ),
            ),
            InkWell(
              onTap: () {
                customShowModalBottomSheet(
                    context: context,
                    inputWidget: SegmentSheetInner(
                      selected: segmenttype,
                      onChanged: updatesegment,
                    ));
              },
              child: SegmentPanel(
                title: segmentoptions[segmenttype]['name'],
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 20.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  AbsorbPointer(
                    absorbing: true,
                    child: Container(
                      height: 220,
                      width: 200,
                      child: SfDateRangePicker(
                        headerHeight: 0,
                        showTodayButton: false,
                        selectionColor: Colors.transparent,
                        todayHighlightColor: Colors.transparent,
                        view: DateRangePickerView.month,
                        allowViewNavigation: false,
                        initialSelectedDate: DateTime(2022, 03, 27),
                        initialDisplayDate: DateTime(2022, 03, 27),
                        monthViewSettings:
                            DateRangePickerMonthViewSettings(blackoutDates: [
                          DateTime(2022, 03, 27),
                          DateTime(2022, 03, 28),
                          DateTime(2022, 03, 29),
                          DateTime(2022, 03, 31)
                        ], specialDates: [
                          DateTime(2022, 03, 08),
                          DateTime(2022, 03, 09),
                          DateTime(2022, 03, 10),
                          DateTime(2022, 03, 11),
                          DateTime(2022, 03, 12),
                          DateTime(2022, 03, 13),
                        ], showTrailingAndLeadingDates: false),
                        monthCellStyle: DateRangePickerMonthCellStyle(
                          selectionColor: Colors.transparent,
                          selectionTextStyle:
                              TextStyle(color: Colors.transparent),
                          rangeSelectionColor: Colors.transparent,
                          startRangeSelectionColor: Colors.transparent,
                          todayTextStyle: TextStyle(color: Colors.transparent),
                          cellDecoration: BoxDecoration(
                              color: customColors().backgroundTertiary,
                              borderRadius: BorderRadius.circular(4.0)),
                          textStyle: TextStyle(
                            color: Colors.transparent,
                          ),
                          blackoutDatesDecoration: BoxDecoration(
                            color: Colors.red,
                            borderRadius: BorderRadius.circular(4.0),
                          ),
                          specialDatesDecoration: BoxDecoration(
                            color: Colors.green,
                            borderRadius: BorderRadius.circular(4.0),
                          ),
                          blackoutDateTextStyle:
                              TextStyle(color: Colors.transparent),
                          specialDatesTextStyle:
                              const TextStyle(color: Colors.transparent),
                        ),
                        backgroundColor: customColors().backgroundPrimary,
                        selectableDayPredicate: (DateTime dateTime) {
                          if (dateTime == DateTime(2021, 9, 5)) {
                            return false;
                          }
                          return true;
                        },
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(top: 6.0),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Text(
                          'March Realized P&L',
                          style: customTextStyle(
                              fontStyle: FontStyle.BodyM_SemiBold,
                              color: FontColor.FontSecondary),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(top: 8.0),
                          child: Text(
                            '₹ 157456.45',
                            style: customTextStyle(
                                fontStyle: FontStyle.HeaderS_Bold,
                                color: FontColor.Success),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(top: 16.0),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Realized Profit',
                                style: customTextStyle(
                                    fontStyle: FontStyle.BodyS_Regular,
                                    color: FontColor.FontPrimary),
                              ),
                              Padding(
                                padding: const EdgeInsets.only(left: 8.0),
                                child: Container(
                                  height: 12,
                                  width: 12,
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(2.0),
                                      color: customColors().success),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(top: 6.0),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Realized Loss',
                                style: customTextStyle(
                                    fontStyle: FontStyle.BodyS_Regular,
                                    color: FontColor.FontPrimary),
                              ),
                              Padding(
                                padding: const EdgeInsets.only(left: 8.0),
                                child: Container(
                                  height: 12,
                                  width: 12,
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(2.0),
                                      color: Color.fromRGBO(246, 78, 75, 1)),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(top: 6.0),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'No Trades',
                                style: customTextStyle(
                                    fontStyle: FontStyle.BodyS_Regular,
                                    color: FontColor.FontPrimary),
                              ),
                              Padding(
                                padding: const EdgeInsets.only(left: 8.0),
                                child: Container(
                                  height: 12,
                                  width: 12,
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(2.0),
                                      color: customColors().backgroundTertiary),
                                ),
                              ),
                            ],
                          ),
                        )
                      ],
                    ),
                  )
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 20.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    "Positions",
                    style: customTextStyle(
                        fontStyle: FontStyle.HeaderXS_Bold,
                        color: FontColor.FontPrimary),
                  ),
                  Row(
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(right: 6.0, bottom: 2),
                        child: Text(
                          "View All",
                          style: customTextStyle(
                              fontStyle: FontStyle.BodyL_SemiBold,
                              color: FontColor.Primary),
                        ),
                      ),
                      Image.asset('assets/strokeright.png')
                    ],
                  )
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 12.0),
              child: Container(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      child: PsitionProfitCard(
                        amount: 3000025,
                        title: "Unrealized Profit",
                        height: 78.0,
                      ),
                    ),
                    SizedBox(
                      width: 12,
                    ),
                    Expanded(
                      child: PsitionProfitCard(
                        amount: -10256.45,
                        title: "Realized Profit",
                        height: 78.0,
                      ),
                    )
                  ],
                ),
              ),
            ),
            RadialBarChart(
              chartData: chartData,
              height: 200.0,
              toppadd: 20.0,
              centerval: '10',
            ),
            Padding(
              padding: const EdgeInsets.only(top: 20.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    "Orders",
                    style: customTextStyle(
                        fontStyle: FontStyle.HeaderXS_Bold,
                        color: FontColor.FontPrimary),
                  ),
                  Row(
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(right: 6.0, bottom: 2),
                        child: Text(
                          "View All",
                          style: customTextStyle(
                              fontStyle: FontStyle.BodyL_SemiBold,
                              color: FontColor.Primary),
                        ),
                      ),
                      Image.asset('assets/strokeright.png')
                    ],
                  )
                ],
              ),
            ),
            RadialBarChart(
              chartData: orderchartData,
              height: 200.0,
              toppadd: 20.0,
              centerval: '09',
            ),
            Padding(
              padding: const EdgeInsets.only(top: 20.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    "Recommendation",
                    style: customTextStyle(
                        fontStyle: FontStyle.HeaderXS_Bold,
                        color: FontColor.FontPrimary),
                  ),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(right: 6.0, bottom: 2),
                        child: Text(
                          "View All",
                          style: customTextStyle(
                              fontStyle: FontStyle.BodyL_SemiBold,
                              color: FontColor.Primary),
                        ),
                      ),
                      Image.asset('assets/strokeright.png')
                    ],
                  )
                ],
              ),
            ),
            const Padding(
              padding: EdgeInsets.only(top: 14.0),
              child: RecomendationWindow(),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 40.0),
              child: Row(
                children: [
                  Text(
                    "Actions Required",
                    style: customTextStyle(
                        fontStyle: FontStyle.HeaderXS_Bold,
                        color: FontColor.FontPrimary),
                  )
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 12.0),
              child: ListView.builder(
                  physics: ScrollPhysics(),
                  itemCount: actioncontents.length,
                  shrinkWrap: true,
                  itemBuilder: (context, index) {
                    return Padding(
                      padding: const EdgeInsets.only(top: 4.0),
                      child: ActionTile(
                        actioncontents: actioncontents[index],
                      ),
                    );
                  }),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 18.0, bottom: 34.0),
              child: Container(
                  height: 60,
                  width: MediaQuery.of(context).size.width,
                  decoration: BoxDecoration(
                      color: customColors().backgroundSecondary,
                      borderRadius: BorderRadius.circular(4.0)),
                  child: Padding(
                    padding: EdgeInsets.only(right: 18.0, left: 16.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          "Statutory Payout (In 10 days)",
                          style: customTextStyle(
                              fontStyle: FontStyle.BodyL_SemiBold,
                              color: FontColor.FontPrimary),
                        ),
                        Text(
                          "01-03-22",
                          style: customTextStyle(
                              fontStyle: FontStyle.BodyL_Regular,
                              color: FontColor.FontSecondary),
                        )
                      ],
                    ),
                  )),
            )
          ],
        ),
      ),
    );
  }

  final List<ChartData> chartData = [
    ChartData('Closed', 40, customColors().warning, "01"),
    ChartData('Short', 110, customColors().danger, "03"),
    ChartData('Long', 270, green500, "06"),
  ];

  final List<ChartData> orderchartData = [
    ChartData('Others', 360, Color.fromRGBO(246, 78, 75, 0.2), "00"),
    ChartData('Pending', 110, customColors().accent, "03"),
    ChartData('Executed', 270, green500, "06"),
  ];

  final List<Map<String, dynamic>> actioncontents = [
    {
      'title': 'AMC Dues',
      'content': 'AMC due is Rs 560/-',
    },
    {
      'title': 'KYC update',
      'content': 'Update your KYC details to secure your demat account.',
    },
    {
      'title': 'POA',
      'content': 'Submit a Power of Attorney documents.',
    },
    {
      'title': 'Smartfolio',
      'content': 'You have not accepted Smartfolio Recommendations ',
    },
    {
      'title': 'Pending Pledge',
      'content': 'You have not accepted the pledge ',
    },
  ];

  void updatesegment(int st) {
    setState(() {
      segmenttype = st;
    });
  }
}

class ChartData {
  final String content;
  final int gdp;
  final Color pointcolor;
  final String gdpcount;
  ChartData(this.content, this.gdp, this.pointcolor, this.gdpcount);
}

class Event {
  final DateTime date;
  final String title;

  Event(this.date, this.title);

  Event copyWith({DateTime? date, String? title}) => Event(
        date ?? this.date,
        title ?? this.title,
      );
}
