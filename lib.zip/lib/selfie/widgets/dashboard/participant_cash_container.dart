import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/dashboard/cash_participant_list_item.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class ParticipantCashContainer extends StatefulWidget {
  const ParticipantCashContainer({Key? key}) : super(key: key);

  @override
  State<ParticipantCashContainer> createState() =>
      _ParticipantCashContainerState();
}

class _ParticipantCashContainerState extends State<ParticipantCashContainer> {
  List<Map<String, dynamic>> cashpartdata = [
    {
      'day': '15 Feb',
      'fii': '+18,486.25',
      'dii': '-19,220.50',
      'net': '+1202.25'
    },
    {
      'day': '14 Feb',
      'fii': '+18,486.25',
      'dii': '-19,220.50',
      'net': '+1202.25'
    },
    {
      'day': '13 Feb',
      'fii': '+18,486.25',
      'dii': '-19,220.50',
      'net': '-1202.25'
    },
    {
      'day': '12 Feb',
      'fii': '+18,486.25',
      'dii': '-19,220.50',
      'net': '-1202.25'
    },
    {
      'day': '11 Feb',
      'fii': '+18,486.25',
      'dii': '-19,220.50',
      'net': '+1202.25'
    }
  ];

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.only(left: 12.0, right: 12.0),
            child: Row(
              children: [
                Expanded(child: SizedBox()),
                Expanded(
                    child: Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(
                      "Fll",
                      style: customTextStyle(
                          fontStyle: FontStyle.BodyM_SemiBold,
                          color: FontColor.FontSecondary),
                    )
                  ],
                )),
                Expanded(
                    child: Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(
                      "Dll",
                      style: customTextStyle(
                          fontStyle: FontStyle.BodyM_SemiBold,
                          color: FontColor.FontSecondary),
                    )
                  ],
                )),
                Expanded(
                    child: Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(
                      "Net",
                      style: customTextStyle(
                          fontStyle: FontStyle.BodyM_SemiBold,
                          color: FontColor.FontSecondary),
                    )
                  ],
                ))
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 16.0),
            child: ListView.builder(
                shrinkWrap: true,
                itemCount: cashpartdata.length,
                physics: ScrollPhysics(),
                itemBuilder: (context, index) {
                  return CashParticipantlistItem_(
                    index: index,
                    cashpartdata: cashpartdata,
                  );
                }),
          ),
          Container(
            padding: const EdgeInsets.only(left: 12.0, right: 12.0),
            width: MediaQuery.of(context).size.width,
            height: 40.0,
            decoration:
                BoxDecoration(color: customColors().backgroundSecondary),
            child: Row(
              children: [
                Expanded(
                    child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Text(
                      "Total",
                      style: customTextStyle(
                          fontStyle: FontStyle.BodyM_SemiBold,
                          color: FontColor.FontPrimary),
                    )
                  ],
                )),
                Expanded(
                    child: Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    Text(
                      "+68486.25",
                      style: customTextStyle(
                          fontStyle: FontStyle.BodyM_SemiBold,
                          color: FontColor.Success),
                    )
                  ],
                )),
                Expanded(
                    child: Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    Text(
                      "-19,220.50",
                      style: customTextStyle(
                          fontStyle: FontStyle.BodyM_SemiBold,
                          color: FontColor.Danger),
                    )
                  ],
                )),
                Expanded(
                    child: Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    Text(
                      "-392.50",
                      style: customTextStyle(
                          fontStyle: FontStyle.BodyM_SemiBold,
                          color: FontColor.Danger),
                    )
                  ],
                )),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 4.0, left: 13.0),
            child: Row(
              children: [
                Text(
                  "*In Indian Rupees (INR) | Amount is in Crores",
                  style: customTextStyle(
                      fontStyle: FontStyle.BodyS_Regular,
                      color: FontColor.FontSecondary),
                )
              ],
            ),
          )
        ],
      ),
    );
  }
}
