import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/dashboard/dashboard_calender_list_container.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/dashboard/dashboard_news_container.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/dashboard/ipo_list_container.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/dashboard/participant_cash_container.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/dashboard/participant_fo_container.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/dashboard/performence_list_container.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

import '../../presentation_layer/features/feature_order_window/order_window_components/order_window_title_component.dart';
import 'deals_list_container.dart';

class MarketDashBoardPage extends StatefulWidget {
  const MarketDashBoardPage({Key? key}) : super(key: key);

  @override
  State<MarketDashBoardPage> createState() => _MarketDashBoardPageState();
}

class _MarketDashBoardPageState extends State<MarketDashBoardPage>
    with SingleTickerProviderStateMixin {
  int groupval = 0;
  int performval = 0;

  late TabController _controller;

  int initialIndex = 0;
  String tabName = "Fll";
  int index = 0;
  List<Widget> participantwidget = [
    ParticipantCashContainer(),
    ParticipantFOContainer(),
  ];

  List<Map<String, dynamic>> dealslist = [
    {
      'security': 'TATA MOTORS',
      'buyer': 'By Rakesh Jhunjhunwala',
      'stat': 'Bought',
      'Qty': '2,123,123',
      'Date': '18/09/22',
      'Avg': '1987.27'
    },
    {
      'security': 'YES BANK',
      'buyer': 'By QE Securities',
      'stat': 'Bought',
      'Qty': '2,123,123',
      'Date': '18/09/22',
      'Avg': '1987.27'
    },
    {
      'security': 'BOAT',
      'buyer': 'By Dipesh Jain',
      'stat': 'Sold',
      'Qty': '2,123,123',
      'Date': '18/09/22',
      'Avg': '1987.27'
    },
  ];

  List<Map<String, dynamic>> ipolistitems = [
    {
      'ipo': 'MANYAWR',
      'stat': 'Closed',
      'statColor': FontColor.CarnationRed,
      'statBac': customColors().carnationRed,
      'Qty': '5000',
      'Date': '18/09/22 - 22/02/22',
      'Price': '500-800',
      'img': 'assets/manya.png'
    },
    {
      'ipo': 'TRACK & TRAIL',
      'stat': 'OPen',
      'statColor': FontColor.SecretGarden,
      'statBac': customColors().secretGarden,
      'Qty': '5000',
      'Date': '18/09/22 - 22/02/22',
      'Price': '500-800',
      'img': 'assets/tracktrail.png'
    },
    {
      'ipo': 'Westside',
      'stat': 'UPcoming',
      'statColor': FontColor.DodgerBlue,
      'statBac': customColors().dodgerBlue,
      'Qty': '5000',
      'Date': '18/09/22 - 22/02/22',
      'Price': '500-800',
      'img': 'assets/westside.png'
    },
  ];

  List<Map<String, dynamic>> calenderlistitems = [
    {
      'ipo': 'MANYAVAR - IPO',
      'stat': 'UPcoming',
      'statColor': FontColor.SecretGarden,
      'statBac': customColors().secretGarden,
      'minqty': '500',
      'Date': '26',
      'month': 'DEC',
      'Price': '2000-3500',
    },
    {
      'ipo': 'TATAPOWER - Investormeet/con. call',
      'stat': 'Announcements',
      'statColor': FontColor.MattPurple,
      'statBac': customColors().mattPurple,
      'minqty': '500',
      'Date': '26',
      'month': 'JAN',
      'description': 'Tata Power has informed the exchange about...'
    },
    {
      'ipo': 'HDFC - Buyback',
      'stat': 'Bonus',
      'statColor': FontColor.Crisps,
      'statBac': customColors().crisps,
      'minqty': '500',
      'Date': '12',
      'month': 'JAN',
      'description': ''
    },
  ];

  List<Map<String, dynamic>> performencelist1 = [
    {
      'name': 'Agriculture',
      'percentage': 195.0,
      'value': '5%',
      'color': customColors().success,
      'backcolor': customColors().success.withOpacity(0.2)
    },
    {
      'name': 'Materials',
      'percentage': 200.0,
      'value': '1.5%',
      'color': customColors().success,
      'backcolor': customColors().success.withOpacity(0.2)
    },
    {
      'name': 'Utillities',
      'percentage': 205.0,
      'value': '0.5%',
      'color': customColors().success,
      'backcolor': customColors().success.withOpacity(0.2)
    },
    {
      'name': 'Power',
      'percentage': 206.0,
      'value': '0.3%',
      'color': customColors().success,
      'backcolor': customColors().success.withOpacity(0.2)
    },
    {
      'name': 'Technology',
      'percentage': 208.0,
      'value': '-0.1%',
      'color': semanticRed,
      'backcolor': semanticRed.withOpacity(0.2)
    }
  ];

  List<Map<String, dynamic>> performencelist2 = [
    {
      'name': 'Finance',
      'percentage': 175.0,
      'value': '35%',
      'color': customColors().success,
      'backcolor': customColors().success.withOpacity(0.2)
    },
    {
      'name': 'Materials',
      'percentage': 185.0,
      'value': '25%',
      'color': customColors().success,
      'backcolor': customColors().success.withOpacity(0.2)
    },
    {
      'name': 'Utillities',
      'percentage': 195.0,
      'value': '15%',
      'color': customColors().success,
      'backcolor': customColors().success.withOpacity(0.2)
    },
    {
      'name': 'Consumer',
      'percentage': 200.0,
      'value': '-10%',
      'color': customColors().success,
      'backcolor': customColors().success.withOpacity(0.2)
    },
    {
      'name': 'Agriculture',
      'percentage': 205.0,
      'value': '5%',
      'color': semanticRed,
      'backcolor': semanticRed.withOpacity(0.2)
    }
  ];

  List<List<Map<String, dynamic>>> performlist = [];

  List<Tab> tablist = [
    Tab(
      text: "Bulk Deal",
    ),
    Tab(
      text: "Block Deal",
    ),
  ];

  List<Widget> fofilterwidgets = [];

  List<Map<String, dynamic>> newslist = [
    {
      'image': 'assets/imgone.png',
      'newshead':
          'Stock in review: TCS, Zee Entertainment, Axis bank, ITC, & more',
      'source': 'Economic Times',
      'time': '1 hour ago',
    },
    {
      'image': 'assets/imgtwo.png',
      'newshead': 'Metro Brands, HCL Tech, TCS in focus',
      'source': 'Economic Times',
      'time': '1 hour ago',
    },
    {
      'image': 'assets/imgthree.png',
      'newshead':
          'Stocks to watch: Reliance Industries, Zee, Yess Bank, Dish TV, TCS',
      'source': 'Economic Times',
      'time': '1 hour ago',
    }
  ];

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    initialIndex = 0;
    tabName = "Fll";
    _controller = TabController(length: tablist.length, vsync: this);
    performlist = [performencelist2, performencelist1];

    _controller.addListener(() {
      setState(() {
        initialIndex = _controller.index;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    List<Widget> dealstabs = [
      Padding(
        padding: const EdgeInsets.only(top: 16.0, left: 16.0, right: 16.0),
        child: ListView.builder(
            itemCount: dealslist.length,
            shrinkWrap: true,
            physics: ScrollPhysics(),
            itemBuilder: (context, index) {
              return Deals_List_Container(
                deals: dealslist[index],
              );
            }),
      ),
      Padding(
        padding: const EdgeInsets.only(top: 16.0, left: 16.0, right: 16.0),
        child: ListView.builder(
            itemCount: dealslist.length,
            shrinkWrap: true,
            physics: ScrollPhysics(),
            itemBuilder: (context, index) {
              return Deals_List_Container(
                deals: dealslist[index],
              );
            }),
      )
    ];
    return Padding(
      padding: const EdgeInsets.only(top: 20.0, bottom: 23.0),
      child: SingleChildScrollView(
          physics: ScrollPhysics(),
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.only(left: 16.0, right: 16.0),
                child: Column(
                  children: [
                    Row(
                      children: [
                        Text(
                          "Market Overview",
                          style: customTextStyle(
                              fontStyle: FontStyle.HeaderS_Bold,
                              color: FontColor.FontPrimary),
                        )
                      ],
                    ),
                    Padding(
                      padding: const EdgeInsets.only(top: 24.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  "nifty".toUpperCase(),
                                  style: customTextStyle(
                                      fontStyle: FontStyle.BodyL_SemiBold,
                                      color: FontColor.FontPrimary),
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(top: 6.0),
                                  child: Text(
                                    "1764.77",
                                    style: customTextStyle(
                                        fontStyle: FontStyle.BodyL_SemiBold,
                                        color: FontColor.Danger),
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(top: 4.0),
                                  child: Text(
                                    "-12.34 (0.02%)",
                                    style: customTextStyle(
                                        fontStyle: FontStyle.BodyM_Regular,
                                        color: FontColor.FontSecondary),
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(top: 24.0),
                                  child: Text(
                                    "usdinr".toUpperCase(),
                                    style: customTextStyle(
                                        fontStyle: FontStyle.BodyL_SemiBold,
                                        color: FontColor.FontPrimary),
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(top: 6.0),
                                  child: Text(
                                    "80.12",
                                    style: customTextStyle(
                                        fontStyle: FontStyle.BodyL_SemiBold,
                                        color: FontColor.Success),
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(top: 4.0),
                                  child: Text(
                                    "+11.12 (1.5%)",
                                    style: customTextStyle(
                                        fontStyle: FontStyle.BodyM_Regular,
                                        color: FontColor.FontSecondary),
                                  ),
                                )
                              ],
                            ),
                          ),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  "banknifty".toUpperCase(),
                                  style: customTextStyle(
                                      fontStyle: FontStyle.BodyL_SemiBold,
                                      color: FontColor.FontPrimary),
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(top: 6.0),
                                  child: Text(
                                    "36780.87",
                                    style: customTextStyle(
                                        fontStyle: FontStyle.BodyL_SemiBold,
                                        color: FontColor.Success),
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(top: 4.0),
                                  child: Text(
                                    "+362.23 (1.5%)",
                                    style: customTextStyle(
                                        fontStyle: FontStyle.BodyM_Regular,
                                        color: FontColor.FontSecondary),
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(top: 24.0),
                                  child: Text(
                                    "india vix".toUpperCase(),
                                    style: customTextStyle(
                                        fontStyle: FontStyle.BodyL_SemiBold,
                                        color: FontColor.FontPrimary),
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(top: 6.0),
                                  child: Text(
                                    "20.12",
                                    style: customTextStyle(
                                        fontStyle: FontStyle.BodyL_SemiBold,
                                        color: FontColor.Danger),
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(top: 4.0),
                                  child: Text(
                                    "-1.92 (5.21%)",
                                    style: customTextStyle(
                                        fontStyle: FontStyle.BodyM_Regular,
                                        color: FontColor.FontSecondary),
                                  ),
                                )
                              ],
                            ),
                          ),
                          SizedBox()
                        ],
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(top: 20.0),
                      child: Divider(
                        color: customColors().backgroundTertiary,
                        thickness: 1.0,
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(top: 40.0),
                      child: Row(
                        children: [
                          Text(
                            "Participant Wise Activity",
                            style: customTextStyle(
                                fontStyle: FontStyle.HeaderXS_Bold,
                                color: FontColor.FontPrimary),
                          )
                        ],
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(top: 20.0),
                      child: Row(
                        children: [
                          Row(
                            children: [
                              CustomRadioButton(
                                  noLabel: true,
                                  value: 0,
                                  groupValue: groupval,
                                  onChanged: (int val) {
                                    setState(() {
                                      groupval = val;
                                    });
                                    // widget.onChanged(index);
                                  }),
                              Padding(
                                padding: const EdgeInsets.only(left: 8.0),
                                child: InkWell(
                                  onTap: () {
                                    setState(() {
                                      groupval = 0;
                                    });
                                  },
                                  child: Text(
                                    "Cash",
                                    style: customTextStyle(
                                        fontStyle: FontStyle.BodyL_Regular,
                                        color: FontColor.FontPrimary),
                                  ),
                                ),
                              )
                            ],
                          ),
                          Padding(
                            padding: const EdgeInsets.only(left: 24.0),
                            child: Row(
                              children: [
                                CustomRadioButton(
                                    noLabel: true,
                                    value: 1,
                                    groupValue: groupval,
                                    onChanged: (int val) {
                                      setState(() {
                                        groupval = val;
                                      });
                                      // widget.onChanged(index);
                                    }),
                                Padding(
                                  padding: const EdgeInsets.only(left: 8.0),
                                  child: InkWell(
                                    onTap: () {
                                      setState(() {
                                        groupval = 1;
                                      });
                                    },
                                    child: Text(
                                      "Futures & Options",
                                      style: customTextStyle(
                                          fontStyle: FontStyle.BodyL_Regular,
                                          color: FontColor.FontPrimary),
                                    ),
                                  ),
                                )
                              ],
                            ),
                          )
                        ],
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(top: 16.0),
                      child: Container(
                        width: MediaQuery.of(context).size.width,
                        decoration: BoxDecoration(
                            border: Border.all(
                                color: customColors().backgroundTertiary),
                            borderRadius: BorderRadius.circular(4.0)),
                        child: Padding(
                          padding:
                              const EdgeInsets.only(top: 12.0, bottom: 8.0),
                          child: participantwidget[groupval],
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(top: 40.0),
                      child: Row(
                        children: [
                          Text(
                            "Deals",
                            style: customTextStyle(
                                fontStyle: FontStyle.HeaderXS_Bold,
                                color: FontColor.FontPrimary),
                          )
                        ],
                      ),
                    )
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 9.0),
                child: Container(
                  width: MediaQuery.of(context).size.width,
                  decoration: BoxDecoration(
                      border: Border(
                          bottom: BorderSide(
                              width: 1.0,
                              color: customColors().backgroundTertiary))),
                  child: TabBar(
                    controller: _controller,
                    tabs: tablist,
                    isScrollable: true,
                    labelStyle: customTextStyle(
                        fontStyle: FontStyle.BodyL_SemiBold,
                        color: FontColor.Primary),
                    labelColor: customColors().primary,
                    indicatorSize: TabBarIndicatorSize.label,
                    indicatorColor: customColors().primary,
                    unselectedLabelStyle: customTextStyle(
                        fontStyle: FontStyle.BodyL_Regular,
                        color: FontColor.FontSecondary),
                    unselectedLabelColor: customColors().fontSecondary,
                  ),
                ),
              ),
              Builder(builder: (_) {
                if (_controller.index == 0) {
                  return dealstabs[0]; //1st custom tabBarView
                } else if (_controller.index == 1) {
                  return dealstabs[1]; //2nd tabView
                  //3rd tabView
                } else {
                  return dealstabs[0]; //3rd tabView
                }
              }),
              // SizedBox(
              //     child: Expanded(
              //         child: TabBarView(
              //             controller: _controller, children: dealstabs))),
              Padding(
                padding: const EdgeInsets.only(top: 12.0, right: 16.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(right: 6.0, bottom: 3),
                      child: Text(
                        "View More",
                        style: customTextStyle(
                            fontStyle: FontStyle.BodyL_SemiBold,
                            color: FontColor.Primary),
                      ),
                    ),
                    Image.asset('assets/strokeright.png')
                  ],
                ),
              ),
              Padding(
                padding:
                    const EdgeInsets.only(left: 16.0, right: 16.0, top: 20.0),
                child: Divider(
                  height: 1.0,
                  color: customColors().backgroundTertiary,
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 16.0, right: 16.0),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(top: 20.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            'Sectors',
                            style: customTextStyle(
                                fontStyle: FontStyle.HeaderXS_Bold,
                                color: FontColor.FontPrimary),
                          ),
                          Text(
                            'Data from last 5 days',
                            style: customTextStyle(
                                fontStyle: FontStyle.BodyS_Regular),
                          )
                        ],
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(top: 18.0),
                      child: Row(
                        children: [
                          Expanded(
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                CustomRadioButton(
                                    noLabel: true,
                                    value: 0,
                                    groupValue: performval,
                                    onChanged: (int val) {
                                      setState(() {
                                        performval = val;
                                      });
                                      // widget.onChanged(index);
                                    }),
                                Padding(
                                  // padding: const EdgeInsets.only(left: 8.0),
                                  padding: const EdgeInsets.only(left: 8.0),
                                  child: InkWell(
                                    onTap: () {
                                      setState(() {
                                        performval = 0;
                                      });
                                    },
                                    child: Text(
                                      "Highest Performing",
                                      style: customTextStyle(
                                          fontStyle: FontStyle.BodyL_Regular,
                                          color: FontColor.FontPrimary),
                                    ),
                                  ),
                                )
                              ],
                            ),
                          ),
                          // const SizedBox(
                          //   width: 20.0,
                          // ),
                          Expanded(
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                CustomRadioButton(
                                    noLabel: true,
                                    value: 1,
                                    groupValue: performval,
                                    onChanged: (int val) {
                                      setState(() {
                                        performval = val;
                                      });
                                      // widget.onChanged(index);
                                    }),
                                Padding(
                                  padding: const EdgeInsets.only(left: 8.0),
                                  child: InkWell(
                                    onTap: () {
                                      setState(() {
                                        performval = 0;
                                      });
                                    },
                                    child: Text(
                                      "Lowest Performing",
                                      style: customTextStyle(
                                          fontStyle: FontStyle.BodyL_Regular,
                                          color: FontColor.FontPrimary),
                                    ),
                                  ),
                                )
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.only(top: 20.0),
                      child: ListView.builder(
                          itemCount: performlist[performval].length,
                          shrinkWrap: true,
                          physics: NeverScrollableScrollPhysics(),
                          itemBuilder: (context, index) {
                            return PerformenceListContainer(
                              performlist: performlist[performval][index],
                            );
                          }),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(top: 40.0),
                      child: Row(
                        children: [
                          Text(
                            'Initial Public Offerings (IPOs) ',
                            style: customTextStyle(
                                fontStyle: FontStyle.HeaderXS_Bold,
                                color: FontColor.FontPrimary),
                          )
                        ],
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(top: 16.0),
                      child: ListView.builder(
                          itemCount: ipolistitems.length,
                          shrinkWrap: true,
                          physics: NeverScrollableScrollPhysics(),
                          itemBuilder: (context, index) {
                            return IPOListContainer(
                              ipos: ipolistitems[index],
                            );
                          }),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(top: 12.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          Padding(
                            padding:
                                const EdgeInsets.only(right: 6.0, bottom: 3),
                            child: Text(
                              "View More",
                              style: customTextStyle(
                                  fontStyle: FontStyle.BodyL_SemiBold,
                                  color: FontColor.Primary),
                            ),
                          ),
                          Image.asset('assets/strokeright.png')
                        ],
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(top: 40.0),
                      child: Row(
                        children: [
                          Text(
                            'Calendar',
                            style: customTextStyle(
                                fontStyle: FontStyle.HeaderXS_Bold,
                                color: FontColor.FontPrimary),
                          )
                        ],
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(top: 8.0),
                      child: ListView.builder(
                          itemCount: calenderlistitems.length,
                          shrinkWrap: true,
                          physics: NeverScrollableScrollPhysics(),
                          itemBuilder: (context, index) {
                            return Padding(
                              padding: const EdgeInsets.only(bottom: 4.0),
                              child: CalenderListContainer(
                                calenderitem: calenderlistitems[index],
                              ),
                            );
                          }),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(top: 12),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          Padding(
                            padding:
                                const EdgeInsets.only(right: 6.0, bottom: 3),
                            child: Text(
                              "View More",
                              style: customTextStyle(
                                  fontStyle: FontStyle.BodyL_SemiBold,
                                  color: FontColor.Primary),
                            ),
                          ),
                          Image.asset('assets/strokeright.png')
                        ],
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(top: 38.0),
                      child: Row(
                        children: [
                          Text(
                            'Company News',
                            style: customTextStyle(
                                fontStyle: FontStyle.HeaderXS_Bold,
                                color: FontColor.FontPrimary),
                          )
                        ],
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(top: 8.0),
                      child: ListView.builder(
                          itemCount: newslist.length,
                          shrinkWrap: true,
                          physics: NeverScrollableScrollPhysics(),
                          itemBuilder: (context, index) {
                            return DashBoardNewsListItem(
                              newslist: newslist[index],
                            );
                          }),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(top: 12.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          Padding(
                            padding:
                                const EdgeInsets.only(right: 6.0, bottom: 3),
                            child: Text(
                              "View More",
                              style: customTextStyle(
                                  fontStyle: FontStyle.BodyL_SemiBold,
                                  color: FontColor.Primary),
                            ),
                          ),
                          Image.asset('assets/strokeright.png')
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          )),
    );
  }
}
