import 'package:flutter/material.dart';

import '../../../theme/styles.dart';
import '../others/options_widget.dart';

class IPOListContainer extends StatelessWidget {
  Map<String, dynamic> ipos;
  IPOListContainer({Key? key, required this.ipos}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8.0),
      child: Container(
        padding: EdgeInsets.only(left: 16.0, right: 16.0),
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(4.0),
            border: Border.all(color: customColors().backgroundTertiary)),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 16),
          child: Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Image.asset(ipos['img']),
                      Padding(
                        padding: const EdgeInsets.only(left: 8.0),
                        child: Text(
                          ipos['ipo'].toString().toUpperCase(),
                          style: customTextStyle(
                              fontStyle: FontStyle.BodyL_Bold,
                              color: FontColor.FontPrimary),
                        ),
                      ),
                    ],
                  ),
                  Row(
                    children: [
                      // getProductTypeWidget(ipos['stat']),
                      ProductTypeWidget(
                        text: ipos['stat'].toString().toUpperCase(),
                        textColor: ipos['statColor'],
                        boxColor: ipos['statBac'],
                      )
                    ],
                  ),
                ],
              ),
              const SizedBox(height: 22),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  SizedBox(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "Date",
                          style: customTextStyle(
                              fontStyle: FontStyle.BodyM_Regular,
                              color: FontColor.FontTertiary),
                        ),
                        const SizedBox(height: 5),
                        Text(
                          ipos['Date'],
                          style: customTextStyle(
                              fontStyle: FontStyle.BodyM_SemiBold,
                              color: FontColor.FontPrimary),
                        ),
                      ],
                    ),
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "Min Qty",
                        style: customTextStyle(
                            fontStyle: FontStyle.BodyM_Regular,
                            color: FontColor.FontTertiary),
                      ),
                      const SizedBox(height: 5),
                      Text(
                        '5000',
                        style: customTextStyle(
                            fontStyle: FontStyle.BodyM_SemiBold,
                            color: FontColor.FontPrimary),
                      ),
                    ],
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "Price",
                        style: customTextStyle(
                            fontStyle: FontStyle.BodyM_Regular,
                            color: FontColor.FontTertiary),
                      ),
                      const SizedBox(height: 5),
                      Text(
                        '500-800',
                        style: customTextStyle(
                            fontStyle: FontStyle.BodyM_SemiBold,
                            color: FontColor.FontPrimary),
                      ),
                    ],
                  )
                ],
              )
            ],
          ),
        ),
      ),
    );
  }
}
