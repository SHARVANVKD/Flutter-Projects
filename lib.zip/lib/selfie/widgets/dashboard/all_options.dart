import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/dashboard/allfilterlistitem.dart';

import '../../../theme/styles.dart';

class AllOptions extends StatefulWidget {
  const AllOptions({Key? key}) : super(key: key);

  @override
  State<AllOptions> createState() => _AllOptionsState();
}

class _AllOptionsState extends State<AllOptions> {
  List<Map<String, dynamic>> alloptionarray = [
    {
      'option': 'Futures',
      'sub': 'Net Long',
      'fii': '+48%',
      'pro': '100%',
      'clients': '-15%',
      'dii': '-37%'
    },
    {
      'option': 'Call',
      'sub': 'Net Long',
      'fii': '-99%',
      'pro': '+8%',
      'clients': '-92%',
      'dii': '+1%'
    },
    {
      'option': 'Put',
      'sub': 'Net Long',
      'fii': '-48%',
      'pro': '+87%',
      'clients': '-13%',
      'dii': '-19%'
    },
  ];

  List<Map<String, dynamic>> allstocksarray = [
    {
      'option': 'Futures',
      'sub': 'Net Long',
      'fii': '+48%',
      'pro': '100%',
      'clients': '-15%',
      'dii': '-37%'
    },
    {
      'option': 'Call',
      'sub': 'Net Long',
      'fii': '-99%',
      'pro': '+8%',
      'clients': '-92%',
      'dii': '+1%'
    },
    {
      'option': 'Put',
      'sub': 'Net Long',
      'fii': '-48%',
      'pro': '+87%',
      'clients': '-13%',
      'dii': '-19%'
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Column(children: [
        Container(
          padding: const EdgeInsets.only(left: 12.0, right: 12.0),
          width: MediaQuery.of(context).size.width,
          height: 40.0,
          child: Row(
            children: [
              Expanded(
                  child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Text(
                    "Index",
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyM_SemiBold,
                        color: FontColor.FontSecondary),
                  )
                ],
              )),
              Expanded(
                  child: Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Text(
                    "FII",
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyM_SemiBold,
                        color: FontColor.FontSecondary),
                  )
                ],
              )),
              Expanded(
                  child: Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Text(
                    "Pro",
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyM_SemiBold,
                        color: FontColor.FontSecondary),
                  )
                ],
              )),
              Expanded(
                  child: Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Text(
                    "Clients",
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyM_SemiBold,
                        color: FontColor.FontSecondary),
                  )
                ],
              )),
              Expanded(
                  child: Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Text(
                    "Dll",
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyM_SemiBold,
                        color: FontColor.FontSecondary),
                  )
                ],
              )),
            ],
          ),
        ),
        ListView.builder(
            itemCount: alloptionarray.length,
            shrinkWrap: true,
            physics: ScrollPhysics(),
            itemBuilder: (context, index) {
              return AllFilterListItem(
                index: index,
                list: alloptionarray[index],
              );
            }),
        Container(
          padding: const EdgeInsets.only(left: 12.0, right: 12.0),
          width: MediaQuery.of(context).size.width,
          height: 40.0,
          decoration: BoxDecoration(color: customColors().backgroundSecondary),
          child: Row(
            children: [
              Expanded(
                  child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Text(
                    "Total",
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyM_SemiBold,
                        color: FontColor.FontPrimary),
                  )
                ],
              )),
              Expanded(
                  child: Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Text(
                    "-44k",
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyM_SemiBold,
                        color: FontColor.Success),
                  )
                ],
              )),
              Expanded(
                  child: Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Text(
                    "100%",
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyM_SemiBold,
                        color: FontColor.Danger),
                  )
                ],
              )),
              Expanded(
                  child: Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Text(
                    "-31%",
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyM_SemiBold,
                        color: FontColor.Danger),
                  )
                ],
              )),
              Expanded(
                  child: Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Text(
                    "-26%",
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyM_SemiBold,
                        color: FontColor.Danger),
                  )
                ],
              )),
            ],
          ),
        ),
        Container(
          padding: const EdgeInsets.only(left: 12.0, right: 12.0),
          width: MediaQuery.of(context).size.width,
          height: 40.0,
          child: Row(
            children: [
              Expanded(
                  child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Text(
                    "Stocks",
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyM_SemiBold,
                        color: FontColor.FontSecondary),
                  )
                ],
              )),
              Expanded(
                  child: Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Text(
                    "FLL",
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyM_SemiBold,
                        color: FontColor.FontSecondary),
                  )
                ],
              )),
              Expanded(
                  child: Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Text(
                    "Clients",
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyM_SemiBold,
                        color: FontColor.FontSecondary),
                  )
                ],
              )),
              Expanded(
                  child: Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Text(
                    "Pro",
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyM_SemiBold,
                        color: FontColor.FontSecondary),
                  )
                ],
              )),
              Expanded(
                  child: Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Text(
                    "Dll",
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyM_SemiBold,
                        color: FontColor.FontSecondary),
                  )
                ],
              )),
            ],
          ),
        ),
        ListView.builder(
            itemCount: allstocksarray.length,
            shrinkWrap: true,
            physics: ScrollPhysics(),
            itemBuilder: (context, index) {
              return AllFilterListItem(
                index: index,
                list: allstocksarray[index],
              );
            }),
        Container(
          padding: const EdgeInsets.only(left: 12.0, right: 12.0, bottom: 16.0),
          width: MediaQuery.of(context).size.width,
          height: 40.0,
          decoration: BoxDecoration(color: customColors().backgroundSecondary),
          child: Row(
            children: [
              Expanded(
                  child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Text(
                    "Total",
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyM_SemiBold,
                        color: FontColor.FontPrimary),
                  )
                ],
              )),
              Expanded(
                  child: Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Text(
                    "-44k",
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyM_SemiBold,
                        color: FontColor.Success),
                  )
                ],
              )),
              Expanded(
                  child: Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Text(
                    "100%",
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyM_SemiBold,
                        color: FontColor.Danger),
                  )
                ],
              )),
              Expanded(
                  child: Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Text(
                    "-31%",
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyM_SemiBold,
                        color: FontColor.Danger),
                  )
                ],
              )),
              Expanded(
                  child: Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Text(
                    "-26%",
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyM_SemiBold,
                        color: FontColor.Danger),
                  )
                ],
              )),
            ],
          ),
        ),
      ]),
    );
  }
}
