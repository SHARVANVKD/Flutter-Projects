import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/options_widget.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class CalenderListContainer extends StatelessWidget {
  Map<String, dynamic> calenderitem;
  CalenderListContainer({Key? key, required this.calenderitem})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
          border: Border.all(color: customColors().backgroundTertiary),
          borderRadius: BorderRadius.circular(4.0)),
      child: Row(
        children: [
          Container(
            height: 98.0,
            width: 60.0,
            decoration:
                BoxDecoration(color: customColors().backgroundSecondary),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  calenderitem['Date'],
                  style: customTextStyle(
                      fontStyle: FontStyle.HeaderXS_Bold,
                      color: FontColor.FontPrimary),
                ),
                Text(
                  calenderitem['month'],
                  style: customTextStyle(
                      fontStyle: FontStyle.TagNameS_Bold,
                      color: FontColor.FontSecondary),
                )
              ],
            ),
          ),
          Expanded(
              child: Padding(
            padding: const EdgeInsets.only(left: 14.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    // getProductTypeWidget(calenderitem['stat']),
                    ProductTypeWidget(
                      text: calenderitem['stat'].toString().toUpperCase(),
                      textColor: calenderitem['statColor'],
                      boxColor: calenderitem['statBac'],
                    )
                  ],
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 8.0),
                  child: Text(
                    calenderitem['ipo'],
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyL_SemiBold,
                        color: FontColor.FontPrimary),
                  ),
                ),
                calenderitem.containsKey('Price')
                    ? Padding(
                        padding: const EdgeInsets.only(top: 4.0),
                        child: Row(
                          children: [
                            Row(
                              children: [
                                Text(
                                  'Min Qty -',
                                  style: customTextStyle(
                                      fontStyle: FontStyle.BodyS_Regular,
                                      color: FontColor.FontPrimary),
                                ),
                                Text(
                                  ' 500',
                                  style: customTextStyle(
                                      fontStyle: FontStyle.BodyS_SemiBold,
                                      color: FontColor.FontPrimary),
                                )
                              ],
                            ),
                            Padding(
                              padding: const EdgeInsets.only(left: 16.0),
                              child: Row(
                                children: [
                                  Text(
                                    'Price -',
                                    style: customTextStyle(
                                        fontStyle: FontStyle.BodyS_Regular,
                                        color: FontColor.FontPrimary),
                                  ),
                                  Text(
                                    ' 2000-3500',
                                    style: customTextStyle(
                                        fontStyle: FontStyle.BodyS_SemiBold,
                                        color: FontColor.FontPrimary),
                                  )
                                ],
                              ),
                            )
                          ],
                        ),
                      )
                    : Padding(
                        padding: const EdgeInsets.only(top: 4.0),
                        child: Row(
                          children: [
                            Text(
                              calenderitem['description'].toString(),
                              style: customTextStyle(
                                  fontStyle: FontStyle.BodyS_Regular,
                                  color: FontColor.FontPrimary),
                            )
                          ],
                        ),
                      ),
              ],
            ),
          ))
        ],
      ),
    );
  }
}
