import 'package:flutter/material.dart';
import '../../../theme/styles.dart';

class PerformenceListContainer extends StatefulWidget {
  Map<String, dynamic> performlist;
  PerformenceListContainer({Key? key, required this.performlist})
      : super(key: key);

  @override
  State<PerformenceListContainer> createState() =>
      _PerformenceListContainerState();
}

class _PerformenceListContainerState extends State<PerformenceListContainer> {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 5.0),
      child: SizedBox(
        width: MediaQuery.of(context).size.width,
        child: Row(
          children: [
            SizedBox(
              width: 67,
              child: Text(
                widget.performlist['name'],
                style: customTextStyle(
                    fontStyle: FontStyle.BodyM_SemiBold,
                    color: FontColor.FontPrimary),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(left: 13.0),
              child: Container(
                height: 40.0,
                width: 210.0,
                decoration: BoxDecoration(
                    color: widget.performlist['backcolor'],
                    borderRadius: BorderRadius.circular(2.0)),
                child: Padding(
                  padding: EdgeInsets.only(
                    right: widget.performlist['percentage'],
                  ),
                  child: Container(
                    height: 40.0,
                    width: MediaQuery.of(context).size.width,
                    decoration: BoxDecoration(
                        color: widget.performlist['color'],
                        borderRadius: BorderRadius.circular(2.0)),
                  ),
                ),
              ),
            ),
            Expanded(
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Text(
                    widget.performlist['value'],
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyL_Regular,
                        color: FontColor.FontPrimary),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
    // return Padding(
    //   padding: const EdgeInsets.only(top: 5.0),
    //   // child: LinearPercentIndicator(
    //   //   alignment: MainAxisAlignment.center,
    //   //   barRadius: Radius.circular(2.0),
    //   //   backgroundColor: widget.performlist['backcolor'],
    //   //   width: 192,
    //   //   animation: true,
    //   //   animationDuration: 1000,
    //   //   lineHeight: 40.0,
    //   //   leading: Row(
    //   //     children: [
    //   //       Text(
    //   //         'Agriculture',
    //   //         style: customTextStyle(
    //   //             fontStyle: FontStyle.BodyM_SemiBold,
    //   //             color: FontColor.FontPrimary),
    //   //       ),
    //   //     ],
    //   //   ),
    //   //   trailing: Text(
    //   //     widget.performlist['value'],
    //   //     style: customTextStyle(
    //   //         fontStyle: FontStyle.BodyL_Regular, color: FontColor.FontPrimary),
    //   //   ),
    //   //   percent: 0.1,
    //   //   linearStrokeCap: LinearStrokeCap.butt,
    //   //   progressColor: widget.performlist['color'],
    //   // ),
    //   child: Row(
    //     children: [
    //       Expanded(
    //         child: Text(
    //           widget.performlist['name'],
    //           style: customTextStyle(
    //               fontStyle: FontStyle.BodyM_SemiBold,
    //               color: FontColor.FontPrimary),
    //         ),
    //       ),
    //       Padding(
    //         padding: const EdgeInsets.only(left: 13.0),
    //         child: Container(
    //           height: 40.0,
    //           width: 210.0,
    //           decoration: BoxDecoration(
    //               color: widget.performlist['backcolor'],
    //               borderRadius: BorderRadius.circular(2.0)),
    //           child: Stack(children: [
    //             Padding(
    //               padding:
    //                   EdgeInsets.only(right: widget.performlist['percentage']),
    //               child: Container(
    //                 height: 40.0,
    //                 width: MediaQuery.of(context).size.width,
    //                 decoration: BoxDecoration(
    //                     color: widget.performlist['color'],
    //                     borderRadius: BorderRadius.circular(2.0)),
    //               ),
    //             )
    //           ]),
    //         ),
    //       ),
    //       Expanded(
    //         child: Padding(
    //           padding: const EdgeInsets.only(left: 15.0),
    //           child: Row(
    //             crossAxisAlignment: CrossAxisAlignment.end,
    //             children: [
    //               Text(
    //                 widget.performlist['value'],
    //                 style: customTextStyle(
    //                     fontStyle: FontStyle.BodyL_Regular,
    //                     color: FontColor.FontPrimary),
    //               ),
    //             ],
    //           ),
    //         ),
    //       )
    //     ],
    //   ),
    // );
  }
}
