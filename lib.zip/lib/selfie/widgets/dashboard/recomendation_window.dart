import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class RecomendationWindow extends StatefulWidget {
  const RecomendationWindow({Key? key}) : super(key: key);

  @override
  State<RecomendationWindow> createState() => _RecomendationWindowState();
}

class _RecomendationWindowState extends State<RecomendationWindow>
    with SingleTickerProviderStateMixin {
  int initialIndex = 0;
  String tabName = "Technical";
  int index = 0;
  late TabController _controller;
  List<Widget> recomandationwidgets = [];

  List<Tab> tablist = [
    Tab(
      text: "Technical",
    ),
    Tab(
      text: "Fundamental",
    ),
  ];
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    initialIndex = 0;
    tabName = "My Dashboard";
    _controller = TabController(length: tablist.length, vsync: this);

    _controller.addListener(() {
      setState(() {
        initialIndex = _controller.index;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    recomandationwidgets = [
      Container(
        height: 50.0,
        width: 50.0,
        child: Center(
          child: Text("Tech"),
        ),
      ),
      Container(
        height: 50.0,
        width: 50.0,
        child: Center(
          child: Text("Fund"),
        ),
      )
    ];

    return Container(
        decoration: BoxDecoration(
            border: Border.all(color: customColors().backgroundTertiary),
            borderRadius: BorderRadius.circular(4.0)),
        child: Column(
          children: [
            Container(
              width: MediaQuery.of(context).size.width,
              decoration: BoxDecoration(
                  border: Border(
                      bottom: BorderSide(
                          width: 1.0,
                          color: customColors().backgroundTertiary))),
              child: TabBar(
                controller: _controller,
                tabs: tablist,
                isScrollable: true,
                labelStyle: customTextStyle(
                    fontStyle: FontStyle.BodyL_SemiBold,
                    color: FontColor.Primary),
                labelColor: customColors().primary,
                indicatorSize: TabBarIndicatorSize.label,
                indicatorColor: customColors().primary,
                unselectedLabelStyle: customTextStyle(
                    fontStyle: FontStyle.BodyL_Regular,
                    color: FontColor.FontSecondary),
                unselectedLabelColor: customColors().fontSecondary,
              ),
            ),
            // TabBarView(
            //   children: recomandationwidgets,
            //   controller: _controller,
            // )
            Builder(builder: (_) {
              if (_controller.index == 0) {
                return Technicalwidget(); //1st custom tabBarView
              } else if (_controller.index == 1) {
                return Fundamentalwidget(); //2nd tabView
              } else {
                return Container(); //3rd tabView
              }
            }),
          ],
        ));
  }
}

class Technicalwidget extends StatefulWidget {
  const Technicalwidget({Key? key}) : super(key: key);

  @override
  State<Technicalwidget> createState() => _TechnicalwidgetState();
}

class _TechnicalwidgetState extends State<Technicalwidget> {
  List<Map<String, dynamic>> recomlist = [
    {'count': '05', 'ringcolor': customColors().success, 'techname': 'Buy'},
    {'count': '04', 'ringcolor': customColors().danger, 'techname': 'Sell'},
    {'count': '0', 'ringcolor': customColors().info, 'techname': 'Open'},
    {
      'count': '05',
      'ringcolor': customColors().silverDust,
      'techname': 'Close'
    },
    {
      'count': '04',
      'ringcolor': customColors().pacificBlue,
      'techname': 'Target Hit'
    },
    {'count': '0', 'ringcolor': customColors().crisps, 'techname': 'SL Hit'},
  ];
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 16.0),
      child: GridView.builder(
          shrinkWrap: true,
          physics: ScrollPhysics(),
          itemCount: recomlist.length,
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 3, childAspectRatio: 1.1),
          itemBuilder: (context, index) {
            return Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Container(
                  height: 72,
                  width: 72,
                  decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(
                          width: 5.0, color: recomlist[index]['ringcolor'])),
                  child: Center(
                      child: Text(
                    recomlist[index]['count'],
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyL_SemiBold,
                        color: FontColor.FontPrimary),
                  )),
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 8.0),
                  child: Text(
                    recomlist[index]['techname'],
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyS_SemiBold,
                        color: FontColor.FontSecondary),
                  ),
                )
              ],
            );
          }),
    );
  }
}

class Fundamentalwidget extends StatefulWidget {
  const Fundamentalwidget({Key? key}) : super(key: key);

  @override
  State<Fundamentalwidget> createState() => _FundamentalwidgetState();
}

class _FundamentalwidgetState extends State<Fundamentalwidget> {
  List<Map<String, dynamic>> funlist = [
    {'count': '05', 'ringcolor': customColors().success, 'techname': 'Buy'},
    {'count': '04', 'ringcolor': customColors().danger, 'techname': 'Sell'},
    {'count': '0', 'ringcolor': customColors().silverDust, 'techname': 'Hold'},
    {
      'count': '05',
      'ringcolor': customColors().pacificBlue,
      'techname': 'Accomodate'
    },
    {'count': '05', 'ringcolor': customColors().crisps, 'techname': 'Reduce'},
  ];
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding:
          const EdgeInsets.only(top: 8.0, bottom: 10.0, right: 8.0, left: 8.0),
      child: GridView.builder(
          shrinkWrap: true,
          physics: ScrollPhysics(),
          itemCount: funlist.length,
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 5, childAspectRatio: 0.9),
          itemBuilder: (context, index) {
            return Column(
              children: [
                Container(
                  height: 52,
                  width: 52,
                  decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(
                          width: 5.0, color: funlist[index]['ringcolor'])),
                  child: Center(
                      child: Text(
                    funlist[index]['count'],
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyL_SemiBold,
                        color: FontColor.FontPrimary),
                  )),
                ),
                Align(
                  alignment: Alignment.center,
                  child: Padding(
                    padding: const EdgeInsets.only(top: 5.5),
                    child: Container(
                      child: Text(
                        funlist[index]['techname'],
                        style: customTextStyle(
                            fontStyle: FontStyle.BodyS_SemiBold,
                            color: FontColor.FontSecondary),
                      ),
                    ),
                  ),
                )
              ],
            );
          }),
    );
  }
}
