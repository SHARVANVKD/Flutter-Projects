import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/custom_dot.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/options_widget.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class PortfolioPositionListItemSelected extends StatefulWidget {
  Map<String, dynamic> positionsamples;
  List<String> checklist;
  final Function(int) upcount;
  PortfolioPositionListItemSelected(
      {Key? key,
      required this.positionsamples,
      required this.checklist,
      required this.upcount})
      : super(key: key);

  @override
  State<PortfolioPositionListItemSelected> createState() =>
      _PortfolioListItemState();
}

class _PortfolioListItemState extends State<PortfolioPositionListItemSelected> {

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    

    return Padding(
      padding: const EdgeInsets.only(left: 16.0),
      child: Column(
        children: [
          Container(
            height: 104,
            width: MediaQuery.of(context).size.width,
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: 9.0),
              child: Container(
                padding: const EdgeInsets.only(left: 8.0),
                width: 2.0,
                decoration: BoxDecoration(
                    border: Border(
                  left: BorderSide(
                      color: widget.positionsamples["sidebarcolor"], width: 2),
                )),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Column(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Row(
                                children: [
                                  Visibility(
                                    visible:
                                        widget.positionsamples["badge"] == "Y"
                                            ? true
                                            : false,
                                    child: Padding(
                                      padding: const EdgeInsets.only(right: 6),
                                      child: Image.asset(
                                          "assets/tag_position.png"),
                                    ),
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 0.0),
                                    child:getProductTypeWidget(
                                      widget.positionsamples["OrderType"]),
                                  ),
                                ],
                              ),
                            ]),
                        Padding(
                          padding: const EdgeInsets.only(top: 10),
                          child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Row(
                                  children: [
                                    Text(
                                      widget.positionsamples["name"],
                                      style: customTextStyle(
                                          fontStyle: FontStyle.BodyL_SemiBold,
                                          color: FontColor.FontPrimary),
                                    ),
                                    Visibility(
                                      visible: widget.positionsamples
                                          .containsKey("contract"),
                                      child: Row(
                                        children: [
                                          Padding(
                                            padding: const EdgeInsets.only(
                                                left: 4.0),
                                            child: Container(
                                                width: 14,
                                                height: 14,
                                                alignment: Alignment.center,
                                                decoration: BoxDecoration(
                                                    color: customColors()
                                                        .wTokenBackground,
                                                    shape: BoxShape.circle),
                                                child: Align(
                                                  alignment: Alignment.center,
                                                  child: Text(
                                                    "W",
                                                    textAlign: TextAlign.center,
                                                    style: TextStyle(
                                                        fontFamily:
                                                            "OpenSansRegular",
                                                        fontSize: 8,
                                                        fontWeight:
                                                            FontWeight.w600,
                                                        color: customColors()
                                                            .wTokenFontColor),
                                                  ),
                                                )),
                                          ),
                                          const SizedBox(
                                            width: 4,
                                          ),
                                          Visibility(
                                            visible: widget.positionsamples
                                                .containsKey("date"),
                                            child: Text(
                                              "FEB 18100 CE",
                                              style: customTextStyle(
                                                  fontStyle:
                                                      FontStyle.BodyL_SemiBold,
                                                  color: FontColor.FontPrimary),
                                            ),
                                          )
                                        ],
                                      ),
                                    )
                                  ],
                                )
                              ]),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(top: 4.0),
                          child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Row(
                                  crossAxisAlignment: CrossAxisAlignment.end,
                                  children: [
                                    Text(
                                      "10",
                                      style: customTextStyle(
                                          fontStyle: FontStyle.BodyM_SemiBold,
                                          color: FontColor.FontSecondary),
                                    ),
                                    Text(
                                      " Qty",
                                      style: customTextStyle(
                                          fontStyle: FontStyle.BodyM_Regular,
                                          color: FontColor.FontTertiary),
                                    ),
                                    const Padding(
                              padding:
                                   EdgeInsets.only(left: 6.0, right: 6.0),
                              child:CustomDot(),),
                                    Text(
                                      " Avg",
                                      style: customTextStyle(
                                          fontStyle: FontStyle.BodyM_Regular,
                                          color: FontColor.FontTertiary),
                                    ),
                                    Text(
                                      " 281.12",
                                      style: customTextStyle(
                                          fontStyle: FontStyle.BodyM_SemiBold,
                                          color: FontColor.FontSecondary),
                                    ),
                                  ],
                                )
                              ]),
                        ),
                      ],
                    ),
                    Checkbox(
                      activeColor: customColors().primary,
                      onChanged: (value) {
                        checkinlist(widget.positionsamples["name"]);
                      },
                      value: widget.checklist
                              .contains(widget.positionsamples["name"])
                          ? true
                          : false,
                    ),
                  ],
                ),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(right: 16.0),
            child: Divider(
              thickness: 2.0,
              color: customColors().backgroundTertiary,
            ),
          )
        ],
      ),
    );
  }

  void checkinlist(String name) {
    setState(() {
      if (widget.checklist.contains(name)) {
        widget.checklist.remove(name);
      } else {
        widget.checklist.add(name);
      }
      widget.upcount(widget.checklist.length);
    });
  }
}
