import 'package:fade_shimmer/fade_shimmer.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/constants/enums.dart';
import 'package:selfie_mobile_flutter/global_methods/global_methods.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_portfolio/my_portfolio/bloc/my_position_screen_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_portfolio/my_portfolio/bloc/position_screen_state.dart';
import 'package:selfie_mobile_flutter/selfie/repository_layer/portfolio_content.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/scrollable_bottomsheet/scrollable_bottomsheet.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/search_insights_filter/portfolio_holding_filter_bar.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/textfields/position_search_field.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/empty_container.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/message_tile.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/options_widget.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/sort.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/portfolio/port_smart_header.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/portfolio/portfolio_list_item.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/portfolio/position/position_bottom_sheets.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/portfolio/position/position_shimmer.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';
import 'package:selfie_mobile_flutter/app_page_injectable.dart';
import 'package:selfie_mobile_flutter/user_controller/user_controller.dart';
import 'package:selfie_mobile_flutter/utils/common_prop.dart';
import 'package:selfie_mobile_flutter/utils/shimmer_loader.dart';

import '../../others/custom_dot.dart';
import '../position_bottom_sheet.dart';

class PositionInnerWidget extends StatefulWidget {
  const PositionInnerWidget({Key? key}) : super(key: key);
  @override
  State<PositionInnerWidget> createState() => _PositionInnerWidgetState();
}

class _PositionInnerWidgetState extends State<PositionInnerWidget> {
  bool isSearch = true;
  final _controller = TextEditingController();
  final _editcontroller = TextEditingController();
  List<Map<String, dynamic>> positionSampleList2 = [];
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
        create: (context) =>
            MyPositionScreenCubit(apiGateway: context.gTradingApiGateway),
        child: BlocBuilder<MyPositionScreenCubit, PositionScreenState>(
            builder: (context, state) {
          if (state is MyPositionScreenInitial) {
            return SingleChildScrollView(
              child: Column(
                children: [
                  if (state.intradaydata.isNotEmpty && state.searchvisible)
                    SingleChildScrollView(
                      child: Column(
                        children: [
                          Column(
                            children: [
                              Visibility(
                                visible: isSearch,
                                child: Column(
                                  key: const Key("is_search"),
                                  children: [
                                    Padding(
                                      padding: const EdgeInsets.symmetric(
                                          vertical: 8.0),
                                      child: Position_Search_Field(
                                          onBackPressed: () {
                                            BlocProvider.of<
                                                        MyPositionScreenCubit>(
                                                    context)
                                                .openInitial();
                                          },
                                          hintText: "Search eg: infy",
                                          controller: _editcontroller,
                                          onSearch: (String keyword) {
                                            if (keyword.isEmpty) {
                                              BlocProvider.of<
                                                          MyPositionScreenCubit>(
                                                      context)
                                                  .updateSearchList(keyword);
                                            } else {
                                              BlocProvider.of<
                                                          MyPositionScreenCubit>(
                                                      context)
                                                  .updateSearchList(keyword);
                                            }
                                          }),
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.only(top: 14.0),
                                      child: MediaQuery.removePadding(
                                        context: context,
                                        removeTop: true,
                                        child: ListView.builder(
                                            itemCount:
                                                state.intradaydata.length,
                                            shrinkWrap: true,
                                            physics: const ScrollPhysics(),
                                            itemBuilder: (context, index) {
                                              return PortfolioListItem(
                                                portfoliolist:
                                                    state.intradaydata,
                                                index: index,
                                                onLongPressAction: () {
                                                  context.gNavigationService
                                                      .openPositionLongPress(
                                                          context);
                                                },
                                                onTap: () {
                                                  customShowModalBottomSheet(
                                                      ltp: double.parse(state.intradaydata[index].lasttradeprice)
                                                          .toStringAsFixed(2)
                                                          .toString(),
                                                      symbolname: state
                                                          .intradaydata[index]
                                                          .securitycode
                                                          .toString(),
                                                      pl: state
                                                          .intradaydata[index]
                                                          .pl
                                                          .toString(),
                                                      change_percentage:
                                                          state
                                                                  .intradaydata[
                                                                      index]
                                                                  .plPercentage
                                                                  .isNaN
                                                              ? "0.0"
                                                              : state
                                                                  .intradaydata[
                                                                      index]
                                                                  .plPercentage
                                                                  .toString(),
                                                      ifport: true,
                                                      net_pos: state
                                                          .intradaydata[index]
                                                          .netqty,
                                                      productType: state
                                                          .intradaydata[index]
                                                          .producttype
                                                          .toString(),
                                                      context: context,
                                                      inputWidget: PositionBottomSheet(
                                                        notify: false,
                                                        toggles: false,
                                                        future: false,
                                                        reportData:
                                                            state.intradaydata,
                                                        index: index,
                                                        pl: state.pl.toString(),
                                                        pl_percentage: double
                                                                .parse(state
                                                                    .change_pl_percentage
                                                                    .toString())
                                                            .toStringAsFixed(2)
                                                            .toString(),
                                                        todays_pl: state
                                                            .total_todyas_pl
                                                            .toString(),
                                                        todays_pl_percentage:
                                                            state
                                                                .total_todyas_pl
                                                                .toString(),
                                                      ));
                                                },
                                              );
                                            }),
                                      ),
                                    )
                                  ],
                                ),
                              ),
                            ],
                          )
                        ],
                      ),
                    )
                  else if (state.searchvisible == false)
                    SingleChildScrollView(
                      child: Column(
                        children: [
                          Column(
                            children: [
                              Column(
                                key: const Key("is_search"),
                                children: [
                                  if (state.searchvisible == false)
                                    Column(
                                      children: [
                                        Padding(
                                          padding: const EdgeInsets.fromLTRB(
                                              16.0, 16.0, 16.0, 0.0),
                                          child: Row(
                                            children: [
                                              Expanded(
                                                child: InkWell(
                                                  onTap: () {
                                                    context.gNavigationService
                                                        .openDefaultOrderSettingsPage(
                                                            context);
                                                  },
                                                  child: Port_Smart_Header(
                                                    bgcolor: customColors()
                                                        .backgroundSecondary,
                                                    title: "TOTAL P&L",
                                                    total: state.pl
                                                        .toStringAsFixed(2)
                                                        .toString(),
                                                    totalcolor: getFeedColor(
                                                        double.parse(state.pl
                                                            .toString())),
                                                  ),
                                                ),
                                              ),
                                              const SizedBox(
                                                width: 12.0,
                                              ),
                                              Expanded(
                                                child: Port_Smart_Header(
                                                  bgcolor: customColors()
                                                      .backgroundSecondary,
                                                  title: "TODAYS P&L",
                                                  total: state.total_todyas_pl
                                                      .toStringAsFixed(2)
                                                      .toString(),
                                                  totalcolor: FontColor.Danger,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Padding(
                                            padding: const EdgeInsets.only(
                                              top: 24.0,
                                            ),
                                            child: SearchFilterHoldings(
                                              showInsights: false,
                                              onFilterPress: () {
                                                customShowModalBottomSheet(
                                                    context: context,
                                                    inputWidget:
                                                        PortfolioSortList(
                                                            currentval:
                                                                filterval,
                                                            selectedLocation:
                                                                SortFilterLocation
                                                                    .position,
                                                            selectedTabIndex: 0,
                                                            onPressFilter:
                                                                (List<String>
                                                                    elements) {
                                                              BlocProvider.of<
                                                                          MyPositionScreenCubit>(
                                                                      context)
                                                                  .updateFilterList(
                                                                      elements);
                                                            },
                                                            onPressSort:
                                                                (int index) {
                                                              List<
                                                                      Map<String,
                                                                          dynamic>>
                                                                  list = [];
                                                            },
                                                            onPressReset:
                                                                () {}));
                                              },
                                              onSortPress: () {
                                                customShowModalBottomSheet(
                                                    context: context,
                                                    inputWidget:
                                                        PortfolioSortList(
                                                            currentval:
                                                                state.filterval,
                                                            selectedLocation:
                                                                SortFilterLocation
                                                                    .position,
                                                            selectedTabIndex: 1,
                                                            onPressFilter:
                                                                (List<String>
                                                                    elements) {},
                                                            onPressSort:
                                                                (int index) {
                                                              BlocProvider.of<
                                                                          MyPositionScreenCubit>(
                                                                      context)
                                                                  .updateSortList(
                                                                      index);

                                                              Navigator.pop(
                                                                  context);
                                                            },
                                                            onPressReset: () {
                                                              BlocProvider.of<
                                                                          MyPositionScreenCubit>(
                                                                      context)
                                                                  .resetSortList();
                                                              Navigator.pop(
                                                                  context);
                                                            }));
                                              },
                                              onSearchPress: () {
                                                BlocProvider.of<
                                                            MyPositionScreenCubit>(
                                                        context)
                                                    .openSearch();
                                              },
                                            )),
                                      ],
                                    )
                                  else
                                    Column(
                                      children: [
                                        Padding(
                                          padding: const EdgeInsets.symmetric(
                                              vertical: 8.0),
                                          child: Position_Search_Field(
                                              onBackPressed: () {
                                                // BlocProvider.of<HoldingsComponentCubit>(context)
                                                //     .openInitial();
                                              },
                                              hintText: "Search eg: infy",
                                              controller: _editcontroller,
                                              onSearch: (String keyword) {
                                                print(keyword);
                                                if (keyword.isEmpty) {
                                                  // BlocProvider.of<HoldingsComponentCubit>(context)
                                                  //     .updateSearchList(
                                                  //         UserController()
                                                  //             .portfolioresponce
                                                  //             .reportData,
                                                  //         keyword);
                                                } else {
                                                  // BlocProvider.of<HoldingsComponentCubit>(context)
                                                  //     .updateSearchList(
                                                  //         state.portfolioResponce, keyword);
                                                }
                                              }),
                                        ),
                                      ],
                                    ),
                                  Padding(
                                    padding: const EdgeInsets.only(top: 14.0),
                                    child: MediaQuery.removePadding(
                                      context: context,
                                      removeTop: true,
                                      child: ListView.builder(
                                          itemCount: state.intradaydata.length,
                                          shrinkWrap: true,
                                          physics: const ScrollPhysics(),
                                          itemBuilder: (context, index) {
                                            return PortfolioListItem(
                                              portfoliolist: state.intradaydata,
                                              index: index,
                                              onLongPressAction: () {
                                                context.gNavigationService
                                                    .openPositionLongPress(
                                                        context);
                                              },
                                              onTap: () {
                                                customShowModalBottomSheet(
                                                    ltp: double.parse(state
                                                            .intradaydata[index]
                                                            .lasttradeprice)
                                                        .toStringAsFixed(2)
                                                        .toString(),
                                                    symbolname: state
                                                        .intradaydata[index]
                                                        .securitycode
                                                        .toString(),
                                                    pl: state
                                                        .intradaydata[index].pl
                                                        .toString(),
                                                    change_percentage: state
                                                        .intradaydata[index]
                                                        .plPercentage
                                                        .toString(),
                                                    ifport: true,
                                                    net_pos: state
                                                        .intradaydata[index]
                                                        .netqty,
                                                    productType: state
                                                        .intradaydata[index]
                                                        .producttype
                                                        .toString(),
                                                    context: context,
                                                    inputWidget:
                                                        PositionBottomSheet(
                                                      notify: false,
                                                      toggles: false,
                                                      future: false,
                                                      reportData:
                                                          state.intradaydata,
                                                      index: index,
                                                      pl: state.pl.toString(),
                                                      pl_percentage:
                                                          double.parse(state
                                                                  .change_pl_percentage
                                                                  .toString())
                                                              .toStringAsFixed(
                                                                  2)
                                                              .toString(),
                                                      todays_pl: state
                                                          .total_todyas_pl
                                                          .toString(),
                                                      todays_pl_percentage:
                                                          state.total_todyas_pl
                                                              .toString(),
                                                    ));
                                              },
                                            );
                                          }),
                                    ),
                                  )
                                ],
                              ),
                            ],
                          )
                        ],
                      ),
                    )
                  else
                    SingleChildScrollView(
                      child: Column(children: [
                        FutureBuilder(
                            future: Future.delayed(Duration(seconds: 1)),
                            builder: (c, s) =>
                                s.connectionState == ConnectionState.done
                                    ? Column(
                                        children: [
                                          Visibility(
                                            visible: isSearch,
                                            child: Column(
                                              key: const Key("is_search"),
                                              children: [
                                                Padding(
                                                  padding:
                                                      const EdgeInsets.fromLTRB(
                                                          16.0,
                                                          16.0,
                                                          16.0,
                                                          0.0),
                                                  child: Row(
                                                    children: [
                                                      Expanded(
                                                        child: InkWell(
                                                          onTap: () {},
                                                          child:
                                                              Port_Smart_Header(
                                                            bgcolor: customColors()
                                                                .backgroundSecondary,
                                                            title: "TOTAL P&L",
                                                            total: "0",
                                                            totalcolor:
                                                                FontColor
                                                                    .Success,
                                                          ),
                                                        ),
                                                      ),
                                                      const SizedBox(
                                                        width: 12.0,
                                                      ),
                                                      Expanded(
                                                        child:
                                                            Port_Smart_Header(
                                                          bgcolor: customColors()
                                                              .backgroundSecondary,
                                                          title: "TODAYS P&L",
                                                          total: "0",
                                                          totalcolor:
                                                              FontColor.Danger,
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                                Padding(
                                                    padding:
                                                        const EdgeInsets.only(
                                                      top: 24.0,
                                                    ),
                                                    child: SearchFilterHoldings(
                                                      showInsights: false,
                                                      onFilterPress: () {
                                                        customShowModalBottomSheet(
                                                            context: context,
                                                            inputWidget:
                                                                PortfolioSortList(
                                                                    currentval:
                                                                        filterval,
                                                                    selectedLocation:
                                                                        SortFilterLocation
                                                                            .position,
                                                                    selectedTabIndex:
                                                                        0,
                                                                    onPressFilter:
                                                                        (List<String>
                                                                            elements) {
                                                                      List<Map<String, dynamic>>
                                                                          list =
                                                                          [];
                                                                      positionSampleList2
                                                                          .forEach(
                                                                              (el) {
                                                                        for (int i =
                                                                                0;
                                                                            i < elements.length;
                                                                            i++) {
                                                                          if (el
                                                                              .containsValue(elements[i])) {
                                                                            list.add(el);
                                                                          }
                                                                        }
                                                                      });
                                                                    },
                                                                    onPressSort:
                                                                        (int
                                                                            index) {
                                                                      List<Map<String, dynamic>>
                                                                          list =
                                                                          [];
                                                                    },
                                                                    onPressReset:
                                                                        () {}));
                                                      },
                                                      onSortPress: () {
                                                        customShowModalBottomSheet(
                                                            context: context,
                                                            inputWidget:
                                                                PortfolioSortList(
                                                                    currentval:
                                                                        filterval,
                                                                    selectedLocation:
                                                                        SortFilterLocation
                                                                            .position,
                                                                    selectedTabIndex:
                                                                        1,
                                                                    onPressFilter:
                                                                        (List<String>
                                                                            elements) {
                                                                      List<Map<String, dynamic>>
                                                                          list =
                                                                          [];
                                                                      positionSampleList2
                                                                          .forEach(
                                                                              (el) {
                                                                        for (int i =
                                                                                0;
                                                                            i < elements.length;
                                                                            i++) {
                                                                          if (el
                                                                              .containsValue(elements[i])) {
                                                                            list.add(el);
                                                                          }
                                                                        }
                                                                      });
                                                                    },
                                                                    onPressSort:
                                                                        (int
                                                                            index) {
                                                                      List<Map<String, dynamic>>
                                                                          list =
                                                                          [];
                                                                    },
                                                                    onPressReset:
                                                                        () {}));
                                                      },
                                                      onSearchPress: () {},
                                                    )),
                                                Padding(
                                                  padding: EdgeInsets.only(
                                                      top:
                                                          MediaQuery.of(context)
                                                                  .size
                                                                  .height *
                                                              0.1),
                                                  child:
                                                      emptyContainerSmartfolio(
                                                          context),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ],
                                      )
                                    : Column(
                                        children: [
                                          ListView.builder(
                                              shrinkWrap: true,
                                              itemCount: 2,
                                              itemBuilder: (context, index) {
                                                return InkWell(
                                                  child: Container(
                                                    padding: const EdgeInsets
                                                            .symmetric(
                                                        horizontal: 16),
                                                    child: Container(
                                                      padding: const EdgeInsets
                                                              .symmetric(
                                                          vertical: 16),
                                                      decoration: BoxDecoration(
                                                          border: Border(
                                                        bottom: BorderSide(
                                                            color: customColors()
                                                                .backgroundTertiary,
                                                            width: 1),
                                                      )),
                                                      child: Container(
                                                        padding:
                                                            const EdgeInsets
                                                                    .symmetric(
                                                                horizontal: 8),
                                                        child: Column(
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .spaceBetween,
                                                          children: [
                                                            Visibility(
                                                              visible: true,
                                                              child: Row(
                                                                  mainAxisAlignment:
                                                                      MainAxisAlignment
                                                                          .spaceBetween,
                                                                  children: [
                                                                    Row(
                                                                      children: [
                                                                        Visibility(
                                                                          visible:
                                                                              false,
                                                                          child:
                                                                              Padding(
                                                                            padding:
                                                                                const EdgeInsets.only(right: 6),
                                                                            child:
                                                                                Image.asset("assets/tag_position.png"),
                                                                          ),
                                                                        ),
                                                                        Padding(
                                                                            padding:
                                                                                const EdgeInsets.symmetric(horizontal: 0.0),
                                                                            child: ShimmerLoader(height: 20, width: 50)),
                                                                      ],
                                                                    ),
                                                                    ShimmerLoader(
                                                                        height:
                                                                            20.0,
                                                                        width:
                                                                            20.0)
                                                                  ]),
                                                            ),
                                                            Padding(
                                                              padding:
                                                                  const EdgeInsets
                                                                          .only(
                                                                      top: 10),
                                                              child: Row(
                                                                  mainAxisAlignment:
                                                                      MainAxisAlignment
                                                                          .spaceBetween,
                                                                  children: [
                                                                    Row(
                                                                      children: [
                                                                        ShimmerLoader(
                                                                            height:
                                                                                20.0,
                                                                            width:
                                                                                20.0)
                                                                      ],
                                                                    ),
                                                                  ]),
                                                            ),
                                                            Padding(
                                                              padding:
                                                                  const EdgeInsets
                                                                          .only(
                                                                      top: 4.0),
                                                              child: Row(
                                                                  mainAxisAlignment:
                                                                      MainAxisAlignment
                                                                          .spaceBetween,
                                                                  children: [
                                                                    Row(
                                                                      crossAxisAlignment:
                                                                          CrossAxisAlignment
                                                                              .end,
                                                                      children: [
                                                                        ShimmerLoader(
                                                                            height:
                                                                                20.0,
                                                                            width:
                                                                                20.0),
                                                                        ShimmerLoader(
                                                                            height:
                                                                                20.0,
                                                                            width:
                                                                                20.0),
                                                                        ShimmerLoader(
                                                                            height:
                                                                                20.0,
                                                                            width:
                                                                                70.0),
                                                                        ShimmerLoader(
                                                                            height:
                                                                                20.0,
                                                                            width:
                                                                                70.0)
                                                                      ],
                                                                    ),
                                                                    Row(
                                                                      children: [
                                                                        ShimmerLoader(
                                                                            height:
                                                                                20.0,
                                                                            width:
                                                                                70.0),
                                                                        ShimmerLoader(
                                                                            height:
                                                                                20.0,
                                                                            width:
                                                                                20.0)
                                                                      ],
                                                                    ),
                                                                  ]),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                );
                                              }),
                                        ],
                                      ))
                      ]),
                    ),
                ],
              ),
            );
          }

          if (state is MyPositionScreenloading) {
            return PositionShimmer();
          } else {
            return Column(
              children: [
                Visibility(
                  visible: isSearch,
                  child: Column(
                    key: const Key("is_search"),
                    children: [
                      Padding(
                        padding:
                            const EdgeInsets.fromLTRB(16.0, 16.0, 16.0, 0.0),
                        child: Row(
                          children: [
                            Expanded(
                              child: InkWell(
                                onTap: () {},
                                child: Port_Smart_Header(
                                  bgcolor: customColors().backgroundSecondary,
                                  title: "TOTAL P&L",
                                  total: "0",
                                  totalcolor: FontColor.Success,
                                ),
                              ),
                            ),
                            const SizedBox(
                              width: 12.0,
                            ),
                            Expanded(
                              child: Port_Smart_Header(
                                bgcolor: customColors().backgroundSecondary,
                                title: "TODAYS P&L",
                                total: "0",
                                totalcolor: FontColor.Danger,
                              ),
                            ),
                          ],
                        ),
                      ),
                      Padding(
                          padding: const EdgeInsets.only(
                            top: 24.0,
                          ),
                          child: SearchFilterHoldings(
                            showInsights: false,
                            onFilterPress: () {
                              customShowModalBottomSheet(
                                  context: context,
                                  inputWidget: PortfolioSortList(
                                      currentval: filterval,
                                      selectedLocation:
                                          SortFilterLocation.position,
                                      selectedTabIndex: 0,
                                      onPressFilter: (List<String> elements) {
                                        List<Map<String, dynamic>> list = [];
                                        positionSampleList2.forEach((el) {
                                          for (int i = 0;
                                              i < elements.length;
                                              i++) {
                                            if (el.containsValue(elements[i])) {
                                              list.add(el);
                                            }
                                          }
                                        });
                                      },
                                      onPressSort: (int index) {
                                        List<Map<String, dynamic>> list = [];
                                      },
                                      onPressReset: () {}));
                            },
                            onSortPress: () {
                              customShowModalBottomSheet(
                                  context: context,
                                  inputWidget: PortfolioSortList(
                                      currentval: filterval,
                                      selectedLocation:
                                          SortFilterLocation.position,
                                      selectedTabIndex: 1,
                                      onPressFilter: (List<String> elements) {
                                        List<Map<String, dynamic>> list = [];
                                        positionSampleList2.forEach((el) {
                                          for (int i = 0;
                                              i < elements.length;
                                              i++) {
                                            if (el.containsValue(elements[i])) {
                                              list.add(el);
                                            }
                                          }
                                        });
                                      },
                                      onPressSort: (int index) {
                                        List<Map<String, dynamic>> list = [];
                                      },
                                      onPressReset: () {}));
                            },
                            onSearchPress: () {},
                          )),
                      Padding(
                        padding: EdgeInsets.only(
                            top: MediaQuery.of(context).size.height * 0.1),
                        child: emptyContainerSmartfolio(context),
                      ),
                    ],
                  ),
                ),
              ],
            );
          }
        }));
  }
}

emptyContainerSmartfolio(BuildContext context) {
  return Column(
    mainAxisAlignment: MainAxisAlignment.center,
    children: [
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: EmptyContainer(
            height: 152,
            width: double.infinity,
            color: customColors().backgroundTertiary),
      ),
      Padding(
        padding: const EdgeInsets.only(top: 20.0),
        child: Align(
            alignment: Alignment.center,
            child: Text(
              "No positions",
              style: customTextStyle(
                  fontStyle: FontStyle.BodyL_SemiBold,
                  color: FontColor.FontPrimary),
            )),
      ),
      Padding(
        padding: const EdgeInsets.only(top: 4),
        child: Align(
            alignment: Alignment.center,
            child: Container(
              width: 286,
              child: Text(
                "Place an order from your watchlist",
                softWrap: true,
                textAlign: TextAlign.center,
                style: customTextStyle(
                    fontStyle: FontStyle.BodyM_Regular,
                    color: FontColor.FontSecondary),
              ),
            )),
      ),
    ],
  );
}
