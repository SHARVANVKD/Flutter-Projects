import 'package:flutter/material.dart';

import '../../../../theme/styles.dart';
import '../../../../utils/shimmer_loader.dart';

class PositionShimmer extends StatelessWidget {
  const PositionShimmer({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
        shrinkWrap: true,
        itemCount: 5,
        itemBuilder: (context, index) {
          return InkWell(
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Container(
                padding: const EdgeInsets.symmetric(vertical: 16),
                decoration: BoxDecoration(
                    border: Border(
                  bottom: BorderSide(
                      color: customColors().backgroundTertiary, width: 1),
                )),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Visibility(
                        visible: true,
                        child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Row(
                                children: [
                                  Visibility(
                                    visible: false,
                                    child: Padding(
                                      padding: const EdgeInsets.only(right: 6),
                                      child: Image.asset(
                                          "assets/tag_position.png"),
                                    ),
                                  ),
                                  Padding(
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 0.0),
                                      child: ShimmerLoader(
                                          height: 20.0, width: 50.0)),
                                ],
                              ),
                              ShimmerLoader(height: 20, width: 20)
                            ]),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(top: 10),
                        child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Row(
                                children: [
                                  ShimmerLoader(height: 20.0, width: 50.0)
                                ],
                              ),
                              // Text(
                              //   widget.portfoliolist["PANDL"],
                              //   style: customTextStyle(
                              //       fontStyle: FontStyle.BodyL_SemiBold,
                              //       color: widget.portfoliolist["pandlcolor"]),
                              // ),
                            ]),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(top: 4.0),
                        child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Row(
                                crossAxisAlignment: CrossAxisAlignment.end,
                                children: [
                                  ShimmerLoader(height: 20.0, width: 20.0),
                                  ShimmerLoader(height: 20.0, width: 20.0),
                                  // Padding(
                                  //   padding: const EdgeInsets
                                  //           .only(
                                  //       left: 8.0,
                                  //       right:
                                  //           8.0),
                                  //   child: CustomDot(
                                  //       color: customColors()
                                  //           .fontSecondary),
                                  // ),
                                  ShimmerLoader(height: 20.0, width: 70.0),
                                  ShimmerLoader(height: 20.0, width: 70.0)
                                ],
                              ),
                              Row(
                                children: [
                                  ShimmerLoader(height: 20.0, width: 70.0),
                                  ShimmerLoader(height: 20.0, width: 20.0)
                                ],
                              ),
                            ]),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          );
        });
  }
}
