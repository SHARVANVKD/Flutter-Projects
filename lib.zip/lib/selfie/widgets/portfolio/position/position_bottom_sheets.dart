import 'package:flutter/material.dart';

import 'package:selfie_mobile_flutter/selfie/repository_layer/portfolio_content.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/scrollable_bottomsheet/scrollable_bottomsheet.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/portfolio_bottom_sheet_panel/fixed_button.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/portfolio_bottom_sheet_panel/portfolio_button_actions.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/portfolio_bottom_sheet_panel/portfolio_postion_stock_panel.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/sort.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';
import 'package:trading_api/responses/portfolio_responce.dart';

class PositionBottomSheet extends StatefulWidget {
  bool notify;
  bool toggles;
  bool future;
  final Function()? onRollTap;
  final Function()? onOCOTap;
  final Function()? onAddMoreTap;
  final Function()? onSquareOffTap;
  List<Intradaydatum>? reportData;
  int index;
  String? pl;
  String? pl_percentage;
  String? todays_pl;
  String? todays_pl_percentage;
  PositionBottomSheet(
      {Key? key,
      required this.notify,
      required this.toggles,
      required this.future,
      this.reportData,
      required this.index,
      this.onRollTap,
      this.onOCOTap,
      this.onAddMoreTap,
      this.onSquareOffTap,
      this.pl,
      this.pl_percentage,
      this.todays_pl,
      this.todays_pl_percentage})
      : super(key: key);

  @override
  State<PositionBottomSheet> createState() => _PositionBottomSheetState();
}

class _PositionBottomSheetState extends State<PositionBottomSheet> {
  Color? selectedColor;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        StatefulBuilder(builder: (context, setState) {
          return PortFolioActionButton(
            positionSheet: true,
            showBubble: widget.notify,
            toggle: widget.toggles,
            tag: true,
            setAlert: () {
              setState(() {
                widget.notify = !widget.notify;
              });
            },
            addtag: () {
              setState(() {
                widget.toggles = !widget.toggles;
              });
              customShowModalBottomSheet(
                context: context,
                inputWidget: StatefulBuilder(builder: (context, setState) {
                  return TagColorWidget(
                    onCountChanged: (Color color) {
                      this.setState(() {
                        selectedColor = color;
                      });
                    },
                    colorSelection: () {},
                    colorList: [
                      {"name": "Red", "color": customColors().danger},
                      {"name": "Green", "color": customColors().success},
                      {"name": "Yellow", "color": customColors().warning},
                      {"name": "Blue", "color": customColors().info}
                    ],
                  );
                }),
              );
            },
          );
        }),
        PortFolioPositionPanel(
          reportData: widget.reportData![widget.index],
          total_pl: widget.pl.toString(),
          todays_pl: widget.todays_pl.toString(),
          total_pl_percentage: widget.pl_percentage.toString(),
          todays_pl_percentage: widget.todays_pl_percentage.toString(),
        ),
        FixedButton(
          future: widget.future,
          rollOnTap: widget.onRollTap,
          addMoreOnTap: widget.onAddMoreTap,
          ocoOnTap: widget.onOCOTap,
          squareOffOnTap: widget.onSquareOffTap,
        ),
      ],
    );
  }
}
