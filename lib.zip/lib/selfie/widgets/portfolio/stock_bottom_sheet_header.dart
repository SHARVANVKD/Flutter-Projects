import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/options_widget.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';
import 'package:selfie_mobile_flutter/utils/common_prop.dart';

class Stock_Sheet_Header extends StatefulWidget {
  Color? bgcolor;
  String symbol;
  String ltp;
  String per_change;
  String net_pos;
  String change_per;
  String producttype;
  Stock_Sheet_Header(
      {Key? key,
      this.bgcolor,
      required this.ltp,
      required this.change_per,
      required this.producttype,
      required this.symbol,
      required this.per_change,
      required this.net_pos})
      : super(key: key);

  @override
  State<Stock_Sheet_Header> createState() => _Stock_Sheet_HeaderState();
}

class _Stock_Sheet_HeaderState extends State<Stock_Sheet_Header> {
  @override
  Widget build(BuildContext context) {
    double mheight = MediaQuery.of(context).size.height * 1.22;
    return Container(
      width: MediaQuery.of(context).size.width,
      height: widget.net_pos != "" ? 134.0 : 102,
      decoration: BoxDecoration(
          color: widget.bgcolor,
          border: Border.all(color: transparent),
          borderRadius: BorderRadius.only(
              topLeft: Radius.circular(15.0), topRight: Radius.circular(15.0))),
      child: Center(
          child: Padding(
        padding: const EdgeInsets.only(left: 16.5, right: 16.0, top: 19.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Row(
                      children: [
                        Text(
                          widget.symbol,
                          style: customTextStyle(
                              fontStyle: FontStyle.BodyL_SemiBold,
                              color: FontColor.FontPrimary),
                        ),
                        Visibility(
                          visible: false,
                          child: Padding(
                            padding: const EdgeInsets.only(left: 4.0),
                            child: Container(
                                width: 14,
                                height: 14,
                                alignment: Alignment.center,
                                decoration: BoxDecoration(
                                    color: customColors().wTokenBackground,
                                    borderRadius: BorderRadius.circular(14)),
                                child: Align(
                                  alignment: Alignment.center,
                                  child: Text(
                                    "W",
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                        fontFamily: "OpenSansRegular",
                                        fontSize: 8,
                                        fontWeight: FontWeight.w600,
                                        color: customColors().wTokenFontColor),
                                  ),
                                )),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(left: 8.0),
                          child: getProductTypeWidget(widget.producttype),
                        ),
                      ],
                    ),
                    Padding(
                      padding: EdgeInsets.only(
                        top: 10.0,
                      ),
                      child: Row(
                        children: [
                          Text(
                            "LTP: ",
                            style: customTextStyle(
                                fontStyle: FontStyle.BodyL_Regular,
                                color: FontColor.FontTertiary),
                          ),
                          Text(
                            widget.ltp,
                            style: customTextStyle(
                                fontStyle: FontStyle.BodyL_SemiBold,
                                color: FontColor.FontPrimary),
                          ),
                          Padding(
                            padding: EdgeInsets.only(left: 12.0),
                            child: Text(
                              widget.per_change +
                                  "(" +
                                  widget.change_per +
                                  "%)",
                              style: customTextStyle(
                                  fontStyle: FontStyle.BodyM_SemiBold,
                                  color: getFeedColor(
                                      double.parse(widget.per_change))),
                            ),
                          )
                        ],
                      ),
                    )
                  ],
                ),
                Container(
                  height: 23.0,
                  width: 23.0,
                  decoration: BoxDecoration(
                      color: customColors().primary, shape: BoxShape.circle),
                  child: Icon(
                    Icons.arrow_forward_ios,
                    color: customColors().backgroundPrimary,
                    size: 10.0,
                  ),
                ),
              ],
            ),
            widget.net_pos != ""
                ? Padding(
                    padding: const EdgeInsets.only(top: 16.0),
                    child: Row(
                      children: [
                        Text(
                          "Net Positon:",
                          style: customTextStyle(
                              fontStyle: FontStyle.BodyL_Regular,
                              color: FontColor.FontTertiary),
                        ),
                        SizedBox(
                          width: 4.0,
                        ),
                        Text(
                          widget.net_pos,
                          style: customTextStyle(
                              fontStyle: FontStyle.BodyL_SemiBold,
                              color: FontColor.FontPrimary),
                        )
                      ],
                    ),
                  )
                : Container(),
          ],
        ),
      )),
    );
  }
}
