import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/custom_dot.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/options_widget.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';
import 'package:selfie_mobile_flutter/user_controller/user_controller.dart';
import 'package:selfie_mobile_flutter/utils/common_prop.dart';
import 'package:trading_api/responses/portfolio_responce.dart';

class HoldingsListTile extends StatefulWidget {
  List<ReportDatum> reportData;
  int index;
  HoldingsListTile({Key? key, required this.reportData, required this.index})
      : super(key: key);

  @override
  State<HoldingsListTile> createState() => _HoldingsListTileState();
}

class _HoldingsListTileState extends State<HoldingsListTile> {
  var paint1 = Paint()
    ..color = customColors().success
    ..strokeCap = StrokeCap.round //rounded points
    ..strokeWidth = 10;

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 16),
        decoration: BoxDecoration(
            border: Border(
          bottom:
              BorderSide(color: customColors().backgroundTertiary, width: 1),
        )),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Visibility(
                // visible: widget.portfoliolist.containsKey("topview"),
                visible: true,
                child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          Padding(
                            padding:
                                const EdgeInsets.symmetric(horizontal: 0.0),
                            child: getProductTypeWidget(
                                widget.reportData[widget.index].producttype),
                          ),
                        ],
                      ),
                      Text(
                        widget.reportData[widget.index].plPercentage.isNaN
                            ? "0.00"
                            : widget.reportData[widget.index].plPercentage
                                .toStringAsFixed(2)
                                .toString(),
                        style: customTextStyle(
                                fontStyle: FontStyle.BodyM_Regular,
                                color: getFeedColor(widget
                                    .reportData[widget.index].plPercentage))
                            .copyWith(fontWeight: FontWeight.w600),
                      ),
                    ]),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 10),
                child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          Text(
                            widget.reportData[widget.index].securitycode
                                .toString(),
                            style: customTextStyle(
                                fontStyle: FontStyle.BodyL_SemiBold,
                                color: FontColor.FontPrimary),
                          ),
                          // Visibility(
                          //   visible:
                          //       widget.portfoliolist.containsKey("contract"),
                          //   child: Row(
                          //     children: [
                          //       Padding(
                          //         padding: const EdgeInsets.only(left: 8.0),
                          //         child: Container(
                          //             width: 14,
                          //             height: 14,
                          //             alignment: Alignment.center,
                          //             decoration: BoxDecoration(
                          //                 color:
                          //                     customColors().wTokenBackground,
                          //                 borderRadius:
                          //                     BorderRadius.circular(14)),
                          //             child: Align(
                          //               alignment: Alignment.center,
                          //               child: Text(
                          //                 "W",
                          //                 textAlign: TextAlign.center,
                          //                 style: TextStyle(
                          //                     fontFamily: "OpenSansRegular",
                          //                     fontSize: 8,
                          //                     fontWeight: FontWeight.w600,
                          //                     color: customColors()
                          //                         .wTokenFontColor),
                          //               ),
                          //             )),
                          //       ),
                          //       const SizedBox(
                          //         width: 5,
                          //       ),
                          //       Visibility(
                          //         visible:
                          //             widget.portfoliolist.containsKey("date"),
                          //         child: Text(
                          //           widget.portfoliolist["date"].toString(),
                          //           style: customTextStyle(
                          //               fontStyle: FontStyle.BodyL_SemiBold,
                          //               color: FontColor.FontPrimary),
                          //         ),
                          //       )
                          //     ],
                          //   ),
                          // )
                        ],
                      ),
                      Text(
                        widget.reportData[widget.index].pl
                            .toStringAsFixed(2)
                            .toString(),
                        style: customTextStyle(
                            fontStyle: FontStyle.BodyL_SemiBold,
                            color: widget.reportData[widget.index].pl
                                    .toStringAsFixed(2)
                                    .toString()
                                    .contains("-")
                                ? FontColor.Danger
                                : FontColor.Success),
                      ),
                    ]),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 4.0),
                child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Text(
                            widget.reportData[widget.index].availablenetqty,
                            style: customTextStyle(
                                fontStyle: FontStyle.BodyM_SemiBold,
                                color: FontColor.FontSecondary),
                          ),
                          Text(
                            " Qty",
                            style: customTextStyle(
                                fontStyle: FontStyle.BodyM_Regular,
                                color: FontColor.FontTertiary),
                          ),
                          Padding(
                            padding:
                                const EdgeInsets.only(left: 8.0, right: 8.0),
                            child:
                                CustomDot(color: customColors().fontSecondary),
                          ),
                          Text(
                            "Avg ",
                            style: customTextStyle(
                                fontStyle: FontStyle.BodyM_Regular,
                                color: FontColor.FontTertiary),
                          ),
                          Text(
                            double.parse(
                                    widget.reportData[widget.index].avgrate)
                                .toStringAsFixed(2)
                                .toString(),
                            style: customTextStyle(
                                fontStyle: FontStyle.BodyM_SemiBold,
                                color: FontColor.FontSecondary),
                          ),
                        ],
                      ),
                      Row(
                        children: [
                          Text(
                            "LTP ",
                            style: customTextStyle(
                                fontStyle: FontStyle.BodyM_Regular,
                                color: FontColor.FontTertiary),
                          ),
                          Text(
                            widget.reportData[widget.index].mktrate,
                            style: customTextStyle(
                                fontStyle: FontStyle.BodyM_SemiBold,
                                color: FontColor.FontSecondary),
                          )
                        ],
                      ),
                    ]),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
