import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/constants/formaters.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/empty_container.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

holdingsContainer(
    {required BuildContext context,
    required double amount,
    required double percentage,
    Function()? onClickIcon}) {
  return GestureDetector(
    onTap: onClickIcon,
    child: Container(
      decoration: BoxDecoration(
          borderRadius: const BorderRadius.all(Radius.circular(4)),
          color: customColors().backgroundSecondary),
      padding: const EdgeInsets.fromLTRB(16, 16, 18, 16),
      margin: const EdgeInsets.all(16),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "TOTAL P&L",
                style: customTextStyle(
                    fontStyle: FontStyle.BodyM_SemiBold,
                    color: FontColor.FontSecondary),
              ),
              const SizedBox(height: 10),
              RichText(
                  text: TextSpan(children: <TextSpan>[
                TextSpan(
                  text: amount < 0
                      ? Formats.valueFormat.format(amount)
                      : amount > 0
                          ? "+${Formats.valueFormat.format(amount)}"
                          : "-${Formats.valueFormat.format(amount)}",
                  style: customTextStyle(
                      fontStyle: FontStyle.HeaderS_Bold,
                      color: amount < 0 ? FontColor.Danger : FontColor.Success),
                ),
                const TextSpan(text: "  "),
                TextSpan(
                  text: percentage < 0
                      ? "${Formats.valueFormat.format(percentage)}%"
                      : percentage > 0
                          ? "+${Formats.valueFormat.format(percentage)}%"
                          : "-${Formats.valueFormat.format(percentage)}.0%",
                  style: customTextStyle(
                      fontStyle: FontStyle.BodyM_SemiBold,
                      color: FontColor.FontSecondary),
                )
              ])),
            ],
          ),
          percentage > 0
              ? IconButton(
                  onPressed: onClickIcon,
                  icon: Image.asset("assets/primary_filled_arrow.png"))
              : Container(
                  height: 20,
                  width: 20,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: customColors().primary.withOpacity(0.4),
                  ),
                  child: Center(
                      child: Icon(
                    Icons.arrow_forward_ios,
                    size: 10.0,
                    color: customColors().backgroundPrimary,
                  )),
                )
        ],
      ),
    ),
  );
}

emptyContainerPortfolioHoldings(BuildContext context) {
  return Column(
    mainAxisAlignment: MainAxisAlignment.center,
    children: [
      EmptyContainer(
          height: 150, width: 320, color: customColors().backgroundSecondary),
      Padding(
        padding: const EdgeInsets.only(top: 20.0),
        child: Align(
            alignment: Alignment.center,
            child: Text(
              "No Holdings",
              style: customTextStyle(
                  fontStyle: FontStyle.BodyL_SemiBold,
                  color: FontColor.FontPrimary),
            )),
      ),
      Padding(
        padding: const EdgeInsets.only(top: 4),
        child: Align(
            alignment: Alignment.center,
            child: Text(
              "Buy equities from your watchlist",
              style: customTextStyle(
                  fontStyle: FontStyle.BodyM_Regular,
                  color: FontColor.FontSecondary),
            )),
      )
    ],
  );
}
