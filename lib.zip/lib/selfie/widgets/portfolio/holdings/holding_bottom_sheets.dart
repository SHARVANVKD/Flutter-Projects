import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/repository_layer/portfolio_content.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/portfolio_bottom_sheet_panel/portfolio_button_actions.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/portfolio_bottom_sheet_panel/portfolio_holding_panel.dart';
import 'package:selfie_mobile_flutter/user_controller/user_controller.dart';
import 'package:trading_api/responses/portfolio_responce.dart';

class HoildinBottomSheet extends StatefulWidget {
  List<ReportDatum>? reportData;
  int index;
  String pl;
  String pl_percentage;
  String todays_pl;
  HoildinBottomSheet(
      {Key? key,
      required this.reportData,
      required this.index,
      required this.pl,
      required this.pl_percentage,
      required this.todays_pl})
      : super(key: key);

  @override
  State<HoildinBottomSheet> createState() => _HoildinBottomSheetState();
}

class _HoildinBottomSheetState extends State<HoildinBottomSheet> {
  bool notify = false;
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        StatefulBuilder(builder: (context, setState) {
          return PortFolioActionButton(
            positionSheet: false,
            tag: false,
            addtag: () {},
            setAlert: () {
              setState(() {
                notify = !notify;
              });
            },
            showBubble: notify,
          );
        }),
        PortFolioHoldingPanel(
          portFolioHoldingData: widget.reportData![widget.index],
          total_pl: widget.pl,
          total_pl_percentage: widget.pl_percentage,
          todays_pl: widget.todays_pl,
        ),
      ],
    );
  }
}
