import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class Port_Smart_Header extends StatefulWidget {
  Color bgcolor;
  String total;
  FontColor? totalcolor;
  String title;
  double? hwidth;
  Port_Smart_Header(
      {Key? key,
      required this.bgcolor,
      required this.total,
      this.totalcolor,
      required this.title,
      this.hwidth})
      : super(key: key);

  @override
  _Port_Smart_HeaderState createState() => _Port_Smart_HeaderState();
}

class _Port_Smart_HeaderState extends State<Port_Smart_Header> {
  @override
  Widget build(BuildContext context) {

    double mheight = MediaQuery.of(context).size.height * 2.222;

    return Container(
      width: widget.hwidth,
      decoration: BoxDecoration(
          color: widget.bgcolor, borderRadius: BorderRadius.circular(4.0)),
      child: Padding(
        padding: const EdgeInsets.only(left: 16.0, bottom: 10.0, top: 16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.end,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              widget.title.toString(),
              style: customTextStyle(
                  fontStyle: FontStyle.BodyM_SemiBold,
                  color: FontColor.FontSecondary),
            ),
            const SizedBox(
              height: 10,
            ),
            Text(
              widget.total,
              style: customTextStyle(
                  fontStyle: FontStyle.HeaderS_Bold,
                  color: widget.totalcolor!),
            )
          ],
        ),
      ),
    );
  }
}
