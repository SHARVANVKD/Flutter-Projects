import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/custom_dot.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class SmartfolioHoldingItem extends StatefulWidget {
  Map<String, dynamic> portfoliolist;
  SmartfolioHoldingItem({Key? key, required this.portfoliolist})
      : super(key: key);

  @override
  State<SmartfolioHoldingItem> createState() => _PortfolioListItemState();
}

class _PortfolioListItemState extends State<SmartfolioHoldingItem> {
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 16),
        decoration: BoxDecoration(
            border: Border(
          bottom:
              BorderSide(color: customColors().backgroundTertiary, width: 1),
        )),
        child: InkWell(
          onTap: () {},
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Padding(
                padding: const EdgeInsets.only(top: 10),
                child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          Text(
                            widget.portfoliolist["name"],
                            style: customTextStyle(
                                fontStyle: FontStyle.BodyL_SemiBold,
                                color: FontColor.FontPrimary),
                          ),
                          Visibility(
                            visible:
                                widget.portfoliolist.containsKey("contract"),
                            child: Row(
                              children: [
                                Padding(
                                  padding: const EdgeInsets.only(left: 8.0),
                                  child: Container(
                                      width: 14,
                                      height: 14,
                                      alignment: Alignment.center,
                                      decoration: BoxDecoration(
                                          color:
                                              customColors().wTokenBackground,
                                          borderRadius:
                                              BorderRadius.circular(14)),
                                      child: Align(
                                        alignment: Alignment.center,
                                        child: Text(
                                          "W",
                                          textAlign: TextAlign.center,
                                          style: TextStyle(
                                              fontFamily: "OpenSansRegular",
                                              fontSize: 8,
                                              fontWeight: FontWeight.w600,
                                              color: customColors()
                                                  .wTokenFontColor),
                                        ),
                                      )),
                                ),
                                const SizedBox(
                                  width: 5,
                                ),
                                Visibility(
                                  visible:
                                      widget.portfoliolist.containsKey("date"),
                                  child: Text(
                                    widget.portfoliolist["date"].toString(),
                                    style: customTextStyle(
                                        fontStyle: FontStyle.BodyL_SemiBold,
                                        color: FontColor.FontPrimary),
                                  ),
                                )
                              ],
                            ),
                          )
                        ],
                      ),
                      Row(
                        children: [
                          Text(
                            widget.portfoliolist["PANDL"],
                            style: customTextStyle(
                                fontStyle: FontStyle.BodyL_SemiBold,
                                color: widget.portfoliolist["pandlcolor"]),
                          ),
                          Text(
                            " (" + widget.portfoliolist["PANDLPER"] + ")",
                            style: customTextStyle(
                                fontStyle: FontStyle.BodyM_Regular,
                                color: widget.portfoliolist["pandlcolor"]),
                          ),
                        ],
                      ),
                    ]),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 4.0),
                child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Text(
                            widget.portfoliolist["QUANTITY"].toString(),
                            style: customTextStyle(
                                fontStyle: FontStyle.BodyM_SemiBold,
                                color: FontColor.FontSecondary),
                          ),
                          Text(
                            " Qty",
                            style: customTextStyle(
                                fontStyle: FontStyle.BodyM_Regular,
                                color: FontColor.FontTertiary),
                          ),
                          Padding(
                            padding:
                                const EdgeInsets.only(left: 6.0, right: 6.0),
                            child:
                                CustomDot(color: customColors().fontSecondary),
                          ),
                          Text(
                            " Avg ",
                            style: customTextStyle(
                                fontStyle: FontStyle.BodyM_Regular,
                                color: FontColor.FontTertiary),
                          ),
                          Text(
                            widget.portfoliolist["avg"].toString(),
                            style: customTextStyle(
                                fontStyle: FontStyle.BodyM_SemiBold,
                                color: FontColor.FontSecondary),
                          ),
                        ],
                      ),
                      Row(
                        children: [
                          Text(
                            "LTP ",
                            style: customTextStyle(
                                fontStyle: FontStyle.BodyM_Regular,
                                color: FontColor.FontTertiary),
                          ),
                          Text(
                            widget.portfoliolist["Ltp"].toString(),
                            style: customTextStyle(
                                fontStyle: FontStyle.BodyM_SemiBold,
                                color: FontColor.FontSecondary),
                          )
                        ],
                      ),
                    ]),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
