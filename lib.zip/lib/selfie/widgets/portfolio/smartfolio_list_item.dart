import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/bloc_navigation/navigation_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/custom_dot.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class SmartfolioListItem extends StatefulWidget {
  final Map<String, dynamic> smartfolioListContent;
  const SmartfolioListItem({Key? key, required this.smartfolioListContent})
      : super(key: key);

  @override
  State<SmartfolioListItem> createState() => _SmartfolioListItemState();
}

class _SmartfolioListItemState extends State<SmartfolioListItem> {
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.only(bottom: 8, left: 16, right: 16, top: 8),
      child: InkWell(
        onTap: () {
          BlocProvider.of<NavigationCubit>(context).updateWatchList(7);
        },
        child: Container(
          height: 160,
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
              color: customColors().backgroundPrimary,
              borderRadius: BorderRadius.circular(4),
              border: Border.all(color: customColors().backgroundTertiary)),
          child: Column(
            children: [
              Container(
                  height: 75,
                  decoration: BoxDecoration(
                      border: Border(
                    bottom:
                        BorderSide(color: customColors().backgroundTertiary),
                  )),
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            children: [
                              Image.asset(
                                widget.smartfolioListContent["icon"],
                                color: widget.smartfolioListContent["iconcolor"],
                                height: 32,
                                width: 32,
                              ),
                              Padding(
                                padding: const EdgeInsets.only(left: 8),
                                child: Text(
                                  widget.smartfolioListContent["hedder"],
                                  style: customTextStyle(
                                      fontStyle: FontStyle.HeaderXS_Bold,
                                      color: FontColor.FontPrimary),
                                ),
                              ),
                            ],
                          ),
                          Image.asset("assets/filled_arrow.png"),
                        ],
                      ),
                      Padding(
                        padding: const EdgeInsets.only(top: 8),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Text(
                              widget.smartfolioListContent["QUANTITY"],
                              style: customTextStyle(
                                  fontStyle: FontStyle.BodyM_SemiBold,
                                  color: FontColor.FontSecondary),
                            ),
                            Text(
                              " Stocks",
                              style: customTextStyle(
                                  fontStyle: FontStyle.BodyM_Regular,
                                  color: FontColor.FontSecondary),
                            ),
                            Padding(
                              padding:
                                  const EdgeInsets.only(left: 6.0, right: 6.0),
                              child: CustomDot(
                                  color: customColors().fontSecondary),
                            ),
                            Text(
                              widget.smartfolioListContent["holdingper"],
                              style: customTextStyle(
                                  fontStyle: FontStyle.BodyM_SemiBold,
                                  color: FontColor.FontSecondary),
                            ),
                            Text(
                              " of holdings",
                              style: customTextStyle(
                                  fontStyle: FontStyle.BodyM_Regular,
                                  color: FontColor.FontSecondary),
                            ),
                          ],
                        ),
                      ),
                    ],
                  )),
              Container(
                padding: const EdgeInsets.only(top: 12),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(widget.smartfolioListContent["label1"],
                              style: customTextStyle(
                                  fontStyle: FontStyle.BodyM_Regular,
                                  color: FontColor.FontSecondary)),
                          const SizedBox(height: 4,),     
                          Text(
                            widget.smartfolioListContent["value1"],
                            style: customTextStyle(
                                fontStyle: FontStyle.BodyL_SemiBold,
                                color: FontColor.FontPrimary),
                          ),
                        ],
                      ),
                    ),
                    Expanded(
                      flex:1,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Text(
                            widget.smartfolioListContent["label2"],
                            style: customTextStyle(
                                fontStyle: FontStyle.BodyM_Regular,
                                color: FontColor.FontSecondary),
                          ),
                          const SizedBox(height: 4,),   
                      Text(
                        widget.smartfolioListContent["value2"],
                        style: customTextStyle(
                            fontStyle: FontStyle.BodyL_SemiBold,
                            color: FontColor.FontPrimary),
                      ),
                        ],
                      ),
                    ),
                    Expanded(
                      flex:1,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Text(
                            widget.smartfolioListContent["label3"],
                            style: customTextStyle(
                                fontStyle: FontStyle.BodyM_Regular,
                                color: FontColor.FontSecondary),
                          ),
                          const SizedBox(height: 4,),   
                          Text(
                            widget.smartfolioListContent["value3"],
                            style: customTextStyle(
                                fontStyle: FontStyle.BodyL_SemiBold,
                                color: FontColor.Success),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
