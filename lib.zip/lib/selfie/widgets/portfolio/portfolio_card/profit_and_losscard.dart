import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/constants/formaters.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class ProfitAndLossCard extends StatefulWidget {
  double amount;
  String percentage;
  bool ststus;
  double width;
  double height;
  ProfitAndLossCard(
      {Key? key,
      required this.amount,
      required this.percentage,
      required this.ststus,
      this.height = double.maxFinite,
      this.width = double.maxFinite})
      : super(key: key);

  @override
  State<ProfitAndLossCard> createState() => _ProfitAndLossCardState();
}

class _ProfitAndLossCardState extends State<ProfitAndLossCard> {
  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: const BorderRadius.all(Radius.circular(4)),
        color: customColors().backgroundSecondary,
      ),
      padding: const EdgeInsets.all(16),
      margin: const EdgeInsets.symmetric(horizontal: 16),
      height: widget.height,
      width: widget.width,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "TOTAL P&L",
                style: customTextStyle(
                    fontStyle: FontStyle.BodyM_Regular,
                    color: FontColor.FontSecondary),
              ),
              const SizedBox(height: 10),
              RichText(
                  text: TextSpan(children: <TextSpan>[
                TextSpan(
                  text: widget.ststus
                      ? "+ ${Formats.valueFormat.format(widget.amount)}"
                      : "- ${Formats.valueFormat.format(widget.amount)}",
                  style: customTextStyle(
                      fontStyle: FontStyle.HeaderS_Bold,
                      color:
                          widget.ststus ? FontColor.Success : FontColor.Danger),
                ),
                const TextSpan(text: "   "),
                TextSpan(
                  text: widget.ststus
                      ? "+${widget.percentage}%"
                      : "-${widget.percentage}%",
                  style: customTextStyle(
                      fontStyle: FontStyle.BodyM_SemiBold,
                      color: FontColor.FontSecondary),
                )
              ])),
            ],
          ),
          const Expanded(child: SizedBox()),
          GestureDetector(
              onTap: () {}, child: Image.asset("assets/rightbtn.png"))
        ],
      ),
    );
  }
}
