import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/constants/formaters.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class HoldingsCard extends StatefulWidget {
  double amount;
  String percentage;
  double width;
  double height;
  bool status;
  String? equity;
  HoldingsCard(
      {Key? key,
      required this.amount,
      this.width = double.maxFinite,
      this.height = double.maxFinite,
      required this.percentage,
      required this.status,
      this.equity})
      : super(key: key);

  @override
  State<HoldingsCard> createState() => _HoldingsCardState();
}

class _HoldingsCardState extends State<HoldingsCard> {
  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
          borderRadius: const BorderRadius.all(Radius.circular(4)),
          color: customColors().backgroundSecondary),
      padding: const EdgeInsets.all(16),
      margin: const EdgeInsets.symmetric(horizontal: 16),
      height: widget.height,
      width: widget.width,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Text(
            "TOTAL P&L",
            style: customTextStyle(
                fontStyle: FontStyle.BodyM_SemiBold,
                color: FontColor.FontSecondary),
          ),
          const SizedBox(height: 8),
          RichText(
              text: TextSpan(children: <TextSpan>[
            TextSpan(
              text: widget.status
                  ? "+${Formats.valueFormat.format(widget.amount)}"
                  : "-${Formats.valueFormat.format(widget.amount)}",
              style: customTextStyle(
                  fontStyle: FontStyle.HeaderS_Bold,
                  color: widget.status ? FontColor.Success : FontColor.Danger),
            ),
            const TextSpan(text: "   "),
            TextSpan(
              text: widget.status
                  ? "+${widget.percentage}%"
                  : "-${widget.percentage}%",
              style: widget.equity == "y"
                  ? customTextStyle(
                      fontStyle: FontStyle.BodyM_SemiBold,
                      color: FontColor.Success)
                  : customTextStyle(
                      fontStyle: FontStyle.BodyM_SemiBold,
                      color: FontColor.FontSecondary),
            )
          ])),
        ],
      ),
    );
  }
}
