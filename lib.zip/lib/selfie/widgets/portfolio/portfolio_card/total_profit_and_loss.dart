import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/constants/formaters.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class TotalProfitAndLoss extends StatefulWidget {
  double amount;
  bool status;
  double width;
  double height;
  TotalProfitAndLoss(
      {Key? key,
      required this.amount,
      required this.status,
      this.height = double.maxFinite,
      this.width = double.maxFinite})
      : super(key: key);

  @override
  State<TotalProfitAndLoss> createState() => _TotalProfitAndLossState();
}

class _TotalProfitAndLossState extends State<TotalProfitAndLoss> {
  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
          borderRadius: const BorderRadius.all(Radius.circular(4)),
          color: customColors().backgroundSecondary),
      padding: const EdgeInsets.all(16),
      margin: const EdgeInsets.symmetric(horizontal: 16),
      height: widget.height,
      width: widget.width,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "TOTAL P&L",
            style: customTextStyle(
                fontStyle: FontStyle.BodyM_Regular,
                color: FontColor.FontSecondary),
          ),
          const SizedBox(height: 10),
          Text(
            widget.status
                ? "+ ${Formats.valueFormat.format(widget.amount)}"
                : "- ${Formats.valueFormat.format(widget.amount)}",
            style: customTextStyle(
                fontStyle: FontStyle.HeaderS_Bold,
                color: widget.status ? FontColor.Success : FontColor.Danger),
          ),
        ],
      ),
    );
  }
}
