import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/constants/formaters.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class InvestmentDetailCard extends StatefulWidget {
  double amount;
  String title;
  double width;
  double height;

  InvestmentDetailCard(
      {Key? key,
      required this.amount,
      required this.title,
      this.height = double.maxFinite,
      this.width = double.maxFinite})
      : super(key: key);

  @override
  State<InvestmentDetailCard> createState() => _InvestmentDetailCardState();
}

class _InvestmentDetailCardState extends State<InvestmentDetailCard> {
  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: const BorderRadius.all(Radius.circular(4)),
        color: customColors().backgroundSecondary,
      ),
      padding: const EdgeInsets.all(16),
      height: widget.height,
      width: widget.width,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Text(
            widget.title,
            style: customTextStyle(
                fontStyle: FontStyle.BodyM_Regular,
                color: FontColor.FontSecondary),
          ),
          const SizedBox(height: 4),
          Text(
            Formats.valueFormatIndian.format(widget.amount),
            style: customTextStyle(
                fontStyle: FontStyle.HeaderXS_Bold,
                color: FontColor.FontPrimary),
          ),
        ],
      ),
    );
  }
}
