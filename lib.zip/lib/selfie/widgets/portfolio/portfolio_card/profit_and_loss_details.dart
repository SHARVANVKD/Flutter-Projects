import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/constants/formaters.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class ProfitAndLossDetails extends StatefulWidget {
  double totalAmount;
  double todayAmount;
  String totalPercentage;
  String todayPercentage;
  double width;
  double height;
  bool totalStatus;
  bool todayStatus;
  bool smartfolio;

  ProfitAndLossDetails(
      {Key? key,
      required this.todayAmount,
      required this.todayPercentage,
      this.height = double.maxFinite,
      this.width = double.maxFinite,
      required this.todayStatus,
      required this.totalAmount,
      required this.totalPercentage,
      this.smartfolio = false,
      required this.totalStatus})
      : super(key: key);

  @override
  State<ProfitAndLossDetails> createState() => _ProfitAndLossDetailsState();
}

class _ProfitAndLossDetailsState extends State<ProfitAndLossDetails> {
  @override
  Widget build(BuildContext context) {
    Size screenSize = MediaQuery.of(context).size;
    return Container(
      decoration: BoxDecoration(
        borderRadius: const BorderRadius.all(Radius.circular(4)),
        color: customColors().backgroundSecondary,
      ),
      padding: const EdgeInsets.all(16),
      height: widget.height,
      width: widget.width,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          const Expanded(child: SizedBox()),
          SizedBox(
            width: screenSize.width * 0.3,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Text(
                  "TOTAL P&L",
                  style: customTextStyle(
                      fontStyle: FontStyle.BodyM_Regular,
                      color: FontColor.FontSecondary),
                ),
                const SizedBox(height: 6),
                Text(
                  widget.totalAmount != 0
                      ? widget.totalStatus
                          ? "+${Formats.valueFormat.format(widget.totalAmount)}"
                          : "-${Formats.valueFormat.format(widget.totalAmount)}"
                      : Formats.valueFormat.format(widget.totalAmount),
                  style: customTextStyle(
                      fontStyle: FontStyle.HeaderXS_Bold,
                      color: widget.totalStatus
                          ? FontColor.Success
                          : FontColor.Danger),
                ),
                const SizedBox(height: 3),
                widget.totalPercentage == "0"
                    ? Text(
                        "${widget.totalPercentage}%",
                        style: customTextStyle(
                            fontStyle: FontStyle.BodyM_SemiBold,
                            color: FontColor.FontSecondary),
                      )
                    : Text(
                        "+${widget.totalPercentage}%",
                        style: customTextStyle(
                            fontStyle: FontStyle.BodyM_SemiBold,
                            color: FontColor.FontSecondary),
                      ),
              ],
            ),
          ),
          const Expanded(child: SizedBox()),
          Container(
            width: 1,
            color: customColors().backgroundTertiary,
            height: double.maxFinite,
          ),
          const Expanded(child: SizedBox()),
          SizedBox(
            width: screenSize.width * 0.3,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Text(
                  widget.smartfolio ? "REALIZED P&L" : "TODAYS P&L",
                  style: customTextStyle(
                      fontStyle: FontStyle.BodyM_Regular,
                      color: FontColor.FontSecondary),
                ),
                const SizedBox(height: 6),
                Text(
                  widget.todayAmount != 0
                      ? widget.todayStatus
                          ? "+${Formats.valueFormat.format(widget.todayAmount)}"
                          : "-${Formats.valueFormat.format(widget.todayAmount)}"
                      : Formats.valueFormat.format(widget.todayAmount),
                  style: customTextStyle(
                      fontStyle: FontStyle.HeaderXS_Bold,
                      color: widget.todayStatus
                          ? FontColor.Success
                          : FontColor.Danger),
                ),
                const SizedBox(height: 3),
                widget.todayPercentage == "0"
                    ? Text(
                        widget.todayStatus
                            ? "${widget.todayPercentage}%"
                            : "${widget.todayPercentage}%",
                        style: customTextStyle(
                            fontStyle: FontStyle.BodyM_SemiBold,
                            color: FontColor.FontSecondary),
                      )
                    : Text(
                        widget.todayStatus
                            ? "+${widget.todayPercentage}%"
                            : "-${widget.todayPercentage}%",
                        style: customTextStyle(
                            fontStyle: FontStyle.BodyM_SemiBold,
                            color: FontColor.FontSecondary),
                      ),
              ],
            ),
          ),
          const Expanded(child: SizedBox()),
        ],
      ),
    );
  }
}
