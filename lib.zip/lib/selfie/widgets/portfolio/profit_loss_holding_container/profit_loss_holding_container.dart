import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class HoldingContainer extends StatelessWidget {
  double? height;
  double? width;
  HoldingContainer({Key? key, this.height, this.width}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      height: height ?? MediaQuery.of(context).size.height * 0.14,
      width: width ?? MediaQuery.of(context).size.width * 0.9,
      decoration: BoxDecoration(
        color: customColors().backgroundSecondary,
        borderRadius: BorderRadius.circular(4),
      ),
      child: Row(
        children: const [],
      ),
    );
  }
}
