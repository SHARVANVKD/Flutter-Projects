import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class Holding_List_Header extends StatelessWidget {
  Color bgcolor;
  String total;
  String change_percentage;
  FontColor? totalcolor;
  String title;
  double? hwidth;
  Holding_List_Header(
      {Key? key,
      required this.title,
      required this.bgcolor,
      required this.total,
      required this.change_percentage,
      this.totalcolor,
      this.hwidth})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    double mheight = MediaQuery.of(context).size.height * 1.22;

    return Padding(
      padding: const EdgeInsets.only(left: 16.0, right: 16.0, top: 16.0),
      child: Container(
        height: mheight * .084,
        width: hwidth,
        decoration: BoxDecoration(
          color: bgcolor,
        ),
        child: Center(
            child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              title,
              style: customTextStyle(
                  fontStyle: FontStyle.BodyM_SemiBold,
                  color: FontColor.FontTertiary),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 8.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    total,
                    style: customTextStyle(
                        fontStyle: FontStyle.HeaderS_Bold,
                        color: totalcolor!),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left: 8.0),
                    child: Text(
                      change_percentage,
                      style: customTextStyle(
                          fontStyle: FontStyle.BodyM_SemiBold,
                          color: totalcolor!),
                    ),
                  )
                ],
              ),
            )
          ],
        )),
      ),
    );
  }
}
