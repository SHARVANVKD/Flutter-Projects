import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/constants/formaters.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/custom_dot.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/options_widget.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';
import 'package:selfie_mobile_flutter/user_controller/user_controller.dart';
import 'package:selfie_mobile_flutter/utils/common_prop.dart';
import 'package:selfie_mobile_flutter/utils/shimmer_loader.dart';
import 'package:trading_api/responses/portfolio_responce.dart';

class PortfolioListItem extends StatefulWidget {
  List<Intradaydatum>? portfoliolist;
  final VoidCallback? onLongPressAction;
  final VoidCallback? onTap;
  int index;
  PortfolioListItem(
      {Key? key,
      required this.portfoliolist,
      this.onLongPressAction,
      this.onTap,
      this.index = 0})
      : super(key: key);

  @override
  State<PortfolioListItem> createState() => _PortfolioListItemState();
}

class _PortfolioListItemState extends State<PortfolioListItem> {
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onLongPress: widget.onLongPressAction,
      onTap: widget.onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 16),
          decoration: BoxDecoration(
              border: Border(
            bottom:
                BorderSide(color: customColors().backgroundTertiary, width: 1),
          )),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 8),
            decoration: BoxDecoration(
                border: Border(
              left: BorderSide(
                  color: getPositionColor(
                      double.parse(widget.portfoliolist![widget.index].netqty)),
                  width: 2),
            )),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Visibility(
                  visible: true,
                  child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          children: [
                            Visibility(
                              visible: false,
                              child: Padding(
                                padding: const EdgeInsets.only(right: 6),
                                child: Image.asset("assets/tag_position.png"),
                              ),
                            ),
                            Padding(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 0.0),
                              child: widget.portfoliolist![widget.index]
                                          .producttype !=
                                      null
                                  ? getProductTypeWidget(widget
                                      .portfoliolist![widget.index].producttype)
                                  : ShimmerLoader(height: 20, width: 50),
                            ),
                          ],
                        ),
                        // Text(
                        //   double.parse(UserController()
                        //           .portfolioresponce!
                        //           .intradaydata[widget.index]
                        //           .pl
                        //           .toString())
                        //       .toStringAsFixed(2)
                        //       .toString(),
                        //   style: customTextStyle(
                        //       fontStyle: FontStyle.BodyL_SemiBold,
                        //       color: getFeedColor(double.parse(UserController()
                        //           .portfolioresponce!
                        //           .intradaydata[widget.index]
                        //           .pl
                        //           .toString()))),
                        // ),
                      ]),
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 10),
                  child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              widget.portfoliolist![widget.index].securitycode,
                              style: customTextStyle(
                                  fontStyle: FontStyle.BodyL_SemiBold,
                                  color: FontColor.FontPrimary),
                            ),
                          ],
                        ),
                        Text(
                          double.parse(widget.portfoliolist![widget.index].pl
                                  .toString())
                              .toStringAsFixed(2)
                              .toString(),
                          style: customTextStyle(
                              fontStyle: FontStyle.BodyL_SemiBold,
                              color: getFeedColor(double.parse(widget
                                  .portfoliolist![widget.index].pl
                                  .toString()))),
                        ),
                        // Text(
                        //   widget.portfoliolist["PANDL"],
                        //   style: customTextStyle(
                        //       fontStyle: FontStyle.BodyL_SemiBold,
                        //       color: widget.portfoliolist["pandlcolor"]),
                        // ),
                      ]),
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 4.0),
                  child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Text(
                              "${widget.portfoliolist![widget.index].netqty}",
                              style: customTextStyle(
                                  fontStyle: FontStyle.BodyM_SemiBold,
                                  color: FontColor.FontSecondary),
                            ),
                            Text(
                              " Qty",
                              style: customTextStyle(
                                  fontStyle: FontStyle.BodyM_Regular,
                                  color: FontColor.FontTertiary),
                            ),
                            Padding(
                              padding:
                                  const EdgeInsets.only(left: 8.0, right: 8.0),
                              child: CustomDot(
                                  color: customColors().fontSecondary),
                            ),
                            Text(
                              "Avg ",
                              style: customTextStyle(
                                  fontStyle: FontStyle.BodyM_Regular,
                                  color: FontColor.FontTertiary),
                            ),
                            Text(
                              widget.portfoliolist![widget.index].avgrate
                                  .toString(),
                              style: customTextStyle(
                                  fontStyle: FontStyle.BodyM_SemiBold,
                                  color: FontColor.FontSecondary),
                            ),
                          ],
                        ),
                        Row(
                          children: [
                            Text(
                              "LTP ",
                              style: customTextStyle(
                                  fontStyle: FontStyle.BodyM_Regular,
                                  color: FontColor.FontTertiary),
                            ),
                            Text(
                              double.parse(widget.portfoliolist![widget.index]
                                      .lasttradeprice)
                                  .toStringAsFixed(2)
                                  .toString(),
                              style: customTextStyle(
                                  fontStyle: FontStyle.BodyM_SemiBold,
                                  color: FontColor.FontSecondary),
                            )
                          ],
                        ),
                      ]),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
