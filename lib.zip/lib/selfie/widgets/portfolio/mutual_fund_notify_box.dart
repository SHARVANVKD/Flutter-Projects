import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class Mutual_Fund_Notify_Box extends StatelessWidget {
  const Mutual_Fund_Notify_Box({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    double mheight = MediaQuery.of(context).size.height * 1.222;

    return Container(
      height: mheight * .07,
      width: MediaQuery.of(context).size.width,
      decoration: BoxDecoration(
        color: customColors().backgroundSecondary,
      ),
      child: Padding(
        padding: const EdgeInsets.only(left: 16.0, right: 16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  height: mheight * .036,
                  width: 219.0,
                  child: Text(
                    "Access your Demat and Physical Mutual Funds holdings on Funds Genie",
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyM_Regular,
                        color: FontColor.FontPrimary),
                  ),
                ),
                Container(
                  height: mheight * .032,
                  width: 64.0,
                  decoration: BoxDecoration(
                    border: Border.all(color: customColors().primary),
                    borderRadius: BorderRadius.circular(4.0),
                  ),
                  child: Center(
                    child: Text(
                      "View",
                      style: customTextStyle(
                          fontStyle: FontStyle.BodyL_SemiBold,
                          color: FontColor.Primary),
                    ),
                  ),
                ),
              ],
            )
          ],
        ),
      ),
    );
  }
}
