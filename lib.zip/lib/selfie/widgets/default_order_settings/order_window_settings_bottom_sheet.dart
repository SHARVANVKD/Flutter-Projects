import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/app_page_injectable.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order_window/order_window_components/order_window_title_component.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/default_order_settings/default_order_settings_values.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/options_widget.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class OrderSettingsSheetComponent extends StatefulWidget {
  final List<Map<String, dynamic>> list;
  final OrderSettingsSheetType orderSettingsSheetType;
  final int selected;
  final Function(int) onChanged;
  const OrderSettingsSheetComponent(
      {Key? key,
      required this.orderSettingsSheetType,
      required this.selected,
      required this.onChanged,
      required this.list})
      : super(key: key);

  @override
  State<OrderSettingsSheetComponent> createState() =>
      _OrderSettingsSheetComponentState();
}

class _OrderSettingsSheetComponentState
    extends State<OrderSettingsSheetComponent> {
  int selected = 0;
  @override
  void initState() {
    super.initState();
    setState(() {
      selected = widget.selected;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Column(children: [
      Padding(
        padding: const EdgeInsets.symmetric(vertical: 12.0, horizontal: 16.0),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              widget.orderSettingsSheetType == OrderSettingsSheetType.EXCHANGE
                  ? "Exchange"
                  : widget.orderSettingsSheetType ==
                          OrderSettingsSheetType.ORDER
                      ? "Order"
                      : widget.orderSettingsSheetType ==
                              OrderSettingsSheetType.TYPE
                          ? "Type"
                          : widget.orderSettingsSheetType ==
                                  OrderSettingsSheetType.PRODUCT
                              ? "Product"
                              : widget.orderSettingsSheetType ==
                                      OrderSettingsSheetType.TIME_CONDITION
                                  ? "Time Condition"
                                  : widget.orderSettingsSheetType ==
                                          OrderSettingsSheetType.TOPIC
                                      ? "Topic"
                                      : widget.orderSettingsSheetType ==
                                              OrderSettingsSheetType.CONDITION
                                          ? "Condition"
                                          : "",
              style: customTextStyle(
                  fontStyle: FontStyle.HeaderXS_SemiBold,
                  color: FontColor.FontPrimary),
            ),
            InkWell(
                onTap: () {
                  context.gNavigationService
                      .openDefaultOrderSettingsPage(context);
                },
                child: Image.asset("assets/settings.png",
                    color: customColors().fontPrimary))
          ],
        ),
      ),
      Container(
        height: 1,
        color: customColors().backgroundTertiary,
      ),
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: ListView.builder(
          physics: const NeverScrollableScrollPhysics(),
          shrinkWrap: true,
          itemCount: widget.list.length,
          addRepaintBoundaries: true,
          itemBuilder: (context, index) {
            return InkWell(
              onTap: () {
                setState(() {
                  selected = index;
                });
                widget.onChanged(index);
              },
              child: Container(
                padding: const EdgeInsets.symmetric(vertical: 16.0),
                decoration: BoxDecoration(
                  border: Border(
                      bottom: BorderSide(
                          color: index < widget.list.length
                              ? customColors().backgroundTertiary
                              : transparent,
                          width: 1)),
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    CustomRadioButton(
                        noLabel: true,
                        value: index,
                        groupValue: selected,
                        onChanged: (int val) {
                          setState(() {
                            selected = val;
                          });
                          widget.onChanged(index);
                        }),
                    const SizedBox(width: 12.0),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(widget.list[index]["name"],
                                  style: customTextStyle(
                                      fontStyle: FontStyle.BodyL_SemiBold,
                                      color: FontColor.FontPrimary)),
                              const SizedBox(width: 6),
                              if (index == 0) getProductTypeWidget("DEFAULT")
                            ],
                          ),
                          const SizedBox(
                            height: 3.0,
                          ),
                          if (widget.list[index]["description"] != null &&
                              widget.list[index]["description"] != "")
                            Text(widget.list[index]["description"],
                                style: customTextStyle(
                                    fontStyle: FontStyle.BodyM_Regular,
                                    color: FontColor.FontSecondary)),
                        ],
                      ),
                    )
                  ],
                ),
              ),
            );
          },
        ),
      )
    ]);
  }
}
