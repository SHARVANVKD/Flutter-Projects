import 'package:flutter/material.dart';
import 'package:just_the_tooltip/just_the_tooltip.dart';
import 'package:selfie_mobile_flutter/constants/prefefence_utils.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/scrollable_bottomsheet/scrollable_bottomsheet.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/default_order_settings/default_order_settings_values.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/default_order_settings/order_window_settings_bottom_sheet.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/default_order_settings/preset_card.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/default_order_settings/settings_list_panel.dart';
import 'package:selfie_mobile_flutter/user_controller/user_controller.dart';
import 'package:selfie_mobile_flutter/utils/user_settings.dart';

class OptionsContainer extends StatefulWidget {
  final List<Map<String, dynamic>> ordersdropdownlist;
  final List<Map<String, dynamic>> typsettingslist;
  final List<Map<String, dynamic>> productsettingslist;
  const OptionsContainer(
      {Key? key,
      required this.ordersdropdownlist,
      required this.typsettingslist,
      required this.productsettingslist})
      : super(key: key);

  @override
  State<OptionsContainer> createState() => _OptionsContainerState();
}

class _OptionsContainerState extends State<OptionsContainer> {
  bool isSwitched = false;
  String presetCartMapTitle ="options";
  int _order = UserSettings.userSettings.orderSettings.optionOrder;
  int _type = UserSettings.userSettings.orderSettings.optionType;
  int _product = UserSettings.userSettings.orderSettings.optionProductType;
   JustTheController? controller = JustTheController();
  JustTheController? controller2 = JustTheController();
  JustTheController? controller3 = JustTheController();
  Map<String,dynamic> presetCardStorageDataModel ={};
  @override
  void initState() {
    presetCardStorageDataModel[presetCartMapTitle] ={
    "defaultOrder": UserSettings.userSettings.orderSettings.optionOrder,
    "maxLots":UserSettings.userSettings.orderSettings.optionMaxLot,
    "presetStatus":UserSettings.userSettings.orderSettings.optionAdvancePreset,
    "orderStatusList":[
      {"controller":controller,"status":UserSettings.userSettings.orderSettings.optionReviewOrderAndSendStatus},
      {"controller":controller2,"status":UserSettings.userSettings.orderSettings.optionAllowSplitOrderStatus},
      {"controller":controller3,"status":UserSettings.userSettings.orderSettings.optionDefaultPercentageLimitOrderStatus}

      ],
      "stocksDefaultPercentageLimitOrder":UserSettings.userSettings.orderSettings.optionDefaultPercentageLimitOrder
  };
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(
          left: 16.0, right: 16.0, top: 20.0, bottom: 16.0),
      child: SingleChildScrollView(
          physics: const ScrollPhysics(),
          child: Column(
            children: [
              InkWell(
                  onTap: () {
                    customShowModalBottomSheet(
                        context: context,
                        inputWidget: OrderSettingsSheetComponent(
                            orderSettingsSheetType:
                                OrderSettingsSheetType.ORDER,
                            selected: _order,
                            onChanged: updateorder,
                            list: ordersdropdownlist));
                  },
                  child: SettongsListPanel(
                      title: "Order",
                      optionName: ordersdropdownlist[_order]["name"])),
              Padding(
                padding: const EdgeInsets.only(top: 16.0),
                child: InkWell(
                  onTap: () {
                    customShowModalBottomSheet(
                        context: context,
                        inputWidget: OrderSettingsSheetComponent(
                            orderSettingsSheetType: OrderSettingsSheetType.TYPE,
                            selected: _type,
                            onChanged: updatetype,
                            list: typsettingslist));
                  },
                  child: SettongsListPanel(
                    title: "Type",
                    optionName: typsettingslist[_type]["name"],
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 16.0),
                child: InkWell(
                  onTap: () {
                    customShowModalBottomSheet(
                        context: context,
                        inputWidget: OrderSettingsSheetComponent(
                            orderSettingsSheetType:
                                OrderSettingsSheetType.PRODUCT,
                            selected: _product,
                            onChanged: updateproduct,
                            list: productSettingslist));
                  },
                  child: SettongsListPanel(
                    title: "Product",
                    optionName: productSettingslist[_product]["name"],
                  ),
                ),
              ),
              PresetCard(
                  title: "Advanced Preset",
                  FO: false,
                  mmarray: mmarrayfuture,
                  presetCardStorageDataModel: presetCardStorageDataModel,
                  parentTitle: presetCartMapTitle,
                  isbo: false,
                  valueChanged: (updatedData)async{
                    presetCardStorageDataModel[presetCartMapTitle] =updatedData;
                    await PreferenceUtils.storeDataToShared(UserController.userController.userId, UserSettings.userSettings.toJsonString());
                  },
                  ),
              const SizedBox(
                height: 80.0,
              )
            ],
          )),
    );
  }

  void updateorder(int value) async{
    UserSettings.userSettings.orderSettings.optionOrder=value;
    await PreferenceUtils.storeDataToShared(UserController.userController.userId, UserSettings.userSettings.toJsonString());
    setState(() {
      _order = value;
    });
  }

  void updatetype(int value) async{
    UserSettings.userSettings.orderSettings.optionType=value;
    await PreferenceUtils.storeDataToShared(UserController.userController.userId, UserSettings.userSettings.toJsonString());
    setState(() {
      _type = value;
    });
  }

  void updateproduct(int value) async{
    UserSettings.userSettings.orderSettings.optionProductType=value;
    await PreferenceUtils.storeDataToShared(UserController.userController.userId, UserSettings.userSettings.toJsonString());
    setState(() {
      _product = value;
    });
  }
}
