enum OrderSettingsSheetType {
  EXCHANGE,
  ORDER,
  TYPE,
  PRODUCT,
  TIME_CONDITION,
  CONDITION,
  TOPIC
}
int exchange = 0;
int order = 0;
int type = 0;
int product = 0;
int timeCondition = 0;
int condition = 0;

List<Map<String, dynamic>> ordersdropdownlist = [
  {
    "name": "Regular",
    "description": "A regular order is placed to buy or sell a stock",
  },
  {
    "name": "BO",
    "description": "Bracket Order",
  },
];

List<Map<String, dynamic>> typsettingslist = [
  {
    "name": "Market",
    "description": "Buy and Sell a Stock at its current market price",
  },
  {
    "name": "Limit",
    "description": "Buy and Sell a Stock at a specific price",
  },
  {
    "name": "Stop Loss Limit",
    "description":
        "Your order will be executed within a trigger price and Limit Price you specify",
  },
  {
    "name": "Stop Loss Market",
    "description":
        "Your order will be executed at the current market price if it crosses a trigger price you specify",
  },
];

List<Map<String, dynamic>> productsettingslist = [
  {
    "name": "Cash",
    "description": "Lorem ipsum dolor sit amet, consectetur",
  },
  {
    "name": "Intraday",
    "description": "Buy and Sellstocks on the same day",
  },
  {
    "name": "BTST",
    "description": "Lorem ipsum dolor sit amet, consectetur",
  },
  {
    "name": "MTF",
    "description": "Lorem ipsum dolor sit amet, consectetur",
  },
];

List<Map<String, dynamic>> mmarray = [
  {
    "name": "Review order and send",
    "value": false,
    "content": "You will be able to review your order before placing it."
  },
  {
    "name": "Default percentage for limit order",
    "value": false,
    "content":
        "Limit price will be calculated based on this value if its checked"
  }
];

List<Map<String, dynamic>> mmarrayfuture = [
  {
    "name": "Review order and send",
    "value": false,
    "content": "You will be able to review your order before placing it."
  },
  {
    "name": "Allow split orders",
    "value": false,
    "content":
        "Limit price will be calculated based on this value if its checked"
  },
  {
    "name": "Default percentage for limit order",
    "value": false,
    "content":
        "Limit price will be calculated based on this value if its checked"
  }
];
List<Map<String, dynamic>> timeconditionsettingslist = [
  {
    "name": "Day",
    "description":
        "Your order is valid till the end of the day. If not executed it gets cancelled.",
  },
  {
    "name": "IOC",
    "description":
        "Your order will be executed fully or partially if the quantity entered is immediately available. Else, it will be cancelled.",
  },
  {
    "name": "Conditional",
    "description": "Lorem ipsum dolor sit amet, consectetur",
  },
  {
    "name": "GTD",
    "description": "Lorem ipsum dolor sit amet, consectetur",
  },
];

List<Map<String, dynamic>> exchanglist = [
  {
    "name": "Ask Everytime",
    "description": "Choose between BSE & NSE while placing an order.",
  },
  {
    "name": "NSE",
    "description": "National Stock Exchange",
  },
  {
    "name": "BSE",
    "description": "Bombay Stock Exchange",
  }
];

List<Map<String, dynamic>> productSettingslist = [
  {
    "name": "Cash",
    "description": "Lorem ipsum dolor sit amet, consectetur",
  },
  {
    "name": "Intraday",
    "description": "Buy and Sellstocks on the same day",
  },
  {
    "name": "BTST",
    "description": "Lorem ipsum dolor sit amet, consectetur",
  },
  {
    "name": "MTF",
    "description": "Lorem ipsum dolor sit amet, consectetur",
  },
];

List<Map<String, dynamic>> conditionalSettingsList = [

  {
    "name": "Greater Than",
    "description": "",
  },
  {
    "name": "Less Than",
    "description": "",
  },
];

List<Map<String, dynamic>> topicList = [
  {
    "name": "General Enquiry",
  },
  {
    "name": "Complaint",
  },
  {
    "name": "Others",
  },
];

List<Map<String, dynamic>> pickAProductList = [
  {
    "name": "Selfie App",
  },
  {
    "name": "My Geojit",
  },
  {
    "name": "Fund Ginie",
  },
  {
    "name": "Smartfolio",
  },
  {
    "name": "Others",
  },
];

List<Map<String, dynamic>> timeList = [
  {
    "name": "Call Anytime",
  },
  {
    "name": "9:00AM - 11:00AM",
  },
  {
    "name": "11:00AM - 01:00PM",
  },
  {
    "name": "01:00PM - 03:00PM",
  },
  {
    "name": "03:00PM - 05:00PM",
  },
];

// List<Map<String, dynamic>> ordersdropdownlist = [
//     {
//       "option": "Regular",
//       "selection": 0,
//       "content": "A regular order is placed to buy or sell a stock",
//       "default": true
//     },
//     {
//       "option": "BO",
//       "selection": 1,
//       "content": "Bracket Order",
//       "default": false
//     },
//   ];



// List<Map<String, dynamic>> timeconditionsettingslist = [
//   {
//     "option": "Day",
//     "selection": 0,
//     "content":
//         "Your order is valid till the end of the day. If not executed it gets cancelled.",
//     "default": true
//   },
//   {
//     "option": "IOC",
//     "selection": 1,
//     "content":
//         "Your order will be executed fully or partially if the quantity entered is immediately available. Else, it will be cancelled.",
//     "default": false
//   },
//   {
//     "option": "Conditional",
//     "selection": 2,
//     "content": "Lorem ipsum dolor sit amet, consectetur",
//     "default": false
//   },
//   {
//     "option": "GTD",
//     "selection": 3,
//     "content": "Lorem ipsum dolor sit amet, consectetur",
//     "default": false
//   },
// ];


// List<Map<String, dynamic>> productSettingslist = [
//   {
//     "option": "Cash",
//     "selection": 0,
//     "content":
//         "Lorem ipsum dolor sit amet, consectetur",
//     "default": true
//   },
//   {
//     "option": "Intraday",
//     "selection": 1,
//     "content":
//         "Lorem ipsum dolor sit amet, consectetur",
//     "default": false
//   },
//   {
//     "option": "BTST",
//     "selection": 2,
//     "content": "Lorem ipsum dolor sit amet, consectetur",
//     "default": false
//   },
//   {
//     "option": "MTF",
//     "selection": 3,
//     "content": "Lorem ipsum dolor sit amet, consectetur",
//     "default": false
//   },
// ];


// List<Map<String, dynamic>> exchanglist = [
//   {
//     "option": "Ask Everytime",
//     "selection": 0,
//     "content": "Choose between BSE & NSE while placing an order.",
//     "default": true
//   },
//   {
//     "option": "NSE",
//     "selection": 1,
//     "content": "National Stock Exchange",
//     "default": false
//   },
//   {
//     "option": "BSE",
//     "selection": 2,
//     "content": "Bombay Stock Exchange",
//     "default": false
//   }
// ];

  // List<Map<String, dynamic>> mmarray = [
  //   {
  //     "name": "Review order and send",
  //     "description": "You will be able to review your order before placing it."
  //   },
  //   {
  //     "name": "Allow split orders",
  //     "description":
  //         "Limit price will be calculated based on this value if its checked"
  //   },
  //   {
  //     "name": "Default percentage for limit order",
  //     "description":
  //         "Limit price will be calculated based on this value if its checked"
  //   }
  // ];

//   List<Map<String, dynamic>> conditionsettingslist = [
//   {"option": "Greater Than", "selection": 0, "content": "", "default": true},
//   {"option": "Less Than", "selection": 1, "content": "", "default": false},
// ];


  // List<Map<String, dynamic>> productsettingslist = [
  //   {
  //     "option": "Cash",
  //     "selection": 0,
  //     "content": "Lorem ipsum dolor sit amet, consectetur",
  //     "default": true
  //   },
  //   {
  //     "option": "Intraday",
  //     "selection": 1,
  //     "content": "Buy and Sellstocks on the same day",
  //     "default": false
  //   },
  //   {
  //     "option": "BTST",
  //     "selection": 2,
  //     "content": "Lorem ipsum dolor sit amet, consectetur",
  //     "default": false
  //   },
  //   {
  //     "option": "MTF",
  //     "selection": 3,
  //     "content": "Lorem ipsum dolor sit amet, consectetur",
  //     "default": false
  //   },
  // ];

  
  // List<Map<String, dynamic>> typsettingslist = [
  //   {
  //     "option": "Market",
  //     "selection": 0,
  //     "content": "Buy and Sell a Stock at its current market price",
  //     "default": true
  //   },
  //   {
  //     "option": "Limit",
  //     "selection": 1,
  //     "content": "Buy and Sell a Stock at a specific price",
  //     "default": false
  //   },
  //   {
  //     "option": "Stop Loss Limit",
  //     "selection": 2,
  //     "content":
  //         "Your order will be executed within a trigger price and Limit Price you specify",
  //     "default": false
  //   },
  //   {
  //     "option": "Stop Loss Market",
  //     "selection": 3,
  //     "content":
  //         "Your order will be executed at the current market price if it crosses a trigger price you specify",
  //     "default": false
  //   },
  // ];