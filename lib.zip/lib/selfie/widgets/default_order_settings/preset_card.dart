import 'package:expandable/expandable.dart';
import 'package:flutter/material.dart';
import 'package:just_the_tooltip/just_the_tooltip.dart';
import 'package:selfie_mobile_flutter/constants/formaters.dart';
import 'package:selfie_mobile_flutter/constants/prefefence_utils.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/textfields/formatters.dart';
import 'package:selfie_mobile_flutter/user_controller/user_controller.dart';
import 'package:selfie_mobile_flutter/utils/user_settings.dart';

import '../../../theme/styles.dart';
import '../custom_app_components/textfields/custom_text_form_field.dart';
import '../stock/empty_custom_checkbox/empty_custom_checkbox.dart';

class PresetCard extends StatefulWidget {
  String title;
  String parentTitle;
  bool FO = true;
  bool isbo;
  List<Map<String, dynamic>> mmarray = [];
  Map<String, dynamic> presetCardStorageDataModel;
  Function(Map<String, dynamic>)? valueChanged;
  PresetCard(
      {Key? key,
      required this.title,
      required this.parentTitle,
      required this.FO,
      required this.mmarray,
      required this.isbo,
      required this.presetCardStorageDataModel,
      this.valueChanged})
      : super(key: key);

  @override
  State<PresetCard> createState() => _PresetCardState();
}

class _PresetCardState extends State<PresetCard> {
  String? userData;
  TextEditingController ovcontroller = TextEditingController(text: "1");
  TextEditingController mvcontroller = TextEditingController();
  TextEditingController botcontroller = TextEditingController(text: "0.00%");
  TextEditingController boscontroller = TextEditingController(text: "0.00%");
  TextEditingController limitOrderPercentagecontroller =
      TextEditingController(text: "");
  bool isSwitched = false;
  // var presetcontroller =ExpandableController();
  // ExpandableController.of(context, required: widget.presetCardStorageDataModel[widget.parentTitle]["presetStatus"])!;
  // JustTheController? controller = JustTheController();
  // JustTheController? controller2 = JustTheController();
  // JustTheController? controller3 = JustTheController();
  List tooltipControllerList = [];
  // ExpandableController presetcontroller =ExpandableController(initialExpanded: true);

  @override
  void initState() {
    isSwitched =
        widget.presetCardStorageDataModel[widget.parentTitle]["presetStatus"];
    // presetcontroller =ExpandableController.of(context, required: widget.presetCardStorageDataModel[widget.parentTitle]["presetStatus"])!;
    // if(isSwitched){
    //   presetcontroller.toggle();
    // }
    ovcontroller.text = (widget.parentTitle == "stock")
        ? widget.presetCardStorageDataModel[widget.parentTitle]["orderValue"]
            .toString()
        : widget.presetCardStorageDataModel[widget.parentTitle]["defaultOrder"]
            .toString();
    mvcontroller.text = (widget.parentTitle == "stock")
        ? Formats.valueFormat
            .format(widget.presetCardStorageDataModel[widget.parentTitle]
                ["maxOrderValue"])
            .toString()
        : Formats.valueFormat
            .format(widget.presetCardStorageDataModel[widget.parentTitle]
                ["maxLots"])
            .toString();
    botcontroller.text = (widget.presetCardStorageDataModel[widget.parentTitle]
                ["boTakeProfit"] !=
            null)
        ? (double.tryParse(widget.presetCardStorageDataModel[widget.parentTitle]
                            ["boTakeProfit"]
                        .toString())!
                    .toStringAsFixed(2))
                .toString() +
            "%"
        : "0.00%";
    boscontroller.text = (widget.presetCardStorageDataModel[widget.parentTitle]
                ["boStopLoss"] !=
            null)
        ? (double.tryParse(widget.presetCardStorageDataModel[widget.parentTitle]
                            ["boStopLoss"]
                        .toString())!
                    .toStringAsFixed(2))
                .toString() +
            "%"
        : "0.00%";
    tooltipControllerList = widget
        .presetCardStorageDataModel[widget.parentTitle]["orderStatusList"];
    limitOrderPercentagecontroller.text =
        (widget.presetCardStorageDataModel[widget.parentTitle]
                    ["DefaultPercentageLimitOrder"] !=
                0)
            ? widget.presetCardStorageDataModel[widget.parentTitle]
                    ["stocksDefaultPercentageLimitOrder"]
                .toString()
            : "";
    super.initState();
  }

  Widget build(BuildContext context) {
    mvcontroller.selection = TextSelection.fromPosition(
        TextPosition(offset: mvcontroller.text.length));
    buildExpanded1() {
      return MediaQuery.removePadding(
        context: context,
        removeTop: true,
        child: SingleChildScrollView(
          child:
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: <
                  Widget>[
            Padding(
              padding: const EdgeInsets.only(left: 16.0, right: 16.0),
              child: Divider(
                color: customColors().backgroundTertiary,
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(
                left: 16.0,
                right: 16.0,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Expanded(
                          flex: 2,
                          child: CustomTextFormField(
                            controller: ovcontroller,
                            keyboardType: TextInputType.number,
                            inputFormatter: [DecimalFormatter()],
                            fieldName: widget.FO
                                ? "Order Value (Apox)"
                                : "Default Order (Lots)",
                            onChange: (value) async {
                              ovcontroller.text = value;
                              if (widget.parentTitle == "stock") {
                                UserSettings.userSettings.orderSettings
                                    .stocksOrderValue = int.tryParse(value)!;
                              } else if (widget.parentTitle == "future") {
                                UserSettings.userSettings.orderSettings
                                    .futureOrder = int.tryParse(value)!;
                              } else if (widget.parentTitle == "option") {
                                UserSettings.userSettings.orderSettings
                                    .optionOrder = int.tryParse(value)!;
                              }
                              await PreferenceUtils.storeDataToShared(
                                  UserController.userController.userId,
                                  UserSettings.userSettings.toJsonString());
                              // await PreferenceUtils.storeDataToShared("userCode", UserSettings.userSettings.toJsonString());
                              // widget.valueChanged!(widget.presetCardStorageDataModel);
                            },
                          )),
                      Expanded(
                          flex: 2,
                          child: Padding(
                            padding: const EdgeInsets.only(left: 16.0),
                            child: CustomTextFormField(
                              controller: mvcontroller,
                              keyboardType: TextInputType.number,
                              inputFormatter: [DecimalFormatter()],
                              fieldName:
                                  widget.FO ? "Max Order Value" : "Max Lots",
                              onChange: (value) async {
                                mvcontroller.text = value;
                                if (value.isEmpty) return;
                                if (widget.parentTitle == "stock") {
                                  UserSettings.userSettings.orderSettings
                                          .stocksMaxOrderValue =
                                      int.tryParse(value)!;
                                } else if (widget.parentTitle == "future") {
                                  UserSettings.userSettings.orderSettings
                                      .futureMaxLot = int.tryParse(value)!;
                                } else if (widget.parentTitle == "option") {
                                  UserSettings.userSettings.orderSettings
                                      .optionMaxLot = int.tryParse(value)!;
                                }
                                await PreferenceUtils.storeDataToShared(
                                    UserController.userController.userId,
                                    UserSettings.userSettings.toJsonString());
                              },
                            ),
                          ))
                    ],
                  ),
                  Visibility(
                    visible: widget.FO,
                    child: Padding(
                      padding: const EdgeInsets.only(top: 20.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Expanded(
                              flex: 2,
                              child: CustomTextFormField(
                                controller: botcontroller,
                                fieldName: "BO - Take Profit %",
                                onChange: (value) async {
                                  botcontroller.text = value;
                                  if (value.isEmpty) return;
                                  UserSettings.userSettings.orderSettings
                                          .stocksBoTakeProfit =
                                      double.tryParse(value)!;
                                  await PreferenceUtils.storeDataToShared(
                                      UserController.userController.userId,
                                      UserSettings.userSettings.toJsonString());
                                },
                              )),
                          Expanded(
                              flex: 2,
                              child: Padding(
                                padding: const EdgeInsets.only(left: 16.0),
                                child: CustomTextFormField(
                                  controller: boscontroller,
                                  fieldName: "BO - Stop Loss %",
                                  onChange: (value) async {
                                    boscontroller.text = value;
                                    if (value.isEmpty) return;
                                    UserSettings.userSettings.orderSettings
                                            .stocksBoStopLoss =
                                        double.tryParse(value)!;
                                    await PreferenceUtils.storeDataToShared(
                                        UserController.userController.userId,
                                        UserSettings.userSettings
                                            .toJsonString());
                                  },
                                ),
                              ))
                        ],
                      ),
                    ),
                  ),
                  for (int index = 0; index < widget.mmarray.length; index++)
                    Padding(
                      padding: const EdgeInsets.only(top: 20.0, right: 0.0),
                      child: Container(
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Row(
                              children: [
                                Text(
                                  widget.mmarray[index]['name'],
                                  style: customTextStyle(
                                      fontStyle: FontStyle.BodyL_Regular,
                                      color: FontColor.FontPrimary),
                                ),
                                JustTheTooltip(
                                  offset: 2.0,
                                  backgroundColor:
                                      customColors().backgroundSecondary,
                                  preferredDirection: AxisDirection.up,
                                  controller: tooltipControllerList[index]
                                      ["controller"],
                                  margin:
                                      EdgeInsets.only(left: 32.0, right: 32.0),
                                  child: Material(
                                      child: Container(
                                    height: 22.0,
                                    width: 22.0,
                                    child: Center(
                                        child: InkWell(
                                      onTap: () {
                                        tooltipControllerList[index]
                                                ["controller"]
                                            ?.showTooltip();
                                      },
                                      child: Icon(
                                        Icons.info_outline_rounded,
                                        size: 14.0,
                                      ),
                                    )),
                                  )),
                                  content: Container(
                                    child: Padding(
                                        padding: const EdgeInsets.only(
                                            top: 16.0,
                                            left: 10.0,
                                            right: 8.0,
                                            bottom: 10.0),
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          mainAxisSize: MainAxisSize.min,
                                          children: [
                                            Text(
                                              widget.mmarray[index]['name'],
                                              style: customTextStyle(
                                                  fontStyle:
                                                      FontStyle.BodyM_SemiBold,
                                                  color: FontColor.FontPrimary),
                                            ),
                                            Padding(
                                                padding: EdgeInsets.only(
                                                    top: 16.0, right: 10.0),
                                                child: Container(
                                                  child: Text(
                                                    widget.mmarray[index]
                                                        ['content'],
                                                    style: customTextStyle(
                                                        fontStyle: FontStyle
                                                            .BodyS_Regular,
                                                        color: FontColor
                                                            .FontPrimary),
                                                    textAlign:
                                                        TextAlign.justify,
                                                  ),
                                                )),
                                          ],
                                        )),
                                  ),
                                )
                              ],
                            ),
                            EmptyCustomCheckBox(
                              isSelect: tooltipControllerList[index]["status"],
                              callback: (checkValue) async {
                                storeStatusToLocalStorage(
                                    title: widget.parentTitle,
                                    index: index,
                                    value: checkValue);
                              },
                            )
                          ],
                        ),
                      ),
                    ),
                  Padding(
                    padding: const EdgeInsets.only(top: 18.0),
                    child: Row(
                      children: [
                        Expanded(
                          flex: 1,
                          child: Container(
                            decoration: BoxDecoration(
                                border: Border.all(
                                    color: customColors().backgroundTertiary),
                                borderRadius: BorderRadius.circular(4.0)),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Expanded(
                                    flex: 2,
                                    child: TextFormField(
                                      textAlign: TextAlign.end,
                                      controller:
                                          limitOrderPercentagecontroller,
                                      decoration: InputDecoration(
                                        border: InputBorder.none,
                                        contentPadding:
                                            EdgeInsets.only(left: 12.0),
                                      ),
                                      onChanged: (value) async {
                                        limitOrderPercentagecontroller.text =
                                            value;
                                        if (value.isEmpty) return;
                                        if (widget.parentTitle == "stock") {
                                          UserSettings
                                                  .userSettings
                                                  .orderSettings
                                                  .stocksDefaultPercentageLimitOrder =
                                              double.tryParse(value)!;
                                        } else if (widget.parentTitle ==
                                            "future") {
                                          UserSettings
                                                  .userSettings
                                                  .orderSettings
                                                  .futureDefaultPercentageLimitOrder =
                                              double.tryParse(value)!;
                                        } else if (widget.parentTitle ==
                                            "option") {
                                          UserSettings
                                                  .userSettings
                                                  .orderSettings
                                                  .optionDefaultPercentageLimitOrder =
                                              double.tryParse(value)!;
                                        }
                                        await PreferenceUtils.storeDataToShared(
                                            UserController
                                                .userController.userId,
                                            UserSettings.userSettings
                                                .toJsonString());
                                      },
                                    )),
                                Padding(
                                  padding: const EdgeInsets.only(right: 10.0),
                                  child: Text(
                                    '%',
                                    style: customTextStyle(
                                        fontStyle: FontStyle.BodyL_SemiBold,
                                        color: FontColor.FontSecondary),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Expanded(flex: 1, child: SizedBox())
                      ],
                    ),
                  ),
                  Container(
                    height: 16.0,
                  )
                ],
              ),
            ),
          ]),
        ),
      );
    }

    return Padding(
      padding: const EdgeInsets.only(
        top: 16.0,
      ),
      child: ExpandableNotifier(
          child: ScrollOnExpand(
        child: Container(
          decoration: BoxDecoration(
              border: Border.all(color: customColors().backgroundTertiary),
              borderRadius: BorderRadius.circular(4.0)),
          child: MediaQuery.removePadding(
            context: context,
            removeTop: true,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Builder(builder: (context) {
                  // bool isSwitched=widget.presetCardStorageDataModel[widget.parentTitle]["presetStatus"];
                  var presetcontroller = ExpandableController.of(context,
                      required:
                          widget.presetCardStorageDataModel[widget.parentTitle]
                              ["presetStatus"])!;
                  return InkWell(
                    onTap: () {
                      toggleSwitch(!isSwitched);

                      // presetcontroller.toggle();
                    },
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: <Widget>[
                        Padding(
                          padding: const EdgeInsets.only(left: 16.0),
                          child: Text(
                            widget.title,
                            style: customTextStyle(
                                fontStyle: FontStyle.BodyL_SemiBold,
                                color: FontColor.FontPrimary),
                          ),
                        ),
                        // Builder(
                        //   builder: (context) {

                        //     return Switch(
                        //       // value: presetcontroller.expanded,
                        //       value: isSwitched,
                        //       onChanged: (value) async{
                        //         setState(() {

                        //         isSwitched=value;
                        //         });
                        //         presetcontroller.toggle();
                        //         if(widget.parentTitle=="stock") {
                        //         UserSettings.userSettings.orderSettings.stocksAdvancePreset=value;
                        //       }else if(widget.parentTitle=="future"){
                        //         UserSettings.userSettings.orderSettings.futureAdvancePreset=value;
                        //       }else if(widget.parentTitle=="option"){
                        //         UserSettings.userSettings.orderSettings.optionAdvancePreset=value;
                        //       }
                        //       await PreferenceUtils.storeDataToShared(UserController.userController.userId, UserSettings.userSettings.toJsonString());
                        //       },

                        //       activeColor: customColors().primary,
                        //       activeTrackColor:
                        //           customColors().backgroundTertiary,
                        //     );
                        //   },
                        // ),
                        Switch(
                          value: isSwitched,
                          onChanged: (value) async {
                            setState(() {
                              isSwitched = (isSwitched == false) ? true : false;
                            });
                            if (widget.parentTitle == "stock") {
                              UserSettings.userSettings.orderSettings
                                  .stocksAdvancePreset = value;
                            } else if (widget.parentTitle == "future") {
                              UserSettings.userSettings.orderSettings
                                  .futureAdvancePreset = value;
                            } else if (widget.parentTitle == "option") {
                              UserSettings.userSettings.orderSettings
                                  .optionAdvancePreset = value;
                            }
                            await PreferenceUtils.storeDataToShared(
                                UserController.userController.userId,
                                UserSettings.userSettings.toJsonString());
                          },
                          activeColor: customColors().primary,
                          activeTrackColor: customColors().backgroundTertiary,
                        )
                      ],
                    ),
                  );
                }),
                Visibility(
                  visible: isSwitched,
                  child: buildExpanded1(),
                ),
              ],
            ),
          ),
        ),
      )),
    );
  }

  storeStatusToLocalStorage(
      {required String title, required int index, required bool value}) async {
    switch (title) {
      case "stock":
        switch (index) {
          case 0:
            UserSettings.userSettings.orderSettings
                .stocksReviewOrderAndSendStatus = value;
            break;
          case 1:
            UserSettings.userSettings.orderSettings
                .stocksDefaultPercentageLimitOrderStatus = value;
            break;
          default:
            break;
        }
        ;
        break;
      case "future":
        switch (index) {
          case 0:
            UserSettings.userSettings.orderSettings
                .futureReviewOrderAndSendStatus = value;
            break;
          case 1:
            UserSettings
                .userSettings.orderSettings.futureAllowSplitOrderStatus = value;
            break;
          case 2:
            UserSettings.userSettings.orderSettings
                .futureDefaultPercentageLimitOrderStatus = value;
            break;
          default:
            break;
        }
        ;
        break;
      case "option":
        switch (index) {
          case 0:
            UserSettings.userSettings.orderSettings
                .optionReviewOrderAndSendStatus = value;
            break;
          case 1:
            UserSettings
                .userSettings.orderSettings.optionAllowSplitOrderStatus = value;
            break;
          case 2:
            UserSettings.userSettings.orderSettings
                .optionDefaultPercentageLimitOrderStatus = value;
            break;
          default:
            break;
        }
        ;
        break;
      default:
        break;
    }
    await PreferenceUtils.storeDataToShared(
        UserController.userController.userId,
        UserSettings.userSettings.toJsonString());
  }

  void toggleSwitch(bool value) async {
    setState(() {
      isSwitched = (isSwitched == false) ? true : false;
    });
    // presetcontroller.toggle();
    if (widget.parentTitle == "stock") {
      UserSettings.userSettings.orderSettings.stocksAdvancePreset = value;
    } else if (widget.parentTitle == "future") {
      UserSettings.userSettings.orderSettings.futureAdvancePreset = value;
    } else if (widget.parentTitle == "option") {
      UserSettings.userSettings.orderSettings.optionAdvancePreset = value;
    }
    await PreferenceUtils.storeDataToShared(
        UserController.userController.userId,
        UserSettings.userSettings.toJsonString());
  }
}
