import 'package:flutter/material.dart';
import 'package:just_the_tooltip/just_the_tooltip.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/stock/empty_custom_checkbox/empty_custom_checkbox.dart';

import '../../../theme/styles.dart';

class ListItemToolTip extends StatefulWidget {
  Map<String, dynamic> mmarray = {};
  ListItemToolTip({Key? key, required this.mmarray}) : super(key: key);

  @override
  State<ListItemToolTip> createState() => _ListItemToolTipState();
}

class _ListItemToolTipState extends State<ListItemToolTip> {
  JustTheController? controller = JustTheController();
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 20.0, right: 0.0),
      child: Container(
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Row(
              children: [
                Text(
                  widget.mmarray['name'],
                  style: customTextStyle(
                      fontStyle: FontStyle.BodyL_Regular,
                      color: FontColor.FontPrimary),
                ),
                JustTheTooltip(
                  backgroundColor: customColors().backgroundSecondary,
                  preferredDirection: AxisDirection.up,
                  controller: controller,
                  margin: widget.mmarray['name']
                          .toString()
                          .contains('Default Percentage for limit Order')
                      ? EdgeInsets.only(
                          left: 30.0,
                        )
                      : EdgeInsets.only(left: 16.0, right: 16.0),
                  child: Material(
                      child: Container(
                    height: 20.0,
                    width: 20.0,
                    child: Center(
                        child: InkWell(
                      onTap: () {
                        controller?.showTooltip();
                      },
                      child: Icon(
                        Icons.info_outline_rounded,
                        size: 14.0,
                      ),
                    )),
                  )),
                  content: Padding(
                      padding: EdgeInsets.only(
                          top: 16.0, left: 16.0, right: 16.0, bottom: 10.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(
                            widget.mmarray['name'],
                            style: customTextStyle(
                                fontStyle: FontStyle.BodyM_SemiBold,
                                color: FontColor.FontPrimary),
                          ),
                          Padding(
                              padding: EdgeInsets.only(top: 16.0, right: 10.0),
                              child: Container(
                                width: 268,
                                child: Text(
                                  widget.mmarray['content'],
                                  style: customTextStyle(
                                      fontStyle: FontStyle.BodyS_Regular,
                                      color: FontColor.FontPrimary),
                                  textAlign: TextAlign.justify,
                                ),
                              )),
                        ],
                      )),
                )
              ],
            ),
            EmptyCustomCheckBox(
              callback: (bool) {},
            )
            // Checkbox(
            //     activeColor: customColors().primary,
            //     value: widget.mmarray['value'],
            //     onChanged: (v) {
            //       setState(() {
            //         widget.mmarray['value'] = v;
            //       });
            //     })
          ],
        ),
      ),
    );
  }
}
