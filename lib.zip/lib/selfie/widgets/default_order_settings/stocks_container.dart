import 'package:flutter/material.dart';
import 'package:just_the_tooltip/just_the_tooltip.dart';
import 'package:selfie_mobile_flutter/constants/prefefence_utils.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/scrollable_bottomsheet/scrollable_bottomsheet.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/default_order_settings/default_order_settings_values.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/default_order_settings/order_window_settings_bottom_sheet.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/default_order_settings/preset_card.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/default_order_settings/settings_list_panel.dart';
import 'package:selfie_mobile_flutter/user_controller/user_controller.dart';
import 'package:selfie_mobile_flutter/utils/user_settings.dart';

class StocksContainer extends StatefulWidget {
  const StocksContainer({Key? key}) : super(key: key);

  @override
  State<StocksContainer> createState() => _StocksContainerState();
}

class _StocksContainerState extends State<StocksContainer> {
  UserSettings _userSettings = UserSettings();
  bool isSwitched = false;
  String presetCartMapTitle = "stock";
  int _exchange = UserSettings.userSettings.orderSettings.stockExchange;
  int _order = UserSettings.userSettings.orderSettings.stockOrder;
  int _type = UserSettings.userSettings.orderSettings.stocksType;
  int _productType = UserSettings.userSettings.orderSettings.stocksProductType;
  JustTheController? controller = JustTheController();
  JustTheController? controller2 = JustTheController();
  Map<String, dynamic> presetCardStorageDataModel = {};
  @override
  void initState() {
    presetCardStorageDataModel[presetCartMapTitle] = {
      "orderValue": UserSettings.userSettings.orderSettings.stocksOrderValue,
      "maxOrderValue":
          UserSettings.userSettings.orderSettings.stocksMaxOrderValue,
      "boTakeProfit":
          UserSettings.userSettings.orderSettings.stocksBoTakeProfit,
      "boStopLoss": UserSettings.userSettings.orderSettings.stocksBoStopLoss,
      "presetStatus":
          UserSettings.userSettings.orderSettings.stocksAdvancePreset,
      "orderStatusList": [
        {
          "controller": controller,
          "status": UserSettings
              .userSettings.orderSettings.stocksReviewOrderAndSendStatus
        },
        {
          "controller": controller2,
          "status": UserSettings.userSettings.orderSettings
              .stocksDefaultPercentageLimitOrderStatus
        }
        // {"controller":controller2,"status":true}
      ],
      "DefaultPercentageLimitOrder": UserSettings
          .userSettings.orderSettings.stocksDefaultPercentageLimitOrder
    };
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(
          left: 16.0, right: 16.0, top: 20.0, bottom: 16.0),
      child: SingleChildScrollView(
        physics: const ScrollPhysics(),
        child: Column(
          children: [
            InkWell(
              onTap: () {
                customShowModalBottomSheet(
                    context: context,
                    inputWidget: OrderSettingsSheetComponent(
                        orderSettingsSheetType: OrderSettingsSheetType.EXCHANGE,
                        selected: _exchange,
                        onChanged: updateexchange,
                        list: exchanglist));
              },
              child: SettongsListPanel(
                title: "Exchange",
                optionName: exchanglist[_exchange]["name"],
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 16.0),
              child: InkWell(
                onTap: () {
                  customShowModalBottomSheet(
                      context: context,
                      inputWidget: OrderSettingsSheetComponent(
                          orderSettingsSheetType: OrderSettingsSheetType.ORDER,
                          selected: _order,
                          onChanged: updateorder,
                          list: ordersdropdownlist));
                },
                child: SettongsListPanel(
                    title: "Order",
                    optionName: ordersdropdownlist[_order]["name"]),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 16.0),
              child: InkWell(
                onTap: () {
                  customShowModalBottomSheet(
                      context: context,
                      inputWidget: OrderSettingsSheetComponent(
                          orderSettingsSheetType: OrderSettingsSheetType.TYPE,
                          selected: _type,
                          onChanged: updateextype,
                          list: typsettingslist));
                },
                child: SettongsListPanel(
                  title: "Type",
                  optionName: typsettingslist[_type]["name"],
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 16.0),
              child: InkWell(
                onTap: () {
                  customShowModalBottomSheet(
                      context: context,
                      inputWidget: OrderSettingsSheetComponent(
                          orderSettingsSheetType:
                              OrderSettingsSheetType.PRODUCT,
                          selected: _productType,
                          onChanged: updateexproducttype,
                          list: productSettingslist));
                },
                child: SettongsListPanel(
                  title: "Product Type",
                  optionName: productSettingslist[_productType]["name"],
                ),
              ),
            ),
            PresetCard(
              mmarray: mmarray,
              title: "Advanced Preset",
              FO: true,
              isbo: false,
              presetCardStorageDataModel: presetCardStorageDataModel,
              parentTitle: presetCartMapTitle,
              valueChanged: (updatedData) async {
                // setState(() {

                //     presetCardStorageDataModel[presetCartMapTitle] =updatedData;
                // });
                //     await PreferenceUtils.storeDataToShared("userCode", UserSettings.userSettings.toJsonString());
              },
            ),
            const SizedBox(
              height: 80.0,
            )
          ],
        ),
      ),
    );
  }

  void updateexchange(int value) async {
    UserSettings.userSettings.orderSettings.stockExchange = value;
    await PreferenceUtils.storeDataToShared(
        UserController.userController.userId,
        UserSettings.userSettings.toJsonString());
    setState(() {
      _exchange = value;
    });
  }

  void updateorder(int value) async {
    UserSettings.userSettings.orderSettings.stockOrder = value;
    await PreferenceUtils.storeDataToShared(
        UserController.userController.userId,
        UserSettings.userSettings.toJsonString());
    setState(() {
      _order = value;
    });
  }

  void updateextype(int value) async {
    UserSettings.userSettings.orderSettings.stocksType = value;
    await PreferenceUtils.storeDataToShared(
        UserController.userController.userId,
        UserSettings.userSettings.toJsonString());
    setState(() {
      _type = value;
    });
  }

  void updateexproducttype(int value) async {
    UserSettings.userSettings.orderSettings.stocksProductType = value;
    await PreferenceUtils.storeDataToShared(
        UserController.userController.userId,
        UserSettings.userSettings.toJsonString());
    setState(() {
      _productType = value;
    });
  }
}

class PresetCardStorageDataModel {
  PresetCardStorageDataModel({required this.orderValue});

  int orderValue;
}
