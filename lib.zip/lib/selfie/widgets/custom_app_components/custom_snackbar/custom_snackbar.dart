import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class CustomSnackbar{
  validationSnackbar({required BuildContext  context,required String message}){
    return ScaffoldMessenger.of(context).showSnackBar(
   SnackBar(
    backgroundColor: customColors().danger,
    duration: const Duration(milliseconds: 1000),
    content: Text(
      "$message",
      style: customTextStyle(
          fontStyle: FontStyle.BodyM_SemiBold, color: FontColor.White),
    ),
  ));

  }}