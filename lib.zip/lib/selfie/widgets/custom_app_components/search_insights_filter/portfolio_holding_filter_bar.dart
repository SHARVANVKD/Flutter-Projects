import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/custom_image_icon.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class SearchFilterHoldings extends StatefulWidget {
  final VoidCallback? onSearchPress;
  final VoidCallback? onFilterPress;
  final VoidCallback? onSortPress;
  final VoidCallback? onInsights;
  final bool showBubble;
  final bool showFilter;
  final bool showInsights;

  const SearchFilterHoldings({
    Key? key,
    this.showBubble = false,
    this.showFilter = true,
    this.showInsights = true,
    this.onSearchPress,
    this.onFilterPress,
    this.onSortPress,
    this.onInsights,
  }) : super(key: key);
  @override
  State<SearchFilterHoldings> createState() => _SearchFilterHoldingsState();
}

class _SearchFilterHoldingsState extends State<SearchFilterHoldings> {
  @override
  Widget build(BuildContext context) {
    TextStyle styles = customTextStyle(
        fontStyle: FontStyle.BodyL_Regular, color: FontColor.FontSecondary);
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          InkWell(
            onTap: widget.onSearchPress,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                CustomImageIcon(imagPath: "assets/search.png"),
                // Image.asset(
                //   "assets/search.png",
                //   color: customColors().fontPrimary,
                //   height: 20,
                //   width: 20,
                // ),
                const SizedBox(
                  width: 6,
                ),
                Text(
                  "Search",
                  style: styles,
                ),
              ],
            ),
          ),
          widget.showInsights
              ? Visibility(
                  visible: widget.showInsights,
                  child: InkWell(
                      onTap: widget.onInsights,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          CustomImageIcon(imagPath: "assets/graph.png"),
                          const SizedBox(
                            width: 6,
                          ),
                          Text(
                            "Insights",
                            style: styles,
                          ),
                        ],
                      )),
                )
              : SizedBox(
                  width: MediaQuery.of(context).size.width * 0.13,
                  height: 5,
                ),
          widget.showFilter
              ? Visibility(
                  visible: widget.showFilter,
                  child: InkWell(
                    onTap: widget.onFilterPress,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Stack(
                          alignment: Alignment.topRight,
                          children: [
                            CustomImageIcon(imagPath: "assets/filter.png"),
                            if (widget.showBubble)
                              Padding(
                                padding:
                                    const EdgeInsets.only(top: 3, right: 1),
                                child: Container(
                                  width: 5,
                                  height: 5,
                                  decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      color: customColors().accent),
                                ),
                              ),
                          ],
                        ),
                        const SizedBox(
                          width: 6,
                        ),
                        Text(
                          "Filter",
                          style: styles,
                        ),
                      ],
                    ),
                  ),
                )
              : SizedBox(
                  width: MediaQuery.of(context).size.width * 0.13,
                  height: 5,
                ),
          InkWell(
            onTap: widget.onSortPress,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                CustomImageIcon(imagPath: "assets/sort.png"),
                const SizedBox(
                  width: 4,
                ),
                Text(
                  "Sort",
                  style: styles,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
