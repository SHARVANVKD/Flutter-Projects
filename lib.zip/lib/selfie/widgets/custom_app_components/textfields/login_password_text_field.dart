import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class LoginPasswordTextField extends StatefulWidget {
  final String hintText;
  final String label;
  final Color? bordercolor;
  TextEditingController passwordcontroller;
  final Function()? submit;
  LoginPasswordTextField(
      {Key? key,
      required this.label,
      required this.hintText,
      this.bordercolor,
      required this.passwordcontroller,
      this.submit})
      : super(key: key);

  @override
  _LoginPasswordTextFieldState createState() => _LoginPasswordTextFieldState();
}

class _LoginPasswordTextFieldState extends State<LoginPasswordTextField> {
  bool vis = true;

  @override
  Widget build(BuildContext context) {
    double mheight = MediaQuery.of(context).size.height * 1.22;

    return Container(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(
                widget.label,
                style: customTextStyle(
                    fontStyle: FontStyle.BodyL_Regular,
                    color: FontColor.FontPrimary),
              ),
            ],
          ),
          Padding(
            padding: EdgeInsets.only(top: mheight * .006),
            child: TextFormField(
              controller: widget.passwordcontroller,
              obscureText: vis,
              obscuringCharacter: '●',
              textAlignVertical: TextAlignVertical.center,
              cursorColor: customColors().fontPrimary,
              onFieldSubmitted: (v) {
                widget.submit!();
              },
              validator: (v) {
                if (v == "") {
                  return "Password required";
                } 
                // else if (v != "admin") {
                //   return "Incorrect Password";
                // }
              },
              style: customTextStyle(
                  fontStyle: FontStyle.BodyL_Regular,
                  color: FontColor.FontPrimary),
              decoration: InputDecoration(
                border: OutlineInputBorder(
                    borderSide:
                        BorderSide(color: widget.bordercolor!, width: 1.1),
                    borderRadius: BorderRadius.circular(4.0)),
                hintText: widget.hintText,
                hintStyle: customTextStyle(
                    fontStyle: FontStyle.BodyL_Regular,
                    color: FontColor.FontTertiary),
                focusedBorder: OutlineInputBorder(
                    borderSide:
                        BorderSide(color: widget.bordercolor!, width: 1.1),
                    borderRadius: BorderRadius.circular(4.0)),
                errorBorder: OutlineInputBorder(
                    borderSide:
                        BorderSide(color: customColors().danger, width: 1.1),
                    borderRadius: BorderRadius.circular(4.0)),
                suffixIcon: IconButton(
                    onPressed: () {
                      setState(() {
                        vis = !vis;
                      });
                    },
                    icon: vis
                        ? Image.asset('assets/vector_eye.png')
                        : Image.asset('assets/vector_eye_cross.png')),
                contentPadding:
                    EdgeInsets.symmetric(vertical: 15, horizontal: 10),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
