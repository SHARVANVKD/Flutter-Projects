import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class CustomImageIcon extends StatelessWidget {
  CustomImageIcon({
    Key? key,
    required this.imagPath,
    this.imageColor,
  }) : super(key: key);

  final String imagPath;
  final Color? imageColor;

  @override
  Widget build(BuildContext context) {
    return Image.asset(
      imagPath,
      color:imageColor?? customColors().fontPrimary,
      height: 16,
      width: 16,
    );
  }
}
