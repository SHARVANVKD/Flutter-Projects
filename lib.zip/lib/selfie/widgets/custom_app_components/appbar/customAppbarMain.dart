import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class CustomAppBarMain extends StatelessWidget {
  final String title;
  Function onTapTitle;
  final bool showTitleButton;
  final Widget? endIcon;
  CustomAppBarMain(
      {Key? key,
      required this.title,
      required this.onTapTitle,
      this.showTitleButton = false,
      this.endIcon})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 58,
      padding: const EdgeInsets.fromLTRB(16, 15, 0, 15),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          GestureDetector(
            onTap: () {
              onTapTitle();
            },
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Text(title,
                    textAlign: TextAlign.center,
                    style: customTextStyle(
                        fontStyle: FontStyle.HeaderS_Bold,
                        color: FontColor.FontPrimary)),
                showTitleButton
                    ? Padding(
                        padding: const EdgeInsets.all(4),
                        child: ImageIcon(
                          const AssetImage("assets/filled_arrow.png"),
                          size: 24,
                          color: customColors().primary,
                        ),
                      )
                    : Container(),
              ],
            ),
          ),
          endIcon ?? Container(),
        ],
      ),
    );
  }
}
