import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class SettingsAppbar extends StatelessWidget {
  final String title;
  final void Function() onBackPressed;
  final void Function() onResetPressed;
  final String buttonname;
  SettingsAppbar(
      {Key? key,
      required this.title,
      required this.onBackPressed,
      required this.onResetPressed,
      required this.buttonname})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 56.0,
      child: Padding(
        padding: EdgeInsets.only(top: 17.0),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Padding(
                  padding: const EdgeInsets.only(right: 12),
                  child: IconButton(
                      onPressed: onBackPressed,
                      icon: const ImageIcon(AssetImage("assets/arrow_left.png"),
                          size: 24)),
                  // child: ,
                ),
                Text(title,
                    textAlign: TextAlign.center,
                    style: customTextStyle(
                        fontStyle: FontStyle.HeaderXS_SemiBold,
                        color: FontColor.FontPrimary)),
              ],
            ),
            Visibility(
              visible: buttonname == "" ? false : true,
              child: Padding(
                padding: const EdgeInsets.only(right: 16.0),
                child: InkWell(
                  onTap: onResetPressed,
                  child: Text(buttonname,
                      style: customTextStyle(
                          fontStyle: FontStyle.HeaderXS_SemiBold,
                          color: FontColor.Primary)),
                ),
              ),
            )
            // endIcon == null || onEndIconPressed == null ?  Container() : AppBarEndIcon(context, endIcon!, onEndIconPressed!),

            // SvgPicture.asset("assets/icons/app_bar/frame.svg", height: 24, width: 24,),
          ],
        ),
      ),
    );
  }
}
