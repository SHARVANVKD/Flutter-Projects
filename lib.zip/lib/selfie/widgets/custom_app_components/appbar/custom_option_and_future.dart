import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/options_widget.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class CustomOptionAndFutureAppBar extends StatelessWidget {
  final String title;
  final String exchangeName;
  final String date;

  final void Function() onBackPressed;
  final void Function()? onMoreActionPressed;

  CustomOptionAndFutureAppBar({
    Key? key,
    required this.date,
    required this.title,
    required this.exchangeName,
    required this.onBackPressed,
    this.onMoreActionPressed,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      color: customColors().backgroundPrimary,
      padding: const EdgeInsets.only(top: 15, bottom: 15, right: 16, left: 5),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Padding(
              padding: const EdgeInsets.only(right: 12),
              child: IconButton(
                  onPressed: onBackPressed,
                  icon: const ImageIcon(AssetImage("assets/arrow_left.png"),
                      size: 24))),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                FittedBox(
                  fit: BoxFit.fitWidth,
                  child: Text(title,
                      textAlign: TextAlign.start,
                      style: customTextStyle(
                          fontStyle: FontStyle.HeaderXS_SemiBold,
                          color: FontColor.FontPrimary),
                      overflow: TextOverflow.fade,),
                ),
                const SizedBox(height: 2),
                Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(right:8.0),
                      child: getProductTypeWidget(
                                      exchangeName),
                    ),
                    
                    Text(
                      date,
                      style: customTextStyle(
                          fontStyle: FontStyle.BodyM_SemiBold,
                          color: FontColor.FontSecondary),
                    ),
                  ],
                )
              ],
            ),
          ),
          const SizedBox(width: 10),
          SizedBox(
            width: 30,
            child: IconButton(
                padding: EdgeInsets.all(0),
                onPressed: onMoreActionPressed,
                icon: const ImageIcon(AssetImage("assets/marketwatch.png"),
                    size: 24)),
          ),
        ],
      ),
    );
  }
}
