import 'package:bloc/bloc.dart';
import 'package:meta/meta.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_watchlist/page_all_watchlist/bloc/my_watch_list/my_watchlist_cubit.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';
import 'package:selfie_mobile_flutter/user_controller/user_controller.dart';
import 'package:selfie_mobile_flutter/utils/models/watchlist_model.dart';
import 'package:trading_api/responses/error_response.dart';
import 'package:trading_api/responses/get_cloud_watch_response.dart';

part 'create_watchlist_state.dart';

class CreateWatchlistCubit extends Cubit<CreateWatchlistState> {
  final ServiceLocator serviceLocator;
  CreateWatchlistCubit({required this.serviceLocator})
      : super(CreateWatchlistInitial());
  Future<ErrorResponse> sendWatchlistCreateRequest(
      {required context,
      required String watchlistName,
      required int sortOrder}) async {
    // emit(MyWatchlistLoading());
    ErrorResponse watchlistResponse = errorResponseFromJson(
        (await serviceLocator.tradingApi.createCloudWatchListData(
                watchName: watchlistName,
                sortOrder: sortOrder,
                userID: UserController().userId))
            .toString());
    if (watchlistResponse.result2!.length > 0 &&
        watchlistResponse.result2![0].errorcode == "0") {
      WatchlistModel newWatchList = WatchlistModel(
          watchlistData: WatchlistData(
              selected: "False",
              usercode: UserController.userController.userId,
              sortorder: sortOrder.toString(),
              watchname: watchlistName,
              watchlistid: watchlistResponse.result3![0].watchlistId.toString(),
              version: "1"));
      UserController.userController.watchlists.add(newWatchList);
    } else {}
    return watchlistResponse;
  }
}
