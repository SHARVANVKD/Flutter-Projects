part of 'create_watchlist_cubit.dart';

@immutable
abstract class CreateWatchlistState {}

class CreateWatchlistInitial extends CreateWatchlistState {}
