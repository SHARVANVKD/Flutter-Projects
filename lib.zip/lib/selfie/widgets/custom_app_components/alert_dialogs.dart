import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

Future<dynamic> showAlertDilogue({
  required BuildContext context, 
  required String content, 
  String? positiveButtonName, 
  String? negativeButtonName,
  VoidCallback? onPositiveButtonClick,
  VoidCallback? onNegativeButtonClick}) async {
    return showDialog(
        context: context,
        builder: (context) {
          return AlertDialog(
            backgroundColor: customColors().backgroundPrimary,
            content: Text(
              content,
              style: customTextStyle(
                  fontStyle: FontStyle.BodyM_SemiBold,
                  color: FontColor.FontSecondary),
            ),
            actions: [
              TextButton(
                child: Text(
                  positiveButtonName ?? "OK",
                  style: customTextStyle(
                      fontStyle: FontStyle.BodyM_SemiBold,
                      color: FontColor.Danger),
                ),
                onPressed: onPositiveButtonClick,
              ),
              TextButton(
                child: Text(
                  negativeButtonName ?? "Cancel",
                  style: customTextStyle(
                      fontStyle: FontStyle.BodyM_SemiBold,
                      color: FontColor.Info),
                ),
                onPressed: onNegativeButtonClick,
              ),
            ],
          );
        });
  }
