import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/custom_dot.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class CardItem extends StatelessWidget {
  double? height;
  double? width;
  Color? color;
  bool isProfit;
  String? icon;
  String category;
  String stockcount;
  String holdingPercentage;
  String invested;
  String current;
  String profitLoss;
  String stockType;
  Function() onPress;
  String? change;
  CardItem(
      {Key? key,
      this.height,
      this.width,
      this.color,
      this.icon,
      this.isProfit = true,
      required this.onPress,
      required this.holdingPercentage,
      required this.stockcount,
      required this.category,
      required this.invested,
      required this.current,
      required this.profitLoss,
      required this.stockType,
      this.change})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    Size screenSize = MediaQuery.of(context).size;
    return GestureDetector(
      onTap: onPress,
      child: Container(
        height: height ?? MediaQuery.of(context).size.height * 0.23,
        margin: const EdgeInsets.symmetric(horizontal: 16),
        width: width ?? double.maxFinite,
        decoration: BoxDecoration(
            color: customColors().backgroundPrimary,
            borderRadius: BorderRadius.circular(4),
            border: Border.all(color: customColors().backgroundTertiary)),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          Container(
                            height: 32,
                            width: 32,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(4),
                              shape: BoxShape.rectangle,
                              color: color ?? red700,
                            ),
                            child: Image.asset("assets/wallet.png"),
                          ),
                          const SizedBox(width: 10),
                          Text(
                            category,
                            style: customTextStyle(
                                fontStyle: FontStyle.HeaderXS_Bold,
                                color: FontColor.FontPrimary),
                          ),
                        ],
                      ),
                      InkWell(
                        onTap: onPress,
                        child: Container(
                            height: 30,
                            width: 30,
                            decoration: BoxDecoration(
                              image: DecorationImage(
                                image: AssetImage(
                                    icon ?? "assets/filledarrow.png"),
                                fit: BoxFit.cover,
                              ),
                            ),
                            child: null),
                      )
                    ],
                  ),
                  const SizedBox(
                    height: 8,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      RichText(
                        text: TextSpan(
                          text: '$stockcount ',
                          style: customTextStyle(
                              fontStyle: FontStyle.BodyM_SemiBold,
                              color: FontColor.FontSecondary),
                          children: <TextSpan>[
                            TextSpan(
                              text: stockType,
                              style: customTextStyle(
                                fontStyle: FontStyle.BodyM_Regular,
                                color: FontColor.FontSecondary,
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(width: 8),
                      const CustomDot(),
                      const SizedBox(width: 8),
                      RichText(
                        text: TextSpan(
                          text: '$holdingPercentage% ',
                          style: customTextStyle(
                              fontStyle: FontStyle.BodyM_SemiBold,
                              color: FontColor.FontSecondary),
                          children: <TextSpan>[
                            TextSpan(
                              text: 'of holdings',
                              style: customTextStyle(
                                  fontStyle: FontStyle.BodyM_Regular,
                                  color: FontColor.FontSecondary),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ],
              ),
              Container(
                height: 1,
                width: double.maxFinite,
                color: customColors().backgroundTertiary,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  SizedBox(
                    width: screenSize.width * 0.17,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "Invested",
                          style: customTextStyle(
                              fontStyle: FontStyle.BodyM_Regular,
                              color: FontColor.FontSecondary),
                        ),
                        const SizedBox(
                          height: 6,
                        ),
                        Text(
                          invested,
                          style: customTextStyle(
                              fontStyle: FontStyle.BodyL_SemiBold,
                              color: FontColor.FontPrimary),
                        )
                      ],
                    ),
                  ),
                  SizedBox(
                    width: screenSize.width * 0.17,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "Current",
                          style: customTextStyle(
                              fontStyle: FontStyle.BodyM_Regular,
                              color: FontColor.FontSecondary),
                        ),
                        const SizedBox(
                          height: 6,
                        ),
                        Text(
                          current,
                          style: customTextStyle(
                              fontStyle: FontStyle.BodyL_SemiBold,
                              color: FontColor.FontPrimary),
                        )
                      ],
                    ),
                  ),
                  SizedBox(
                    width: screenSize.width * 0.17,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Text(
                          "P&L",
                          style: customTextStyle(
                              fontStyle: FontStyle.BodyM_Regular,
                              color: FontColor.FontSecondary),
                        ),
                        const SizedBox(
                          height: 6,
                        ),
                        change == "N"
                            ? Text(
                                isProfit ? "$profitLoss%" : "$profitLoss%",
                                style: customTextStyle(
                                    fontStyle: FontStyle.BodyL_SemiBold,
                                    color: isProfit
                                        ? FontColor.Success
                                        : FontColor.Danger),
                              )
                            : Text(
                                isProfit ? "+$profitLoss%" : "-$profitLoss%",
                                style: customTextStyle(
                                    fontStyle: FontStyle.BodyL_SemiBold,
                                    color: isProfit
                                        ? FontColor.Success
                                        : FontColor.Danger),
                              )
                      ],
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
