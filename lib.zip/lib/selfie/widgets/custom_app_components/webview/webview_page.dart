import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

class CustomWebviewPage extends StatefulWidget {
  String urlAddress;
  CustomWebviewPage({ Key? key ,required this.urlAddress}) : super(key: key);

  @override
  State<CustomWebviewPage> createState() => _CustomWebviewPageState();
}

class _CustomWebviewPageState extends State<CustomWebviewPage> with TickerProviderStateMixin{


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: WebView(initialUrl: widget.urlAddress,
      javascriptMode: JavascriptMode.unrestricted,
              javascriptChannels: <JavascriptChannel>[
                JavascriptChannel(
                    name: 'MessageInvoker',
                    onMessageReceived: (s) {
                    Scaffold.of(context).showSnackBar(SnackBar(
                       content: Text(s.message),
                    ));
                    }),
              ].toSet(),
    
      ),
    );
  }
}