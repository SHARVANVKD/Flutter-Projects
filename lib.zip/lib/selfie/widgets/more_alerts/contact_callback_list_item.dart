import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/options_widget.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class ContactCallbackListItem extends StatefulWidget {
  Map<String, dynamic> contactCallbackList;
  VoidCallback? onLongPressAction;
  VoidCallback? onTap;
  ContactCallbackListItem(
      {Key? key, required this.contactCallbackList, this.onLongPressAction, this.onTap})
      : super(key: key);

  @override
  State<ContactCallbackListItem> createState() => _ContactCallbackListItemState();
}

class _ContactCallbackListItemState extends State<ContactCallbackListItem> {
  var paint1 = Paint()
    ..color = customColors().success
    ..strokeCap = StrokeCap.round //rounded points
    ..strokeWidth = 10;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onLongPress: widget.onLongPressAction,
      onTap: widget.onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 16),
          decoration: BoxDecoration(
              border: Border(
            bottom:
                BorderSide(color: customColors().backgroundTertiary, width: 1),
          )),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Visibility(
                // visible: widget.closedList.containsKey("topview"),
                visible: true,
                child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      // Row(
                      //   children: [
                      //     Padding(
                      //       padding:
                      //           const EdgeInsets.symmetric(horizontal: 0.0),
                      //       child: getProductTypeWidget(
                      //           widget.closedList["position"]),
                      //     ),
                      //     SizedBox(
                      //       width: 6,
                      //     ),
                      //     Padding(
                      //       padding:
                      //           const EdgeInsets.symmetric(horizontal: 0.0),
                      //       child: getProductTypeWidget(
                      //           widget.closedList["order_type"]),
                      //     ),
                      //   ],
                      // ),
                      // Row(
                      //   crossAxisAlignment: CrossAxisAlignment.end,
                      //   children: [
                      //     Text(
                      //       "${widget.closedList["last_update"]}",
                      //       style: customTextStyle(
                      //           fontStyle: FontStyle.BodyS_SemiBold,
                      //           color: FontColor.FontTertiary),
                      //     ),
                      //     getOrderStatusWidget(widget.closedList["status"])
                          
                      //   ],
                      // )
                    ]),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 10),
                // child: Row(
                //     mainAxisAlignment: MainAxisAlignment.spaceBetween,
                //     children: [
                //       Text(
                //         widget.closedList["name"],
                //         style: customTextStyle(
                //             fontStyle: FontStyle.BodyL_SemiBold,
                //             color: FontColor.FontPrimary),
                //       ),
                //       RichText(
                //           text: TextSpan(
                //               text: "Avg. ",
                //               style: customTextStyle(
                //                   fontStyle: FontStyle.BodyL_Regular,
                //                   color: FontColor.FontPrimary),
                //               children: [
                            
                //           ])),
                //     ]),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 4.0),
                child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      // Text(
                      //   "${widget.closedList["quantity"]}/${widget.closedList["total_quantity"]}",
                      //   style: customTextStyle(
                      //       fontStyle: FontStyle.BodyM_SemiBold,
                      //       color: FontColor.FontSecondary),
                      // ),
                      // Text(
                      //   "${widget.closedList["market"]}",
                      //   style: customTextStyle(
                      //       fontStyle: FontStyle.BodyM_SemiBold,
                      //       color: FontColor.FontSecondary),
                      // ),
                    ]),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
