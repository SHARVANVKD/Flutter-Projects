import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_more/page_more_alerts/components/triggered_model_data.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/options_widget.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/stock/empty_custom_checkbox/empty_custom_checkbox.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class ListViewModel extends StatelessWidget {
  String exchange;
  String date;
  String symbol;
  String ltp;
  String status;
  String amount;
  FontColor statusColor;
  bool ischeck;
  List<int> checklist;
  Function(int) check;
  int index;
  ListViewModel(
      {Key? key,
      required this.amount,
      required this.date,
      required this.exchange,
      required this.ltp,
      required this.status,
      required this.statusColor,
      required this.symbol,
      required this.ischeck,
      required this.checklist,
      required this.check,
      required this.index})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const SizedBox(
          height: 16,
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            getProductTypeWidget(exchange),
            Row(
              children: [
                Text(
                  status,
                  style: customTextStyle(
                      fontStyle: FontStyle.TagNameS_SemiBold,
                      color: statusColor),
                ),
                Visibility(
                  visible: ischeck,
                  child: Padding(
                    padding: const EdgeInsets.only(left: 9.0),
                    child: SizedBox(
                        height: 17.0,
                        child: checklist.length == 3
                            ? InkWell(
                                splashColor: customColors().primary,
                                child: SizedBox(
                                  height: 24,
                                  width: 24,
                                  child: Image.asset(
                                    "assets/checkedicon.png",
                                  ),
                                ),
                              )
                            : EmptyCustomCheckBox(callback: (v) {
                                check(index);
                              })),
                  ),
                )
              ],
            ),
          ],
        ),
        const SizedBox(
          height: 8,
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              symbol,
              style: customTextStyle(
                  fontStyle: FontStyle.BodyL_SemiBold,
                  color: FontColor.FontPrimary),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.only(right: 6),
                  child: Image.asset(
                    "assets/calendar.png",
                    color: customColors().fontTertiary,
                    height: 13,
                    width: 13,
                  ),
                ),
                Text(
                  date,
                  style: customTextStyle(
                      fontStyle: FontStyle.BodyL_Regular,
                      color: FontColor.FontSecondary),
                ),
              ],
            )
          ],
        ),
        const SizedBox(
          height: 4,
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            RichText(
              text: TextSpan(
                  text: "LTP ",
                  style: customTextStyle(
                    fontStyle: FontStyle.BodyM_Regular,
                    color: FontColor.FontSecondary,
                  ),
                  children: <TextSpan>[
                    TextSpan(
                      text: "is greater than ",
                      style: customTextStyle(
                        fontStyle: FontStyle.BodyM_SemiBold,
                        color: FontColor.FontSecondary,
                      ),
                    ),
                    TextSpan(
                      text: ltp,
                      style: customTextStyle(
                        fontStyle: FontStyle.BodyM_SemiBold,
                        color: FontColor.FontPrimary,
                      ),
                    ),
                  ]),
            ),
            const SizedBox(
              height: 4,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                RichText(
                  text: TextSpan(
                      text: "₹ ",
                      style: customTextStyle(
                        fontStyle: FontStyle.BodyM_Regular,
                        color: FontColor.FontPrimary,
                      ),
                      children: <TextSpan>[
                        TextSpan(
                          text: amount,
                          style: customTextStyle(
                            fontStyle: FontStyle.BodyM_SemiBold,
                            color: FontColor.FontPrimary,
                          ),
                        ),
                      ]),
                ),
              ],
            )
          ],
        ),
        Padding(
          padding: const EdgeInsets.only(top: 16),
          child: Divider(
            height: 1,
            color: customColors().backgroundTertiary,
          ),
        ),
      ],
    );
  }
}
