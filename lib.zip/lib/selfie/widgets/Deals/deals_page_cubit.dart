import 'package:bloc/bloc.dart';
import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/app_page_injectable.dart';
part 'deals_page_state.dart';

class DealsPageCubit extends Cubit<DealsPageState> {
  DealsPageCubit() : super(DealsPageInitial());

  changeTabIndex(int index) {
    emit(DealsPageInitial(tabIndex: index));
  }
}
