import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/selfie/repository_layer/list_data.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/Deals/deals_page_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/custom_top_tab.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/dealst_list_container.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

const tabItems = ["Block Deal", "Bulk Deal"];

class DealsComponent extends StatefulWidget {
  const DealsComponent({Key? key}) : super(key: key);

  @override
  State<DealsComponent> createState() => _DealsComponentState();
}

class _DealsComponentState extends State<DealsComponent>
    with TickerProviderStateMixin {
  void initState() {
    // TODO: implement initState
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => DealsPageCubit(),
      child: BlocBuilder<DealsPageCubit, DealsPageState>(
          builder: (context, state) {
        return Column(
          mainAxisAlignment: MainAxisAlignment.start, 
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
          Expanded(
            child : CustomTabBar(
              isScrollable: true,
              tabContent: tabItems,
              tabBarViewChildern: [
                DealsListContainer(
                      dealsList: dealsList,
                    ),
                DealsListContainer(dealsList: bulkDealsList)
              ],
              ),
          )
        ]);
      }),
    );
  }
}
