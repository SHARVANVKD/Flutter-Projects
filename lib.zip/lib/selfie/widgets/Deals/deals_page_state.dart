part of 'deals_page_cubit.dart';

@immutable
abstract class DealsPageState {}

class DealsPageInitial extends DealsPageState {
  final int tabIndex;
  DealsPageInitial({this.tabIndex = 0});
}
