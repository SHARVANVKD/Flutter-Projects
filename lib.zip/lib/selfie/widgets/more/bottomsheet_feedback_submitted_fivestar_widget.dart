import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/buttons/BasketButton.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class FeedbackSubmittedFiveStarBottomsheetWidget extends StatelessWidget {
  const FeedbackSubmittedFiveStarBottomsheetWidget({Key? key})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    Size screenSize = MediaQuery.of(context).size;
    return Column(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        SizedBox(
          height: 40,
        ), //groupimage
        Stack(alignment: AlignmentDirectional.center, children: [
          Container(
            width: screenSize.width * 0.34,
            height: screenSize.width * 0.29,
            decoration: BoxDecoration(
                image: DecorationImage(
                    image: AssetImage("assets/groupimage.png"),
                    fit: BoxFit.fill)),
            //  color: Colors.blue.withOpacity(.2),
            // child: Image.asset(
            //   "assets/groupimage.png",
            // ),
          ),
          Container(
            width: screenSize.width * 0.2,
            height: screenSize.width * 0.2,
            decoration: BoxDecoration(
                image: DecorationImage(
                    image: AssetImage("assets/rating5.png"), fit: BoxFit.fill)),
            //  color: Colors.blue.withOpacity(.2),
            // child: Image.asset(
            //   "assets/groupimage.png",
            // ),
          ),
        ]),
        SizedBox(
          height: 16,
        ),
        Text(
          "Thank You",
          style: customTextStyle(
              fontStyle: FontStyle.HeaderS_SemiBold,
              color: FontColor.FontPrimary),
        ),
        SizedBox(
          height: 16,
        ),
        Text(
          "We are glad that you loved us!",
          style: customTextStyle(
              fontStyle: FontStyle.BodyL_Regular,
              color: FontColor.FontSecondary),
        ),
        SizedBox(
          height: 22,
        ),
        Padding(
          padding: const EdgeInsets.all(16.0),
          child: Row(
            children: [
              Expanded(
                child: BasketButton(
                  bordercolor: customColors().green4,
                  text: "Back",
                  textStyle: customTextStyle(
                      fontStyle: FontStyle.BodyL_Bold,
                      color: FontColor.Primary),
                  onpress: () {
                    Navigator.of(context).pop(true);
                  },
                ),
              ),
              SizedBox(
                width: 8,
              ),
              Expanded(
                child: BasketButton(
                  bordercolor: transparent,
                  bgcolor: customColors().primary,
                  text: "Rate on Playstore",
                  textStyle: customTextStyle(
                      fontStyle: FontStyle.BodyL_Bold, color: FontColor.White),
                  onpress: () {
                    Navigator.of(context).pop(true);
                  },
                ),
              )
            ],
          ),
        ),
      ],
    );
  }
}
