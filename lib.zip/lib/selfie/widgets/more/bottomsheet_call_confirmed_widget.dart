import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/buttons/BasketButton.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class CallConfirmedBottosheetWidget extends StatelessWidget {
  const CallConfirmedBottosheetWidget({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          SizedBox(
            height: 40,
          ),
          Image.asset("assets/Tick.png"),
          SizedBox(
            height: 16,
          ),
          Text(
            "Call Confirmed",
            style: customTextStyle(
                fontStyle: FontStyle.HeaderS_SemiBold,
                color: FontColor.FontPrimary),
          ),
          SizedBox(
            height: 16,
          ),
          Text(
            "We will get back to you between",
            style: customTextStyle(
                fontStyle: FontStyle.BodyL_Regular,
                color: FontColor.FontSecondary),
          ),
          SizedBox(
            height: 8,
          ),
          Text(
            "@10:00AM-1:00PM on 24-03-22",
            style: customTextStyle(
                fontStyle: FontStyle.BodyL_SemiBold,
                color: FontColor.FontPrimary),
          ),
          SizedBox(
            height: 22,
          ),
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Row(
              children: [
                Expanded(
                  child: BasketButton(
                    bordercolor: customColors().primary,
                    text: "Edit Request",
                    textStyle: customTextStyle(
                        fontStyle: FontStyle.BodyL_SemiBold,
                        color: FontColor.Primary),
                    onpress: () {
                      Navigator.of(context).pop(true);
                    },
                  ),
                ),
                SizedBox(
                  width: 8,
                ),
                Expanded(
                  child: BasketButton(
                    bordercolor: transparent,
                    bgcolor: customColors().primary,
                    text: "Close",
                    textStyle: customTextStyle(
                        fontStyle: FontStyle.BodyL_Bold,
                        color: FontColor.White),
                    onpress: () {
                      Navigator.of(context).pop(true);
                    },
                  ),
                )
              ],
            ),
          ),
          
        ],
      );
  }
}