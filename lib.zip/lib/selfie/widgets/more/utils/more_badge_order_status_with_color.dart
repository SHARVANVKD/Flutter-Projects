import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/options_widget.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

Widget moreBadgeWidget(String value) {
  switch (value.toUpperCase()) {
    case "":
      return SizedBox();
    case "CASH":
      return ProductTypeWidget(
          text: "CASH",
          textColor: FontColor.PacificBlue,
          boxColor: customColors().info);
    case "BTST":
      return ProductTypeWidget(
          text: "BTST",
          textColor: FontColor.Ultraviolet,
          boxColor: customColors().ultraviolet);
    case "INTRADAY":
      return ProductTypeWidget(
          text: "INTRADAY",
          textColor: FontColor.PacificBlue,
          boxColor: customColors().pacificBlue);
    case "MTF":
      return ProductTypeWidget(
          text: "MTF",
          textColor: FontColor.Purple,
          boxColor: customColors().mattPurple);
    case "SMARTFOLIO":
      return ProductTypeWidget(
          text: "SMARTFOLIO",
          textColor: FontColor.Ultraviolet,
          boxColor: customColors().ultraviolet);
    case "BUY":
      return ProductTypeWidget(
          text: "BUY",
          textColor: FontColor.SecretGarden,
          boxColor: customColors().success);
    case "SELL":
      return ProductTypeWidget(
          text: "SELL",
          textColor: FontColor.CarnationRed,
          boxColor: customColors().danger);
    case "NSE":
      return ProductTypeWidget(
          text: "NSE",
          textColor: FontColor.Purple,
          boxColor: customColors().mattPurple);
    case "BSE":
      return ProductTypeWidget(
          text: "BSE",
          textColor: FontColor.Ultraviolet,
          boxColor: customColors().ultraviolet);
    case "NFO":
      return ProductTypeWidget(
          text: "NFO",
          textColor: FontColor.PacificBlue,
          boxColor: customColors().pacificBlue);
    case "NSECD":
      return ProductTypeWidget(
          text: "NSECD",
          textColor: FontColor.Purple,
          boxColor: customColors().mattPurple);
    case "NSEMF":
      return ProductTypeWidget(
          text: "SMARTFOLIO",
          textColor: FontColor.Ultraviolet,
          boxColor: customColors().ultraviolet);
    case "MF":
      return ProductTypeWidget(
          text: "MF",
          textColor: FontColor.Purple,
          boxColor: customColors().mattPurple);
    case "BFO":
      return ProductTypeWidget(
          text: "BFO",
          textColor: FontColor.DodgerBlue,
          boxColor: customColors().dodgerBlue);
    case "MCX":
      return ProductTypeWidget(
          text: "MCX",
          textColor: FontColor.Crisps,
          boxColor: customColors().crisps);
    case "CDS":
      return ProductTypeWidget(
          text: "CDS",
          textColor: FontColor.Purple,
          boxColor: customColors().mattPurple);
    case "DEFAULT":
      return ProductTypeWidget(
          text: "DEFAULT",
          textColor: FontColor.DodgerBlue,
          boxColor: customColors().dodgerBlue);
    case "BONUS":
      return ProductTypeWidget(
          text: "BONUS",
          textColor: FontColor.Purple,
          boxColor: customColors().mattPurple);
    case "DIVIDENT":
      return ProductTypeWidget(
          text: "DIVIDENT",
          textColor: FontColor.Crisps,
          boxColor: customColors().crisps);
    case "HOLD":
      return ProductTypeWidget(
          text: "HOLD",
          textColor: FontColor.SilverDust,
          boxColor: customColors().silverDust);
    case "SPLIT":
      return ProductTypeWidget(
          text: "SPLIT",
          textColor: FontColor.PacificBlue,
          boxColor: customColors().pacificBlue);
    case "INDEX":
      return ProductTypeWidget(
          text: "INDEX",
          textColor: FontColor.FontSecondary,
          boxColor: customColors().silverDust);
    case "BULK":
      return ProductTypeWidget(
          text: "BULK",
          textColor: FontColor.Purple,
          boxColor: customColors().mattPurple);
    case "BLOCK":
      return ProductTypeWidget(
          text: "BLOCK",
          textColor: FontColor.DodgerBlue,
          boxColor: customColors().dodgerBlue);
    case "POSITIVE":
      return ProductTypeWidget(
          text: "POSITIVE",
          textColor: FontColor.SecretGarden,
          boxColor: customColors().success);
    case "NEGATIVE":
      return ProductTypeWidget(
          text: "NEGATIVE",
          textColor: FontColor.CarnationRed,
          boxColor: customColors().danger);
    case "NUETRAL":
      return ProductTypeWidget(
          text: "NUETRAL",
          textColor: FontColor.FontSecondary,
          boxColor: customColors().silverDust);
    case "MY GEOJIT":
      return ProductTypeWidget(
          text: "MY GEOJIT",
          textColor: FontColor.Purple,
          boxColor: customColors().mattPurple);
    case "SELFIE APP":
      return ProductTypeWidget(
          text: "SELFIE APP",
          textColor: FontColor.Crisps,
          boxColor: customColors().crisps);
    case "BOUGHT":
      return ProductTypeWidget(
          text: "Bought".toUpperCase(),
          textColor: FontColor.SecretGarden,
          boxColor: Color.fromRGBO(25, 175, 85, 0.15));

    case "SOLD":
      return ProductTypeWidget(
          text: "Sold".toUpperCase(),
          textColor: FontColor.CarnationRed,
          boxColor: Color.fromRGBO(255, 59, 48, 0.15));

    case "UPCOMING":
      return ProductTypeWidget(
          text: "UPcoming".toUpperCase(),
          textColor: FontColor.SecretGarden,
          boxColor: Color.fromRGBO(25, 175, 85, 0.15));

    case "ANNOUNCEMENTS":
      return ProductTypeWidget(
          text: "Announcements".toUpperCase(),
          textColor: FontColor.MattPurple,
          boxColor: Color.fromRGBO(151, 104, 225, 0.15));
    case "CLOSED":
      return ProductTypeWidget(
          text: "Closed".toUpperCase(),
          textColor: FontColor.CarnationRed,
          boxColor: customColors().carnationRed.withOpacity(0.15));

    case "OPEN":
      return ProductTypeWidget(
          text: "OPen".toUpperCase(),
          textColor: FontColor.Success,
          boxColor: Color.fromRGBO(25, 175, 85, 0.15));
    default:
      return ProductTypeWidget(
          text: "NO Badge",
          textColor: FontColor.DodgerBlue,
          boxColor: customColors().dodgerBlue);
  }
}

Widget moreOrderStatusWidget(String value) {
  switch (value.toUpperCase()) {
    case "ACTIVE":
      return const OrderStatusWidget(
          text: "ACTIVE", textColor: FontColor.Success);
    case "CONFIRMED":
      return const OrderStatusWidget(
          text: "CONFIRMED", textColor: FontColor.Success);
    case "UPCOMING":
      return const OrderStatusWidget(
          text: "UPCOMING", textColor: FontColor.Success);
    case "PENDING":
      return const OrderStatusWidget(
          text: "PENDING", textColor: FontColor.Danger);
    case "SAVED":
      return const OrderStatusWidget(text: "SAVED", textColor: FontColor.Info);
    case "EXECUTED":
      return const OrderStatusWidget(
          text: "EXECUTED", textColor: FontColor.Success);
    case "REJECTED":
      return const OrderStatusWidget(
          text: "REJECTED", textColor: FontColor.Danger);
    case "CANCELLED":
      return const OrderStatusWidget(
          text: "CANCELLED", textColor: FontColor.Danger);
    case "PEXE":
      return const OrderStatusWidget(
          text: "PEXE", textColor: FontColor.Warning);
    case "RECEIVED":
      return const OrderStatusWidget(
          text: "RECEIVED", textColor: FontColor.Info);
    default:
      return const OrderStatusWidget(
          text: "no status", textColor: FontColor.Success);
  }
}