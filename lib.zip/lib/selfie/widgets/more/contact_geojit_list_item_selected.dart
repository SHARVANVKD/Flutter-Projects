import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/more/utils/more_badge_order_status_with_color.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/stock/empty_custom_checkbox/empty_custom_checkbox.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class ContactListItemSelected extends StatefulWidget {
  Map<String, dynamic> positionsamples;
  bool isActive;
  List<String> checklist;
  final Function(int) upcount;
  ContactListItemSelected(
      {Key? key,
      required this.positionsamples,
      required this.checklist,
      required this.upcount,
      this.isActive = false})
      : super(key: key);

  @override
  State<ContactListItemSelected> createState() => _PortfolioListItemState();
}

class _PortfolioListItemState extends State<ContactListItemSelected> {
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    Size screenSize = MediaQuery.of(context).size;
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        moreBadgeWidget(widget.positionsamples["badge"]),
                        moreOrderStatusWidget(widget.positionsamples["status"])


                      ],
                    ),
                    SizedBox(height: 8,),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Text(
                          widget.positionsamples["name"],
                          style: customTextStyle(
                              fontStyle: FontStyle.BodyL_SemiBold,
                              color: FontColor.FontPrimary),
                        ),
                        Text(
                          "Call Date & Time",
                          style: customTextStyle(
                              fontStyle: FontStyle.BodyS_SemiBold,
                              color: FontColor.FontSecondary),
                        ),
                      ],
                    ),
                    SizedBox(height: 1,),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Expanded(
                          child: Text(
                            widget.positionsamples["description"].replaceRange(
                                45,
                                widget.positionsamples["description"].length,
                                '...'),
                            style: customTextStyle(
                                fontStyle: FontStyle.BodyM_Regular,
                                color: FontColor.FontSecondary),
                          ),
                        ),
                        SizedBox(
                          width: screenSize.width * .147,
                        ),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Text(
                              widget.positionsamples["date"],
                              style: customTextStyle(
                                  fontStyle: FontStyle.BodyM_SemiBold,
                                  color: FontColor.FontPrimary),
                            ),
                            Text(
                              widget.positionsamples["time"],
                              style: customTextStyle(
                                  fontStyle: FontStyle.BodyM_SemiBold,
                                  color: FontColor.FontPrimary),
                            ),
                          ],
                        ),
                      ],
                    )
                  ],
                ),
              ),
              if (widget.isActive)
                Row(
                  children: [
                    SizedBox(
                      width: 10,
                    ),
                    EmptyCustomCheckBox(callback: (val) {
                      checkinlist(widget.positionsamples["name"]);
                    }),
                  ],
                )
            ],
          ),
          SizedBox(
            height: 20,
          ),
          Divider(
            thickness: 1.0,
            color: customColors().backgroundTertiary,
          )
        ],
      ),
    );
  }

  void checkinlist(String name) {
    setState(() {
      if (widget.checklist.contains(name)) {
        widget.checklist.remove(name);
      } else {
        widget.checklist.add(name);
      }
      widget.upcount(widget.checklist.length);
    });
  }
}
