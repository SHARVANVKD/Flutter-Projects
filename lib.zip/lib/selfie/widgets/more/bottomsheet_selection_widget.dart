import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/custom_radio_button.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/stock/empty_custom_checkbox/empty_custom_checkbox.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class BottomsheetSelectionWidget extends StatefulWidget {
  final Function(int) onfilterpress;
  final List<Map<String,dynamic>> selectionList;
  final String title;
  int currentval;
  BottomsheetSelectionWidget({Key? key,required this.selectionList, required this.onfilterpress, required this.currentval,required this.title})
      : super(key: key);

  @override
  State<BottomsheetSelectionWidget> createState() => _bottomsheetSelectionWidgetState();
}

class _bottomsheetSelectionWidgetState extends State<BottomsheetSelectionWidget> {
  int _value = -1;
  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(left:16,bottom: 12),
          child: Text(widget.title, 
                                  style: customTextStyle(
                                    fontStyle: FontStyle.BodyL_SemiBold,
                                    color: FontColor.FontPrimary
                                    )),
        ),
        Divider(
          height: 0,
          thickness: 1,
          color: customColors().backgroundTertiary,
        ),
        Container(
          child: Padding(
            padding: const EdgeInsets.only(left: 10),
            child: Column(
              children: [
                
                ListView.builder(
                    shrinkWrap: true,
                    itemCount: widget.selectionList.length,
                    itemBuilder: (context, index) {
                      return MyRadioListTile<int>(
                        value: index,
                        groupValue: widget.currentval,
                        // groupValue: _value,
                        title: Text(
                          "${widget.selectionList[index]["name"]}",
                          style: customTextStyle(
                            fontStyle: FontStyle.BodyL_Regular,
                            color: FontColor.FontPrimary,
                          ),
                        ),
                        onChanged: (value) {
                         
                          setState(() {
                            widget.currentval = value!;
                            // widget.onfilterpress(widget.selectionList[value]["name"]);
                            widget.onfilterpress(value);
                            Navigator.of(context).pop();
                          });
                        },
                      );
                    }),
              ],
            ),
          ),
        )
      ],
    );
  }
}


class BottomsheetMultiSelectionWidget extends StatefulWidget {
  final void Function(String) onfilterpress;
  final List<Map<String,dynamic>> selectionList;
  final String title;
  int currentval;
  BottomsheetMultiSelectionWidget({Key? key,required this.selectionList, required this.onfilterpress, required this.currentval,required this.title})
      : super(key: key);

  @override
  State<BottomsheetMultiSelectionWidget> createState() => _BottomsheetMultiSelectionWidgetState();
}

class _BottomsheetMultiSelectionWidgetState extends State<BottomsheetMultiSelectionWidget> {
  int _value = -1;
int totalCount = 0;
  callback(bool stsa) {
    setState(() {
      stsa ? totalCount++ : totalCount--;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(left:16,bottom: 12,right: 16),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(widget.title, 
                style: customTextStyle(
                  fontStyle: FontStyle.HeaderXS_SemiBold,
                  color: FontColor.FontPrimary
                  )),
              Text("Clear", 
                style: customTextStyle(
                  fontStyle: FontStyle.BodyL_Bold,
                  color: FontColor.Primary
                  )),
            ],
          ),
        ),
        Divider(
          height: 0,
          thickness: 1,
          color: customColors().backgroundTertiary,
        ),
        Container(
          child: Padding(
            padding: const EdgeInsets.only(left: 10),
            child: Column(
              children: [

                for (int index = 0; index < widget.selectionList.length; index++)
                Padding(
                  padding: const EdgeInsets.only(left: 16, right: 16),
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          EmptyCustomCheckBox(callback: callback),
                          Padding(
                            padding: const EdgeInsets.only(top: 14, bottom: 14,left: 13),
                            child: Text(
                              widget.selectionList[index]["name"],
                              style: customTextStyle(
                                fontStyle: FontStyle.BodyL_Regular,
                                color: FontColor.FontPrimary,
                              ),
                            ),
                          ),
                          
                        ],
                      ),
                      
                    ],
                  ),
                ),
              ],
            ),
          ),
        )
      ],
    );
  }
}