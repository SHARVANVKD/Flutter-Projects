import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class EmptyVolumeOffButton extends StatefulWidget {
  Function(bool) callback;
  final bool isSelect;
  EmptyVolumeOffButton(
      {Key? key, required this.callback, this.isSelect = false})
      : super(key: key);
  @override
  State<EmptyVolumeOffButton> createState() => _EmptyVolumeOffButtonState();
}

class _EmptyVolumeOffButtonState extends State<EmptyVolumeOffButton> {
  bool isChecked = false;
  ontap() {
    setState(() {
      isChecked ? isChecked = false : isChecked = true;
      widget.callback(isChecked);
    });
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    setState(() {
      isChecked = widget.isSelect;
    });
  }

  @override
  Widget build(BuildContext context) {
    return isChecked
        ? InkWell(
            onTap: ontap,
            child: SizedBox(
              height: 24,
              width: 24,
              child: Image.asset("assets/volume.png",
                  color: customColors().primary),
            ),
          )
        : InkWell(
            onTap: ontap,
            child: SizedBox(
              height: 24,
              width: 24,
              child: Image.asset(
                "assets/volumeoff.png",
              ),
            ));
  }
}
