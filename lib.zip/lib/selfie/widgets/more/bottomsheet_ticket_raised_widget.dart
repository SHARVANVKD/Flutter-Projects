import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/buttons/BasketButton.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class TicketRaisedBottosheetWidget extends StatelessWidget {
  const TicketRaisedBottosheetWidget({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
        // mainAxisAlignment: MainAxisAlignment.spaceBetween,
        // mainAxisSize: MainAxisSize.min,
        children: [
          SizedBox(
            height: 40,
          ),
          Image.asset("assets/Tick.png"),
          SizedBox(
            height: 16,
          ),
          Text(
            "Ticket Raised!",
            style: customTextStyle(
                fontStyle: FontStyle.HeaderS_SemiBold,
                color: FontColor.FontPrimary),
          ),
          SizedBox(
            height: 16,
          ),
          Text(
            "Your ticket has been raised successfully.",
            style: customTextStyle(
                fontStyle: FontStyle.BodyL_Regular,
                color: FontColor.FontSecondary),
          ),
          Text(
            "We will get back to you within 24 hours.",
            style: customTextStyle(
                fontStyle: FontStyle.BodyL_Regular,
                color: FontColor.FontSecondary),
          ),
          SizedBox(
            height: 24,
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: Row(
              children: [
                Expanded(
                  child: BasketButton(
                    bordercolor: transparent,
                    bgcolor: customColors().primary,
                    text: "Close",
                    textStyle: customTextStyle(
                        fontStyle: FontStyle.BodyL_Bold,
                        color: FontColor.White),
                    onpress: () {
                      Navigator.of(context).pop(true);
                    },
                  ),
                ),
              ],
            ),
          ),
          
        ],
      );
  }
}