import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class AllNotifcationListContainer extends StatelessWidget {
  String? tiltle;
  String? subtitle;
  String? date;
  String? titleSymbol;
  AllNotifcationListContainer({
    Key? key,
    this.tiltle,
    this.subtitle,
    this.date,
    this.titleSymbol,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(
        vertical: 12,
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Stack(
            alignment: Alignment.center,
            children: [
              Image.asset(
                "assets/ellipse.png",
                height: 36,
                width: 36,
              ),
              Container(
                alignment: Alignment.center,
                child: Text(titleSymbol.toString(),
                    textAlign: TextAlign.center,
                    style: customTextStyle(
                        fontStyle: FontStyle.HeaderXS_SemiBold,
                        color: FontColor.Accent)),
              ),
            ],
          ),
          // Container(
          //   height: 36,
          //   width: 36,
          //   decoration: BoxDecoration(
          //       shape: BoxShape.circle, color: customColors().accent),
          //   child: Text(
          //     titleSymbol.toString(),
          //     style: customTextStyle(
          //         fontStyle: FontStyle.BodyM_SemiBold,
          //         color: FontColor.FontPrimary),
          //   ),
          // ),
          const SizedBox(
            width: 14,
          ),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      tiltle.toString(),
                      style: customTextStyle(
                          fontStyle: FontStyle.BodyM_SemiBold,
                          color: FontColor.FontPrimary),
                    ),
                    Text(date.toString(),
                        style: customTextStyle(
                            fontStyle: FontStyle.BodyS_Regular,
                            color: FontColor.FontSecondary)),
                  ],
                ),
                const SizedBox(
                  height: 4,
                ),
                Text(subtitle.toString(),
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyS_Regular,
                        color: FontColor.FontPrimary)),
                const SizedBox(
                  height: 8,
                ),
                Divider(
                  height: 1,
                  color: customColors().backgroundTertiary,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
