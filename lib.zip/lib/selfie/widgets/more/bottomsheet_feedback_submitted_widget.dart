import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/buttons/BasketButton.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class FeedbackSubmittedBottomsheetWidget extends StatelessWidget {
  const FeedbackSubmittedBottomsheetWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        SizedBox(
          height: 40,
        ),
        Image.asset("assets/circles_confirm.png"),
        SizedBox(
          height: 16,
        ),
        Text(
          "Submitted",
          style: customTextStyle(
              fontStyle: FontStyle.HeaderS_SemiBold,
              color: FontColor.FontPrimary),
        ),
        SizedBox(
          height: 16,
        ),
        Text(
          "Thank you for your feedback!",
          style: customTextStyle(
              fontStyle: FontStyle.BodyL_Regular,
              color: FontColor.FontSecondary),
        ),
        SizedBox(
          height: 22,
        ),
        Padding(
          padding: const EdgeInsets.all(16.0),
          child: Row(
            children: [
              Expanded(
                child: BasketButton(
                  bordercolor: transparent,
                  bgcolor: customColors().primary,
                  text: "Done",
                  textStyle: customTextStyle(
                      fontStyle: FontStyle.BodyL_Bold, color: FontColor.White),
                  onpress: () {
                    Navigator.of(context).pop(true);
                  },
                ),
              )
            ],
          ),
        ),
      ],
    );
  }
}
