import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class OptionMoreActionBottomSheet extends StatefulWidget {
  bool enabled;
  final VoidCallback? onAddWatchList;
  final VoidCallback? onSetAlert;
  OptionMoreActionBottomSheet(
      {Key? key, this.onSetAlert, this.onAddWatchList, required this.enabled})
      : super(key: key);

  @override
  State<OptionMoreActionBottomSheet> createState() =>
      _OptionMoreActionBottomSheetState();
}

class _OptionMoreActionBottomSheetState
    extends State<OptionMoreActionBottomSheet> {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(18, 0, 18, 0),
      child: Column(
        children: [
          InkWell(
            onTap: widget.onAddWatchList,
            child: items(
                enabled: widget.enabled,
                context: context,
                imagepath: "assets/add.png",
                title: "Add to Watchlist"),
          ),
          InkWell(
            onTap: widget.onSetAlert,
            child: items(
                enabled: widget.enabled,
                context: context,
                imagepath: "assets/bag.png",
                title: "Add to Basket"),
          ),
          InkWell(
              onTap: () {},
              child: items(
                  enabled: true,
                  context: context,
                  imagepath: "assets/help.png",
                  title: "Help")),
        ],
      ),
    );
  }

  Widget items({
    required BuildContext context,
    required String imagepath,
    required String title,
    required bool enabled,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 14),
      child: Row(
        children: [
          Image.asset(
            imagepath,
            height: 20,
            width: 20,
            color: enabled
                ? customColors().fontPrimary
                : customColors().fontPrimary.withOpacity(.4),
          ),
          const SizedBox(width: 10),
          Text(
            title,
            style: enabled
                ? customTextStyle(
                    fontStyle: FontStyle.BodyL_SemiBold,
                    color: FontColor.FontPrimary)
                : customTextStyle(fontStyle: FontStyle.BodyL_SemiBold).copyWith(
                    color: customColors().fontPrimary.withOpacity(0.4)),
          ),
        ],
      ),
    );
  }
}
