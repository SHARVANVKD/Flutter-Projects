import 'package:flutter/material.dart';

import '../../../theme/styles.dart';

class MoreDataListwidget extends StatefulWidget {
  final List<Map<String, dynamic>> holdingList;
  String header;
  MoreDataListwidget(
      {Key? key, required this.holdingList, required this.header})
      : super(key: key);

  @override
  State<MoreDataListwidget> createState() => _MoreDataListwidgetState();
}

class _MoreDataListwidgetState extends State<MoreDataListwidget> {
  int selectedHolding = 0;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(height: 10),
        // Padding(
        //   padding: const EdgeInsets.all(16.0),
        //   child: Text("Select Tag Color",
        //       style: customTextStyle(
        //           context: context,
        //           fontStyle: FontStyle.HeaderXS_SemiBold,
        //           color: FontColor.FontPrimary)),
        // ),
        // Divider(
        //   height: 0,
        //   thickness: 1,
        //   color: customColors().backgroundTertiary,
        // ),

        for (int index = 0; index < widget.holdingList.length; index++)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        widget.holdingList[index]["name"],
                        style: customTextStyle(
                            fontStyle: FontStyle.BodyL_Regular,
                            color: FontColor.FontSecondary),
                      ),
                      Text(
                        widget.holdingList[index]["value"],
                        style: customTextStyle(
                            fontStyle: FontStyle.BodyL_SemiBold,
                            color: FontColor.FontPrimary),
                      ),
                    ],
                  ),
                ),
                if (index != widget.holdingList.length - 1)
                  Divider(
                    height: 0,
                    thickness: 1,
                    color: customColors().backgroundTertiary,
                  ),
              ],
            ),
          ),
        SizedBox(
          height: 16,
        )
      ],
    );
  }
}
