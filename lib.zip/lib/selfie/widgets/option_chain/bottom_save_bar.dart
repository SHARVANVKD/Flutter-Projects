import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/buttons/BasketButton.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class BottomSaveBar extends StatelessWidget {
  const BottomSaveBar({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        border: Border(
          top: BorderSide(
            color: customColors().backgroundTertiary,
            width: 1,
          ),
        ),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      height: 72,
      child: BasketButton(
        text: "Save",
        bgcolor: customColors().primary,
        textStyle: customTextStyle(
                fontStyle: FontStyle.BodyL_Bold, color: FontColor.FontPrimary)
            .copyWith(color: customColors().backgroundPrimary),
      ),
    );
  }
}
