import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/navigation/navigation.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_option_chain/components/edit_present_bottomsheet.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order_window/order_window_components/order_window_title_component.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/buttons/BasketButton.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/scrollable_bottomsheet/scrollable_bottomsheet.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

import 'bottom_save_bar.dart';

class PresentItem extends StatefulWidget {
  Function(int) radioBtn;
  int groupValue;
  int value;
  String category;
  PresentItem(
      {Key? key,
      required this.groupValue,
      required this.category,
      required this.radioBtn,
      required this.value})
      : super(key: key);

  @override
  State<PresentItem> createState() => _PresentItemState();
}

class _PresentItemState extends State<PresentItem> {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 13),
      child: Row(
        children: [
          CustomRadioButton(
              innerVisible: false,
              value: widget.value,
              groupValue: widget.groupValue,
              noLabel: true,
              onChanged: widget.radioBtn),
          const SizedBox(width: 12),
          Text(
            widget.category,
            style: customTextStyle(fontStyle: FontStyle.BodyL_Regular),
          ),
          const Expanded(child: SizedBox()),
          InkWell(
              onTap: () {
                Navigator.pop(context);
                customBottomSheet(
                    height: .76,
                    maxHeight: .89,
                    context: context,
                    inputWidget: EditPresentBottomSheet(title: widget.category),
                    fixedBottomWidget: BottomSaveBar());
              },
              child: SizedBox(
                  width: 20, height: 20, child: Image.asset('assets/icon.png')))
        ],
      ),
    );
  }
}
