import 'package:flutter/material.dart';
import 'package:just_the_tooltip/just_the_tooltip.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class SelectedPresentItem extends StatelessWidget {
  String itemName;
  Function() selectedMethod;
  SelectedPresentItem(
      {Key? key, required this.itemName, required this.selectedMethod})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Row(
        children: [
          Image.asset('assets/reoder.png'),
          const SizedBox(width: 16),
          Text(
            itemName,
            style: customTextStyle(
                fontStyle: FontStyle.BodyL_Regular,
                color: FontColor.FontPrimary),
          ),
          const SizedBox(width: 8),
          JustTheTooltip(
            backgroundColor: customColors().fontPrimary,
            child: Image.asset('assets/vector_icon.png'),
            content: Padding(
              padding: const EdgeInsets.all(16.0),
              child: SizedBox(
                width: 250,
                height: 100,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Last Traded Price",
                      style: customTextStyle(
                              fontStyle: FontStyle.BodyM_SemiBold,
                              color: FontColor.FontPrimary)
                          .copyWith(color: customColors().backgroundPrimary),
                    ),
                    const SizedBox(height: 12),
                    Text(
                      'LTP or the Last Traded Price is the price from which the next sale of the stocks happens. LTP is essential in determining how the stock prices will fluctuate in the future.',
                      style: customTextStyle(
                              fontStyle: FontStyle.BodyS_Regular,
                              color: FontColor.FontPrimary)
                          .copyWith(color: customColors().backgroundPrimary),
                    ),
                  ],
                ),
              ),
            ),
          ),
          const Expanded(child: SizedBox()),
          InkWell(
              onTap: selectedMethod, child: Image.asset('assets/remove.png')),
        ],
      ),
    );
  }
}
