import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class CompanyDetails extends StatelessWidget {
  const CompanyDetails({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "Company Profile",
            style: customTextStyle(
                fontStyle: FontStyle.HeaderXS_Bold,
                color: FontColor.FontPrimary),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 16),
            child: Text(
              "Tata Consultancy Services Ltd.",
              style: customTextStyle(
                  fontStyle: FontStyle.BodyL_SemiBold,
                  color: FontColor.FontPrimary),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 8),
            child: Text(
              "Tata Consultency Services Limited (TCS) is engaged in providing information technology (IT) services, digital and business solutions.",
              softWrap: true,
              style: customTextStyle(
                  fontStyle: FontStyle.BodyL_Regular,
                  color: FontColor.FontSecondary),
            ),
          ),
        ],
      ),
    );
  }
}
