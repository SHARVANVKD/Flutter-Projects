import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class EmptyCustomCheckBox extends StatefulWidget {
  Function(bool) callback;
  final bool isSelect;
  EmptyCustomCheckBox({Key? key, required this.callback, this.isSelect = false})
      : super(key: key);
  @override
  State<EmptyCustomCheckBox> createState() => _EmptyCustomCheckBoxState();
}

class _EmptyCustomCheckBoxState extends State<EmptyCustomCheckBox> {
  bool isChecked = false;

  ontap() {
    setState(() {
      isChecked ? isChecked = false : isChecked = true;
      widget.callback(isChecked);
    });
  }

  @override
  void initState() {
    super.initState();
    setState(() {
      isChecked = widget.isSelect;
    });
  }

  @override
  Widget build(BuildContext context) {
    return InkWell(
        splashColor: customColors().primary,
        onTap: ontap,
        child: SizedBox(
          height: 24,
          width: 24,
          child: isChecked
              ? Image.asset(
                  "assets/checkedicon.png",
                )
              : Image.asset("assets/emptycheckbox.png",
                  color: customColors().fontSecondary),
        ));
  }
}
