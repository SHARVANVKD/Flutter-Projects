import 'package:bloc/bloc.dart';
import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';

part 'workspace_state.dart';

class WorkSpaceCubit extends Cubit<WorkspaceState> {
  final ServiceLocator serviceLocator;
  WorkSpaceCubit({required this.serviceLocator}) : super(WatchlistState());

  openEditWatchList(BuildContext context, String title) {
    serviceLocator.navigationService.openAllWatchlistPage(context);
  }

  // openMore(BuildContext context) {
  //   serviceLocator.navigationService.openMorePage(context);
  // }

  previous() {
    int pageCount = (state as WatchlistState).pageCount;
    if (pageCount > 1) {
      emit(WatchlistState(pageCount: pageCount - 1));
    }
  }

  next() {
    int pageCount = (state as WatchlistState).pageCount;
    if (pageCount < 3) {
      emit(WatchlistState(pageCount: pageCount + 1));
    }
  }

  openWatclist(){
    emit(WatchlistState());
  }

  openPortfolio(){
    emit(PortfolioState());
  }

  openOrders(){
    emit(OrderState());
  }

  openIdea(){
    emit(IdeaState());
  }

  openMore(){
    emit(MoreState());
  }
}
