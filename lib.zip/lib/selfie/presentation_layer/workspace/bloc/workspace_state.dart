part of 'workspace_cubit.dart';

@immutable
abstract class WorkspaceState {}

class WatchlistState extends WorkspaceState {
  final int pageCount;
  WatchlistState({this.pageCount = 1});
  
}

class PortfolioState extends WorkspaceState {
  PortfolioState();
}

class OrderState extends WorkspaceState {

  OrderState();
  
}
class IdeaState extends WorkspaceState {

  IdeaState();
  
}
class MoreState extends WorkspaceState {
  MoreState();
  
}


