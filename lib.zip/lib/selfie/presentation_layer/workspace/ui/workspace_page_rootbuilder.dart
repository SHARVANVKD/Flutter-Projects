import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_profile/cubit/profile_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/workspace/bloc/workspace_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/scrollable_bottomsheet/cubit/create_watchlist_cubit.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';
import 'workspace_page.dart';

class WorkspacePageRouteBuilder {
  final ServiceLocator _serviceLocator;

  WorkspacePageRouteBuilder(this._serviceLocator);

  Widget call(BuildContext context) {
    return MultiBlocProvider(
        providers: [
          BlocProvider(
              create: (context) =>
                  WorkSpaceCubit(serviceLocator: _serviceLocator)),
          BlocProvider(
              create: (context) =>
                  ProfileCubit()),
        ],
        child: MultiRepositoryProvider(providers: [
          RepositoryProvider.value(value: _serviceLocator.navigationService),
          RepositoryProvider<CubitsLocator>.value(value: _serviceLocator),
        ], child: WorkspacePage(serviceLocator: _serviceLocator,)));
  }
}
