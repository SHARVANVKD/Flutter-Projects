import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/app_page_injectable.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

import '../../../widgets/custom_app_components/appbar/customAppbarInner.dart';
import 'package:selfie_mobile_flutter/app_page_injectable.dart';

class MyAppsPage extends StatelessWidget {
   MyAppsPage({Key? key}) : super(key: key);
  List<Map<String,dynamic>> myGeojitList=[
    {
      "name":"Profit & Loss",
    },
    {"name":"Tax Profit & Loss"},
    {"name":"Pledge"},
    {"name":"FPO"},
    {"name":"Contact Note"}
    ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
          child: SingleChildScrollView(
        child: Column(
          children: [
            CustomAppBarInner(
              title: "My Apps",
              onBackPressed: () {
                context.gNavigationService.back(context);
              },
            ),
            Theme(
              data: ThemeData().copyWith(dividerColor: Colors.transparent),
              child: ExpansionTile(
                childrenPadding: EdgeInsets.only(left: 55),
                leading: Image.asset("assets/icon_mygeojit.png"),
                title: Text(
                  "My Geojit",
                  style: customTextStyle(
                      fontStyle: FontStyle.BodyL_SemiBold,
                      color: FontColor.FontPrimary),
                ),
                subtitle: Text(
                  "Lorem ipsum dolor sit amet, consectetur adipiscing elit. In ultricies sed eleifend.",
                  style: customTextStyle(
                      fontStyle: FontStyle.BodyM_Regular,
                      color: FontColor.FontSecondary),
                ),
                children: List.generate(myGeojitList.length, (index) => 
                ListTile(
                    leading: Text(
                      myGeojitList[index]["name"],
                      style: customTextStyle(
                          fontStyle: FontStyle.BodyL_SemiBold,
                          color: FontColor.FontPrimary),
                    ),
                    trailing: Icon(Icons.chevron_right_rounded,color: customColors().fontPrimary),
                  ),
                ),
              ),
            ),
            SizedBox(
              height: 20,
            ),
            Divider(
                height: 1,
                color: customColors().fontTertiary,
                indent: 20,
                endIndent: 18),
            SizedBox(
              height: 20,
            ),
            Theme(
                data: ThemeData().copyWith(dividerColor: Colors.transparent),
                child: ListTile(
                  leading: Padding(
                    padding: const EdgeInsets.only(left: 6, top: 10),
                    child: Image.asset("assets/smartfolio_icon.png"),
                  ),
                  title: Text(
                    "Smartfolio",
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyL_SemiBold,
                        color: FontColor.FontPrimary),
                  ),
                  subtitle: Text(
                    "Smartfolios provides the opportunity to harvest the benefits of direct investments\nin equity.",
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyM_Regular,
                        color: FontColor.FontSecondary),
                  ),
                  trailing: Icon(Icons.chevron_right_rounded),
                )),
            SizedBox(
              height: 20,
            ),
            Divider(
                height: 1,
                color: customColors().fontTertiary,
                indent: 20,
                endIndent: 18),
            SizedBox(
              height: 20,
            ),
            Theme(
                data: ThemeData().copyWith(dividerColor: Colors.transparent),
                child: ListTile(
                  leading: Image.asset("assets/fund_genie.png"),
                  title: Text(
                    "Fund Genie",
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyL_SemiBold,
                        color: FontColor.FontPrimary),
                  ),
                  subtitle: Text(
                    "Lorem ipsum dolor sit amet, consectetur adipiscing elit. In ultricies sed eleifend.",
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyM_Regular,
                        color: FontColor.FontSecondary),
                  ),
                  trailing: Icon(Icons.chevron_right_rounded),
                )),
            SizedBox(
              height: 20,
            ),
            Divider(
                height: 1,
                color: customColors().fontTertiary,
                indent: 20,
                endIndent: 18),
            SizedBox(
              height: 20,
            ),
            Theme(
                data: ThemeData().copyWith(dividerColor: Colors.transparent),
                child: ListTile(
                  onTap: () {
                    context.gNavigationService.openIpoPage(context);
                  },
                  leading: Image.asset("assets/fund_genie.png"),
                  title: Text(
                    "Initial Public Offering (IPO)",
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyL_SemiBold,
                        color: FontColor.FontPrimary),
                  ),
                  subtitle: Text(
                    "Lorem ipsum dolor sit amet, consectetur adipiscing elit. In ultricies sed eleifend.",
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyM_Regular,
                        color: FontColor.FontSecondary),
                  ),
                  trailing: Icon(Icons.chevron_right_rounded),
                )),
            SizedBox(
              height: 20,
            ),
            Divider(
                height: 1,
                color: customColors().fontTertiary,
                indent: 20,
                endIndent: 18),
            SizedBox(
              height: 20,
            ),
            Theme(
                data: ThemeData().copyWith(dividerColor: Colors.transparent),
                child: ListTile(
                  leading: Image.asset("assets/fund_genie.png"),
                  title: Text(
                    "Bonds",
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyL_SemiBold,
                        color: FontColor.FontPrimary),
                  ),
                  subtitle: Text(
                    "Lorem ipsum dolor sit amet, consectetur adipiscing elit. In ultricies sed eleifend.",
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyM_Regular,
                        color: FontColor.FontSecondary),
                  ),
                  trailing: Icon(Icons.chevron_right_rounded),
                )),
            SizedBox(
              height: 20,
            ),
            Divider(
                height: 1,
                color: customColors().fontTertiary,
                indent: 20,
                endIndent: 18),
          ],
        ),
      )),
    );
  }
}
