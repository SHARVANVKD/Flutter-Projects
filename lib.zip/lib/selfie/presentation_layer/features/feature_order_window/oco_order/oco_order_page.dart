import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/app_page_injectable.dart';
import 'package:selfie_mobile_flutter/constants/enums.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order_window/order_window_components/order_window_time_condition.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/appbar/customAppbarInner.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/buttons/BasketButton.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/buttons/custom_swipe_button.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/textfields/custom_text_form_field.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/order_book/custom_bottom_strip.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/message_tile.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class OCOOrderPage extends StatefulWidget {
  final Map<String, dynamic> data;
  const OCOOrderPage({Key? key, required this.data}) : super(key: key);

  @override
  State<OCOOrderPage> createState() => _OCOOrderPageState();
}

class _OCOOrderPageState extends State<OCOOrderPage> {
  bool isBuy = false;

  int timeCondition = 0;
  int condition = 0;

  int _pageCount = 1;
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
          preferredSize: const Size.fromHeight(0.0),
          child: AppBar(
            elevation: 0,
            backgroundColor: customColors().backgroundPrimary,
          )),
      body: GestureDetector(
        onTap: (() {
          FocusManager.instance.primaryFocus?.unfocus();
        }),
        child: Column(
          children: [
            CustomAppBarInner(
                title: _pageCount == 1 ? "OCO Order" : "Modify OCO Order",
                onBackPressed: () {
                  context.gNavigationService.back(context);
                }),
            Expanded(
              child: Stack(
                children: [
                  SingleChildScrollView(
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Text(
                              "${widget.data["symbol"]} ${widget.data["qty"]} @ ₹${widget.data["price"]}",
                              style: customTextStyle(
                                  fontStyle: FontStyle.HeaderXS_Bold,
                                  color: FontColor.Success)),
                          const SizedBox(
                            height: 16,
                          ),
                          Row(
                            children: [
                              Expanded(
                                  child: CustomTextFormField(
                                controller: TextEditingController(text: "100"),
                                fieldName: "Quantity",
                                hintText: "0",
                              )),
                              const SizedBox(
                                width: 16,
                              ),
                              Expanded(
                                  child: CustomTextFormField(
                                controller: TextEditingController(),
                                fieldName: "Price",
                                hintText: "00.00",
                                enabled: false,
                              )),
                            ],
                          ),
                          const SizedBox(
                            height: 24,
                          ),
                          RichText(
                            text: TextSpan(
                                text: 'OCO Order ',
                                style: customTextStyle(
                                    fontStyle: FontStyle.BodyL_Bold,
                                    color: FontColor.FontPrimary),
                                children: <TextSpan>[
                                  TextSpan(
                                      text: isBuy ? "(Buy)" : "(Sell)",
                                      style: customTextStyle(
                                          fontStyle: FontStyle.BodyL_Bold,
                                          color: isBuy
                                              ? FontColor.Success
                                              : FontColor.Danger)),
                                ]),
                          ),
                          const SizedBox(
                            height: 16,
                          ),
                          Container(
                            decoration: BoxDecoration(
                              border: Border.all(
                                  width: 1,
                                  color: customColors().backgroundTertiary),
                              borderRadius: BorderRadius.circular(4.0),
                            ),
                            padding: const EdgeInsets.symmetric(
                                vertical: 14, horizontal: 16),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  "Product Type",
                                  style: customTextStyle(
                                      fontStyle: FontStyle.BodyL_SemiBold,
                                      color: FontColor.FontPrimary),
                                ),
                                Text(
                                  "Cash",
                                  style: customTextStyle(
                                      fontStyle: FontStyle.BodyL_Bold,
                                      color: FontColor.FontPrimary),
                                )
                              ],
                            ),
                          ),
                          const SizedBox(
                            height: 16,
                          ),
                          Row(
                            children: [
                              Expanded(
                                  child: CustomTextFormField(
                                controller: TextEditingController(text: "0"),
                                fieldName: "Target Price",
                                hintText: "0",
                                topEndWidget: Text("+0.05",
                                    style: customTextStyle(
                                        fontStyle: FontStyle.BodyM_Regular,
                                        color: FontColor.FontSecondary)),
                                bottomStartWidget: RichText(
                                  text: TextSpan(
                                      text: 'Apox Profit: ',
                                      style: customTextStyle(
                                          fontStyle: FontStyle.BodyM_Regular,
                                          color: FontColor.FontSecondary),
                                      children: <TextSpan>[
                                        TextSpan(
                                            text: '+20,000',
                                            style: customTextStyle(
                                                fontStyle:
                                                    FontStyle.BodyM_Regular,
                                                color: FontColor.Success))
                                      ]),
                                ),
                              )),
                              const SizedBox(width: 16),
                              Expanded(
                                  child: CustomTextFormField(
                                controller:
                                    TextEditingController(text: "00.00"),
                                fieldName: "Stoploss Price",
                                hintText: "00.00",
                                topEndWidget: Text("-0.03",
                                    style: customTextStyle(
                                        fontStyle: FontStyle.BodyM_Regular,
                                        color: FontColor.FontSecondary)),
                                bottomStartWidget: RichText(
                                  text: TextSpan(
                                      text: 'Apox Loss: ',
                                      style: customTextStyle(
                                          fontStyle: FontStyle.BodyM_Regular,
                                          color: FontColor.FontSecondary),
                                      children: <TextSpan>[
                                        TextSpan(
                                            text: '-1,000',
                                            style: customTextStyle(
                                                fontStyle:
                                                    FontStyle.BodyM_Regular,
                                                color: FontColor.Danger))
                                      ]),
                                ),
                              )),
                            ],
                          ),
                          const SizedBox(
                            height: 16,
                          ),
                          OrderWindowTimeCondition(
                            timeCondition: timeCondition,
                            condition: condition,
                            onTimeConditionChange: (int val) {
                              setState(() {
                                timeCondition = val;
                              });
                            },
                            onConditionChange: (int val) {
                              setState(() {
                                condition = val;
                              });
                            },
                          ),
                        ],
                      ),
                    ),
                  ),
                  Align(
                      alignment: Alignment.bottomCenter,
                      child: skipButton(context, "${_pageCount}/2", () {
                        int count = _pageCount - 1;
                        if (count >= 1) {
                          setState(() {
                            _pageCount = count;
                          });
                        }
                      }, () {
                        int count = _pageCount + 1;
                        if (count <= 2) {
                          setState(() {
                            _pageCount = count;
                          });
                        }
                      })),
                ],
              ),
            ),
            const CustomBottomStrip(
              fundOrMargin: FundOrMargin.MARGIN,
              required: "15,000",
              available: "21,000",
              refreshIcon: true,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
              child: BasketButton(
                textStyle: customTextStyle(
                    fontStyle: FontStyle.BodyL_SemiBold,
                    color: FontColor.White),
                text: "Send order",
                bgcolor: isBuy ? customColors().success : customColors().danger,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
