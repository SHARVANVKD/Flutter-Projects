import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';
import 'order_window_page.dart';

class OrderWindowPageRouteBuilder {
  final ServiceLocator _serviceLocator;
  final Map<String, dynamic> data;

  OrderWindowPageRouteBuilder(this._serviceLocator, this.data);

  Widget call(BuildContext context) {
    return MultiRepositoryProvider(providers: [
      RepositoryProvider.value(value: _serviceLocator.tradingApi),
    ], child: OrderWindowPage(data: data,));
  }
}
