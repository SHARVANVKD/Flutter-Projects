import 'package:flutter/material.dart';

import 'package:selfie_mobile_flutter/app_page_injectable.dart';
import 'package:selfie_mobile_flutter/constants/enums.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order_window/order_window_components/order_window_bo_component.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order_window/order_window_components/order_window_buysell_component.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order_window/order_window_components/order_window_product_type.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order_window/order_window_components/order_window_tab_component.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order_window/order_window_components/order_window_time_condition.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order_window/order_window_components/order_window_title_component.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/appbar/customAppbarInner.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/buttons/BasketButton.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/default_order_settings/default_order_settings_values.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/order_book/custom_bottom_strip.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/message_tile.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/stock/empty_custom_checkbox/empty_custom_checkbox.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

import '../../../../widgets/custom_app_components/textfields/custom_text_form_field.dart';

enum OrderType {
  CASH,
  FO,
  SPREAD,
}

class OrderWindowPage extends StatefulWidget {
  final Map<String, dynamic> data;
  const OrderWindowPage({Key? key, required this.data}) : super(key: key);

  @override
  State<OrderWindowPage> createState() => _OrderWindowPageState();
}

class _OrderWindowPageState extends State<OrderWindowPage> {
  bool isBuy = true;
  bool BO_order = false;
  bool stopLoss = false;
  OrderType orderType = OrderType.CASH;
  double BSP = 278.95;
  double BBP = 278.95;

  double NSE_price = 278.95;
  double BSE_price = 278.92;
  int _productType = product;
  int _timeCondition = timeCondition;
  int _condition = condition;
  int _pageCount = 1;
  String title = "TATAPOWER";

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    setState(() {
      orderType = widget.data["type"] == "FO"
          ? OrderType.FO
          : widget.data["type"] == "Spread"
              ? OrderType.SPREAD
              : orderType;
      isBuy = widget.data["order"] == "buy";
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
          preferredSize: const Size.fromHeight(0.0),
          child: AppBar(
            elevation: 0,
            backgroundColor: customColors().backgroundPrimary,
          )),
      body: GestureDetector(
        onTap: (() {
          FocusManager.instance.primaryFocus?.unfocus();
        }),
        child: Column(
          children: [
            CustomAppBarInner(
                title: title,
                extraWidget: orderType == OrderType.CASH
                    ? OrderWindowTitleComponent(
                        NSE_price: NSE_price,
                        BSE_price: BSE_price,
                        onChanged: (String value) {
                          setState(() {
                            if (value == "NSE") {
                              BSP = BBP = NSE_price;
                            } else {
                              BSP = BBP = BSE_price;
                            }
                          });
                        },
                      )
                    : RichText(
                        text: TextSpan(
                            text: "₹ ",
                            style: customTextStyle(
                                fontStyle: FontStyle.BodyL_SemiBold,
                                color: FontColor.FontSecondary),
                            children: <TextSpan>[
                              TextSpan(
                                  text: NSE_price.toString(),
                                  style: customTextStyle(
                                      fontStyle: FontStyle.BodyM_SemiBold,
                                      color: FontColor.FontSecondary))
                            ]),
                      ),
                endIcon: EndIcon.Settings,
                onEndIconPressed: () {
                  context.gNavigationService
                      .openDefaultOrderSettingsPage(context);
                },
                onBackPressed: () {
                  context.gNavigationService.back(context);
                }),
            Expanded(
              child: Stack(
                children: [
                  SingleChildScrollView(
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16.0),
                      child: Column(
                        children: [
                          const SizedBox(
                            height: 17,
                          ),
                          OrderWindowBuySellSwitch(
                              isBuy: isBuy,
                              BSP: BSP,
                              BBP: BBP,
                              onChanged: (bool value) {
                                setState(() {
                                  isBuy = value;
                                });
                              }),
                          if (orderType == OrderType.SPREAD)
                            Padding(
                                padding: const EdgeInsets.only(top: 6.0),
                                child: SpreadData(spreadData: const {
                                  "title": "INFY 22JAN FUT",
                                  "buy": 222.12,
                                  "sell": 123.12,
                                })),
                          const SizedBox(
                            height: 24,
                          ),
                          if (orderType == OrderType.FO)
                            const OrderWindowTabContainer(
                              orderType: OrderTypes.FO,
                              lotsQuantity: "100,000",
                            ),
                          if (orderType != OrderType.FO)
                            const OrderWindowTabContainer(),
                          const SizedBox(
                            height: 16,
                          ),
                          if (orderType != OrderType.SPREAD)
                            Column(
                              children: [
                                OrderWindowBOComponent(
                                  isBuy: isBuy,
                                  BO_Order: BO_order,
                                  stopLoss: stopLoss,
                                  onTapBO: () {
                                    setState(() {
                                      BO_order = !BO_order;
                                    });
                                  },
                                  onTapStoploss: () {
                                    setState(() {
                                      stopLoss = !stopLoss;
                                    });
                                  },
                                ),
                                const SizedBox(
                                  height: 16,
                                ),
                              ],
                            ),
                          OrderWindowProduct(
                            selected: _productType,
                            onProductUpdate: (int product) {
                              setState(() {
                                _productType = product;
                              });
                            },
                          ),
                          const SizedBox(
                            height: 16,
                          ),
                          OrderWindowTimeCondition(
                            timeCondition: _timeCondition,
                            condition: _condition,
                            onTimeConditionChange: (int val) {
                              timeCondition = val;
                              setState(() {
                                _timeCondition = val;
                              });
                            },
                            onConditionChange: (int val) {
                              condition = val;
                              setState(() {
                                _condition = val;
                              });
                            },
                          ),
                          const SizedBox(
                            height: 16,
                          ),
                          CustomTextFormField(
                            controller: TextEditingController(),
                            fieldName: "Disclosed Quantity",
                            hintText: "0",
                          ),
                          const SizedBox(
                            height: 16,
                          ),
                          if (orderType == OrderType.FO)
                            Column(
                              children: [
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Row(
                                      children: [
                                        Text(
                                          "Allow split orders",
                                          style: customTextStyle(
                                              fontStyle:
                                                  FontStyle.BodyL_Regular,
                                              color: FontColor.FontPrimary),
                                        ),
                                        const SizedBox(
                                          width: 7.33,
                                        ),
                                        Image.asset(
                                          "assets/info.png",
                                          color: customColors().fontPrimary,
                                          height: 13.33,
                                          width: 13.33,
                                        )
                                      ],
                                    ),
                                    EmptyCustomCheckBox(
                                      callback: (bool) {},
                                    )
                                  ],
                                ),
                                const SizedBox(
                                  height: 16,
                                ),
                              ],
                            ),
                        ],
                      ),
                    ),
                  ),
                  Align(
                      alignment: Alignment.bottomCenter,
                      child: skipButton(context, "${_pageCount}/3", () {
                        int count = _pageCount - 1;
                        if (count >= 1) {
                          setState(() {
                            orderType = count == 1
                                ? OrderType.CASH
                                : count == 2
                                    ? OrderType.FO
                                    : OrderType.SPREAD;
                            _pageCount = count;
                            _pageCount == 1
                                ? title = "TATAPOWER"
                                : _pageCount == 2
                                    ? title = "AMBUJACEMENT FUT"
                                    : title = "INFY 22DEC - INFY 22JAN FUT";
                          });
                        }
                      }, () {
                        int count = _pageCount + 1;
                        if (count <= 3) {
                          setState(() {
                            orderType = count == 1
                                ? OrderType.CASH
                                : count == 2
                                    ? OrderType.FO
                                    : OrderType.SPREAD;
                            _pageCount = count;
                            _pageCount == 1
                                ? title = "TATAPOWER"
                                : _pageCount == 2
                                    ? title = "AMBUJACEMENT FUT"
                                    : title = "INFY 22DEC - INFY 22JAN FUT";
                          });
                        }
                      })),
                ],
              ),
            ),
            const CustomBottomStrip(
              fundOrMargin: FundOrMargin.MARGIN,
              required: "15,000",
              available: "21,000",
              refreshIcon: true,
            ),
            Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                child: BasketButton(
                  textStyle: customTextStyle(
                      fontStyle: FontStyle.BodyL_SemiBold,
                      color: FontColor.White),
                  text: "Send order",
                  bgcolor:
                      isBuy ? customColors().success : customColors().danger,
                  onpress: () {
                    context.gNavigationService.openReviewOrder(context);
                  },
                )),
          ],
        ),
      ),
    );
  }
}

/*

  SwipeOnOffButton(
                  width: MediaQuery.of(context).size.width - 32,
                  startText: "Swipe to send order",
                  endText: "order placed",
                  backgroundColor:
                      
                  foregroundColor: isBuy ? green600 : red600,
                  onConfirmation: () {
                    context.gNavigationService.OpenReviewOrder(context);
                  },
                ),

*/

class SpreadData extends StatelessWidget {
  final Map<String, dynamic> spreadData;
  const SpreadData({
    Key? key,
    required this.spreadData,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              spreadData["title"],
              style: customTextStyle(
                  fontStyle: FontStyle.BodyM_Bold, color: FontColor.Success),
            ),
            const SizedBox(
              height: 4,
            ),
            RichText(
              text: TextSpan(
                  text: "₹ ",
                  style: customTextStyle(
                      fontStyle: FontStyle.BodyM_SemiBold,
                      color: FontColor.Success),
                  children: <TextSpan>[
                    TextSpan(
                        text: spreadData["buy"].toString(),
                        style: customTextStyle(
                            fontStyle: FontStyle.BodyS_SemiBold,
                            color: FontColor.Success))
                  ]),
            ),
          ],
        ),
        Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Text(
              spreadData["title"],
              style: customTextStyle(
                  fontStyle: FontStyle.BodyM_Bold, color: FontColor.Danger),
            ),
            const SizedBox(
              height: 4,
            ),
            RichText(
              text: TextSpan(
                  text: "₹ ",
                  style: customTextStyle(
                      fontStyle: FontStyle.BodyM_SemiBold,
                      color: FontColor.Danger),
                  children: <TextSpan>[
                    TextSpan(
                        text: spreadData["sell"].toString(),
                        style: customTextStyle(
                            fontStyle: FontStyle.BodyS_SemiBold,
                            color: FontColor.Danger))
                  ]),
            ),
          ],
        ),
      ],
    );
  }
}
