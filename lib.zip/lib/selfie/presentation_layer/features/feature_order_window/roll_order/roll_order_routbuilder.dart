import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';
import 'roll_order_page.dart';

class RollOrderPageRouteBuilder {
  final ServiceLocator _serviceLocator;
  final Map<String, dynamic> data;

  RollOrderPageRouteBuilder(this._serviceLocator, this.data);

  Widget call(BuildContext context) {
    return MultiRepositoryProvider(providers: [
      RepositoryProvider.value(value: _serviceLocator.tradingApi),
    ], child: RollOrderPage(data: data,));
  }
}
