import 'package:flutter/material.dart';

import 'package:selfie_mobile_flutter/app_page_injectable.dart';
import 'package:selfie_mobile_flutter/constants/enums.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order_window/roll_order/roll__order_components.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/appbar/customAppbarInner.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/buttons/BasketButton.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/order_book/custom_bottom_strip.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class RollOrderPage extends StatefulWidget {
  final Map<String, dynamic> data;
  const RollOrderPage({Key? key, required this.data}) : super(key: key);

  @override
  State<RollOrderPage> createState() => _RollOrderPageState();
}

class _RollOrderPageState extends State<RollOrderPage> {
  bool isBuy = true;
  double BSP = 278.95;
  double BBP = 278.95;

  double NSE_price = 278.95;
  double BSE_price = 278.92;
  String timeCondition = getTimeConditionString(TimeCondition.conditional);
  String condition = getConditionString(Condition.greaterThan);
  bool leg1Buy = false;
  int leg1LotsCount = 1;
  int leg1ProdType = 1;

  bool leg2Buy = true;
  int leg2LotsCount = 1;
  int leg2ProdType = 1;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
          preferredSize: const Size.fromHeight(0.0),
          child: AppBar(
            elevation: 0,
            backgroundColor: customColors().backgroundPrimary,
          )),
      body: GestureDetector(
        onTap: (() {
          FocusManager.instance.primaryFocus?.unfocus();
        }),
        child: Column(
          children: [
            CustomAppBarInner(
                title: "Roll Order",
                onBackPressed: () {
                  context.gNavigationService.back(context);
                }),
            Expanded(
              child: SingleChildScrollView(
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16.0),
                  child: Column(
                    children: [
                      OrderContainerTitle(
                        tagName: "LEG 1",
                        isBuy: leg1Buy,
                        prodType: leg1ProdType,
                        onProdTypeChange: (int val) {
                          setState(() {
                            leg1ProdType = val;
                          });
                        },
                      ),
                      const SizedBox(
                        height: 16,
                      ),
                      OrderContainerTitle(
                        tagName: "LEG 2",
                        isBuy: leg2Buy,
                        prodType: leg2ProdType,
                        onProdTypeChange: (int val) {
                          setState(() {
                            leg2ProdType = val;
                          });
                        },
                      ),
                      const SizedBox(
                        height: 16,
                      ),
                    ],
                  ),
                ),
              ),
            ),
            const CustomBottomStrip(
              fundOrMargin: FundOrMargin.MARGIN,
              required: "15,000",
              available: "21,000",
              refreshIcon: true,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
              child: BasketButton(
                textStyle: customTextStyle(
                    fontStyle: FontStyle.BodyL_SemiBold,
                    color: FontColor.White),
                text: "Review and Send",
                bgcolor: isBuy ? customColors().success : customColors().danger,
                onpress: () {
                  context.gNavigationService.openRollOrderReview(context);
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
