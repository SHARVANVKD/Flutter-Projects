import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/scrollable_bottomsheet/scrollable_bottomsheet.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/default_order_settings/default_order_settings_values.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/default_order_settings/order_window_settings_bottom_sheet.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class OrderWindowProduct extends StatefulWidget {
  final int selected;
  final Function(int) onProductUpdate;
  OrderWindowProduct(
      {Key? key, required this.selected, required this.onProductUpdate})
      : super(key: key);

  @override
  State<OrderWindowProduct> createState() => _OrderWindowProductState();
}

class _OrderWindowProductState extends State<OrderWindowProduct> {
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => customShowModalBottomSheet(
          context: context,
          inputWidget: OrderSettingsSheetComponent(
              orderSettingsSheetType: OrderSettingsSheetType.PRODUCT,
              selected: widget.selected,
              onChanged: widget.onProductUpdate,
              list: productSettingslist)),
      child: Container(
        decoration: BoxDecoration(
            border:
                Border.all(width: 1, color: customColors().backgroundTertiary),
            borderRadius: BorderRadius.circular(4.0)),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 14.0),
          child: Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    "Product Type",
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyL_SemiBold,
                        color: FontColor.FontPrimary),
                  ),
                  InkWell(
                    onTap: () {
                      customShowModalBottomSheet(
                          context: context,
                          inputWidget: OrderSettingsSheetComponent(
                              orderSettingsSheetType:
                                  OrderSettingsSheetType.PRODUCT,
                              selected: widget.selected,
                              onChanged: widget.onProductUpdate,
                              list: productSettingslist));
                    },
                    child: Row(
                      children: [
                        Text(
                          productSettingslist[widget.selected]["name"] ??
                              "Cash",
                          style: customTextStyle(
                              fontStyle: FontStyle.BodyL_Bold,
                              color: FontColor.Primary),
                        ),
                        const SizedBox(
                          width: 11,
                        ),
                        Image.asset("assets/down_arrow.png"),
                      ],
                    ),
                  )
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
