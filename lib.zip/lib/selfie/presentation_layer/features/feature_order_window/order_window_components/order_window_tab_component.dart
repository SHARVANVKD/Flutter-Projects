import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/textfields/custom_text_form_field.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/custom_top_tab.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

enum OrderTypes { FO, Cash }

class OrderWindowTabContainer extends StatefulWidget {
  final OrderTypes orderType;
  final String lotsQuantity;
  const OrderWindowTabContainer(
      {Key? key, this.orderType = OrderTypes.Cash, this.lotsQuantity = "0"})
      : super(key: key);

  @override
  State<OrderWindowTabContainer> createState() =>
      _OrderWindowTabContainerState();
}

class _OrderWindowTabContainerState extends State<OrderWindowTabContainer> {
  List<String> orderWindowTabList = ["Market", "Limit", "SL-Lmt", "SL-Mkt"];
  int orderTabIndex = 0;
  TextEditingController quantityController = TextEditingController(text: "100");
  TextEditingController priceController = TextEditingController();
  TextEditingController triggerPriceController = TextEditingController();
  @override
  Widget build(BuildContext context) {
    double width = MediaQuery.of(context).size.width;
    return Container(
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(4.0),
          border: Border.all(color: customColors().backgroundTertiary)),
      child: Column(
        children: [
          DefaultTabController(
            length: orderWindowTabList.length,
            child: TabBar(
              labelStyle: customTextStyle(
                  fontStyle: FontStyle.BodyL_SemiBold,
                  color: FontColor.Primary),
              unselectedLabelStyle: customTextStyle(
                  fontStyle: FontStyle.BodyL_Regular,
                  color: FontColor.FontSecondary),
              unselectedLabelColor: customColors().fontSecondary,
              labelColor: customColors().primary,
              indicatorColor: customColors().primary,
              indicatorSize: TabBarIndicatorSize.label,
              onTap: (value) {
                setState(() {
                  orderTabIndex = value;
                });
              },
              tabs: [for (var item in orderWindowTabList) Tab(text: item)],
            ),
          ),
          Container(
            height: 1,
            color: customColors().backgroundTertiary,
          ),
          const SizedBox(
            height: 16,
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: Column(
              children: [
                if (orderTabIndex == 0)
                  Row(
                    children: [
                      Expanded(
                          child: CustomTextFormField(
                        controller: quantityController,
                        fieldName: widget.orderType == OrderTypes.Cash
                            ? "Quantity"
                            : "Lots",
                        hintText: "0",
                        topEndWidget: widget.orderType == OrderTypes.Cash
                            ? Container()
                            : Text(
                                "Qty: ${widget.lotsQuantity}",
                                style: customTextStyle(
                                    fontStyle: FontStyle.BodyL_Regular,
                                    color: FontColor.FontSecondary),
                              ),
                      )),
                      const SizedBox(width: 16),
                      Expanded(
                          child: CustomTextFormField(
                        controller: priceController,
                        fieldName: "Price",
                        hintText: "00.00",
                        enabled: false,
                      )),
                    ],
                  ),
                if (orderTabIndex == 1)
                  Row(
                    children: [
                      Expanded(
                        child: CustomTextFormField(
                            controller: quantityController,
                            fieldName: widget.orderType == OrderTypes.Cash
                                ? "Quantity"
                                : "Lots",
                            hintText: "0",
                            topEndWidget: widget.orderType == OrderTypes.Cash
                                ? Container()
                                : Text("Qty: ${widget.lotsQuantity}",
                                    style: customTextStyle(
                                        fontStyle: FontStyle.BodyL_Regular,
                                        color: FontColor.FontSecondary))),
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                          child: CustomTextFormField(
                        controller: priceController,
                        fieldName: "Price",
                        hintText: "00.00",
                      )),
                    ],
                  ),
                if (orderTabIndex == 2)
                  Column(
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: CustomTextFormField(
                                controller: quantityController,
                                fieldName: widget.orderType == OrderTypes.Cash
                                    ? "Quantity"
                                    : "Lots",
                                hintText: "0",
                                topEndWidget: widget.orderType ==
                                        OrderTypes.Cash
                                    ? Container()
                                    : Text(
                                        "Qty: ${widget.lotsQuantity}",
                                        style: customTextStyle(
                                            fontStyle: FontStyle.BodyL_Regular,
                                            color: FontColor.FontSecondary),
                                      )),
                          ),
                          const SizedBox(width: 16),
                          Expanded(
                            child: CustomTextFormField(
                              controller: priceController,
                              fieldName: "Price",
                              hintText: "00.00",
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(
                        height: 16.0,
                      ),
                      Row(
                        children: [
                          Expanded(
                            child: Container(),
                          ),
                          const SizedBox(width: 16),
                          Expanded(
                              child: CustomTextFormField(
                            controller: triggerPriceController,
                            fieldName: "Triggered Price",
                            hintText: "00.00",
                          )),
                        ],
                      ),
                    ],
                  ),
                if (orderTabIndex == 3)
                  Column(
                    children: [
                      Row(
                        children: [
                          Expanded(
                              child: CustomTextFormField(
                            controller: quantityController,
                            fieldName: widget.orderType == OrderTypes.Cash
                                ? "Quantity"
                                : "Lots",
                            hintText: "0",
                            topEndWidget: widget.orderType == OrderTypes.Cash
                                ? Container()
                                : Text(
                                    "Qty: ${widget.lotsQuantity}",
                                    style: customTextStyle(
                                        fontStyle: FontStyle.BodyL_Regular,
                                        color: FontColor.FontSecondary),
                                  ),
                          )),
                          const SizedBox(width: 16),
                          Expanded(
                              child: CustomTextFormField(
                            controller: priceController,
                            fieldName: "Price",
                            hintText: "00.00",
                            enabled: false,
                          )),
                        ],
                      ),
                      const SizedBox(
                        height: 16.0,
                      ),
                      Row(
                        children: [
                          Expanded(
                            child: Container(),
                          ),
                          const SizedBox(width: 16),
                          Expanded(
                              child: CustomTextFormField(
                            controller: triggerPriceController,
                            fieldName: "Triggered Price",
                            hintText: "00.00",
                          )),
                        ],
                      ),
                    ],
                  ),
              ],
            ),
          ),
          const SizedBox(
            height: 16,
          ),
        ],
      ),
    );
  }
}
