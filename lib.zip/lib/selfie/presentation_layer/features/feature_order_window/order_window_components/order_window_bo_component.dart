import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/textfields/custom_text_form_field.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class OrderWindowBOComponent extends StatelessWidget {
  final isBuy;
  final BO_Order;
  final stopLoss;
  final Function() onTapBO;
  final Function() onTapStoploss;

  OrderWindowBOComponent({
    Key? key, 
    this.isBuy = true, 
    this.BO_Order = false, 
    this.stopLoss = false, 
    required this.onTapBO, 
    required this.onTapStoploss,
  }) : super(key: key);
  TextEditingController targetPrice = TextEditingController(text: "0");
  TextEditingController stoplossPrice = TextEditingController(text: "00.00");
  TextEditingController trailCount = TextEditingController(text: "100");

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
          border:
              Border.all(width: 1, color: customColors().backgroundTertiary),
          borderRadius: BorderRadius.circular(4.0)),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 14.0),
        child: Column(
          children: [
            InkWell(
              splashColor: transparent,
              highlightColor: transparent,
              onTap: onTapBO,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(children: [
                    Text(
                      "Bracket Order ",
                      style: customTextStyle(
                          fontStyle: FontStyle.BodyL_SemiBold,
                          color: FontColor.FontPrimary),
                    ),
                    if (BO_Order)
                      isBuy
                          ? Text(
                              "(Sell)",
                              style: customTextStyle(
                                  fontStyle: FontStyle.BodyL_SemiBold,
                                  color: FontColor.Danger),
                            )
                          : Text(
                              "(Buy)",
                              style: customTextStyle(
                                  fontStyle: FontStyle.BodyL_SemiBold,
                                  color: FontColor.Success),
                            ),
                  ]),
                  SizedBox(
                    height: 20,
                    width: 35,
                    child: Switch(
                      value: BO_Order,
                      onChanged: (bool val) {
                        onTapBO();
                      },
                      activeColor: customColors().primary,
                      inactiveTrackColor: customColors().backgroundTertiary,
                      activeTrackColor: customColors().backgroundTertiary,
                    ),
                  ),
                ],
              ),
            ),
            if (BO_Order)
              Column(
                children: [
                  Container(
                    margin: const EdgeInsets.only(top: 14.0, bottom: 16.0),
                    height: 1,
                    color: customColors().backgroundTertiary,
                  ),
                  Row(
                    children: [
                      Expanded(
                          child: CustomTextFormField(
                        controller: targetPrice,
                        fieldName: "Target Price",
                        hintText: "0",
                        topEndWidget: Text("+0.05%",
                            style: customTextStyle(
                                fontStyle: FontStyle.BodyM_Regular,
                                color: FontColor.FontSecondary)),
                        bottomStartWidget: RichText(
                          text: TextSpan(
                              text: 'Apox Profit: ',
                              style: customTextStyle(
                                  fontStyle: FontStyle.BodyM_Regular,
                                  color: FontColor.FontSecondary),
                              children: <TextSpan>[
                                TextSpan(
                                    text: '+20,000',
                                    style: customTextStyle(
                                        fontStyle: FontStyle.BodyM_Regular,
                                        color: FontColor.Success))
                              ]),
                        ),
                      )),
                      const SizedBox(width: 16),
                      Expanded(
                          child: CustomTextFormField(
                        controller: stoplossPrice,
                        fieldName: "Stoploss Price",
                        hintText: "00.00",
                        topEndWidget: Text("-0.05%",
                            style: customTextStyle(
                                fontStyle: FontStyle.BodyM_Regular,
                                color: FontColor.FontSecondary)),
                        bottomStartWidget: RichText(
                          text: TextSpan(
                              text: 'Apox Loss: ',
                              style: customTextStyle(
                                  fontStyle: FontStyle.BodyM_Regular,
                                  color: FontColor.FontSecondary),
                              children: <TextSpan>[
                                TextSpan(
                                    text: '-1,000',
                                    style: customTextStyle(
                                        fontStyle: FontStyle.BodyM_Regular,
                                        color: FontColor.Danger))
                              ]),
                        ),
                      )),
                    ],
                  ),
                  Container(
                    margin: const EdgeInsets.only(top: 16.0, bottom: 14.0),
                    height: 1,
                    color: customColors().backgroundTertiary,
                  ),
                  InkWell(
                    splashColor: transparent,
                    highlightColor: transparent,
                    onTap: onTapStoploss,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          "Trailing Stoploss",
                          style: customTextStyle(
                              fontStyle: FontStyle.BodyL_Regular,
                              color: FontColor.FontPrimary),
                        ),
                        SizedBox(
                          height: 20,
                          width: 35,
                          child: Switch(
                            value: stopLoss,
                            onChanged: (bool val) {
                              onTapStoploss();
                            },
                            activeColor: customColors().primary,
                            inactiveTrackColor: customColors().backgroundTertiary,
                            activeTrackColor: customColors().backgroundTertiary,
                          ),
                        ),
                      ],
                    ),
                  ),
                  if (stopLoss)
                    Column(
                      children: [
                        Container(
                          margin:
                              const EdgeInsets.only(top: 14.0, bottom: 16.0),
                          height: 1,
                          color: customColors().backgroundTertiary,
                        ),
                        CustomTextFormField(
                          controller: trailCount,
                          fieldName: "Trail by",
                          hintText: "0",
                        )
                      ],
                    )
                ],
              )
          ],
        ),
      ),
    );
  }
}
