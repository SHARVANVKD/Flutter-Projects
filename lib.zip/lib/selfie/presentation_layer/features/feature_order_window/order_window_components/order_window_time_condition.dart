import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/scrollable_bottomsheet/bottom_sheet_calander.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/scrollable_bottomsheet/scrollable_bottomsheet.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/textfields/custom_text_form_field.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/default_order_settings/default_order_settings_values.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/default_order_settings/order_window_settings_bottom_sheet.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class OrderWindowTimeCondition extends StatefulWidget {
  final int timeCondition;
  final int condition;
  final Function(int) onTimeConditionChange;
  final Function(int) onConditionChange;

  const OrderWindowTimeCondition(
      {Key? key,
      required this.timeCondition,
      required this.onConditionChange,
      required this.onTimeConditionChange,
      required this.condition})
      : super(key: key);

  @override
  State<OrderWindowTimeCondition> createState() =>
      _OrderWindowTimeConditionState();
}

class _OrderWindowTimeConditionState extends State<OrderWindowTimeCondition>
    with TickerProviderStateMixin {
  TextEditingController dateField = TextEditingController();
  AnimationController? _controller;
  DateTime? date;

  @override
  void initState() {
    super.initState();
    _controller = BottomSheet.createAnimationController(this);
    _controller!.duration = const Duration(milliseconds: 400);
  }

  @override
  void dispose() {
    _controller!.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
          border:
              Border.all(width: 1, color: customColors().backgroundTertiary),
          borderRadius: BorderRadius.circular(4.0)),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 14.0),
        child: Column(
          children: [
            GestureDetector(
              onTap: () => customShowModalBottomSheet(
                  context: context,
                  inputWidget: OrderSettingsSheetComponent(
                      orderSettingsSheetType:
                          OrderSettingsSheetType.TIME_CONDITION,
                      selected: widget.timeCondition,
                      onChanged: widget.onTimeConditionChange,
                      list: timeconditionsettingslist)),
              child: InkWell(
                onTap: () {
                  customShowModalBottomSheet(
                      context: context,
                      inputWidget: OrderSettingsSheetComponent(
                          orderSettingsSheetType:
                              OrderSettingsSheetType.TIME_CONDITION,
                          selected: widget.timeCondition,
                          onChanged: widget.onTimeConditionChange,
                          list: timeconditionsettingslist));
                },
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      "Time Condition",
                      style: customTextStyle(
                          fontStyle: FontStyle.BodyL_SemiBold,
                          color: FontColor.FontPrimary),
                    ),
                    Row(
                      children: [
                        Text(
                          timeconditionsettingslist[widget.timeCondition]
                              ["name"],
                          style: customTextStyle(
                              fontStyle: FontStyle.BodyL_Bold,
                              color: FontColor.Primary),
                        ),
                        const SizedBox(
                          width: 11,
                        ),
                        Image.asset("assets/down_arrow.png"),
                      ],
                    )
                  ],
                ),
              ),
            ),
            if (widget.timeCondition == 3)
              Column(
                children: [
                  Container(
                    margin: const EdgeInsets.only(top: 14.0, bottom: 16.0),
                    height: 1,
                    color: customColors().backgroundTertiary,
                  ),
                  CustomTextFormField(
                    controller: dateField,
                    fieldName: "Select Date",
                    hintText: "Set Date",
                    suffixIcon: InkWell(
                        onTap: () {
                          customShowModalBottomSheet(
                            context: context,
                            inputWidget: CustommCalandarSheet(
                              onDone: (_date) {
                                date = _date;
                                dateField.text = date == null ? "" :DateFormat("dd/MM/yyyy").format(date!);
                                //  date!.day.toString()+" / "+
                                // date!.month.toString()+" / "+
                                // date!.year.toString();
                                setState(() {});
                              },
                            ),
                          );
                        },
                        child: Image.asset(
                          "assets/calendar.png",
                          color: customColors().fontPrimary,
                        )),
                  )
                ],
              ),
            if (widget.timeCondition == 2)
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    margin: const EdgeInsets.only(top: 14.0, bottom: 16.0),
                    height: 1,
                    color: customColors().backgroundTertiary,
                  ),
                  Text(
                    "Condition :",
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyL_Regular,
                        color: FontColor.FontPrimary),
                  ),
                  const SizedBox(
                    height: 4,
                  ),
                  Text(
                    "Ambuja Cements Spot Price is trading",
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyL_Regular,
                        color: FontColor.FontSecondary),
                  ),
                  const SizedBox(
                    height: 4,
                  ),
                  Container(
                    decoration: BoxDecoration(
                        border: Border.all(
                            width: 1, color: customColors().backgroundTertiary),
                        borderRadius: BorderRadius.circular(4.0)),
                    padding: const EdgeInsets.symmetric(
                        vertical: 14, horizontal: 12),
                    child: InkWell(
                      focusColor: transparent,
                      highlightColor: transparent,
                      onTap: () {
                        customShowModalBottomSheet(
                            context: context,
                            inputWidget: OrderSettingsSheetComponent(
                                orderSettingsSheetType:
                                    OrderSettingsSheetType.CONDITION,
                                selected: widget.condition,
                                onChanged: widget.onTimeConditionChange,
                                list: conditionalSettingsList));
                      },
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            conditionalSettingsList[widget.condition]["name"],
                            style: customTextStyle(
                                fontStyle: FontStyle.BodyL_Regular,
                                color: FontColor.FontPrimary),
                          ),
                          Image.asset(
                            "assets/down_arrow.png",
                            color: customColors().fontPrimary,
                          )
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 16,
                  ),
                  CustomTextFormField(
                    controller: TextEditingController(text: "672.12"),
                    fieldName: "Trigger Price",
                    hintText: "0",
                  ),
                  const SizedBox(
                    height: 12,
                  ),
                  Text(
                    "This Day Order will be send to Exchange only when the above price conditions are met",
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyM_Regular,
                        color: FontColor.FontSecondary),
                  ),
                ],
              )
          ],
        ),
      ),
    );
  }
}
