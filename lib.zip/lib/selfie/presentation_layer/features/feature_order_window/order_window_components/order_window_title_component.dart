import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class OrderWindowTitleComponent extends StatefulWidget {
  final double NSE_price;
  final double BSE_price;
  final Function(String) onChanged;
  const OrderWindowTitleComponent(
      {Key? key,
      required this.NSE_price,
      required this.BSE_price,
      required this.onChanged})
      : super(key: key);

  @override
  State<OrderWindowTitleComponent> createState() =>
      _OrderWindowTitleComponentState();
}

class _OrderWindowTitleComponentState extends State<OrderWindowTitleComponent> {
  int groupValue = -1;
  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Row(
          children: [
            CustomRadioButton(
                value: 1,
                groupValue: groupValue,
                noLabel: true,
                onChanged: (value) {
                  setState(() {
                    groupValue = value;
                  });
                  widget.onChanged("NSE");
                }),
            SizedBox(
              width: 4,
            ),
            RichText(
              text: TextSpan(
                  text: 'NSE: ',
                  style: customTextStyle(
                      fontStyle: FontStyle.BodyM_Regular,
                      color: FontColor.FontPrimary),
                  children: <TextSpan>[
                    TextSpan(
                        text: "₹ ",
                        style: customTextStyle(
                            fontStyle: FontStyle.BodyL_SemiBold,
                            color: FontColor.FontSecondary)),
                    TextSpan(
                        text: widget.NSE_price.toString(),
                        style: customTextStyle(
                            fontStyle: FontStyle.BodyM_SemiBold,
                            color: FontColor.FontSecondary))
                  ]),
            ),
          ],
        ),
        const SizedBox(
          width: 20,
        ),
        Row(
          children: [
            CustomRadioButton(
                value: 2,
                groupValue: groupValue,
                noLabel: true,
                onChanged: (value) {
                  setState(() {
                    groupValue = value;
                  });
                  widget.onChanged("BSE");
                }),
            SizedBox(
              width: 4,
            ),
            RichText(
              text: TextSpan(
                  text: 'BSE: ',
                  style: customTextStyle(
                      fontStyle: FontStyle.BodyM_Regular,
                      color: FontColor.FontPrimary),
                  children: <TextSpan>[
                    TextSpan(
                        text: "₹ ",
                        style: customTextStyle(
                            fontStyle: FontStyle.BodyL_SemiBold,
                            color: FontColor.FontSecondary)),
                    TextSpan(
                        text: widget.BSE_price.toString(),
                        style: customTextStyle(
                            fontStyle: FontStyle.BodyM_SemiBold,
                            color: FontColor.FontSecondary))
                  ]),
            ),
          ],
        )
      ],
    );
  }
}

class CustomRadioButton extends StatelessWidget {
  final int value;
  final int groupValue;
  final ValueChanged<int> onChanged;
  final double size;
  final Color? activeColor;
  final Color? inactiveColor;
  final String? label;
  final EdgeInsetsGeometry? labelStartPadding;
  final bool noLabel;
  final bool disabled;
  final TextStyle? unSelectedLabeStyle;
  final TextStyle? selectedLabeStyle;
  final TextStyle? disabledLabeStyle;
  final innerVisible;

  const CustomRadioButton({
    required this.value,
    required this.groupValue,
    required this.onChanged,
    this.label,
    this.innerVisible = true,
    this.labelStartPadding,
    this.size = 20.0,
    this.activeColor,
    this.inactiveColor,
    this.noLabel = false,
    this.disabled = false,
    this.unSelectedLabeStyle,
    this.selectedLabeStyle,
    this.disabledLabeStyle,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => disabled ? {} : onChanged(value),
      child: _customRadioButton,
    );
  }

  Widget get _customRadioButton {
    final isSelected = value == groupValue;
    return Opacity(
      opacity: disabled ? 0.4 : 1,
      child: Row(
        children: [
          Container(
            alignment: Alignment.center,
            width: size,
            height: size,
            decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: transparent,
                border: Border.all(
                  width: isSelected ?  6.5 : 1.5,
                  color: isSelected ? (activeColor ?? customColors().primary) : (inactiveColor ?? customColors().fontTertiary)
                )
              ),
              child: Container(
                width: size/2,
                height: size/2,
              decoration: const BoxDecoration(
                color: transparent,
                shape: BoxShape.circle,
              ),
              ),
            ),
          if(!noLabel)
          Padding(
            padding: labelStartPadding ?? const EdgeInsets.only(left: 8.0),
            child: Text(
              label??"Radio", 
              style: isSelected ? 
              customTextStyle(fontStyle: FontStyle.BodyL_SemiBold, color: FontColor.FontPrimary)
              :customTextStyle(fontStyle: FontStyle.BodyL_Regular, color: FontColor.FontPrimary)
            ),  
          )
        ],
      ),
    );
  }
}
