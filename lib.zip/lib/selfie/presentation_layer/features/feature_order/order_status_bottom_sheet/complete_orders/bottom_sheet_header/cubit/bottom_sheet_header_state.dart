part of 'bottom_sheet_header_cubit.dart';

@immutable
abstract class BottomSheetHeaderState {}

class BottomSheetHeaderInitial extends BottomSheetHeaderState {
  List<OrderItemOrderLogResponse> orderLogData;
  BottomSheetHeaderInitial({required this.orderLogData});
}
