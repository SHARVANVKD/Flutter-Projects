part of 'order_log_cubit_cubit.dart';

@immutable
abstract class OrderLogCubitState {}

class OrderLogCubitInitial extends OrderLogCubitState {
  List<OrderItemOrderLogResponse> orderLsit;
  OrderLogCubitInitial({required this.orderLsit});
  
}
