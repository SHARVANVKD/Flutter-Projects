import 'package:bloc/bloc.dart';
import 'package:meta/meta.dart';
import 'package:selfie_mobile_flutter/services/api_gateway.dart';
import 'package:selfie_mobile_flutter/user_controller/user_controller.dart';
import 'package:trading_api/responses/order_log_response.dart';
part 'order_log_cubit_state.dart';

class OrderLogCubitCubit extends Cubit<OrderLogCubitState> {
  OrderItemOrderLogResponse? _response;
  final TradingApiGateway gateway;

  OrderLogCubitCubit({required this.gateway})
      : super(OrderLogCubitInitial(
            orderLsit: UserController().orderLogResponse)) {
    updateData();
  }

  // orderLogRequest({transId, securityCode}) async {
  //   _response = await gateway.orderLogRequest(
  //     venueCode: list["VENUECODE"].toString(),
  //     userId: UserController().userId,
  //     transId: list["TRANSID"].toString(),
  //     securityCode: list["SECURITYCODE"].toString(),
  //   );
  //   List<Map<String, dynamic>> demo = [];
  //   demo.clear();
  //   if (_response!.errorCode == 0) {
  //     for (int i = 0; i < _response!.reportData!.length; i++) {
  //       demo.add(_response!.reportData![i].toJson());
  //       UserController().orderLogResponse = demo;
  //     }
  //     emit(
  //       OrderLogCubitInitial(orderLsit: UserController().orderLogResponse),
  //     );
  //   }
  // }

  updateData() {
    emit(OrderLogCubitInitial(orderLsit: UserController().orderLogResponse));
  }
}
