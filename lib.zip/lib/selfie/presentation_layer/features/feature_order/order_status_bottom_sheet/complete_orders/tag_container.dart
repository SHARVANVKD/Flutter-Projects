import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class Tags extends StatelessWidget {
  String exchangeName;
  FontColor exchangeNameColor;
  Color tagColor;
  Tags(
      {Key? key,
      required this.exchangeName,
      required this.tagColor,
      required this.exchangeNameColor})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: tagColor,
        borderRadius: BorderRadius.circular(2),
      ),
      child: Center(
        child: Padding(
          padding: const EdgeInsets.all(6),
          child: Text(
            exchangeName,
            style: customTextStyle(
              fontStyle: FontStyle.TagNameL_SemiBold,
              color: exchangeNameColor,
            ),
          ),
        ),
      ),
    );
  }
}
