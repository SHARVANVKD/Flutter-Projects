// import 'package:flutter/material.dart';
// import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order/order_status_bottom_sheet/complete_orders/tab_view.dart';
// import 'package:selfie_mobile_flutter/selfie/widgets/others/options_widget.dart';
// import 'package:selfie_mobile_flutter/theme/styles.dart';

// class CompletedOrders extends StatelessWidget {
//   Map<String, dynamic> orderLsit;
//   CompletedOrders({Key? key, required this.orderLsit}) : super(key: key);

//   @override
//   Widget build(BuildContext context) {
//     return Column(
//       children: [
//         Padding(
//           padding:
//               const EdgeInsets.only(left: 16, right: 16, top: 10, bottom: 12),
//           child: Row(
//             mainAxisAlignment: MainAxisAlignment.spaceBetween,
//             children: [
//               Text(
//                 "Order Summary",
//                 style: customTextStyle(
//                   fontStyle: FontStyle.HeaderXS_SemiBold,
//                   color: FontColor.FontPrimary,
//                 ),
//               ),
//             ],
//           ),
//         ),
//         Divider(
//           height: 0,
//           thickness: 1,
//           color: customColors().backgroundTertiary,
//         ),
//         Padding(
//           padding: const EdgeInsets.all(16),
//           child: Row(
//             mainAxisAlignment: MainAxisAlignment.spaceBetween,
//             children: [
//               Column(
//                 crossAxisAlignment: CrossAxisAlignment.start,
//                 children: [
//                   Padding(
//                     padding: const EdgeInsets.fromLTRB(0, 0, 0, 4),
//                     child: Text(
//                       orderLsit["SECURITYCODE"],
//                       style: customTextStyle(
//                         fontStyle: FontStyle.BodyL_SemiBold,
//                         color: FontColor.FontPrimary,
//                       ),
//                     ),
//                   ),
//                   Row(
//                     children: [
//                       getProductTypeWidget(orderLsit["VENUECODE"].toString()),
//                       const SizedBox(
//                         width: 6,
//                       ),
//                       getProductTypeWidget(orderLsit["BUYORSELL"].toString()),
//                       const SizedBox(
//                         width: 6,
//                       ),
//                       getProductTypeWidget(orderLsit["PRODUCTTYPE"].toString())
//                     ],
//                   ),
//                 ],
//               ),
//               Column(
//                 crossAxisAlignment: CrossAxisAlignment.end,
//                 children: [
//                   Text(
//                     42.12.toString(),
//                     style: customTextStyle(
//                       fontStyle: FontStyle.BodyL_SemiBold,
//                       color: FontColor.FontPrimary,
//                     ),
//                   ),
//                   const SizedBox(
//                     height: 4,
//                   ),
//                   Text(
//                     "+4.95 (0.72%)",
//                     style: customTextStyle(
//                       fontStyle: FontStyle.BodyM_SemiBold,
//                       color: FontColor.Success,
//                     ),
//                   )
//                 ],
//               )
//             ],
//           ),
//         ),
//         OrderBookTabComponents(
//           orderViewList: orderLsit,
//         ),
//       ],
//     );
//   }
// }
