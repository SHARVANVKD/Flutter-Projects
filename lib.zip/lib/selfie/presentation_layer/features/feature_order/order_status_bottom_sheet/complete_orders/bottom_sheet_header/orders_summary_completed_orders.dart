import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/app_page_injectable.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order/order_status_bottom_sheet/complete_orders/bottom_sheet_header/cubit/bottom_sheet_header_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order/order_status_bottom_sheet/complete_orders/tab_view.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/options_widget.dart';
import 'package:selfie_mobile_flutter/services/api_gateway.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';
import 'package:trading_api/responses/order_status_item_response.dart';

class CompletedOrders extends StatefulWidget {
  List<OrderStatusReportData> overViewList;
  List<OrderStatusReportData> orderLogList;
  int index;

  CompletedOrders(
      {Key? key,
      required this.overViewList,
      required this.orderLogList,
      required this.index})
      : super(key: key);

  @override
  State<CompletedOrders> createState() => _CompletedOrdersState();
}

class _CompletedOrdersState extends State<CompletedOrders> {
  late TradingApiGateway _gateway;

  @override
  void initState() {
    super.initState();
    _gateway = context.gTradingApiGateway;
  }

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => BottomSheetHeaderCubit(
          gateway: _gateway, list: widget.orderLogList, index: widget.index),
      child: BlocBuilder<BottomSheetHeaderCubit, BottomSheetHeaderState>(
        builder: (context, state) {
          if (state is BottomSheetHeaderInitial) {
            return Column(
              children: [
                Padding(
                  padding: const EdgeInsets.only(
                      left: 16, right: 16, top: 10, bottom: 12),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        "Order Summary",
                        style: customTextStyle(
                          fontStyle: FontStyle.HeaderXS_SemiBold,
                          color: FontColor.FontPrimary,
                        ),
                      ),
                    ],
                  ),
                ),
                Divider(
                  height: 0,
                  thickness: 1,
                  color: customColors().backgroundTertiary,
                ),
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Padding(
                            padding: const EdgeInsets.fromLTRB(0, 0, 0, 4),
                            child: Text(
                              widget.overViewList[widget.index].securitycode
                                  .toString(),
                              style: customTextStyle(
                                fontStyle: FontStyle.BodyL_SemiBold,
                                color: FontColor.FontPrimary,
                              ),
                            ),
                          ),
                          Row(
                            children: [
                              getProductTypeWidget(widget
                                  .overViewList[widget.index].venuecode
                                  .toString()),
                              const SizedBox(
                                width: 6,
                              ),
                              getProductTypeWidget(widget
                                  .overViewList[widget.index].buyorsell
                                  .toString()),
                              const SizedBox(
                                width: 6,
                              ),
                              getProductTypeWidget(widget
                                  .overViewList[widget.index].producttype
                                  .toString())
                            ],
                          ),
                        ],
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Text(
                            widget.overViewList[widget.index].price.toString(),
                            style: customTextStyle(
                              fontStyle: FontStyle.BodyL_SemiBold,
                              color: FontColor.FontPrimary,
                            ),
                          ),
                          const SizedBox(
                            height: 4,
                          ),
                          Text(
                            "+4.95 (0.72%)",
                            style: customTextStyle(
                              fontStyle: FontStyle.BodyM_SemiBold,
                              color: FontColor.Success,
                            ),
                          )
                        ],
                      )
                    ],
                  ),
                ),
                OrderBookTabComponents(
                  orderViewList: widget.overViewList,
                  index: widget.index,
                ),
              ],
            );
          }
          return Container();
        },
      ),
    );
  }
}
