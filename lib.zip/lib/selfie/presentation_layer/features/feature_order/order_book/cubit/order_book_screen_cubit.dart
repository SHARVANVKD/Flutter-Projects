import 'package:bloc/bloc.dart';
import 'package:meta/meta.dart';
import 'package:selfie_mobile_flutter/services/api_gateway.dart';
import 'package:selfie_mobile_flutter/user_controller/user_controller.dart';
import 'package:trading_api/responses/order_status_item_response.dart';
part 'order_book_screen_state.dart';

class OrderBookScreenCubit extends Cubit<OrderBookScreenState> {
  OrderStatusItemResponse? _response;
  final TradingApiGateway gateway;
  List<OrderStatusReportData> openOrdersResponse = [];
  List<OrderStatusReportData> closedOrdersResponse = [];

  List<String> openOrderStatus = [
    "PEND",
    "SE",
    "CONF",
    "PEXE",
    "OPEN",
    "INCOMPLTE",
    "SAVED",
    "QUEUED",
    "SEND",
  ];

  List<String> closedOrderStatus = [
    "EXE",
    "PEXE",
    "PEXECAN",
    "CAN",
    "REJ",
    "CLBV",
    "PECLBV",
    "SOTR",
    "COMPLTE",
    "OMS_REJECT",
    "ORDER_REPLY_TIME_OUT",
    "DELETED",
    "TRIGGERED",
    "CLBOMS",
    "INPROC"
  ];

  OrderBookScreenCubit({required this.gateway})
      : super(OrderBookScreenInitial(
          openList: UserController().openOrders,
          closedList: UserController().closedOrders,
        )) {
    orders();
  }

  orders() async {
    UserController().resetClosedOrders.clear();
    UserController().resetOpenOrders.clear();
    UserController().openOrders.clear();
    UserController().closedOrders.clear();
    openOrdersResponse.clear();
    closedOrdersResponse.clear();
    _response = await gateway.orderBookRequest(userId: UserController().userId);
    UserController().orderBookData = _response;

    int cacheDataLength = UserController().orderBookData!.reportData!.length;

    for (int i = 0; i < cacheDataLength; i++) {
      if (openOrderStatus.contains(UserController()
          .orderBookData!
          .reportData![i]
          .status
          .toString()
          .toUpperCase())) {
        openOrdersResponse
            .add(UserController().orderBookData!.reportData![i]);
        UserController()
            .resetOpenOrders
            .add(UserController().orderBookData!.reportData![i]);
      }
      if (closedOrderStatus.contains(UserController()
          .orderBookData!
          .reportData![i]
          .status
          .toString()
          .toUpperCase())) {
        closedOrdersResponse
            .add(UserController().orderBookData!.reportData![i]);
        UserController()
            .resetClosedOrders
            .add(UserController().orderBookData!.reportData![i]);
      }
    }

    UserController().openOrders = openOrdersResponse;
    UserController().closedOrders = closedOrdersResponse;

    emit(
      OrderBookScreenInitial(
        closedList: UserController().closedOrders,
        openList: UserController().openOrders,
        response: _response,
      ),
    );
  }
}
