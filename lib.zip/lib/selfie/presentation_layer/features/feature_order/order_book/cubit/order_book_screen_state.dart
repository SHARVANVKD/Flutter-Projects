part of 'order_book_screen_cubit.dart';

@immutable
abstract class OrderBookScreenState {}

class OrderBookScreenInitial extends OrderBookScreenState {
  final int tabIndex;

  OrderStatusItemResponse? response;
  List<OrderStatusReportData> openList;
  List<OrderStatusReportData> closedList;

  OrderBookScreenInitial({
    // this.tabIndex = 0,
    // this.openList = const [],
    // this.closedList = const [],
    this.tabIndex = 0,
    this.openList = const [],
    this.closedList = const [],
    this.response,
  });
}

class OrderBookLoadingState extends OrderBookScreenState {}
