orderType(String orderType) {
  switch (orderType) {
    case "1":
      {
        return "NEW_ORDER";
      }

    case "2":
      {
        return "MODIFY_ORDER";
      }
    case "3":
      {
        return "CANCEL_ORDER";
      }
    case "4":
      {
        return "MODIFY_ORDER";
      }
    case "5":
      {
        return "CANCELLED";
      }
    case "6":
      {
        return "NEW_ORDER_SE";
      }
    case "7":
      {
        return "MODIFY_ORDER_SE";
      }
    case "8":
      {
        return "CANCEL_ORDER_SE";
      }
    case "9":
      {
        return "NEW_ORDER_CONFIRM";
      }
    case "10":
      {
        return "MODIFY_ORDER_CONFIRM";
      }
    case "11":
      {
        return "CANCEL_ORDER_CONFIRM";
      }
    case "12":
      {
        return "CANCELLED_BY_VENUE";
      }
    case "13":
      {
        return "ORDER_EXECUTION";
      }
    case "14":
      {
        return "ORPHAN_EXECUTION";
      }

    case "15":
      {
        return "NEW_ORDER_REJECT";
      }
    case "16":
      {
        return "MODIFY_ORDER_REJECT";
      }

    case "17":
      {
        return "CANCEL_ORDER_REJECT";
      }
    case "18":
      {
        return "STOP_LOSS_TRIGGER";
      }

    case "19":
      {
        return "ORDER_STATUS";
      }

    case "20":
      {
        return "USER_LOGIN";
      }

    case "21":
      {
        return "OTO_NEW_ORDER";
      }

    case "22":
      {
        return "OTO_MODIFY_ORDER";
      }

    case "23":
      {
        return "OTO_CANCEL_ORDER";
      }

    case "24":
      {
        return "SUSPEND_ORDER_CONFIRM";
      }

    case "25":
      {
        return "ORDER_SYNC_RESPONSE";
      }

    case "26":
      {
        return "OFFLINE_NEW_ORDER";
      }
    case "27":
      {
        return "OFFLINE_MODIFY_ORDER";
      }
    case "28":
      {
        return "OFFLINE_NEW_ORDER";
      }
    case "29":
      {
        return "CONVERT_MKT_TO_LMT";
      }
    case "30":
      {
        return "MODIFY_CONFIRM_BY_VENUE";
      }
    case "31":
      {
        return "CODE_CORRECTED";
      }
    case "32":
      {
        return "CONDITIONAL_CANCEL_ORDER";
      }
    case "33":
      {
        return "MULTI_LEG_ORDER";
      }
    case "34":
      {
        return "SMART_PLUS_ORDER";
      }
    case "35":
      {
        return "SPREAD_NEW_ORDER";
      }
    case "36":
      {
        return "SPREAD_MODIFY_ORDER";
      }
    case "37":
      {
        return "SPREAD_CANCEL_ORDER";
      }
    case "41":
      {
        return "SMART_PLUS_MODIFY_ORDER";
      }
    case "42":
      {
        return "SMART_PLUS_CANCEL_ORDER";
      }
    case "43":
      {
        return "TRAILED";
      }
    case "44":
      {
        return "ALGO_CANCEL_ORDER";
      }
  }
}
