import 'package:bloc/bloc.dart';
import 'package:meta/meta.dart';
import 'package:selfie_mobile_flutter/services/api_gateway.dart';
import 'package:selfie_mobile_flutter/user_controller/user_controller.dart';
import 'package:trading_api/responses/order_status_gtd_response.dart';

part 'gtd_component_state.dart';

class GTDComponentCubit extends Cubit<GTDComponentState> {
  final TradingApiGateway gateway;
  OrderItemOrderGtdResponse? _response;

  GTDComponentCubit({required this.gateway})
      : super(GTDComponentInitial(gtdList: [])) {
   ;
  }

  // gtdSearch() {
  //   emit(GTDComponentInitial(
  //       searchVisible: true, gtdList:gtdList));
  // }

  // gtdOrderRequest() async {
  //   _response = await gateway.orderGtdRequest(userId: UserController().userId);
  //   List<Map<String, dynamic>> gtdList = [];
  //   gtdList.clear();
  //   if (_response!.errorCode == 0) {
  //     for (int i = 0; i < _response!.reportData!.length; i++) {
  //       gtdList.add(_response!.reportData![i].toJson());
  //       UserController().orderGtdResponse = gtdList;
  //     }
  //     emit(
  //       GTDComponentInitial(gtdList: UserController().orderGtdResponse),
  //     );
  //   }
  // }

  // updateData() {
  //   emit(GTDComponentInitial(gtdList: UserController().orderGtdResponse));
  // }
}
