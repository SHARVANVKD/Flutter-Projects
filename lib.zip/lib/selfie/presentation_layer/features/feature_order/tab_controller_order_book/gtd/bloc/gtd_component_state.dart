part of 'gtd_component_cubit.dart';

@immutable
abstract class GTDComponentState {}

class GTDComponentInitial extends GTDComponentState {
  final List<Map<String, dynamic>> gtdList;
  final bool searchVisible;

  GTDComponentInitial({required this.gtdList, this.searchVisible= false});
}
