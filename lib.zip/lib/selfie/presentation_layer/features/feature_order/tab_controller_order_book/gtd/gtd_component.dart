import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/app_page_injectable.dart';
import 'package:selfie_mobile_flutter/constants/enums.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order/order_status_bottom_sheet/complete_orders/bottom_sheet_header/orders_summary_completed_orders.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order/tab_controller_order_book/gtd/bloc/gtd_component_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/scrollable_bottomsheet/scrollable_bottomsheet.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/search_insights_filter/order_book_open_filter_bar.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/order_book/empty_list_widget.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/order_book/gtd/gtd_list_item.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/fixed_bottom_buttons/fixed_bottom_buttons.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/message_tile.dart';
import 'package:selfie_mobile_flutter/services/api_gateway.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class OrderBookGTDComponent extends StatefulWidget {
  Function(bool) onScrollEvent;
  OrderBookGTDComponent({
    Key? key,
    required this.onScrollEvent,
  }) : super(key: key);

  @override
  State<OrderBookGTDComponent> createState() => _OrderBookGTDComponentState();
}

class _OrderBookGTDComponentState extends State<OrderBookGTDComponent>
    with TickerProviderStateMixin {
  int screenCount = 1;
  ScrollController _scrollBottomBarController = new ScrollController();

  bool isScrollingDown = false;
  late TradingApiGateway _gateway;

  void initState() {
    // TODO: implement initState
    super.initState();
    _controller = BottomSheet.createAnimationController(this);
    _controller!.duration = const Duration(milliseconds: 400);
    _gateway = context.gTradingApiGateway;

    myScroll();
  }

  @override
  void dispose() {
    _controller!.dispose();
    super.dispose();
  }

  void myScroll() async {
    _scrollBottomBarController.addListener(() {
      if (_scrollBottomBarController.position.userScrollDirection ==
          ScrollDirection.reverse) {
        if (!isScrollingDown) {
          isScrollingDown = true;
          widget.onScrollEvent(false); //hide appbar
        }
      }
      if (_scrollBottomBarController.position.userScrollDirection ==
          ScrollDirection.forward) {
        if (isScrollingDown) {
          isScrollingDown = false;
          widget.onScrollEvent(true); //show appbar
        }
      }
    });
  }

  AnimationController? _controller;

  bool notify = false;
  @override
  Widget build(BuildContext context) {
    // return Container(child: Center(child: Text("Open component"),),);
    return BlocProvider(
        create: (context) => GTDComponentCubit(gateway: _gateway),
        child: BlocBuilder<GTDComponentCubit, GTDComponentState>(
            builder: (context, state) {
          return RefreshIndicator(
            backgroundColor: customColors().primary,
            onRefresh: () async {
              // BlocProvider.of<GTDComponentCubit>(context).gtdOrderRequest();
            },
            child: Column(
              children: [
                Expanded(
                  child: Stack(
                    children: [
                      SingleChildScrollView(
                        physics: const BouncingScrollPhysics(),
                        controller: _scrollBottomBarController,
                        child: Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              BlocBuilder<GTDComponentCubit, GTDComponentState>(
                                  builder: (context, state) {
                                if (state is GTDComponentInitial) {
                                  return Column(
                                    children: [
                                      SearchFilterHoldings(
                                        onFilterPress: () {
                                          // customShowModalBottomSheet(
                                          //     context: context,
                                          //     inputWidget: OpenSortFilterList(
                                          //       currentval: filterval,
                                          //       // selectedLocation:
                                          //       //     SortFilterLocation.holding,
                                          //       onPressFilter: (String name) {
                                          //         List<Map<String, dynamic>> list = [];
                                          //         state.holdingList.forEach((element) {
                                          //           if (element.containsValue(name)) {
                                          //             list.add(element);
                                          //           }
                                          //         });

                                          //         BlocProvider.of<OpenComponentCubit>(
                                          //                 context)
                                          //             .updateSortList(list);
                                          //       },
                                          //       onPressReset: () {
                                          //         List<Map<String, dynamic>> list = [];
                                          //         list = List.from(holdingsList2);

                                          //         BlocProvider.of<HoldingsComponentCubit>(
                                          //                 context)
                                          //             .updateSortList(list);
                                          //       },
                                          //     ));
                                          // setState(() {
                                          //   notify = !notify;
                                          // });
                                        },
                                        onSearchPress: () {
                                          // BlocProvider.of<
                                          //             GTDComponentCubit>(
                                          //         context)
                                          //     .gtdSearch();
                                        },
                                        //TODO filter notification bubbles
                                      ),
                                      ListView.builder(
                                          physics:
                                              const NeverScrollableScrollPhysics(),
                                          itemCount: state.gtdList.length,
                                          shrinkWrap: true,
                                          itemBuilder: (context, index) {
                                            return InkWell(
                                              onTap: () {
                                                // customBottomSheet(
                                                //   fixedBottomWidget: FixedButton(
                                                //     elevation: true,
                                                //     addMoreOnTap: () {},
                                                //     squareOffOnTap: () {},
                                                //     future: false,
                                                //     ocoOnTap: () {},
                                                //   ),
                                                //   height: .76,
                                                //   maxHeight: .89,
                                                //   ifport: true,
                                                //   context: context,
                                                //   inputWidget:
                                                //       const HoildinBottomSheet(),
                                                // );
                                                // customBottomSheet(
                                                //   height: .76,
                                                //   maxHeight: .89,
                                                //   context: context,
                                                //   inputWidget:
                                                //       CompletedOrders(
                                                //     status: OrderStatus
                                                //         .conditional,
                                                //   ),
                                                //   fixedBottomWidget:
                                                //       OdrderBookFixedButton(
                                                //     elevation: true,
                                                //     modify: true,
                                                //   ),
                                                // );
                                              },
                                              child: GTDListItem(
                                                  gtdList:
                                                      state.gtdList[index]),
                                            );
                                          }),
                                    ],
                                  );
                                } else {
                                  return Container();
                                }
                              }),
                            ]),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          );
        }));
  }
}
