part of 'basket_component_cubit.dart';

@immutable
abstract class BasketComponentState {}

class BasketComponentInitial extends BasketComponentState {
  final List<Map<String, dynamic>> basketList;
  final bool searchVisible;

  BasketComponentInitial({required this.basketList, this.searchVisible=false});
}
