import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order/tab_controller_order_book/basket/basket_edit/basket_edit.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';

class BasketEditRouteBuilder {
  final ServiceLocator serviceLocator;
  BasketEditRouteBuilder(this.serviceLocator);

  Widget call(BuildContext context) {
    return MultiRepositoryProvider(
        providers: [RepositoryProvider.value(value: serviceLocator.tradingApi)],
        child: MyBasketEdit());
  }
}
