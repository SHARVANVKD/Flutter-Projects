import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

import '../../../../../../../widgets/custom_app_components/buttons/BasketButton.dart';

class BasketDeletePop extends StatefulWidget {
  String name;
  BasketDeletePop({Key? key, required this.name}) : super(key: key);

  @override
  State<BasketDeletePop> createState() => _BasketDeletePopState();
}

class _BasketDeletePopState extends State<BasketDeletePop> {
  @override
  Widget build(BuildContext context) {
    Size screenSize = MediaQuery.of(context).size;
    return Container(
      width: MediaQuery.of(context).size.width,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Container(
            height: 80,
            width: 80,
            decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: customColors().backgroundSecondary),
            child: Center(
              child: Image.asset(
                "assets/trashbigIcon.png",
                height: 50.0,
                width: 50.0,
                color: customColors().fontSecondary,
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 15.0),
            child: Text(
              'Delete “${widget.name}”',
              style: customTextStyle(
                  fontStyle: FontStyle.HeaderS_SemiBold,
                  color: FontColor.FontPrimary),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 12.0, bottom: 35.0),
            child: Text(
              'This will delete the whole basket',
              style: customTextStyle(
                  fontStyle: FontStyle.BodyM_SemiBold,
                  color: FontColor.FontSecondary),
            ),
          ),
          Align(
            alignment: Alignment.bottomCenter,
            child: SizedBox(
              height: screenSize.height * 0.13,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Divider(
                    thickness: 1.0,
                    color: customColors().backgroundTertiary,
                  ),
                  Padding(
                    padding: const EdgeInsets.only(
                        left: 16.0, right: 16.0, top: 8.0, bottom: 12.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Expanded(
                          flex: 2,
                          child: BasketButton(
                              onpress: () {
                                Navigator.pop(context);
                              },
                              text: "Cancel",
                              bgcolor: customColors().backgroundPrimary,
                              bordercolor: customColors().primary,
                              textStyle: customTextStyle(
                                  fontStyle: FontStyle.BodyL_Bold,
                                  color: FontColor.Primary)),
                        ),
                        Expanded(
                          flex: 2,
                          child: Padding(
                            padding: const EdgeInsets.only(left: 8.0),
                            child: BasketButton(
                                onpress: () {
                                  Navigator.pop(context);
                                },
                                text: "Delete",
                                bgcolor: customColors().primary,
                                bordercolor: customColors().primary,
                                textStyle: customTextStyle(
                                    fontStyle: FontStyle.BodyL_Bold,
                                    color: FontColor.White)),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }
}
