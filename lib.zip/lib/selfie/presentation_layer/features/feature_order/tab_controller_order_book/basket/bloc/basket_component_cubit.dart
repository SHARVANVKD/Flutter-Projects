import 'package:bloc/bloc.dart';
import 'package:meta/meta.dart';
import 'package:selfie_mobile_flutter/selfie/repository_layer/order_book_content.dart';

part 'basket_component_state.dart';

class BasketComponentCubit extends Cubit<BasketComponentState> {
  BasketComponentCubit() : super(BasketComponentInitial(
    basketList: basketList
  ));
  basketSearch() {
    emit(BasketComponentInitial(
        searchVisible: true, basketList: basketList));
  }
}
