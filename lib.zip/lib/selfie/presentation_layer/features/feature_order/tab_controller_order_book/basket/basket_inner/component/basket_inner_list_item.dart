import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/repository_layer/order_book_content.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/custom_dot.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/stock/empty_custom_checkbox/empty_custom_checkbox.dart';

import '../../../../../../../../theme/styles.dart';
import '../../../../../../../widgets/others/options_widget.dart';

class BasketInnerListItem extends StatefulWidget {
  Map<String, dynamic> basketinner;
  bool longpress;
  List<String> cklist;
  Function(String) addcheck;

  BasketInnerListItem(
      {Key? key,
      required this.basketinner,
      required this.longpress,
      required this.cklist,
      required this.addcheck})
      : super(key: key);

  @override
  State<BasketInnerListItem> createState() => _BasketInnerListItemState();
}

class _BasketInnerListItemState extends State<BasketInnerListItem> {
  @override
  Widget build(BuildContext context) {

    return Container(
      padding: const EdgeInsets.symmetric(vertical: 16),
      decoration: BoxDecoration(
          border: Border(
        bottom: BorderSide(color: customColors().backgroundTertiary, width: 1),
      )),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Container(
            padding: EdgeInsets.only(left: 8.0),
            decoration: BoxDecoration(
                border: Border(
              left: widget.basketinner['ordertype'] == 'buy'
                  ? BorderSide(color: green200, width: 2)
                  : BorderSide(color: customColors().red3, width: 2),
            )),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 0.0),
                      child:
                          getProductTypeWidget(widget.basketinner['ordertype']),
                    ),
                    SizedBox(
                      width: 6,
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 0.0),
                      child: getProductTypeWidget(
                          widget.basketinner['producttype']),
                    ),
                    SizedBox(
                      width: 8,
                    ),
                  ],
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 10.0),
                  child: Text(
                    widget.basketinner['stockname'],
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyL_SemiBold,
                        color: FontColor.FontPrimary),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 4.0),
                  child: Text(
                    "Qty: ${widget.basketinner['qty']}",
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyM_SemiBold,
                        color: FontColor.FontSecondary),
                  ),
                ),
              ],
            ),
          ),
          Row(
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Visibility(
                    visible: widget.basketinner['value'] == '' ? false : true,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Text(
                          'LTP:',
                          style: customTextStyle(
                              fontStyle: FontStyle.BodyM_Regular,
                              color: FontColor.FontTertiary),
                        ),
                        Text(
                          '1445.0',
                          style: customTextStyle(
                              fontStyle: FontStyle.BodyM_Regular,
                              color: FontColor.FontPrimary),
                        ),
                      ],
                    ),
                  ),
                  widget.basketinner['value'] != ''
                      ? Padding(
                          padding: const EdgeInsets.only(top: 8.0),
                          child: Row(
                            children: [
                              Text(
                                "1,242.17 / T-1,250",
                                style: customTextStyle(
                                    fontStyle: FontStyle.BodyL_SemiBold,
                                    color: FontColor.FontPrimary),
                              ),
                            ],
                          ),
                        )
                      : Padding(
                          padding: const EdgeInsets.only(top: 8.0),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              Text(
                                'LTP:',
                                style: customTextStyle(
                                    fontStyle: FontStyle.BodyM_Regular,
                                    color: FontColor.FontTertiary),
                              ),
                              Text(
                                '1445.0',
                                style: customTextStyle(
                                    fontStyle: FontStyle.BodyM_Regular,
                                    color: FontColor.FontPrimary),
                              ),
                            ],
                          ),
                        ),
                  Padding(
                    padding: const EdgeInsets.only(top: 5.0),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Text(
                          widget.basketinner['markettype'],
                          style: customTextStyle(
                              fontStyle: FontStyle.BodyM_SemiBold,
                              color: FontColor.FontSecondary),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              Visibility(
                visible: widget.longpress,
                child: Padding(
                  padding: const EdgeInsets.only(left: 10.0),
                  child: SizedBox(
                      height: 16.6,
                      width: 16.6,
                      child: widget.cklist
                              .contains(widget.basketinner['stockname'])
                          ? Container(
                              height: 16.67,
                              width: 16.67,
                              decoration: BoxDecoration(
                                  color: customColors().primary,
                                  borderRadius: BorderRadius.circular(2.0)),
                              child: Center(
                                child: Image.asset(
                                  "assets/checkedicon.png",
                                ),
                              ),
                            )
                          : EmptyCustomCheckBox(callback: (v) {
                              widget.addcheck(widget.basketinner['stockname']);
                            })),
                ),
              )
            ],
          )
        ],
      ),
    );
  }
}
