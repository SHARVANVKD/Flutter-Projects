import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order/tab_controller_order_book/basket/basket_edit/component/basket_edit_reorder_list.dart';
import 'package:selfie_mobile_flutter/selfie/repository_layer/order_book_content.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class MyBasketEdit extends StatefulWidget {
  const MyBasketEdit({Key? key}) : super(key: key);

  @override
  State<MyBasketEdit> createState() => _MyBasketEditState();
}

class _MyBasketEditState extends State<MyBasketEdit> {
  List<Map<String, dynamic>> my_basket_list = [
    {'name': 'Trial Basket', 'itemcount': '0', 'date': '8/03/22'},
    {'name': 'Agri Basket', 'itemcount': '5', 'date': '8/03/22'},
    {'name': 'Bank Basket', 'itemcount': '15', 'date': '8/03/22'},
    {'name': 'Tech Basket', 'itemcount': '25', 'date': '8/03/22'},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
          preferredSize: const Size.fromHeight(0.0),
          child: AppBar(
            elevation: 0,
            backgroundColor: customColors().backgroundPrimary,
          )),
      body: Column(
        children: [
          Container(
            height: 56,
            width: MediaQuery.of(context).size.width,
            child: Row(
              children: [
                Padding(
                  padding: const EdgeInsets.only(left: 8),
                  child: IconButton(
                      onPressed: () {
                        Navigator.pop(context);
                      },
                      icon: const ImageIcon(AssetImage("assets/arrow_left.png"),
                          size: 24)),
                  // child: ,
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 12.0),
                  child: Text('Edit Basket'),
                ),
              ],
            ),
          ),
          Expanded(
            child: BasketEditReorderList(
              items: my_basket_list,
            ),
          )
        ],
      ),
    );
  }
}
