import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class EditBasketNameField extends StatefulWidget {
  const EditBasketNameField({Key? key}) : super(key: key);

  @override
  State<EditBasketNameField> createState() => _EditBasketNameFieldState();
}

class _EditBasketNameFieldState extends State<EditBasketNameField> {
  TextEditingController namecontroller =
      TextEditingController(text: 'Trial Basket');
  @override
  Widget build(BuildContext context) {
    return Container(
      height: 124,
      width: MediaQuery.of(context).size.width,
      decoration: BoxDecoration(color: customColors().backgroundSecondary),
      child: Padding(
        padding: const EdgeInsets.only(left: 16.0, right: 16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Basket Name',
              style: customTextStyle(
                  fontStyle: FontStyle.BodyL_Regular,
                  color: FontColor.FontPrimary),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 8.0),
              child: Container(
                  height: 48.0,
                  decoration: BoxDecoration(
                      color: customColors().backgroundPrimary,
                      border:
                          Border.all(color: customColors().backgroundTertiary),
                      borderRadius: BorderRadius.circular(4.0)),
                  child: TextFormField(
                    controller: namecontroller,
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyL_Regular,
                        color: FontColor.FontPrimary),
                    decoration: InputDecoration(
                        border: InputBorder.none,
                        contentPadding: EdgeInsets.only(left: 12.0)),
                  )),
            )
          ],
        ),
      ),
    );
  }
}
