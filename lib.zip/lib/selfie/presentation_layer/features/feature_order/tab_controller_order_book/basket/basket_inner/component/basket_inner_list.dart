import 'package:flutter/material.dart';
import 'package:just_the_tooltip/just_the_tooltip.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order/tab_controller_order_book/basket/basket_inner/component/basket_inner_list_item.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order/tab_controller_order_book/basket/basket_inner/component/symbol_detail_dialog.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/scrollable_bottomsheet/scrollable_bottomsheet.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/stock/empty_custom_checkbox/empty_custom_checkbox.dart';
import 'package:selfie_mobile_flutter/app_page_injectable.dart';
import '../../../../../../../../theme/styles.dart';
import '../../../../../../../widgets/dashboard/margin_details.dart';

class BasketInnerListContainer extends StatefulWidget {
  List<String> checklist;
  Function(String) addcheck;
  BasketInnerListContainer(
      {Key? key, required this.checklist, required this.addcheck})
      : super(key: key);

  @override
  State<BasketInnerListContainer> createState() =>
      _BasketInnerListContainerState();
}

class _BasketInnerListContainerState extends State<BasketInnerListContainer> {
  bool swichval = false;
  JustTheController? controller3 = JustTheController();
  bool longpress = false;
  void toggleSwitch(bool value) {
    if (swichval == false) {
      setState(() {
        swichval = true;
      });
    } else {
      setState(() {
        swichval = false;
      });
    }
  }

  List<String> checklist = [];

  List<Map<String, dynamic>> basket_list_content = [
    {
      'ordertype': 'buy',
      'producttype': 'intraday',
      'stockname': 'HDFCBANK',
      'ltp': '1445.50',
      'value': '',
      'totalvalue': '',
      'qty': '1,50,250',
      'markettype': 'Market',
    },
    {
      'ordertype': 'buy',
      'producttype': 'cash',
      'stockname': 'TATAMOTORS',
      'ltp': '1445.50',
      'value': '1445.50',
      'totalvalue': 'T-1445.75',
      'qty': '1,50,250',
      'markettype': 'Limit',
    },
    {
      'ordertype': 'sell',
      'producttype': 'cash',
      'stockname': 'AXISBANK',
      'ltp': '1445.50',
      'value': '1445.50',
      'totalvalue': 'T-1445.75',
      'qty': '1,50,250',
      'markettype': 'SL-Lmt',
    },
    {
      'ordertype': 'buy',
      'producttype': 'intraday',
      'stockname': 'YESBANK',
      'ltp': '1445.50',
      'value': '1445.50',
      'totalvalue': 'T-1445.75',
      'qty': '1,50,250',
      'markettype': 'SL-Mkt',
    }
  ];

  @override
  Widget build(BuildContext context) {
    checklist = widget.checklist;
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 5.0, right: 23.0),
          child: Container(
            height: 56.0,
            child: Padding(
              padding: EdgeInsets.only(top: 17.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Row(
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(right: 8),
                        child: IconButton(
                            onPressed: () {
                              Navigator.pop(context);
                            },
                            icon: const ImageIcon(
                                AssetImage("assets/arrow_left.png"),
                                size: 24)),
                        // child: ,
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Trial Basket',
                            style: customTextStyle(
                                fontStyle: FontStyle.BodyL_SemiBold,
                                color: FontColor.FontPrimary),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(top: 4.0),
                            child: Text(
                              'Created on 28/02/22',
                              style: customTextStyle(
                                  fontStyle: FontStyle.BodyM_Regular,
                                  color: FontColor.FontSecondary),
                            ),
                          )
                        ],
                      ),
                    ],
                  ),
                  Padding(
                    padding: const EdgeInsets.only(right: 8.0),
                    child: InkWell(
                        onTap: () {
                          context.gNavigationService
                              .openBasketInnerEdit(context);
                        },
                        child: Image.asset("assets/icon.png")),
                  )
                ],
              ),
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.only(left: 16.0, right: 16.0),
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.only(top: 12.0),
                child: MarginDetails(
                  title1: "Required Margin",
                  title2: "Final Margin",
                  todaymarginused: 974.45,
                  totalmarginavail: 574.45,
                  totalPercentage: "",
                  todayPercentage: "",
                  height: 84.0,
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 8.0),
                child: Container(
                  height: 44.0,
                  width: MediaQuery.of(context).size.width,
                  decoration: BoxDecoration(
                      color: customColors().backgroundSecondary,
                      borderRadius: BorderRadius.circular(4)),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          Padding(
                            padding: const EdgeInsets.only(left: 12.0),
                            child: Text(
                              'Execute order chronologically',
                              style: customTextStyle(
                                  fontStyle: FontStyle.BodyL_Regular,
                                  color: FontColor.FontPrimary),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(
                                left: 7.0, top: 15.0, bottom: 15.0),
                            child: JustTheTooltip(
                              backgroundColor:
                                  customColors().backgroundSecondary,
                              preferredDirection: AxisDirection.down,
                              controller: controller3,
                              margin: EdgeInsets.only(left: 30.0, bottom: 5.0),
                              child: Padding(
                                padding: const EdgeInsets.only(bottom: 5.0),
                                child: InkWell(
                                  onTap: () {
                                    controller3?.showTooltip();
                                  },
                                  child: Icon(
                                    Icons.info_outline_rounded,
                                    size: 15.0,
                                  ),
                                ),
                              ),
                              content: Padding(
                                  padding: EdgeInsets.only(
                                      top: 16.0,
                                      left: 16.0,
                                      right: 16.0,
                                      bottom: 10.0),
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      Text(
                                        'Execute order chronologically',
                                        style: customTextStyle(
                                            fontStyle: FontStyle.BodyM_SemiBold,
                                            color: FontColor.FontPrimary),
                                      ),
                                      Padding(
                                          padding: EdgeInsets.only(
                                              top: 16.0, right: 10.0),
                                          child: Container(
                                            width: 268,
                                            child: Text(
                                              'The orders will be executed from top to bottom sequentially',
                                              style: customTextStyle(
                                                  fontStyle:
                                                      FontStyle.BodyS_Regular,
                                                  color: FontColor.FontPrimary),
                                              textAlign: TextAlign.justify,
                                            ),
                                          )),
                                    ],
                                  )),
                            ),
                          )
                        ],
                      ),
                      Builder(
                        builder: (context) {
                          return Switch(
                            value: swichval,
                            onChanged: toggleSwitch,
                            activeColor: customColors().primary,
                            activeTrackColor: customColors().backgroundTertiary,
                            inactiveTrackColor:
                                customColors().backgroundTertiary,
                          );
                        },
                      ),
                    ],
                  ),
                ),
              ),
              Padding(
                  padding: const EdgeInsets.only(top: 10.0),
                  child: Row(
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(right: 8.0),
                        child: Image.asset(
                          "assets/searchicon.png",
                          color: customColors().fontPrimary,
                          height: 15.0,
                          width: 15.0,
                        ),
                      ),
                      Flexible(
                        child: TextFormField(
                          decoration: InputDecoration(
                              hintText: 'Search items within this basket',
                              hintStyle: customTextStyle(
                                  fontStyle: FontStyle.BodyS_Regular,
                                  color: FontColor.FontSecondary),
                              border: InputBorder.none),
                        ),
                      ),
                      Text(
                        '5/25',
                        style: customTextStyle(
                            fontStyle: FontStyle.BodyS_Regular,
                            color: FontColor.FontSecondary),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 8.0, right: 8.0),
                        child: Container(
                          height: 16.0,
                          width: 1.5,
                          decoration: BoxDecoration(
                              color: customColors().backgroundTertiary),
                        ),
                      ),
                      Row(
                        children: [
                          Icon(
                            Icons.add,
                            color: customColors().primary,
                            size: 18.0,
                          ),
                          Text(
                            'Add item',
                            style: customTextStyle(
                                fontStyle: FontStyle.BodyM_Bold,
                                color: FontColor.Primary),
                          )
                        ],
                      )
                    ],
                  )),
              Visibility(
                visible: longpress,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    Text(
                      'Select All',
                      style: customTextStyle(
                          fontStyle: FontStyle.BodyM_SemiBold,
                          color: FontColor.FontPrimary),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(left: 10.0),
                      child: SizedBox(
                          height: 20.0,
                          width: 20.0,
                          child: EmptyCustomCheckBox(
                              isSelect: checklist.isNotEmpty,
                              callback: (v) {
                                List.generate(basket_list_content.length,
                                    (index) {
                                  setState(() {
                                    widget.addcheck(basket_list_content[index]
                                        ['stockname']);
                                  });
                                });
                              })),
                    )
                  ],
                ),
              ),
              ListView.builder(
                  shrinkWrap: true,
                  itemCount: basket_list_content.length,
                  itemBuilder: (context, index) {
                    return InkWell(
                      onTap: () {
                        customShowModalBottomSheet(
                            context: context,
                            inputWidget: SymbolDetailDialogue());
                      },
                      onLongPress: () {
                        setState(() {
                          longpress = !longpress;
                        });
                      },
                      child: BasketInnerListItem(
                        basketinner: basket_list_content[index],
                        longpress: longpress,
                        cklist: checklist,
                        addcheck: widget.addcheck,
                      ),
                    );
                  })
            ],
          ),
        ),
      ],
    );
  }
}
