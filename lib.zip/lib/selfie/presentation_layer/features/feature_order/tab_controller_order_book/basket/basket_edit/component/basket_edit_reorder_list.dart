import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order/tab_controller_order_book/basket/basket_edit/component/basket_delete_pop.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/scrollable_bottomsheet/scrollable_bottomsheet.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class BasketEditReorderList extends StatefulWidget {
  final List items;
  const BasketEditReorderList({Key? key, required this.items})
      : super(key: key);

  @override
  State<BasketEditReorderList> createState() => _BasketEditReorderListState();
}

class _BasketEditReorderListState extends State<BasketEditReorderList> {
  @override
  Widget build(BuildContext context) {
    return ReorderableListView.builder(
      shrinkWrap: true,
      itemCount: widget.items.length,
      itemBuilder: (BuildContext context, int index) {
        return Card(
          elevation: 0,
          color: customColors().backgroundPrimary,
          key: ValueKey(index),
          child: InkWell(
            onTap: () {
              customShowModalBottomSheet(
                  context: context,
                  inputWidget: BasketDeletePop(
                    name: widget.items[index]["name"],
                  ));
            },
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Container(
                padding: const EdgeInsets.symmetric(vertical: 20),
                decoration: BoxDecoration(
                    border: Border(
                        bottom: BorderSide(
                            color: customColors().backgroundTertiary))),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        Image.asset('assets/reoder.png'),
                        Padding(
                          padding: const EdgeInsets.only(left: 8.0),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                widget.items[index]["name"],
                                style: TextStyle(
                                    fontFamily: "OpenSansSemiBold",
                                    fontWeight: FontWeight.w600,
                                    fontSize: 14,
                                    color: customColors().fontPrimary),
                              ),
                              Padding(
                                padding: const EdgeInsets.only(top: 4.0),
                                child: Text(
                                  '8/03/22',
                                  style: customTextStyle(
                                      fontStyle: FontStyle.BodyM_SemiBold,
                                      color: FontColor.FontSecondary),
                                ),
                              )
                            ],
                          ),
                        )
                      ],
                    ),
                    Row(
                      children: [
                        Column(
                          children: [
                            Row(
                              children: [
                                Text(
                                  '${widget.items[index]['itemcount']}/25',
                                  style: customTextStyle(
                                      fontStyle: FontStyle.BodyL_SemiBold,
                                      color: FontColor.FontPrimary),
                                )
                              ],
                            ),
                            Padding(
                              padding: const EdgeInsets.only(top: 4.0),
                              child: Row(
                                children: [
                                  Text(
                                    'Items',
                                    style: customTextStyle(
                                        fontStyle: FontStyle.BodyM_SemiBold,
                                        color: FontColor.FontSecondary),
                                  )
                                ],
                              ),
                            )
                          ],
                        ),
                        Padding(
                          padding: const EdgeInsets.only(left: 8.0),
                          child: Image.asset(
                            "assets/trash.png",
                            color: customColors().fontSecondary,
                          ),
                        ),
                      ],
                    )
                  ],
                ),
              ),
            ),
          ),
        );
      },
      onReorder: onReoder,
    );
  }

  onReoder(int oldIndex, int newIndex) {
    setState(() {
      if (newIndex > oldIndex) {
        newIndex -= 1;
      }
      final item = widget.items.removeAt(oldIndex);
      widget.items.insert(newIndex, item);
    });
  }
}
