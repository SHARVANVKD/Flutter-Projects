List<Map<String, dynamic>> openSort(
    List<Map<String, dynamic>> list, int index) {
  switch (index) {
    case 0:
      list.sort(((a, b) => (a["SECURITYCODE"]).compareTo(b["SECURITYCODE"])));
      break;
    case 1:
      list.sort(((a, b) => (a["SECURITYCODE"]).compareTo(b["SECURITYCODE"])));
      list = list.reversed.toList();
      break;
    case 2:
      list.sort(((a, b) => (a["value"]).compareTo(b["value"])));
      break;
    case 3:
      list.sort(((a, b) => (a["value"]).compareTo(b["value"])));
      list = list.reversed.toList();
      break;
    case 4:
      list.sort(((a, b) =>
          (double.parse(a["value2"])).compareTo(double.parse(b["value2"]))));
      break;
    case 5:
      list.sort(((a, b) =>
          (double.parse(a["value2"])).compareTo(double.parse(b["value2"]))));
      list = list.reversed.toList();
      break;
    case 6:
      list.sort(
          ((a, b) => (a["ORDERREPLYTIME"]).compareTo(a["ORDERREPLYTIME"])));

      break;
    case 7:
      break;
  }
  return list;
}
