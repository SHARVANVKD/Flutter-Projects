import 'package:bloc/bloc.dart';
import 'package:meta/meta.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order/tab_controller_order_book/open/components/open_sort.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/sort.dart';
import 'package:selfie_mobile_flutter/services/api_gateway.dart';
import 'package:selfie_mobile_flutter/user_controller/user_controller.dart';
import 'package:trading_api/responses/order_status_item_response.dart';
part 'open_component_state.dart';

class OpenComponentCubit extends Cubit<OpenComponentState> {
  final TradingApiGateway gateway;

  OpenComponentCubit({
    required this.gateway,
  }) : super(OpenComponentInitial(
            openList: UserController.userController.openOrders));

  List<OrderStatusReportData> list = [];

  orderTypeUpdate(String val) {
    switch (val) {
      case "MARKET":
        {
          return "MKT";
        }
      case "LIMIT":
        {
          return "LMT";
        }
      case "SL-LIMIT":
        {
          return "STL";
        }
      case "BASKET ORDER":
        {
          return "BO";
        }
      case "CONFIRMED":
        {
          return "Confirmed";
        }
      case "PENDING":
        {
          return "Pending";
        }
      case "SAVED":
        {
          return "Saved";
        }
    }
    return val;
  }

  List<OrderStatusReportData> openSort(
      List<OrderStatusReportData> list, int index) {
    switch (index) {
      case 0:
        list.sort(((a, b) => (a.securitycode!).compareTo(b.securitycode!)));
        break;
      case 1:
        list.sort(((a, b) => (a.securitycode!).compareTo(b.securitycode!)));
        list = list.reversed.toList();
        break;
    }
    return list;
  }

  search(String keyword) async {
    if (keyword.isEmpty) {
      emit((state as OpenComponentInitial)
          .copyWith(openList: UserController().openOrders));
      return;
    }
    List<OrderStatusReportData> searchResult = [];
    List<OrderStatusReportData> searchSet = UserController().openOrders;
    int len = searchSet.length;
    searchResult.clear();
    for (int i = 0; i < len; i++) {
      if (searchSet[i]
              .securitycode
              .toString()
              .contains(keyword.toUpperCase()) ||
          searchSet[i]
              .securitycode
              .toString()
              .startsWith(keyword.toUpperCase())) {
        searchResult.add(searchSet[i]);
      }
    }
    if (searchResult.isEmpty) {
      emit((state as OpenComponentInitial).copyWith(openList: []));
      return;
    }
    emit((state as OpenComponentInitial).copyWith(openList: searchResult));
  }

  updateFiltertData(List<String> el) {
    List<OrderStatusReportData> filterSet = UserController().openOrders;
    list.clear();

    if (el.isEmpty) {
      emit((state as OpenComponentInitial).copyWith(openList: filterSet));
    } else {
      filterSet.forEach((element) {
        for (int i = 0; i < el.length; i++) {
          if (element.producttype == orderTypeUpdate(el[i].toUpperCase()) ||
              element.buyorsell == orderTypeUpdate(el[i].toUpperCase()) ||
              element.pricecondition == orderTypeUpdate(el[i].toUpperCase()) ||
              element.statussubcategory ==
                  orderTypeUpdate(el[i].toUpperCase())) {
            list.add(element);
          }
        }
      });
      if (list.isEmpty) {
        emit((state as OpenComponentInitial).copyWith(openList: []));
        return;
      }
      emit((state as OpenComponentInitial).copyWith(
        openList: list,
      ));
    }
  }

  updateSortData(int index) {
    List<OrderStatusReportData> list = [];
    List<OrderStatusReportData> sortSet = UserController().openOrders;

    list = openSort(sortSet, index);
    emit((state as OpenComponentInitial)
        .copyWith(openList: list, filterval: index));
  }

  resetList() {
    filterarrayposition.clear();
    emit((state as OpenComponentInitial).copyWith(
      openList: UserController().resetOpenOrders,
      filterval: -1,
    ));
  }

  updateData() {
    emit(
      OpenComponentInitial(
        openList: UserController().openOrders,
      ),
    );
  }
}
