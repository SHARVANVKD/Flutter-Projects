part of 'open_component_cubit.dart';

@immutable
abstract class OpenComponentState {}

class OpenComponentInitial extends OpenComponentState {
  List<OrderStatusReportData> openList;
  final bool searchActive;
  final bool filterActive;
  OrderStatusItemResponse? response;
  final int filterval;
  List<String>? filterarrayposition = [];
  OpenComponentInitial({
    this.searchActive = false,
    this.filterActive = false,
    required this.openList,
    this.response,
    this.filterval = -1,
    this.filterarrayposition,
  });

  OpenComponentInitial copyWith(
      {List<OrderStatusReportData>? openList,
      bool? searchActive,
      bool? filterActive,
      OrderStatusItemResponse? response,
      int? filterval,
      List<String>? filterarrayposition}) {
    return OpenComponentInitial(
      openList: openList ?? this.openList,
      filterarrayposition: filterarrayposition ?? this.filterarrayposition,
      filterval: filterval ?? this.filterval,
      searchActive: searchActive ?? this.searchActive,
      filterActive: filterActive ?? this.filterActive,
      response: response ?? this.response,
    );
  }
}

class OpenLoadingState extends OpenComponentState {}

class OpenLoadedState extends OpenComponentState {
  final List<Map<String, dynamic>> loadedList;
  OpenLoadedState({required this.loadedList});
}
