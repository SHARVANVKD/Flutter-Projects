import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/app_page_injectable.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order/order_book/cubit/order_book_screen_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order/order_status_bottom_sheet/complete_orders/bottom_sheet_header/orders_summary_completed_orders.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order/tab_controller_order_book/open/bloc/open_component_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/repository_layer/portfolio_content.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/scrollable_bottomsheet/scrollable_bottomsheet.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/search_insights_filter/order_book_open_filter_bar.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/textfields/position_search_field.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/order_book/empty_list_widget.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/order_book/filter/search_filter_order_book.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/order_book/open/open_list_item.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/fixed_bottom_buttons/fixed_bottom_buttons.dart';
import 'package:selfie_mobile_flutter/services/api_gateway.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';
import 'package:selfie_mobile_flutter/user_controller/user_controller.dart';

class OrderBookOpenComponent extends StatefulWidget {
  Function(bool) onScrollEvent;
  OrderBookOpenComponent({
    Key? key,
    required this.onScrollEvent,
  }) : super(key: key);

  @override
  State<OrderBookOpenComponent> createState() => _OrderBookOpenComponentState();
}

class _OrderBookOpenComponentState extends State<OrderBookOpenComponent>
    with TickerProviderStateMixin {
  bool orderCancelledStatus = true;
  int screenCount = 1;
  ScrollController _scrollBottomBarController = ScrollController();

  bool isScrollingDown = false;

  // bool search = false;
  bool showFilter = true;

  late TradingApiGateway _gateway;

  void initState() {
    super.initState();
    _gateway = context.gTradingApiGateway;
    _controller = BottomSheet.createAnimationController(this);
    _controller!.duration = const Duration(milliseconds: 400);
    myScroll();
  }

  @override
  void dispose() {
    _controller!.dispose();
    super.dispose();
  }

  void myScroll() async {
    _scrollBottomBarController.addListener(() {
      if (_scrollBottomBarController.position.userScrollDirection ==
          ScrollDirection.reverse) {
        if (!isScrollingDown) {
          isScrollingDown = true;
          widget.onScrollEvent(false); //hide appbar
        }
      }
      if (_scrollBottomBarController.position.userScrollDirection ==
          ScrollDirection.forward) {
        if (isScrollingDown) {
          isScrollingDown = false;
          widget.onScrollEvent(true); //show appbar
        }
      }
    });
  }

  AnimationController? _controller;
  final TextEditingController _serach = TextEditingController();
  bool notify = false;

  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(
      providers: [
        BlocProvider(
          create: (context) => OpenComponentCubit(gateway: _gateway),
        )
      ],
      child: RefreshIndicator(
        backgroundColor: customColors().primary,
        onRefresh: () async {
          BlocProvider.of<OrderBookScreenCubit>(context).orders();
        },
        child: Stack(
          children: [
            BlocListener<OrderBookScreenCubit, OrderBookScreenState>(
              listener: (context, state) {
                if (state is OrderBookScreenInitial) {
                  BlocProvider.of<OpenComponentCubit>(context).updateData();
                }
              },
              child: Container(),
            ),
            BlocBuilder<OpenComponentCubit, OpenComponentState>(
              builder: (context, state) {
                if (state is OpenComponentInitial) {
                  if (UserController.userController.openOrders.isEmpty) {
                    return Column(
                      children: const [
                        Padding(
                          padding: EdgeInsets.only(top: 100),
                          child: OrderbookEmptyContainer(
                              title: "No closed orders",
                              subTitle: "Lorem ipsum dolor sit ame"),
                        )
                      ],
                    );
                  } else {
                    return SingleChildScrollView(
                      padding: const EdgeInsets.only(top: 40.0),
                      physics: const BouncingScrollPhysics(),
                      controller: _scrollBottomBarController,
                      child: Column(
                        children: [
                          ListView.builder(
                            physics: const NeverScrollableScrollPhysics(),
                            itemCount: state.openList.length,
                            shrinkWrap: true,
                            itemBuilder: (context, index) {
                              return InkWell(
                                onTap: () {
                                  customBottomSheet(
                                    height: .76,
                                    maxHeight: .89,
                                    context: context,
                                    inputWidget: CompletedOrders(
                                      overViewList: state.openList,
                                      orderLogList: state.openList,
                                      index: index,
                                    ),
                                    fixedBottomWidget: OdrderBookFixedButton(
                                      elevation: true,
                                      modify: true,
                                    ),
                                  );
                                },
                                // onLongPress: () => context.gNavigationService
                                //     .openOrderOpenLongpressPage(
                                //         context, state.openList),
                                child: OpenListItem(
                                  openList: state.openList,
                                  index: index,
                                ),
                              );
                            },
                          ),
                        ],
                      ),
                    );
                  }
                } else if (state is OpenLoadingState) {
                  return const Text("");
                }
                return Container();
              },
            ),
            BlocBuilder<OpenComponentCubit, OpenComponentState>(
              builder: (context, state) {
                if (state is OpenComponentInitial) {
                  if (UserController.userController.openOrders.isNotEmpty) {
                    return Column(
                      children: [
                        Visibility(
                          visible: !state.searchActive,
                          child: SearchFilterHoldings(
                            onFilterPress: () {
                              customShowModalBottomSheet(
                                context: context,
                                inputWidget: OrderSortFilter(
                                  currentval: state.filterval,
                                  onPresssort: (int index) {
                                    BlocProvider.of<OpenComponentCubit>(context)
                                        .updateSortData(index);
                                  },
                                  onPressFilter: (List<String> el) {
                                    BlocProvider.of<OpenComponentCubit>(context)
                                        .updateFiltertData(el);
                                  },
                                  onPressReset: () {
                                    BlocProvider.of<OpenComponentCubit>(context)
                                        .resetList();
                                  },
                                ),
                              );
                            },
                            onSearchPress: () {
                              BlocProvider.of<OpenComponentCubit>(context).emit(
                                  state.copyWith(
                                      searchActive: true, filterActive: false));
                            },
                          ),
                        ),
                        Visibility(
                          visible: state.searchActive,
                          child: Position_Search_Field(
                            onBackPressed: () {
                              BlocProvider.of<OpenComponentCubit>(context).emit(
                                  state.copyWith(
                                      searchActive: false, filterActive: true));
                            },
                            hintText: "Search eg: infy",
                            controller: _serach,
                            onSearch: (String keyword) {
                              BlocProvider.of<OpenComponentCubit>(context)
                                  .search(keyword);
                            },
                          ),
                        ),
                      ],
                    );
                  }
                }
                return Container();
              },
            ),
          ],
        ),
      ),
    );
  }
}
