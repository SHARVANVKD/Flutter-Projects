import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/app_page_injectable.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order/order_book/cubit/order_book_screen_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order/order_status_bottom_sheet/complete_orders/bottom_sheet_header/orders_summary_completed_orders.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order/tab_controller_order_book/closed/bloc/closed_component_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order/tab_controller_order_book/open/bloc/open_component_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order/tab_controller_order_book/open/components/open_sort.dart';
import 'package:selfie_mobile_flutter/selfie/repository_layer/portfolio_content.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/scrollable_bottomsheet/scrollable_bottomsheet.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/search_insights_filter/order_book_open_filter_bar.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/textfields/position_search_field.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/order_book/closed/closed_list_item.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/order_book/empty_list_widget.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/order_book/filter/search_filter_order_book.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/fixed_bottom_buttons/fixed_bottom_buttons.dart';
import 'package:selfie_mobile_flutter/services/api_gateway.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';
import 'package:selfie_mobile_flutter/user_controller/user_controller.dart';

class OrderBookClosedComponent extends StatefulWidget {
  Function(bool) onScrollEvent;
  OrderBookClosedComponent({
    Key? key,
    required this.onScrollEvent,
  }) : super(key: key);

  @override
  State<OrderBookClosedComponent> createState() =>
      _OrderBookClosedComponentState();
}

class _OrderBookClosedComponentState extends State<OrderBookClosedComponent>
    with TickerProviderStateMixin {
  int screenCount = 1;
  ScrollController _scrollBottomBarController = new ScrollController();

  bool isScrollingDown = false;
  late TradingApiGateway _gateway;

  void initState() {
    // TODO: implement initState
    super.initState();
    _gateway = context.gTradingApiGateway;
    _controller = BottomSheet.createAnimationController(this);
    _controller!.duration = const Duration(milliseconds: 400);
    myScroll();
  }

  @override
  void dispose() {
    _controller!.dispose();
    super.dispose();
  }

  void myScroll() async {
    _scrollBottomBarController.addListener(() {
      if (_scrollBottomBarController.position.userScrollDirection ==
          ScrollDirection.reverse) {
        if (!isScrollingDown) {
          isScrollingDown = true;
          widget.onScrollEvent(false); //hide appbar
        }
      }
      if (_scrollBottomBarController.position.userScrollDirection ==
          ScrollDirection.forward) {
        if (isScrollingDown) {
          isScrollingDown = false;
          widget.onScrollEvent(true); //show appbar
        }
      }
    });
  }

  AnimationController? _controller;

  bool notify = false;
  bool search = false;
  bool showFilter = true;
  final TextEditingController _serach = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(
      providers: [
        BlocProvider(
          create: (context) => ClosedComponentCubit(gateway: _gateway),
        )
      ],
      child: RefreshIndicator(
        backgroundColor: customColors().primary,
        onRefresh: () async {
          BlocProvider.of<OrderBookScreenCubit>(context).orders();
        },
        child: Stack(
          children: [
            BlocListener<OrderBookScreenCubit, OrderBookScreenState>(
              listener: (context, state) {
                if (state is OrderBookScreenInitial) {
                  BlocProvider.of<ClosedComponentCubit>(context).updateData();
                }
              },
              child: Container(),
            ),
            BlocBuilder<ClosedComponentCubit, ClosedComponentState>(
              builder: (context, state) {
                if (state is ClosedComponentInitial) {
                  if (UserController().closedOrders.isEmpty) {
                    return Column(
                      children: const [
                        Padding(
                          padding: EdgeInsets.only(top: 100),
                          child: OrderbookEmptyContainer(
                              title: "No closed orders",
                              subTitle: "Lorem ipsum dolor sit ame"),
                        )
                      ],
                    );
                  } else {
                    return SingleChildScrollView(
                      padding: const EdgeInsets.only(top: 26.0),
                      physics: const BouncingScrollPhysics(),
                      controller: _scrollBottomBarController,
                      child: Column(
                        children: [
                          ListView.builder(
                              physics: const NeverScrollableScrollPhysics(),
                              itemCount: state.closedList.length,
                              shrinkWrap: true,
                              itemBuilder: (context, index) {
                                return InkWell(
                                  onTap: () {
                                    customBottomSheet(
                                      height: .76,
                                      maxHeight: .89,
                                      context: context,
                                      inputWidget: CompletedOrders(
                                        overViewList: state.closedList,
                                        orderLogList: state.closedList,
                                        index: index,
                                      ),
                                      fixedBottomWidget: OdrderBookFixedButton(
                                        elevation: true,
                                        modify: false,
                                      ),
                                    );
                                  },
                                  child: ClosedListTile(
                                    closedList: state.closedList,
                                    index: index,
                                  ),
                                );
                              }),
                        ],
                      ),
                    );
                  }
                } else if (state is OpenLoadingState) {
                  return const Text("");
                }
                return Container();
              },
            ),
            BlocBuilder<ClosedComponentCubit, ClosedComponentState>(
              builder: (context, state) {
                if (state is ClosedComponentInitial) {
                  if (UserController.userController.closedOrders.isNotEmpty) {
                    return Column(
                      children: [
                        Visibility(
                          visible: !state.searchActive,
                          child: SearchFilterHoldings(
                            onFilterPress: () {
                              customShowModalBottomSheet(
                                context: context,
                                inputWidget: OrderSortFilter(
                                  currentval: state.filterval,
                                  onPresssort: (int index) {
                                    BlocProvider.of<ClosedComponentCubit>(
                                            context)
                                        .updateSortData(index);
                                  },
                                  onPressFilter: (List<String> el) {
                                    BlocProvider.of<ClosedComponentCubit>(
                                            context)
                                        .updateFiltertData(el);
                                  },
                                  onPressReset: () {
                                    BlocProvider.of<ClosedComponentCubit>(
                                            context)
                                        .resetList();
                                  },
                                ),
                              );
                            },
                            onSearchPress: () {
                              BlocProvider.of<ClosedComponentCubit>(context)
                                  .emit(state.copyWith(
                                      searchActive: true, filterActive: false));
                            },
                          ),
                        ),
                        Visibility(
                          visible: state.searchActive,
                          child: Position_Search_Field(
                            onBackPressed: () {
                              BlocProvider.of<ClosedComponentCubit>(context)
                                  .emit(state.copyWith(
                                      searchActive: false, filterActive: true));
                            },
                            hintText: "Search eg: infy",
                            controller: _serach,
                            onSearch: (String keyword) {
                              BlocProvider.of<ClosedComponentCubit>(context)
                                  .search(keyword);
                            },
                          ),
                        ),
                      ],
                    );
                  }
                }
                return Container();
              },
            ),
          ],
        ),
      ),
    );
  }
}
