part of 'closed_component_cubit.dart';

@immutable
abstract class ClosedComponentState {}

class ClosedComponentInitial extends ClosedComponentState {
  final List<OrderStatusReportData> closedList;
  final bool searchActive;
  final bool filterActive;
  OrderStatusItemResponse? response;
  final int filterval;
  List<String>? filterarrayposition = [];
  ClosedComponentInitial({
    required this.closedList,
    this.searchActive = false,
    this.filterActive = false,
    this.response,
    this.filterval = 0,
    this.filterarrayposition,
  });

  ClosedComponentInitial copyWith(
      {List<OrderStatusReportData>? closedList,
      bool? searchActive,
      bool? filterActive,
      OrderStatusItemResponse? response,
      int? filterval,
      List<String>? filterarrayposition}) {
    return ClosedComponentInitial(
      closedList: closedList ?? this.closedList,
      filterarrayposition: filterarrayposition ?? this.filterarrayposition,
      filterval: filterval ?? this.filterval,
      searchActive: searchActive ??  this.searchActive,
      filterActive:  filterActive ??  this.filterActive,
      response: response ?? response,
    );
  }
}

class ClosedLoadingState extends ClosedComponentState {}
