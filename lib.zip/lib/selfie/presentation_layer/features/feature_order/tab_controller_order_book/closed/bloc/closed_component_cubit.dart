import 'package:bloc/bloc.dart';
import 'package:meta/meta.dart';
import 'package:selfie_mobile_flutter/services/api_gateway.dart';
import 'package:selfie_mobile_flutter/user_controller/user_controller.dart';
import 'package:trading_api/responses/order_status_item_response.dart';

part 'closed_component_state.dart';

class ClosedComponentCubit extends Cubit<ClosedComponentState> {
  final TradingApiGateway gateway;
  ClosedComponentCubit({required this.gateway})
      : super(
          ClosedComponentInitial(closedList: UserController().closedOrders),
        );

  List<OrderStatusReportData> list = [];

  orderTypeUpdate(String val) {
    switch (val) {
      case "MARKET":
        {
          return "MKT";
        }
      case "LIMIT":
        {
          return "LMT";
        }
      case "SL-LIMIT":
        {
          return "STL";
        }
      case "BASKET ORDER":
        {
          return "BO";
        }
      case "CONFIRMED":
        {
          return "Confirmed";
        }
      case "PENDING":
        {
          return "Pending";
        }
      case "SAVED":
        {
          return "Saved";
        }
    }
    return val;
  }

  List<OrderStatusReportData> closedSort(
      List<OrderStatusReportData> list, int index) {
    switch (index) {
      case 0:
        list.sort(((a, b) => (a.securitycode!).compareTo(b.securitycode!)));
        break;
      case 1:
        list.sort(((a, b) => (a.securitycode!).compareTo(b.securitycode!)));
        list = list.reversed.toList();
        break;
    }
    return list;
  }

  closedOrdersList() async {
    emit(
      ClosedComponentInitial(
        closedList: UserController().closedOrders,
      ),
    );
  }

  search(String keyword) async {
    if (keyword.isEmpty) {
      emit((state as ClosedComponentInitial)
          .copyWith(closedList: UserController().closedOrders));
      return;
    }

    List<OrderStatusReportData> searchResult = [];
    List<OrderStatusReportData> searchSet = UserController().closedOrders;

    int len = searchSet.length;
    searchResult.clear();
    for (int i = 0; i < len; i++) {
      if (searchSet[i]
              .securitycode
              .toString()
              .contains(keyword.toUpperCase()) ||
          searchSet[i]
              .securitycode
              .toString()
              .startsWith(keyword.toUpperCase())) {
        searchResult.add(searchSet[i]);
      }
    }
    if (searchResult.isEmpty) {
      emit((state as ClosedComponentInitial).copyWith(closedList: []));
      return;
    }
    emit((state as ClosedComponentInitial).copyWith(closedList: searchResult));
  }

  updateSortList(List<OrderStatusReportData> list) {
    emit((state as ClosedComponentInitial).copyWith(closedList: list));
  }

  resetList() {
    emit((state as ClosedComponentInitial).copyWith(
        closedList: UserController().resetClosedOrders, filterval: -1));
  }

  updateSortData(int index) {
    List<OrderStatusReportData> list = [];
    List<OrderStatusReportData> sortSet = UserController().closedOrders;

    list = closedSort(sortSet, index);

    emit((state as ClosedComponentInitial)
        .copyWith(closedList: list, filterval: index));
  }

  updateFiltertData(List<String> el) {
    List<OrderStatusReportData> filterSet = UserController().closedOrders;
    list.clear();

    if (el.isEmpty) {
      emit((state as ClosedComponentInitial).copyWith(closedList: filterSet));
    } else {
      filterSet.forEach((element) {
        for (int i = 0; i < el.length; i++) {
          if (element.producttype == orderTypeUpdate(el[i].toUpperCase()) ||
              element.buyorsell == orderTypeUpdate(el[i].toUpperCase()) ||
              element.pricecondition == orderTypeUpdate(el[i].toUpperCase()) ||
              element.statussubcategory ==
                  orderTypeUpdate(el[i].toUpperCase())) {
            list.add(element);
          } else {
            emit((state as ClosedComponentInitial)
                .copyWith(closedList: filterSet));
          }
        }
      });
      if (list.isEmpty) {
        emit((state as ClosedComponentInitial).copyWith(closedList: []));
        return;
      }
      emit((state as ClosedComponentInitial).copyWith(
        closedList: list,
      ));
    }
  }

  updateData() {
    emit(
      ClosedComponentInitial(
        closedList: UserController().closedOrders,
      ),
    );
  }
}
