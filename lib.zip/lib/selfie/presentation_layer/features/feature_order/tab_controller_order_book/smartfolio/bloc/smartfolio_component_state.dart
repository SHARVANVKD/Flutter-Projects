part of 'smartfolio_component_cubit.dart';

@immutable
abstract class SmartfolioComponentState {}

class SmartfolioComponentInitial extends SmartfolioComponentState {
  final List<Map<String, dynamic>> smartfolioList;
  final bool searchVisible;

  SmartfolioComponentInitial({required this.smartfolioList, this.searchVisible=false});
}
