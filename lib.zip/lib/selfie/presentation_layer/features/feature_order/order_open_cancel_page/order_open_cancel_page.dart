import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/repository_layer/order_book_content.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/buttons/BasketButton.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/order_book/open/open_list_item_selected.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class OrderOpenCancelPage extends StatefulWidget {
  final List<Map<String, dynamic>> data;

  const OrderOpenCancelPage({Key? key, required this.data}) : super(key: key);

  @override
  State<OrderOpenCancelPage> createState() => _OrderOpenCancelPageState();
}

class _OrderOpenCancelPageState extends State<OrderOpenCancelPage> {
  List<String> checklist = [];

  int checkcount = 0;
  AnimationController? _controller;
  @override
  Widget build(BuildContext context) {
    // double mheight = MediaQuery.of(context).size.height;
    Size screenSize = MediaQuery.of(context).size;
    return Scaffold(
      appBar: PreferredSize(
          preferredSize: const Size.fromHeight(0.0),
          child: AppBar(
            elevation: 0,
            backgroundColor: customColors().backgroundPrimary,
          )),
      bottomNavigationBar: Padding(
        padding: const EdgeInsets.only(bottom: 12.0),
        child: SizedBox(
          height: screenSize.height * 0.13,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Divider(
                thickness: 1.0,
                color: customColors().backgroundTertiary,
              ),
              Padding(
                padding:
                    const EdgeInsets.only(left: 16.0, right: 16.0, top: 8.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Expanded(
                      flex: 2,
                      child: Padding(
                        padding: const EdgeInsets.only(left: 8.0),
                        child: BasketButton(
                            text:
                                "Cancel Orders ${(checkcount > 0) ? "($checkcount)" : ""}",
                            bgcolor: checkcount == 0
                                ? customColors().danger.withOpacity(0.4)
                                : customColors().danger,
                            bordercolor: checkcount == 0
                                ? customColors().danger.withOpacity(0.1)
                                : customColors().danger,
                            textStyle: customTextStyle(
                                fontStyle: FontStyle.BodyL_Bold,
                                color: FontColor.White)),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
      body: Column(
        children: [
          Container(
            //    width: MediaQuery.of(context).size.width,
            decoration: BoxDecoration(
                border: Border(
                    bottom: BorderSide(
                        width: 2.0, color: customColors().backgroundTertiary))),
            child: Padding(
              padding: EdgeInsets.only(top: screenSize.height * .04, left: 16),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  // IconButton(alignment: Alignment.centerLeft,
                  //     onPressed: () {
                  //       Navigator.pop(context);
                  //     },
                  //     padding: EdgeInsets.zero,
                  //     icon: ImageIcon(AssetImage("assets/arrow_left.png"),
                  //         size: 24)),
                  InkWell(
                      onTap: () => Navigator.pop(context),
                      child: Image.asset("assets/arrow_left.png")),
                  SizedBox(width: 6),
                  Expanded(
                    child: SizedBox(
                      width: double.maxFinite,
                      child: Row(
                        children: [
                          Text(
                            checkcount.toString() +
                                "/" +
                                widget.data.length.toString(),
                            style: customTextStyle(
                                fontStyle: FontStyle.BodyL_SemiBold,
                                color: FontColor.FontPrimary),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(left: 8.0),
                            child: Text(
                              "Selected",
                              style: customTextStyle(
                                  fontStyle: FontStyle.BodyL_SemiBold,
                                  color: FontColor.FontSecondary),
                            ),
                          )
                        ],
                      ),
                    ),
                  ),
                  Row(
                    children: [
                      Text(
                        "All",
                        style: customTextStyle(
                            fontStyle: FontStyle.BodyL_Regular,
                            color: FontColor.FontPrimary),
                      ),
                      Checkbox(
                        activeColor: customColors().primary,
                        onChanged: (value) {
                          checkall();
                        },
                        value: checklist.length == widget.data.length
                            ? true
                            : false,
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
          Expanded(
            child: SingleChildScrollView(
              child: Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.only(top: 5.0),
                    child: ListView.builder(
                        itemCount: widget.data.length,
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        itemBuilder: (context, index) {
                          return OpenListItemSelected(
                            openSamples: widget.data[index],
                            checklist: checklist,
                            upcount: updatecount,
                          );
                        }),
                  ),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  void checkall() {
    setState(() {
      if (checklist.isEmpty) {
        for (int i = 0; i < widget.data.length; i++) {
          checklist.add(widget.data[i]["SECURITYCODE"]);
        }
      } else {
        checklist.clear();
      }
      checkcount = checklist.length;
    });
  }

  void updatecount(int count) {
    setState(() {
      checkcount = count;
    });
  }
}
