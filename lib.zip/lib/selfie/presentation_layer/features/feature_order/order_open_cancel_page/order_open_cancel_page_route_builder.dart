import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order/order_open_cancel_page/order_open_cancel_page.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/workspace/bloc/workspace_cubit.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';

class OrderOpenCancelPageRoute {
  final ServiceLocator _serviceLocator;
  final List<Map<String, dynamic>> data;

  OrderOpenCancelPageRoute(this._serviceLocator, this.data);

  Widget call(BuildContext context) {
    return MultiBlocProvider(
        providers: [
          BlocProvider(
              create: (context) =>
                  WorkSpaceCubit(serviceLocator: _serviceLocator))
        ],
        child: MultiRepositoryProvider(
            providers: [
              RepositoryProvider.value(
                  value: _serviceLocator.navigationService),
              RepositoryProvider.value(value: _serviceLocator)
            ],
            child: OrderOpenCancelPage(
              data: data,
            )));
  }
}
