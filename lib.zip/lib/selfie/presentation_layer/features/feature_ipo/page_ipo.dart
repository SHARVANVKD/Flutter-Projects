import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_ipo/tabs/applied/applied.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_ipo/tabs/ipo_listing/ipo_listing_page.dart';

import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_more/page_more_alerts/tabs/more_alerts/alerts_empty_container.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_more/page_more_alerts/tabs/more_triggered/more_triggered.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/appbar/settingsAppbar.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class Ipo extends StatefulWidget {
  const Ipo({Key? key}) : super(key: key);

  @override
  State<Ipo> createState() => _IpoState();
}

class _IpoState extends State<Ipo> with SingleTickerProviderStateMixin {
  int initialIndex = 0;
  String tabName = "Active";
  int index = 0;
  late TabController _controller;

  List<Widget> alertswidgets = [];

  List<Tab> tablist = [
    const Tab(
      text: "IPO Listings",
    ),
    const Tab(
      text: "Applied",
    ),
  ];

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    initialIndex = 0;
    tabName = "Active";
    _controller = TabController(length: tablist.length, vsync: this);

    _controller.addListener(() {
      setState(() {
        initialIndex = _controller.index;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    alertswidgets = [
      const IpoListingPage(),
      AppliedTab(),
    ];

    return Scaffold(
        backgroundColor: customColors().backgroundPrimary,
        appBar: PreferredSize(
            preferredSize: const Size.fromHeight(0.0),
            child: AppBar(
              elevation: 0,
              backgroundColor: customColors().backgroundPrimary,
            )),
        body: Stack(
          children: [
            Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SettingsAppbar(
                    title: "Initial Public Offering (IPO)",
                    onBackPressed: () {
                      Navigator.pop(context);
                    },
                    onResetPressed: () {},
                    buttonname: ""),
                Padding(
                  padding: const EdgeInsets.only(top: 10),
                  child: Container(
                    width: MediaQuery.of(context).size.width,
                    decoration: BoxDecoration(
                      border: Border(
                          bottom: BorderSide(
                              width: 1.0,
                              color: customColors().backgroundTertiary)),
                    ),
                    child: MediaQuery.removePadding(
                      context: context,
                      removeTop: true,
                      child: TabBar(
                        controller: _controller,
                        tabs: tablist,
                        isScrollable: true,
                        labelStyle: customTextStyle(
                            fontStyle: FontStyle.BodyL_SemiBold,
                            color: FontColor.Primary),
                        labelColor: customColors().primary,
                        indicatorSize: TabBarIndicatorSize.label,
                        indicatorColor: customColors().primary,
                        unselectedLabelStyle: customTextStyle(
                            fontStyle: FontStyle.BodyL_Regular,
                            color: FontColor.FontSecondary),
                        unselectedLabelColor: customColors().fontSecondary,
                      ),
                    ),
                  ),
                ),
                Expanded(
                  child: TabBarView(
                    children: alertswidgets,
                    controller: _controller,
                  ),
                ),
              ],
            )
          ],
        ));
  }
}
