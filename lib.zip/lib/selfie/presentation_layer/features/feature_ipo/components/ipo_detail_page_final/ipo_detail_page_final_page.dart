import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:just_the_tooltip/just_the_tooltip.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_ipo/components/bid_tile.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_ipo/components/bottomsheet/demat_account_bottomsheet.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_ipo/components/bottomsheet/investo_type_bottomsheet.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_ipo/components/bottomsheet/upi_id_selection_bottomsheet.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/appbar/custom_ipo_appbar.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/buttons/BasketButton.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/scrollable_bottomsheet/scrollable_bottomsheet.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/textfields/custom_text_form_field.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/textfields/formatters.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/default_order_settings/default_order_settings_values.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/stock/empty_custom_checkbox/empty_custom_checkbox.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';
import 'package:selfie_mobile_flutter/app_page_injectable.dart';

class IpoDetailPageFinal extends StatefulWidget {
  const IpoDetailPageFinal({Key? key}) : super(key: key);

  @override
  State<IpoDetailPageFinal> createState() => _IpoDetailPageFinalState();
}

class _IpoDetailPageFinalState extends State<IpoDetailPageFinal> {
  TextEditingController _upiController = TextEditingController();

  final TextEditingController _nameController =
      TextEditingController(text: "Jaydeep Nandhu");

  final TextEditingController _panController =
      TextEditingController(text: "BIKEPN0698G");

  TextEditingController lots = TextEditingController(text: "1");
  TextEditingController price = TextEditingController(text: "300");
  JustTheController? controller = JustTheController();

  bool checkBoxEnable = false;

  bool cutOff = false;

  final _formKey = GlobalKey<FormState>();

  ScrollController scrollController = new ScrollController();
  bool isVisible = true;

  @override
  initState() {
    super.initState();
    scrollController.addListener(() {
      if (scrollController.position.userScrollDirection ==
          ScrollDirection.reverse) {
        if (isVisible)
          setState(() {
            isVisible = false;
          });
      }
      if (scrollController.position.userScrollDirection ==
          ScrollDirection.forward) {
        if (!isVisible)
          setState(() {
            isVisible = true;
          });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    TextStyle detailStyleOne = customTextStyle(
      fontStyle: FontStyle.BodyM_Regular,
      color: FontColor.FontSecondary,
    );

    TextStyle detailStyleTwo = customTextStyle(
      fontStyle: FontStyle.BodyM_SemiBold,
      color: FontColor.FontPrimary,
    );
    return Scaffold(
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
            border: Border(
          top: BorderSide(color: customColors().backgroundTertiary),
        )),
        height: 72,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12.0),
          child: Row(children: [
            Expanded(
              child: BasketButton(
                bordercolor: transparent,
                bgcolor: customColors().primary,
                text: "Apply Now!",
                textStyle: customTextStyle(
                    fontStyle: FontStyle.BodyL_Bold, color: FontColor.White),
                onpress: () {
                  if (_formKey.currentState!.validate() &&
                      checkBoxEnable == true) {
                    context.gNavigationService
                        .openIpoApplicationSubmissionPage(context);
                  }
                },
              ),
            ),
          ]),
        ),
      ),
      body: SafeArea(
        child: Column(
          children: [
            IpoAppBar(
              title: "IPO Details",
              iconPress: () {
                Navigator.pop(context);
              },
            ),
            Container(
              width: MediaQuery.of(context).size.width,
              color: customColors().backgroundSecondary,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 20, 0, 16),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Image.asset("assets/lic.png"),
                    Padding(
                      padding: const EdgeInsets.only(left: 16),
                      child: Text(
                        "Life Insurance Corporation\nof India - LIC",
                        maxLines: 2,
                        style: customTextStyle(
                          fontStyle: FontStyle.BodyL_SemiBold,
                          color: FontColor.FontPrimary,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Divider(
              height: 1,
              thickness: 1.2,
              color: customColors().backgroundTertiary,
            ),
            Expanded(
              child: SingleChildScrollView(
                controller: scrollController,
                child: Column(
                  children: [
                    // detailCard(context, detailStyleOne, detailStyleTwo),
                    AnimatedContainer(
                      duration: const Duration(milliseconds: 400),
                      height: isVisible ? 165.0 : 0.0,
                      child:
                          detailCard(context, detailStyleOne, detailStyleTwo),
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 16, vertical: 12),
                      child: Form(
                        key: _formKey,
                        child: Container(
                          color: customColors().backgroundPrimary,
                          child: Column(
                            children: [
                              BidTile(),
                              const SizedBox(
                                height: 20,
                              ),
                              InkWell(
                                onTap: () {
                                  customShowModalBottomSheet(
                                      context: context,
                                      inputWidget: InvestorTypeBottomSheet(
                                        onpress: (v) {
                                          setState(() {});
                                          Navigator.pop(context);
                                        },
                                      ));
                                },
                                child: Container(
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(4),
                                      border: Border.all(
                                          color: customColors()
                                              .backgroundTertiary)),
                                  child: Padding(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 16),
                                    child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Padding(
                                          padding: const EdgeInsets.only(
                                              top: 10, bottom: 10),
                                          child: Text(
                                            "Investor Type",
                                            style: customTextStyle(
                                                fontStyle:
                                                    FontStyle.BodyL_SemiBold,
                                                color: FontColor.FontPrimary),
                                          ),
                                        ),
                                        Row(
                                          children: [
                                            Text(
                                              investorType == 0
                                                  ? "Individual Investor"
                                                  : "Employee",
                                              style: customTextStyle(
                                                  fontStyle:
                                                      FontStyle.BodyL_SemiBold,
                                                  color: FontColor.Primary),
                                            ),
                                            Padding(
                                              padding: const EdgeInsets.only(
                                                  left: 8),
                                              child: Image.asset(
                                                "assets/arrow_down.png",
                                                color: customColors().primary,
                                              ),
                                            )
                                          ],
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.only(top: 12),
                                child: InkWell(
                                  onTap: () {
                                    customShowModalBottomSheet(
                                        context: context,
                                        inputWidget: DematAccount(
                                          onpress: (v) {
                                            setState(() {});
                                            Navigator.pop(context);
                                          },
                                        ));
                                  },
                                  child: Container(
                                    decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(4),
                                        border: Border.all(
                                            color: customColors()
                                                .backgroundTertiary)),
                                    child: Padding(
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 16),
                                      child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        children: [
                                          Padding(
                                            padding: const EdgeInsets.only(
                                                top: 10, bottom: 10),
                                            child: Text(
                                              "Demat Account",
                                              style: customTextStyle(
                                                  fontStyle:
                                                      FontStyle.BodyL_SemiBold,
                                                  color: FontColor.FontPrimary),
                                            ),
                                          ),
                                          Row(
                                            children: [
                                              Text(
                                                dematAccount == 0
                                                    ? "0123456789012345"
                                                    : "2123456789012345",
                                                style: customTextStyle(
                                                    fontStyle: FontStyle
                                                        .BodyL_SemiBold,
                                                    color: FontColor.Primary),
                                              ),
                                              Padding(
                                                padding: const EdgeInsets.only(
                                                    left: 8),
                                                child: Image.asset(
                                                  "assets/arrow_down.png",
                                                  color: customColors().primary,
                                                ),
                                              )
                                            ],
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Padding(
                                padding:
                                    const EdgeInsets.only(top: 12, bottom: 46),
                                child: CustomTextFormField(
                                  controller: _upiController,
                                  fieldName: '',
                                  hintText: 'Enter UPI ID',
                                  validator: Validator.upi,
                                  suffixIcon: InkWell(
                                    onTap: () {
                                      customShowModalBottomSheet(
                                        context: context,
                                        inputWidget: UpiIdSelectionBottomSheet(
                                          onpress: (v) {
                                            setState(() {});
                                            Navigator.pop(context);
                                          },
                                        ),
                                      );
                                    },
                                    child: SizedBox(
                                      width: 90,
                                      child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.end,
                                        children: [
                                          Text(
                                            upiId == 0
                                                ? "@Ybl"
                                                : upiId == 1
                                                    ? "@HDFC"
                                                    : upiId == 2
                                                        ? "@ibl"
                                                        : upiId == 3
                                                            ? "@axl"
                                                            : upiId == 4
                                                                ? "@sbi"
                                                                : "",
                                            style: customTextStyle(
                                                fontStyle:
                                                    FontStyle.BodyL_SemiBold,
                                                color: FontColor.Primary),
                                          ),
                                          Padding(
                                            padding: const EdgeInsets.only(
                                                left: 8, right: 20),
                                            child: Image.asset(
                                              "assets/arrow_down.png",
                                              color: customColors().primary,
                                            ),
                                          )
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              CustomTextFormField(
                                controller: _nameController,
                                fieldName: 'Name*',
                                hintText: '',
                              ),
                              Padding(
                                padding: const EdgeInsets.only(top: 12),
                                child: CustomTextFormField(
                                  controller: _panController,
                                  fieldName: 'PAN*',
                                  hintText: '',
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.only(top: 16),
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    EmptyCustomCheckBox(
                                      callback: (bool enable) {
                                        setState(() {
                                          checkBoxEnable = enable;
                                        });
                                      },
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.only(left: 10),
                                      child: Text(
                                        "I hereby undertake that I have read the Red Herring\nProspectus and I am eligible bidder as per the\napplicable provisions of SEBI (Issue of Capital &\nDisclosure Agreement, 2009) regulations.",
                                        style: customTextStyle(
                                            fontStyle: FontStyle.BodyM_Regular,
                                            color: FontColor.FontPrimary),
                                      ),
                                    )
                                  ],
                                ),
                              ),
                              checkBoxEnable
                                  ? const SizedBox()
                                  : Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: [
                                        Padding(
                                          padding: const EdgeInsets.only(
                                              top: 12, bottom: 12, left: 36),
                                          child: Text(
                                              "Agree to terms & condition",
                                              style: customTextStyle(
                                                  fontStyle:
                                                      FontStyle.BodyM_Regular,
                                                  color: FontColor.Danger)),
                                        ),
                                      ],
                                    )
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Container BidTile() {
    return Container(
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(4),
          border: Border.all(color: customColors().backgroundTertiary)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Padding(
            padding: const EdgeInsets.only(left: 16, top: 13),
            child: Text(
              "Bid",
              style: customTextStyle(
                  fontStyle: FontStyle.BodyL_SemiBold,
                  color: FontColor.FontPrimary),
            ),
          ),
          Divider(
            color: customColors().backgroundTertiary,
            thickness: 1.2,
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: SizedBox(
              height: 100,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Expanded(
                    child: Column(
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              "Lots",
                              style: customTextStyle(
                                  fontStyle: FontStyle.BodyL_Regular,
                                  color: FontColor.FontPrimary),
                            ),
                            Text(
                              "Qty: 3000",
                              style: customTextStyle(
                                  fontStyle: FontStyle.BodyM_Regular,
                                  color: FontColor.FontSecondary),
                            ),
                          ],
                        ),
                        CustomTextFormField(
                          enabled: cutOff ? false : true,
                          controller: lots,
                          keyboardType: TextInputType.number,
                          inputFormatter: [DecimalFormatter()],
                          fieldName: "",
                        ),
                      ],
                    ),
                  ),
                  Expanded(
                      child: Padding(
                    padding: const EdgeInsets.only(left: 16.0),
                    child: CustomTextFormField(
                      enabled: cutOff ? false : true,
                      validator: Validator.price,
                      controller: price,
                      keyboardType: TextInputType.number,
                      inputFormatter: [DecimalFormatter()],
                      fieldName: "Price",
                    ),
                  ))
                ],
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 0, right: 0.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Padding(
                  padding: const EdgeInsets.only(left: 16),
                  child: Row(
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(right: 10),
                        child: EmptyCustomCheckBox(
                          callback: (bool box) {
                            setState(() {
                              cutOff = box;
                            });
                          },
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(right: 5),
                        child: Text(
                          "Apply Cut-off Price",
                          style: customTextStyle(
                              fontStyle: FontStyle.BodyL_Regular,
                              color: FontColor.FontPrimary),
                        ),
                      ),
                      JustTheTooltip(
                        offset: 2.0,
                        backgroundColor: customColors().backgroundSecondary,
                        preferredDirection: AxisDirection.up,
                        controller: controller,
                        margin: EdgeInsets.symmetric(vertical: 20.0),
                        child: Material(
                            child: Container(
                          height: 22.0,
                          width: 22.0,
                          child: Center(
                              child: InkWell(
                            onTap: () {
                              controller?.showTooltip();
                            },
                            child: Icon(
                              Icons.info_outline_rounded,
                              size: 14.0,
                            ),
                          )),
                        )),
                        content: Container(
                          child: Padding(
                              padding: EdgeInsets.only(
                                  top: 16.0,
                                  left: 10.0,
                                  right: 10.0,
                                  bottom: 10.0),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Text(
                                    "Cut-off Price",
                                    style: customTextStyle(
                                        fontStyle: FontStyle.BodyM_SemiBold,
                                        color: FontColor.FontPrimary),
                                  ),
                                  Padding(
                                      padding: EdgeInsets.only(
                                          top: 16.0, right: 10.0),
                                      child: Container(
                                        width: 268,
                                        child: Text(
                                          "The cut-off price is the offer price at which the shares get issued to the investors, which could be any price within the price band. In case you select cut-off, you are eligible for allotment at any discovered issue price.",
                                          style: customTextStyle(
                                              fontStyle:
                                                  FontStyle.BodyS_Regular,
                                              color: FontColor.FontPrimary),
                                          textAlign: TextAlign.justify,
                                        ),
                                      )),
                                ],
                              )),
                        ),
                      )
                    ],
                  ),
                ),

                // Checkbox(
                //     activeColor: customColors().primary,
                //     value: widget.mmarray['value'],
                //     onChanged: (v) {
                //       setState(() {
                //         widget.mmarray['value'] = v;
                //       });
                //     })
              ],
            ),
          ),
          Padding(
            padding:
                const EdgeInsets.only(left: 16, right: 16, top: 10, bottom: 12),
            child: Divider(
              color: customColors().backgroundTertiary,
              thickness: 1.2,
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  "Total Investment",
                  style: customTextStyle(
                      fontStyle: FontStyle.BodyL_SemiBold,
                      color: FontColor.FontPrimary),
                ),
                Text(
                  "90,000",
                  style: customTextStyle(
                      fontStyle: FontStyle.BodyM_Bold,
                      color: FontColor.FontPrimary),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Container detailCard(BuildContext context, TextStyle detailStyleOne,
      TextStyle detailStyleTwo) {
    return Container(
      width: MediaQuery.of(context).size.width,
      color: customColors().backgroundSecondary,
      child: Padding(
        padding: const EdgeInsets.only(left: 16),
        child: Wrap(
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(
                  height: 13,
                ),
                Text(
                  "Date",
                  style: detailStyleOne,
                ),
                const SizedBox(
                  height: 13,
                ),
                Text(
                  "Issue Size",
                  style: detailStyleOne,
                ),
                const SizedBox(
                  height: 13,
                ),
                Text(
                  "Min Investment",
                  style: detailStyleOne,
                ),
                const SizedBox(
                  height: 13,
                ),
                Text(
                  "Min Qty",
                  style: detailStyleOne,
                ),
                const SizedBox(
                  height: 13,
                ),
                Text(
                  "Price Band",
                  style: detailStyleOne,
                ),
                const SizedBox(
                  height: 13,
                ),
              ],
            ),
            Padding(
              padding: const EdgeInsets.only(left: 76),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SizedBox(
                    height: 13,
                  ),
                  Text(
                    "18 Feb’22 - 22 Feb’22",
                    style: detailStyleTwo,
                  ),
                  const SizedBox(
                    height: 13,
                  ),
                  Text(
                    "150 Crore",
                    style: detailStyleTwo,
                  ),
                  const SizedBox(
                    height: 13,
                  ),
                  Text(
                    "50,000.00",
                    style: detailStyleTwo,
                  ),
                  const SizedBox(
                    height: 13,
                  ),
                  Text(
                    "5000",
                    style: detailStyleTwo,
                  ),
                  const SizedBox(
                    height: 13,
                  ),
                  Text(
                    "200-300",
                    style: detailStyleTwo,
                  ),
                  const SizedBox(
                    height: 13,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
