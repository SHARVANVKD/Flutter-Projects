import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_ipo/components/bid_tile.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_ipo/components/bottomsheet/demat_account_bottomsheet.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_ipo/components/bottomsheet/investo_type_bottomsheet.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_ipo/components/bottomsheet/upi_id_selection_bottomsheet.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_ipo/components/ipo_detail_page/ipo_detail_tabbar/ipo_detail_tabbar.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_ipo/components/ipo_detail_page/ipo_detail_tabbar/tabs/overview.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_ipo/components/ipo_detail_page/ipo_detail_tabbar/tabs/status_log.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_more/page_setting_others/components/log_out_bottomsheet.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/appbar/custom_ipo_appbar.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/scrollable_bottomsheet/scrollable_bottomsheet.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/textfields/custom_text_form_field.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/default_order_settings/default_order_settings_values.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/stock/empty_custom_checkbox/empty_custom_checkbox.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';
import 'package:selfie_mobile_flutter/app_page_injectable.dart';

import '../../../../../widgets/custom_app_components/buttons/BasketButton.dart';

class IpoDetailPage extends StatefulWidget {
  const IpoDetailPage({Key? key}) : super(key: key);

  @override
  State<IpoDetailPage> createState() => _IpoDetailPageState();
}

class _IpoDetailPageState extends State<IpoDetailPage>
    with SingleTickerProviderStateMixin {
  int initialIndex = 0;
  String tabName = "Active";
  int index = 0;
  late TabController _controller;

  List<Widget> alertswidgets = [];

  List<Tab> tablist = [
    const Tab(
      text: "Overview",
    ),
    const Tab(
      text: "Status Log",
    ),
  ];

  ScrollController scrollController = ScrollController();

  bool isVisible = true;

  @override
  initState() {
    super.initState();
    initialIndex = 0;
    tabName = "Active";
    _controller = TabController(length: tablist.length, vsync: this);
  }

  @override
  Widget build(BuildContext context) {
    alertswidgets = [
      IpoOverView(),
      IpoStatusLog(),
    ];
    TextStyle detailStyleOne = customTextStyle(
      fontStyle: FontStyle.BodyM_Regular,
      color: FontColor.FontSecondary,
    );

    TextStyle detailStyleTwo = customTextStyle(
      fontStyle: FontStyle.BodyM_SemiBold,
      color: FontColor.FontPrimary,
    );

    return Scaffold(
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
            border: Border(
          top: BorderSide(color: customColors().backgroundTertiary),
        )),
        height: 72,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12.0),
          child: Row(children: [
            Expanded(
              child: BasketButton(
                bordercolor: transparent,
                bgcolor: customColors().primary,
                text: "Apply Now!",
                textStyle: customTextStyle(
                    fontStyle: FontStyle.BodyL_Bold, color: FontColor.White),
                onpress: () {
                  context.gNavigationService.openIpoDetailFinalPage(context);
                },
              ),
            ),
          ]),
        ),
      ),
      body: SafeArea(
        child: Column(
          children: [
            IpoAppBar(
              title: "IPO Details",
              iconPress: () {
                Navigator.pop(context);
              },
            ),
            Container(
              width: MediaQuery.of(context).size.width,
              color: customColors().backgroundSecondary,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 20, 0, 16),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Image.asset("assets/lic.png"),
                    Padding(
                      padding: const EdgeInsets.only(left: 16),
                      child: Text(
                        "Life Insurance Corporation\nof India - LIC",
                        maxLines: 2,
                        style: customTextStyle(
                          fontStyle: FontStyle.BodyL_SemiBold,
                          color: FontColor.FontPrimary,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Divider(
              height: 1,
              thickness: 1.2,
              color: customColors().backgroundTertiary,
            ),
            detailCard(context, detailStyleOne, detailStyleTwo),
            Container(
              width: MediaQuery.of(context).size.width,
              decoration: BoxDecoration(
                border: Border(
                    bottom: BorderSide(
                        width: 1.0, color: customColors().backgroundTertiary)),
              ),
              child: MediaQuery.removePadding(
                context: context,
                removeTop: true,
                child: TabBar(
                  controller: _controller,
                  tabs: tablist,
                  isScrollable: true,
                  labelStyle: customTextStyle(
                      fontStyle: FontStyle.BodyL_SemiBold,
                      color: FontColor.Primary),
                  labelColor: customColors().primary,
                  indicatorSize: TabBarIndicatorSize.label,
                  indicatorColor: customColors().primary,
                  unselectedLabelStyle: customTextStyle(
                      fontStyle: FontStyle.BodyL_Regular,
                      color: FontColor.FontSecondary),
                  unselectedLabelColor: customColors().fontSecondary,
                ),
              ),
            ),
            Expanded(
              child: TabBarView(
                children: alertswidgets,
                controller: _controller,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Container detailCard(BuildContext context, TextStyle detailStyleOne,
      TextStyle detailStyleTwo) {
    return Container(
      width: MediaQuery.of(context).size.width,
      color: customColors().backgroundSecondary,
      child: Padding(
        padding: const EdgeInsets.only(left: 16),
        child: Row(
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(
                  height: 13,
                ),
                Text(
                  "Date",
                  style: detailStyleOne,
                ),
                const SizedBox(
                  height: 13,
                ),
                Text(
                  "Issue Size",
                  style: detailStyleOne,
                ),
                const SizedBox(
                  height: 13,
                ),
                Text(
                  "Min Investment",
                  style: detailStyleOne,
                ),
                const SizedBox(
                  height: 13,
                ),
                Text(
                  "Min Qty",
                  style: detailStyleOne,
                ),
                const SizedBox(
                  height: 13,
                ),
                Text(
                  "Price Band",
                  style: detailStyleOne,
                ),
                const SizedBox(
                  height: 13,
                ),
              ],
            ),
            Padding(
              padding: const EdgeInsets.only(left: 76),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SizedBox(
                    height: 13,
                  ),
                  Text(
                    "18 Feb’22 - 22 Feb’22",
                    style: detailStyleTwo,
                  ),
                  const SizedBox(
                    height: 13,
                  ),
                  Text(
                    "150 Crore",
                    style: detailStyleTwo,
                  ),
                  const SizedBox(
                    height: 13,
                  ),
                  Text(
                    "50,000.00",
                    style: detailStyleTwo,
                  ),
                  const SizedBox(
                    height: 13,
                  ),
                  Text(
                    "5000",
                    style: detailStyleTwo,
                  ),
                  const SizedBox(
                    height: 13,
                  ),
                  Text(
                    "200-300",
                    style: detailStyleTwo,
                  ),
                  const SizedBox(
                    height: 13,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
