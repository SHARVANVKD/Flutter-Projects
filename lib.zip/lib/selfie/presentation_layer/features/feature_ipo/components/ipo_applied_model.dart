import 'package:selfie_mobile_flutter/theme/styles.dart';

List<Map<String, dynamic>> appliedList = [
  {
    "symbol": "Life Insurance Corporation of India - LIC",
    "imgPath": "assets/lic.png",
    "status": "Recommended",
    "applied_date": "30 Jan’22 ",
    "applied_status_1": "Sent To Exchange",
    "applied_status_2": "Mendate Pending",
    "applied_status_1_color": FontColor.Success,
    "applied_status_2_color": FontColor.Danger
  },
  {
    "symbol": "Swaraj Industries",
    "imgPath": "assets/swaraj.png",
    "status": "",
    "applied_date": "30 Jan’22 ",
    "applied_status_1": "UPI Mandate Accepted",
    "applied_status_2": "",
    "applied_status_1_color": FontColor.Success,
    "applied_status_2_color": ""
  },
  {
    "symbol": "Ruchi Soya Industries Limited - Employee",
    "imgPath": "assets/ruchi.png",
    "status": "",
    "applied_date": "30 Jan’22 ",
    "applied_status_1": "Allotment Received",
    "applied_status_2": "",
    "applied_status_1_color": FontColor.Warning,
    "applied_status_2_color": ""
  },
  {
    "symbol": "Ruchi Soya Industries Limited - Employee",
    "imgPath": "assets/ruchi.png",
    "status": "",
    "applied_date": "30 Jan’22 ",
    "applied_status_1": "Allotment Received",
    "applied_status_2": "",
    "applied_status_1_color": FontColor.Danger,
    "applied_status_2_color": ""
  },
];
