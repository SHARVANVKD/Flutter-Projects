List<Map<String, dynamic>> all = [
  {
    "symbol": "Swaraj Industries",
    "imgPath": "assets/swaraj.png",
    "status": "Recommended",
    "date": "18 Feb’22 - 22 Feb’22",
    "qty": "5000",
    "price": "500-800",
  },
  {
    "symbol": "Ruchi Soya Industries Limited - Employee",
    "imgPath": "assets/ruchi.png",
    "status": "",
    "date": "18 Feb’22 - 22 Feb’22",
    "qty": "5000",
    "price": "500-800",
  },
  {
    "symbol": "Manyavar",
    "imgPath": "assets/manya.png",
    "status": "Recommended",
    "date": "18 Feb’22 - 22 Feb’22",
    "qty": "3000",
    "price": "200-300",
  },
  {
    "symbol": "HDFC life insurance",
    "imgPath": "assets/hdfc.png",
    "status": "Recommended",
    "date": "18 Feb’22 - 22 Feb’22",
    "qty": "5000",
    "price": "500-800",
  },
];

List<Map<String, dynamic>> ongoing = [
  {
    "symbol": "Swaraj Industries",
    "imgPath": "assets/swaraj.png",
    "status": "Recommended",
    "date": "18 Feb’22 - 22 Feb’22",
    "qty": "5000",
    "price": "500-800",
  },
  {
    "symbol": "Ruchi Soya Industries Limited - Employee",
    "imgPath": "assets/ruchi.png",
    "status": "",
    "date": "18 Feb’22 - 22 Feb’22",
    "qty": "5000",
    "price": "500-800",
  },
  {
    "symbol": "Manyavar",
    "imgPath": "assets/manya.png",
    "status": "Recommended",
    "date": "18 Feb’22 - 22 Feb’22",
    "qty": "3000",
    "price": "200-300",
  },
  {
    "symbol": "HDFC life insurance",
    "imgPath": "assets/hdfc.png",
    "status": "Recommended",
    "date": "18 Feb’22 - 22 Feb’22",
    "qty": "5000",
    "price": "500-800",
  },
];

List<Map<String, dynamic>> upcoming = [
  {
    "symbol": "Life Insurance Corporation of India - LIC",
    "imgPath": "assets/lic.png",
    "status": "Recommended",
    "date": "18 Feb’22 - 22 Feb’22",
    "qty": "5000",
    "price": "500-800",
  },
  {
    "symbol": "Ruchi Soya Industries Limited - Employee",
    "imgPath": "assets/ruchi.png",
    "status": "",
    "date": "18 Feb’22 - 22 Feb’22",
    "qty": "5000",
    "price": "500-800",
  },
  {
    "symbol": "Manyavar",
    "imgPath": "assets/manya.png",
    "status": "Recommended",
    "date": "18 Feb’22 - 22 Feb’22",
    "qty": "3000",
    "price": "200-300",
  },
];

List<Map<String, dynamic>> closed = [
  {
    "symbol": "Ruchi Soya Industries Limited - Employee",
    "imgPath": "assets/ruchi.png",
    "status": "",
    "date": "18 Feb’22 - 22 Feb’22",
    "qty": "5000",
    "price": "500-800",
  },
  {
    "symbol": "HDFC life insurance",
    "imgPath": "assets/hdfc.png",
    "status": "Recommended",
    "date": "18 Feb’22 - 22 Feb’22",
    "qty": "5000",
    "price": "500-800",
  },
];
