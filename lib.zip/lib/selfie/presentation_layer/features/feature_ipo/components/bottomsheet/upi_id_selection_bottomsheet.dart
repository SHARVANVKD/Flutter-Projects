import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/custom_radio_button.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class UpiIdSelectionBottomSheet extends StatefulWidget {
  final void Function(int) onpress;
  UpiIdSelectionBottomSheet({Key? key, required this.onpress})
      : super(key: key);

  @override
  State<UpiIdSelectionBottomSheet> createState() =>
      _UpiIdSelectionBottomSheetState();
}

class _UpiIdSelectionBottomSheetState extends State<UpiIdSelectionBottomSheet> {
  List<String> listItem = ['@Ybl', '@HDFC', '@ibl', '@axl', '@sbi'];

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisAlignment: MainAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          child: Text(
            "Investor Type",
            style: customTextStyle(
                fontStyle: FontStyle.HeaderXS_SemiBold,
                color: FontColor.FontPrimary),
          ),
        ),
        Container(
          height: 1,
          color: customColors().backgroundTertiary,
        ),
        const SizedBox(
          height: 10,
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 0, 0, 10),
          child: ListView.builder(
              shrinkWrap: true,
              itemCount: listItem.length,
              itemBuilder: (context, index) {
                return MyRadioListTile<int>(
                  value: index,
                  groupValue: upiId,
                  title: Text(
                    listItem[index],
                    style: customTextStyle(
                      fontStyle: FontStyle.BodyL_Regular,
                      color: FontColor.FontPrimary,
                    ),
                  ),
                  onChanged: (value) {
                    setState(() {
                      upiId = value!;
                      widget.onpress(value);
                    });
                  },
                );
              }),
        ),
        const SizedBox(
          height: 20,
        ),
      ],
    );
  }
}

int upiId = 0;
