import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class IpoAppliedStatusLog extends StatefulWidget {
  const IpoAppliedStatusLog({Key? key}) : super(key: key);

  @override
  State<IpoAppliedStatusLog> createState() => _IpoAppliedStatusLogState();
}

class _IpoAppliedStatusLogState extends State<IpoAppliedStatusLog> {
  List<Model> list = [
    Model(
      title: "Listing",
      color: FontColor.FontPrimary,
      date: "24 Feb, 22",
    ),
    Model(
      title: "Demat Transfer",
      color: FontColor.FontPrimary,
      date: "24 Feb, 22",
    ),
    Model(
      title: "Refund Initiation",
      color: FontColor.FontPrimary,
      date: "24 Feb, 22",
    ),
    Model(
      title: "Allotment Finalisation",
      color: FontColor.FontPrimary,
      date: "24 Feb, 22",
    ),
    Model(
      title: "Bidding Ends",
      color: FontColor.Success,
      date: "24 Feb, 22",
    ),
    Model(
      title: "Bidding Starts",
      color: FontColor.Success,
      date: "24 Feb, 22",
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 11, right: 16, top: 20, bottom: 6),
      child: SingleChildScrollView(
        child: Column(
          children: [
            ListView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: list.length,
              itemBuilder: (context, index) => Stack(
                children: [
                  index != list.length - 1
                      ? Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Row(
                              children: [
                                Column(
                                  children: List.generate(
                                    8,
                                    (ii) => Padding(
                                      padding: const EdgeInsets.only(
                                          left: 10,
                                          right: 10,
                                          bottom: 2,
                                          top: 2),
                                      child: Container(
                                        height: 4,
                                        width: 1,
                                        color: customColors().silverDust,
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        )
                      : const SizedBox(),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            children: [
                              Padding(
                                padding: const EdgeInsets.only(
                                    left: 6, right: 12, bottom: 4),
                                child: Container(
                                  height: 10,
                                  width: 10,
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    color: index == 4 || index == 5
                                        ? customColors().success
                                        : customColors().silverDust,
                                  ),
                                ),
                              ),
                              Text(
                                list[index].title,
                                style: customTextStyle(
                                  fontStyle: FontStyle.BodyM_SemiBold,
                                  color: list[index].color,
                                ),
                              )
                            ],
                          ),
                          Text(
                            list[index].date,
                            style: customTextStyle(
                              fontStyle: FontStyle.BodyM_SemiBold,
                              color: FontColor.FontSecondary,
                            ),
                          )
                        ],
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class Model {
  String title;
  String date;

  FontColor? color;

  //Other fields if needed....
  Model({
    required this.title,
    required this.date,
    this.color,
  });
  //initialise other fields so on....
}
