import 'package:flutter/material.dart';

import '../../../../../../../theme/styles.dart';
import '../../../../../../../utils/shimmer_loader.dart';

class WatchlistShimmer extends StatelessWidget {
  const WatchlistShimmer({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
        shrinkWrap: true,
        itemCount: 5,
        itemBuilder: (context, index) {
          return Container(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
            child: Column(
              children: [
                Row(
                  children: [
                    Wrap(
                      crossAxisAlignment: WrapCrossAlignment.center,
                      children: [ShimmerLoader(height: 20.0, width: 100.0)],
                    ),
                  ],
                ),
                SizedBox(
                  height: 8,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        // if (dataList[index]["NSEBSE"] != null)
                        //   Container(
                        //       alignment: Alignment.center,
                        //       child: Text(
                        //         "${dataList[index]["NSEBSE"]}",
                        //         style: customTextStyle(fontStyle: FontStyle.BodyM_Regular, color: FontColor.FontTertiary),
                        //       )),
                        //       Padding(
                        //         padding: const EdgeInsets.only(left: 6.0),
                        //         child: getProductTypeWidget(dataList[index]["BONUS"]??""),
                        //       ),
                        ShimmerLoader(height: 20.0, width: 50.0),
                      ],
                    ),
                    ShimmerLoader(height: 20.0, width: 30.0)
                  ],
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 16),
                  child: Container(
                    color: customColors().backgroundTertiary,
                    height: 1,
                  ),
                )
              ],
            ),
          );
        });
  }
}
