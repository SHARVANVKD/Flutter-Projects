part of 'watchlist_cubit.dart';

@immutable
abstract class WatchlistComponetState {}

class GridState extends WatchlistComponetState {
  final List<Instrument> items;
  GridState({required this.items});
}

class HeatMapState extends WatchlistComponetState {
  final List<Instrument> items;
  HeatMapState({required this.items});
}

class Watchlistloadingstate extends WatchlistComponetState {}
