import 'package:bloc/bloc.dart';
import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/app_page_injectable.dart';
import 'package:selfie_mobile_flutter/mds_controller.dart/mds_controller.dart';
import 'package:selfie_mobile_flutter/mds_controller.dart/mds_model.dart/instrument.dart';
import 'package:selfie_mobile_flutter/utils/models/watchlist_model.dart';
part 'watchlist_state.dart';

class WatchlistComponetCubit extends Cubit<WatchlistComponetState> {
  List<Instrument> feedList;
  WatchlistModel? watchlistDetails;
  Map<String, Instrument> feedMap = {};
  Map<String, dynamic> fromPage = {"Page": "watchlist"};

  WatchlistComponetCubit(this.feedList) : super(Watchlistloadingstate()) {
    feedMap = {for (var element in feedList) element.getRicAddress(1): element};
    subscribeSymbols();
    emit(GridState(items: feedList));
    MDS_Controller().stream.listen((FlairResponseModel flairResponseModel) {
      updateItemOfList(flairResponseModel);
    });
  }

  subscribeSymbols() {
    MDS_Controller().batchSubscrbe(List.generate(feedList.length, (index) {
      String ric = feedList[index].getRicAddress(1);
      MDS_Controller().feedData[ric] = feedList[index];
      return ric;
    }));
  }

  unsubscribeSymbols() {
    MDS_Controller().batchUnsubscribe(List.generate(
        feedList.length, (index) => feedList[index].getRicAddress(1)));
  }

  openEditWatchList(BuildContext context) {
    context.gNavigationService.openEditWatchlistPage(context, {"": 0});
  }

  openSearch(BuildContext context) {
    context.gNavigationService.openSymbolSearch(context, fromPage);
  }

  openReviewOrder(BuildContext context) {
    context.gNavigationService.openReviewOrder(context);
  }

  openHeatMap() {
    emit(HeatMapState(items: feedList));
  }

  updateItemOfList(FlairResponseModel data) {
    if (feedMap.containsKey(data.ric)) {
      feedMap[data.ric] = data.instrument;
      emit(GridState(items: feedMap.values.toList()));
    }
  }

  updateSortlist(List<Instrument> list) {
    feedMap = {for (var element in list) element.getRicAddress(1): element};
    emit(GridState(items: feedMap.values.toList()));
  }

  resetSortOrderList() {
    feedMap = {for (var element in feedList) element.getRicAddress(1): element};
    emit(GridState(items: feedList));
  }

  openGrid({List<Instrument>? list}) {
    emit(GridState(items: list ?? feedList));
  }

  updateData(List<Instrument> list) {
    feedList = list;
    feedMap = {for (var element in feedList) element.getRicAddress(1): element};
    if (state is GridState) {
      emit(GridState(items: list));
    } else if (state is HeatMapState) {
      emit(HeatMapState(items: list));
    }
  }
}
