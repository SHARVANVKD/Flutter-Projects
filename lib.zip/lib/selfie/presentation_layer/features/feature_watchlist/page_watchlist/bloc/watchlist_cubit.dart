import 'package:bloc/bloc.dart';
import 'package:flutter/material.dart';
import 'package:mds/subject_list.dart';
import 'package:selfie_mobile_flutter/app_page_injectable.dart';
import 'package:selfie_mobile_flutter/mds_controller.dart/mds_controller.dart';
import 'package:selfie_mobile_flutter/mds_controller.dart/mds_model.dart/instrument.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/custom_snackbar/custom_snackbar.dart';
import 'package:selfie_mobile_flutter/services/api_gateway.dart';
import 'package:selfie_mobile_flutter/user_controller/repo_files/watchlist/watchlist_repo_impl.dart';
import 'package:selfie_mobile_flutter/user_controller/user_controller.dart';
import 'package:selfie_mobile_flutter/utils/models/watchlist_model.dart';

part 'watchlist_state.dart';

List<Instrument> feed = [];

class WatchlistCubit extends Cubit<WatchlistState> {
  final TradingApiGateway tradingApiGateway;
  WatchlistModel? watchlistDetails;
  String maxSymbols = "50";

  WatchlistCubit({required this.tradingApiGateway})
      : super(WatchlistInitial(
            watchlistName: "", feedData: feed, isLoading: true)) {
    // getWatchlistData(context);
    // MDS_Controller.mdsController.subscrbe();

    // MDS_Controller.mdsController.stream.listen((List<Instrument> event) {
    //     feedData = event;
    //     print("feed update $event");
    //     emit((state as WatchlistInitial).copyWith(feedData: feedData));
    // })
  }

  int watchIndex = -1;
  openAllWatchList(BuildContext context, String title) async {
    Map<String, dynamic> returnArgs =
        await context.gNavigationService.openAllWatchlistPage(context);
    if (returnArgs["selectedIndex"] != -1) {
      MDS_Controller().batchUnsubscribe(
          List.generate(feed.length, (index) => feed[index].getRicAddress(1)));
      getWatchlist(index: returnArgs["selectedIndex"]);
    }
  }

  getWatchlistData(BuildContext context) async {
    try {
      emit((state as WatchlistInitial).copyWith(isLoading: true));
      await Future.delayed(Duration(seconds: 5));
      List<WatchlistModel> listWatchlist =
          await WatchlistRepositoryImpl(gateway: tradingApiGateway)
              .retriveWatchlist(userId: UserController().userId);
      if (listWatchlist.isEmpty) {
        emit((state as WatchlistInitial).copyWith(isLoading: false));
        return;
      }
      listWatchlist.sort((a, b) =>
          a.watchlistData.sortorder.compareTo(b.watchlistData.sortorder));
      UserController.userController.watchlists = listWatchlist;
      int selectedIndex = 0;
      for (var i = 0; i < listWatchlist.length; i++) {
        if (listWatchlist[i].watchlistData.selected.toLowerCase() == "true") {
          selectedIndex = i;
        }
        listWatchlist[i]
            .symbolDataList
            .sort((a, b) => a.sortorder.compareTo(b.sortorder));
      }
      watchIndex = selectedIndex;
      getWatchlist(index: selectedIndex);
    } catch (e) {
      CustomSnackbar()
          .validationSnackbar(context: context, message: e.toString());
    }
    emit((state as WatchlistInitial).copyWith(isLoading: false));
  }

  updateFromEditWatch(Map<String, dynamic> editWatch) {
    if (editWatch["EditedWatchlist"] != "") {
      watchlistDetails = editWatch["EditedWatchlist"];
      UserController.userController.watchlists[watchIndex] = watchlistDetails!;
      updateEditedData(model: watchlistDetails!);
    }
  }

  updateEditedData({required WatchlistModel model}) {
    List<Instrument> feedData = (state as WatchlistInitial).feedData;
    for (var i = 0; i < model.symbolDataList.length; i++) {
      for (var j = 0; j < feedData.length; j++) {
        if (getVenueIndex(model.symbolDataList[i].venuecode) ==
                feedData[j].venueIndex &&
            model.symbolDataList[i].venuescripcode == feedData[j].scripcode) {
          feed.add(feedData[j]);
        }
      }
    }

    emit(WatchlistInitial(
      watchlistName: model.watchlistData.watchname,
      feedData: feed,
    ));
  }

  getWatchlist({required int index}) {
    watchIndex = index;
    List<WatchlistModel> watchlists = UserController.userController.watchlists;
    feed = watchlists[index].generateSymbolData().values.toList();
    return emit(WatchlistInitial(
      watchlistName: UserController
          .userController.watchlists[index].watchlistData.watchname,
      feedData: feed,
    ));
  }
}
