part of 'watchlist_cubit.dart';

@immutable
abstract class WatchlistState {}

class WatchlistInitial extends WatchlistState {
  final List<Instrument> feedData;
  bool isLoading;
  final String watchlistName;
  WatchlistInitial(
      {required this.watchlistName,
      required this.feedData,
      this.isLoading = false});

  WatchlistInitial copyWith({
    String? watchlistName,
    List<Instrument>? feedData,
    bool? isLoading,
  }) {
    return WatchlistInitial(
      watchlistName: watchlistName ?? this.watchlistName,
      feedData: feedData ?? this.feedData,
      isLoading: isLoading ?? this.isLoading,
    );
  }
}

class Watchlistloading extends WatchlistState {}
