part of 'my_watchlist_cubit.dart';

@immutable
abstract class MyWatchlistState {}

class MyWatchlistLoading extends MyWatchlistState {}

class MyWatchListInitialState extends MyWatchlistState {
  final List<WatchlistModel> myWatchListItems;
  MyWatchListInitialState(this.myWatchListItems);
}

class MyWatchlistError extends MyWatchlistState {
  final int errorCode;
  final String errorMessage;

  MyWatchlistError({required this.errorCode, required this.errorMessage});
}


