import 'package:bloc/bloc.dart';
import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/repository_layer/watchlist_content.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';

part 'preset_watchlist_state.dart';

class PresetWatchlistCubit extends Cubit<PresetWatchlistState> {
  final ServiceLocator serviceLocator;
  PresetWatchlistCubit({required this.serviceLocator}) : super(PrestWatchlistInitial(presetWatchListItems));

   List<Map<String, dynamic>> getListItems(List<Map<String, dynamic>> item){
     List<Map<String, dynamic>> generatedItems = [];
      for (var i = 0; i < item.length; i++) {
        item[i]["properties"]["enabled"] ? generatedItems.add(item[i]): null;
      }
      return generatedItems;
  }

  updatelist(int index){
    List items = (state as PrestWatchlistInitial).presetWatchlistItem;
    for (var i = 0; i < items.length; i++) {
      items[i]["properties"]["selected"] = false;
    }
    items[index]["properties"]["selected"] = true;
      emit(PrestWatchlistInitial(items));
  }

  onBackPressed(BuildContext context){
      serviceLocator.navigationService.back(context);
  }

  onManagePressed(BuildContext context){
    serviceLocator.navigationService.openWatchlistManagePage(context, {"name": "presetWatchList"});
  }

  onCreatePressed(BuildContext context){
  }
}
