import 'dart:io';

import 'package:bloc/bloc.dart';
import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/repository_layer/watchlist_content.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';
import 'package:selfie_mobile_flutter/user_controller/user_controller.dart';
import 'package:selfie_mobile_flutter/utils/models/watchlist_model.dart';

part 'my_watchlist_state.dart';

class MyWatchlistCubit extends Cubit<MyWatchlistState> {
  final ServiceLocator serviceLocator;
  List<Map<String, dynamic>> myWatchList = myWatchListItems;
  MyWatchlistCubit({required this.serviceLocator})
      : super(
            MyWatchListInitialState(UserController.userController.watchlists));

  List<Map<String, dynamic>> getListItems(List<Map<String, dynamic>> item) {
    List<Map<String, dynamic>> generatedItems = [];
    for (var i = 0; i < item.length; i++) {
      item[i]["properties"]["enabled"] ? generatedItems.add(item[i]) : null;
    }
    return generatedItems;
  }

  updatelist(int index) async {
    emit(MyWatchlistLoading());
    try {
      List<WatchlistModel> list = UserController.userController.watchlists;
      for (var i = 0; i < list.length; i++) {
        list[i].watchlistData.selected = "false";
      }
      list[index].watchlistData.selected = "true";
      emit(MyWatchListInitialState(list));
      Object response = await serviceLocator.tradingApi.selectedFlagUpdated(
          userID: UserController.userController.userId,
          watchlistId: int.parse(list[index].watchlistData.watchlistid));
    } on SocketException {
      // emit(NetworkError());
    } catch (e) {
      emit(MyWatchlistError(errorCode: 000, errorMessage: e.toString()));
    }
  }

  onBackPressed({required BuildContext context, int index = -1}) {
    serviceLocator.navigationService
        .back(context, arg: {"selectedIndex": index});
  }

  onManagePressed(BuildContext context) {
    serviceLocator.navigationService
        .openWatchlistManagePage(context, {"name": "myWachList"});
  }

  onCreatePressed({required context, required String watchlistName}) {}
}
