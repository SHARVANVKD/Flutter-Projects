part of 'preset_watchlist_cubit.dart';

@immutable
abstract class PresetWatchlistState {}

class PrestWatchlistInitial extends PresetWatchlistState {
  final List presetWatchlistItem;
  final int initialIndex;
  PrestWatchlistInitial(this.presetWatchlistItem, {this.initialIndex = 0});
}


