import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_watchlist/page_all_watchlist/bloc/my_watch_list/my_watchlist_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_watchlist/page_all_watchlist/bloc/preset_watch_list/preset_watchlist_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/appbar/customAppbarInner.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/buttons/BasketButton.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/scrollable_bottomsheet/custom_bottom_sheet.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/scrollable_bottomsheet/scrollable_bottomsheet.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/custom_top_tab.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';
import 'package:selfie_mobile_flutter/user_controller/user_controller.dart';
import 'package:selfie_mobile_flutter/utils/models/watchlist_model.dart';

class AllWatchlistPage extends StatefulWidget {
  final ServiceLocator serviceLocator;
  const AllWatchlistPage({Key? key, required this.serviceLocator})
      : super(key: key);

  @override
  _AllWatchlistPageState createState() => _AllWatchlistPageState();
}

class _AllWatchlistPageState extends State<AllWatchlistPage>
    with TickerProviderStateMixin {
  AnimationController? _controller;
  int selectedIndex = -1;
  int watchlistLimit = 10;
  bool loadingBar = false;

  @override
  void initState() {
    // TODO: implement initState

    super.initState();
    _controller = BottomSheet.createAnimationController(this);
    _controller!.duration = const Duration(milliseconds: 400);
  }

  @override
  void dispose() {
    _controller!.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    double height = MediaQuery.of(context).size.height;
    double width = MediaQuery.of(context).size.width;

    return SafeArea(
      child: WillPopScope(
        onWillPop: () async {
          BlocProvider.of<MyWatchlistCubit>(context)
              .onBackPressed(context: context, index: selectedIndex);
          return false;
        },
        child: Scaffold(
          appBar: PreferredSize(
              preferredSize: const Size.fromHeight(0.0),
              child: AppBar(
                elevation: 0,
                backgroundColor: customColors().backgroundPrimary,
              )),
          backgroundColor: customColors().backgroundPrimary,
          body: Column(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                BlocBuilder<MyWatchlistCubit, MyWatchlistState>(
                  builder: (context, state) {
                    return (state is MyWatchlistLoading)
                        ? LinearProgressIndicator(
                            minHeight: 6.0,
                            color: customColors().primary.withOpacity(0.8),
                            backgroundColor:
                                customColors().primary.withOpacity(0.2),
                            // value: controller.value,
                          )
                        : Container();
                  },
                ),
                CustomAppBarInner(
                    title: "All Watchlists",
                    onBackPressed: () {
                      BlocProvider.of<MyWatchlistCubit>(context).onBackPressed(
                          context: context, index: selectedIndex);
                    }),
                Expanded(
                    child: CustomTabBar(
                  isScrollable: true,
                  indicatorSize: TabBarIndicatorSize.label,
                  tabContent: [
                    "My Watchlist (${UserController.userController.watchlists.length.toString()}/$watchlistLimit)",
                    "Preset Watchlist (6/6)"
                  ],
                  tabBarViewChildern: [
                    BlocBuilder<MyWatchlistCubit, MyWatchlistState>(
                      builder: (context, state) {
                        if (state is MyWatchListInitialState) {
                          return Column(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Expanded(
                                child: myWatchListContent(
                                    context: context,
                                    items: state.myWatchListItems,
                                    onTap: (int index) {
                                      selectedIndex = index;
                                      BlocProvider.of<MyWatchlistCubit>(context)
                                          .updatelist(index);
                                    }),
                              ),
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceEvenly,
                                children: [
                                  Padding(
                                      padding: const EdgeInsets.symmetric(
                                          vertical: 12),
                                      child: BasketButton(
                                        bordercolor: customColors().primary,
                                        bgcolor:
                                            customColors().backgroundPrimary,
                                        text: "Manage",
                                        textStyle: customTextStyle(
                                            fontStyle: FontStyle.BodyL_Bold,
                                            color: FontColor.Primary),
                                        onpress: () {
                                          BlocProvider.of<MyWatchlistCubit>(
                                                  context)
                                              .onManagePressed(context);
                                        },
                                        buttonwidth: width * 0.45,
                                      )),
                                  Padding(
                                      padding: const EdgeInsets.symmetric(
                                          vertical: 12),
                                      child: BasketButton(
                                        bordercolor: transparent,
                                        enabled: (UserController.userController
                                                    .watchlists.length <
                                                watchlistLimit)
                                            ? true
                                            : false,
                                        bgcolor: customColors().primary,
                                        text: "Create",
                                        textStyle: customTextStyle(
                                            fontStyle: FontStyle.BodyL_Bold,
                                            color: FontColor.White),
                                        onpress: () {
                                          customShowModalBottomSheet(
                                            context: context,
                                            inputWidget: CreateWatchlist(
                                              serviceLocator:
                                                  widget.serviceLocator,
                                              onViewWatchlistPressed:
                                                  (updateIndex) {
                                                BlocProvider.of<
                                                            MyWatchlistCubit>(
                                                        context)
                                                    .updatelist(updateIndex!);
                                                selectedIndex = updateIndex;
                                                Navigator.of(context).pop(true);
                                                if (updateIndex is int) {
                                                  BlocProvider.of<
                                                              MyWatchlistCubit>(
                                                          context)
                                                      .onBackPressed(
                                                          context: context,
                                                          index: selectedIndex);
                                                }
                                              },
                                              // loadingStatus:(status){}
                                            ),
                                          );
                                        },
                                        buttonwidth: width * 0.45,
                                      )),
                                ],
                              )
                            ],
                          );
                        } else {
                          return Container();
                        }
                      },
                    ),
                    BlocBuilder<PresetWatchlistCubit, PresetWatchlistState>(
                      builder: (context, state) {
                        if (state is PrestWatchlistInitial) {
                          return Column(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Expanded(
                                child: myWatchListContent(
                                    context: context,
                                    items: UserController
                                        .userController.watchlists,
                                    onTap: (int index) {
                                      BlocProvider.of<PresetWatchlistCubit>(
                                              context)
                                          .updatelist(index);
                                    }),
                              ),
                              Padding(
                                  padding:
                                      const EdgeInsets.symmetric(vertical: 12),
                                  child: BasketButton(
                                    bordercolor: transparent,
                                    bgcolor: customColors().primary,
                                    text: "Manage",
                                    textStyle: customTextStyle(
                                        fontStyle: FontStyle.BodyL_Bold,
                                        color: FontColor.White),
                                    onpress: () {
                                      BlocProvider.of<PresetWatchlistCubit>(
                                              context)
                                          .onManagePressed(context);
                                    },
                                    buttonwidth: width * 0.94,
                                  ))
                            ],
                          );
                        } else {
                          return Container();
                        }
                      },
                    ),
                  ],
                ))
              ]),
        ),
      ),
    );
  }
}

Widget myWatchListContent(
    {required BuildContext context,
    required List<WatchlistModel> items,
    required Function(int) onTap}) {
  return ListView.builder(
      shrinkWrap: true,
      itemCount: items.length,
      itemBuilder: (context, index) {
        return GestureDetector(
          onTap: () => onTap(index),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: 20),
              decoration: BoxDecoration(
                  border: Border(
                      bottom: BorderSide(
                          color: customColors().backgroundTertiary))),
              child: SizedBox(
                height: 24,
                child: Align(
                  alignment: Alignment.center,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        items[index].watchlistData.watchname,
                        style: TextStyle(
                            fontFamily: "OpenSansSemiBold",
                            fontSize: 14,
                            color: customColors().fontPrimary),
                      ),
                      items[index].watchlistData.selected.toLowerCase() ==
                              "true"
                          ? Image.asset("assets/tick_circle.png")
                          : Container(),
                    ],
                  ),
                ),
              ),
            ),
          ),
        );
      });
}
