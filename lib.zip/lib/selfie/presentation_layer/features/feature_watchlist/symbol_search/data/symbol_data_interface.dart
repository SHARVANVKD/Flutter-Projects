import 'package:selfie_mobile_flutter/mds_controller.dart/mds_model.dart/instrument.dart';

abstract class SymbolDataInterface{
  /// get data from SymbolData if exist else
  /// fetch data from api update symboldata then return
  /// ```dart
  /// Instrument instrument = await SymbolData.get(venuCodeScripCode : "1_1536");
  /// ```
  Future<Instrument> get({required String venuCodeScripCode});

  /// add Instrument to SymbolData from
  /// symbol search
  /// ```dart
  /// Instrument inst = Instrument();
  /// SymbolData.add(instrument : inst);
  /// ```
  add({required Instrument instrument});
}