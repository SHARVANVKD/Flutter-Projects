import 'package:mds/subject_list.dart';
import 'package:selfie_mobile_flutter/mds_controller.dart/mds_model.dart/instrument.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_watchlist/symbol_search/data/symbol_data_interface.dart';

class SymbolData extends SymbolDataInterface{

  static Map<String, Instrument> _symbolMap = {};

  @override
  add({required Instrument instrument}) {
    String key = "${instrument.venueIndex}_${instrument.scripcode}";
    _symbolMap[key] = instrument;
  }

  @override
  Future<Instrument> get({required String venuCodeScripCode}) async {
    if(!_symbolMap.containsKey(venuCodeScripCode)){
      await add(
        instrument: await fetchSymbolData(venueCodeScripCode: venuCodeScripCode)
        );
    }
    return _symbolMap[venuCodeScripCode]!;
  }
  
  Future<Instrument> fetchSymbolData({required String venueCodeScripCode}) async{
    String venuCode = venueCodeScripCode.split("_")[0];
    String venueScripCode = venueCodeScripCode.split("_")[1];
    return Instrument(scripcode: venueScripCode, symbol: "symbol", securityName: "securityName", series: "series", venueIndex: 0, type: 0);
  }
}