import 'package:flutter/material.dart';
import 'package:trading_api/responses/symbol_search_response.dart';

class SymbolDetailsModel {
  SymbolDetailsModel({
    required this.details,
    required this.exchange,
    required this.name,
    required this.response,
  });
  String name;
  String exchange;
  String details;
  Reclistxmob response;

  bool equals(SymbolDetailsModel other) =>
      this.response.venue == other.response.venue &&
      this.response.scripcode == other.response.scripcode;
}
