part of 'symbol_search_cubit.dart';

@immutable
abstract class SymbolSearchState {}

class SearchInitialState extends SymbolSearchState {}

class SearchLoadingState extends SymbolSearchState {}

class SearchLoadedState extends SymbolSearchState {
  final List<SymbolDetailsModel> symbolsList;
  SearchLoadedState({required this.symbolsList});
  SearchLoadedState copyWith({List<SymbolDetailsModel>? symbolsList, List<bool>? checkedList}){
    return SearchLoadedState(symbolsList: symbolsList ?? this.symbolsList);
  }
}

class SearchFilterState extends SymbolSearchState {}





class SearchErrorState extends SymbolSearchState {
  final int errorCode;
  final String errorMessage;
  SearchErrorState({required this.errorCode, required this.errorMessage});
}

class SearchNothingFoundState extends SymbolSearchState {}

class ViewMoreLoadingState extends SymbolSearchState {}
