import 'dart:developer';
import 'package:bloc/bloc.dart';
import 'package:meta/meta.dart';
import 'package:selfie_mobile_flutter/constants/error_mapper.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_watchlist/symbol_search/model/symboldetails_model.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';
import 'package:trading_api/responses/symbol_search_response.dart';
part 'symbol_search_state.dart';

class SymbolSearchCubit extends Cubit<SymbolSearchState> {
  ServiceLocator serviceLocator;
  int _length = 0;
  int _categoryIndex = 0;
  int _fromIndex = 1;
  bool _isViewMore = false;
  String _keyWord = "";
  final Map<String, dynamic> fromPage;
  final List<SymbolDetailsModel> _symbolSearchList = [];
  SymbolSearchResponse? _response;
  List<String> categoryItems = [
    "All",
    "Cash",
    "F&O",
    "Index",
    "Currency",
    "Commodity",
    "Spread"
  ];

  SymbolSearchCubit({required this.serviceLocator, required this.fromPage})
      : super(SearchInitialState());
//Search Executed When TextBox Text will be changed
  searchSymbol({required String keyword}) {
    // if (keyword.length < 2) {
    //   _symbolSearchList.clear();
    //   emit(SearchLoadedState(symbolsList: _symbolSearchList));
    //   return;
    // }

    _isViewMore = false;
    _fromIndex = 1;
    _keyWord = keyword;
    filterSymbolSearch(_categoryIndex);
  }

//Search Executed When End Of The List
  viewMoreSymbols() {
    _isViewMore = true;
    _fromIndex += 10;
    filterSymbolSearch(_categoryIndex);
  }

  ///Filters Handled Function
  filterSymbolSearch(int category) {
    //Identifyed The Call From TextBox or Filter Tab
    if (_categoryIndex != category) {
      _symbolSearchList.clear();
      _isViewMore = false;
      _fromIndex = 1;
    }
    _categoryIndex = category;
    switch (_categoryIndex) {
      //All Tab
      case 0:
        {
          _searchSymbol(
              keyword: _keyWord,
              venuCode: "NSE|BSE|NSEFO|NSECD|MCX",
              fromIndex: _fromIndex,
              indexFilter: "N",
              remarks: "N");
          break;
        }
      //Cash
      case 1:
        {
          _searchSymbol(
              keyword: _keyWord,
              venuCode: "NSE|BSE",
              fromIndex: _fromIndex,
              indexFilter: "N",
              remarks: "N");
          break;
        }
      //F&O
      case 2:
        {
          _searchSymbol(
              keyword: _keyWord,
              venuCode: "NSEFO|NSECD|MCX",
              fromIndex: _fromIndex,
              indexFilter: "N",
              remarks: "N");
          break;
        }
      //Index
      case 3:
        {
          _searchSymbol(
              keyword: _keyWord,
              venuCode: "",
              fromIndex: _fromIndex,
              indexFilter: "Y",
              remarks: "N");
          break;
        }
      //Currency
      case 4:
        {
          _searchSymbol(
              keyword: _keyWord,
              venuCode: "NSECD",
              fromIndex: _fromIndex,
              indexFilter: "N",
              remarks: "N");
          break;
        }
      //Commodity
      case 5:
        {
          _searchSymbol(
              keyword: _keyWord,
              venuCode: "MCX|NCDEX",
              fromIndex: _fromIndex,
              indexFilter: "N",
              remarks: "N");
          break;
        }
      //Spread
      case 6:
        {
          _searchSymbol(
              keyword: _keyWord,
              venuCode: "",
              fromIndex: _fromIndex,
              indexFilter: "N",
              remarks: "Y");
          break;
        }
    }
  }

  /// Symbol Search Service Integrated Function
  /// Filter Tab Data Handled
  /// Keyword Venucode and start of seaching Index Parameters are Passed
  _searchSymbol(
      {required String keyword,
      required String venuCode,
      required String remarks,
      required String indexFilter,
      required int fromIndex}) async {
    if (keyword.length > 1) {
      //Service Called From Here
      //await Future.delayed(const Duration(seconds: 1));
      try {
        if (_symbolSearchList.isEmpty) {
          emit(SearchLoadingState());
        }
        _response = await serviceLocator.tradingApi.symbolSearchRequest(
            keyword: keyword,
            start: _fromIndex,
            venuCode: venuCode,
            indexFilter: indexFilter,
            remarks: remarks);
        if (_response!.searchresp![0].errorcode == 0) {
          _symbolSearchList.clear();
          _length = _response!.searchresp![0].reclistxmob!.length;
          // _isViewMore
          //     ? emit(ViewMoreLoadingState())
          //     : _symbolSearchList.clear();
          // if (_length == 0 && _isViewMore == false) {
          //   //Emit When Service Returns Empty List
          //   emit(SearchNothingFoundState());
          // }
          if (_length == 0 || _keyWord.isEmpty) {
            //Emit When Service Returns Empty List
            emit(SearchLoadedState(symbolsList: _symbolSearchList));
            return;
          } else {
            //Get The Data From Service
            for (int _i = 0; _i < _length; _i++) {
              var _flag = _response!.searchresp![0].reclistxmob![_i].w;
              if (_flag == "N") {
                _symbolSearchList.add(
                  SymbolDetailsModel(
                      response: _response!.searchresp![0].reclistxmob![_i],
                      details: _response!
                          .searchresp![0].reclistxmob![_i].description
                          .toString(),
                      exchange: _response!.searchresp![0].reclistxmob![_i].venue
                          .toString(),
                      name: _response!
                          .searchresp![0].reclistxmob![_i].securitycode1
                          .toString()),
                );
              } else if (_flag == "Y") {
                String _name = _response!
                        .searchresp![0].reclistxmob![_i].securitycode
                        .toString() +
                    "W" +
                    _response!.searchresp![0].reclistxmob![_i].securitycode1
                        .toString();

                _symbolSearchList.add(SymbolDetailsModel(
                  response: _response!.searchresp![0].reclistxmob![_i],
                  details: _response!
                      .searchresp![0].reclistxmob![_i].description
                      .toString(),
                  exchange: _response!.searchresp![0].reclistxmob![_i].venue
                      .toString(),
                  name: _name,
                ));
              }
            }

            emit(SearchLoadedState(symbolsList: _symbolSearchList));
          }
        } else {
          emit(SearchErrorState(
              errorCode: 1,
              errorMessage:
                  errorMap[_response!.searchresp![0].errorcode].toString()));
        }
      } catch (e) {
        emit(SearchErrorState(errorCode: 1, errorMessage: e.toString()));
        log(e.toString(), time: DateTime.now());
      }
    } else {
      _symbolSearchList.clear();
      emit(SearchLoadedState(symbolsList: _symbolSearchList));
    }
  }
}
