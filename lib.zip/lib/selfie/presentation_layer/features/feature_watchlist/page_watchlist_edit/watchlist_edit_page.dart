import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/app_page_injectable.dart';
import 'package:selfie_mobile_flutter/constants/enums.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_login/login_page.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_watchlist/page_watchlist_edit/bloc/watchlistedit_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/appbar/customAppbarInner.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/buttons/BasketButton.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/scrollable_bottomsheet/bottomsheet_basket_widget.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/scrollable_bottomsheet/scrollable_bottomsheet.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/textfields/custom_text_form_field.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/delete_watchlist.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/manage_list_item.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/stock/empty_custom_checkbox/empty_custom_checkbox.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class WatchlistEditPage extends StatefulWidget {
  @override
  _symbolLongPressPagestate createState() => _symbolLongPressPagestate();
}

class _symbolLongPressPagestate extends State<WatchlistEditPage>
    with TickerProviderStateMixin {
  // bool willPop = false;
  @override
  // AnimationController? _controller;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    // _controller = BottomSheet.createAnimationController(this);
    // _controller!.duration = const Duration(milliseconds: 400);
  }

  @override
  void dispose() {
    // _controller!.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // double height = MediaQuery.of(context).size.height;
    double width = MediaQuery.of(context).size.width;

    return WillPopScope(
      onWillPop: () async {
        bool _watchName = BlocProvider.of<WatchlisteditCubit>(context).rename;
        bool _deleteOrSort =
            BlocProvider.of<WatchlisteditCubit>(context).deleteOrsort;
        bool _status;
        if (_watchName == true || _deleteOrSort == true) {
          await customShowModalBottomSheet(
            context: context,
            inputWidget: WatchListAction(
              actionType: ActionType.save,
              //Discard Changes
              negativeOnPres: () {
                BlocProvider.of<WatchlisteditCubit>(context).discardChanges();
                Navigator.pop(context);
                context.gNavigationService.back(context, arg: {
                  "EditedWatchlist":
                      BlocProvider.of<WatchlisteditCubit>(context)
                          .watchlistDetailscopy
                });
              },
              //Save Changes
              positiveOnPress: () async {
                //When Only Change WatchName
                if (_watchName == true && _deleteOrSort == false) {
                  _status = await BlocProvider.of<WatchlisteditCubit>(context)
                      .updateWatchName();
                  if (_status == true) {
                    Navigator.pop(context);
                    context.gNavigationService.back(context, arg: {
                      "EditedWatchlist":
                          BlocProvider.of<WatchlisteditCubit>(context)
                              .watchlistDetailscopy
                    });
                  } else {
                    Navigator.pop(context);
                  }
                  //When Change WatchName or Sortorder
                } else if (_watchName == true || _deleteOrSort == true) {
                  _status = await BlocProvider.of<WatchlisteditCubit>(context)
                      .updateCloudWatchNameWithSymbols();
                  if (_status == true) {
                    Navigator.pop(context);
                    context.gNavigationService.back(context, arg: {
                      "EditedWatchlist":
                          BlocProvider.of<WatchlisteditCubit>(context)
                              .watchlistDetailscopy
                    });
                  } else {
                    Navigator.pop(context);
                  }
                } else {
                  context.gNavigationService.back(context, arg: {
                    "EditedWatchlist":
                        BlocProvider.of<WatchlisteditCubit>(context)
                            .watchlistDetailscopy
                  });
                }
              },
            ),
          );
        } else {
          context.gNavigationService.back(context, arg: {
            "EditedWatchlist": BlocProvider.of<WatchlisteditCubit>(context)
                .watchlistDetailscopy
          });
        }
        return false;
      },
      child: Scaffold(
        appBar: PreferredSize(
            preferredSize: const Size.fromHeight(0.0),
            child: AppBar(
              elevation: 0,
              backgroundColor: customColors().backgroundPrimary,
            )),
        body: SafeArea(
          child: Column(children: [
            CustomAppBarInner(
                title: "Edit Watchlist",
                endIcon: EndIcon.Save,

                //Execute When Save Button Taped
                onEndIconPressed: () async {
                  bool _watchName =
                      BlocProvider.of<WatchlisteditCubit>(context).rename;
                  bool _deleteOrSort =
                      BlocProvider.of<WatchlisteditCubit>(context).deleteOrsort;
                  bool _status;

                  if (_watchName == true && _deleteOrSort == false) {
                    _status = await BlocProvider.of<WatchlisteditCubit>(context)
                        .updateWatchName();
                    if (_status == true) {
                      context.gNavigationService.back(context, arg: {
                        "EditedWatchlist":
                            BlocProvider.of<WatchlisteditCubit>(context)
                                .watchlistDetailscopy
                      });
                    }
                  } else if (_watchName == true || _deleteOrSort == true) {
                    _status = await BlocProvider.of<WatchlisteditCubit>(context)
                        .updateCloudWatchNameWithSymbols();

                    if (_status == true) {
                      context.gNavigationService.back(context, arg: {
                        "EditedWatchlist":
                            BlocProvider.of<WatchlisteditCubit>(context)
                                .watchlistDetailscopy
                      });
                    }
                  } else {
                    context.gNavigationService.back(context, arg: {
                      "EditedWatchlist":
                          BlocProvider.of<WatchlisteditCubit>(context)
                              .watchlistDetailscopy
                    });
                  }
                },

                //Execute When Back Button Taped
                onBackPressed: () {
                  bool _watchName =
                      BlocProvider.of<WatchlisteditCubit>(context).rename;
                  bool _deleteOrSort =
                      BlocProvider.of<WatchlisteditCubit>(context).deleteOrsort;
                  bool _status;
                  if (_watchName == true || _deleteOrSort == true) {
                    customShowModalBottomSheet(
                      context: context,
                      inputWidget: WatchListAction(
                        actionType: ActionType.save,
                        negativeOnPres: () {
                          BlocProvider.of<WatchlisteditCubit>(context)
                              .discardChanges();

                          context.gNavigationService.back(context, arg: {
                            "EditedWatchlist":
                                BlocProvider.of<WatchlisteditCubit>(context)
                                    .watchlistDetailscopy
                          });
                        },
                        positiveOnPress: () async {
                          if (_watchName == true && _deleteOrSort == false) {
                            _status = await BlocProvider.of<WatchlisteditCubit>(
                                    context)
                                .updateWatchName();
                            if (_status == true) {
                              Navigator.pop(context);
                              context.gNavigationService.back(context, arg: {
                                "EditedWatchlist":
                                    BlocProvider.of<WatchlisteditCubit>(context)
                                        .watchlistDetailscopy
                              });
                            } else {
                              Navigator.pop(context);
                            }
                          } else if (_watchName == true ||
                              _deleteOrSort == true) {
                            _status = await BlocProvider.of<WatchlisteditCubit>(
                                    context)
                                .updateCloudWatchNameWithSymbols();
                            if (_status == true) {
                              Navigator.pop(context);
                              context.gNavigationService.back(context, arg: {
                                "EditedWatchlist":
                                    BlocProvider.of<WatchlisteditCubit>(context)
                                        .watchlistDetailscopy
                              });
                            } else {
                              Navigator.pop(context);
                            }
                          } else {
                            context.gNavigationService.back(context, arg: {
                              "EditedWatchlist":
                                  BlocProvider.of<WatchlisteditCubit>(context)
                                      .watchlistDetailscopy
                            });
                          }
                        },
                      ),
                    );
                  } else {
                    context.gNavigationService.back(context, arg: {
                      "EditedWatchlist":
                          BlocProvider.of<WatchlisteditCubit>(context)
                              .watchlistDetailscopy
                    });
                  }
                }),
            BlocBuilder<WatchlisteditCubit, WatchlisteditState>(
              builder: (context, state) {
                if (state is WatchlisteditInitial) {
                  return state.isLoading
                      ? LinearProgressIndicator(
                          minHeight: 6.0,
                          color: customColors().primary.withOpacity(0.8),
                          backgroundColor:
                              customColors().primary.withOpacity(0.2),
                          // value: controller.value,
                        )
                      : const SizedBox();
                } else {
                  return const SizedBox();
                }
              },
            ),
            Container(
              color: customColors().backgroundSecondary,
              width: width,
              child: Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 16.0, vertical: 24),
                child: CustomTextFormField(
                  controller: BlocProvider.of<WatchlisteditCubit>(context)
                      .textfieldcontroller,
                  fieldName: "Edit Name",
                  hintText: " Enter watchlist name",
                  onChange: (value) {
                    BlocProvider.of<WatchlisteditCubit>(context)
                        .editWatchName(value);
                  },
                  bordercolor: customColors().backgroundTertiary,
                  inputFormatter: [
                    FilteringTextInputFormatter.allow(
                        RegExp(r'^[A-Za-z 0-9]+')),
                  ],
                  onFieldSubmit: (value) {},
                  keyboardAction: () {},
                ),
              ),
            ),
            BlocConsumer<WatchlisteditCubit, WatchlisteditState>(
                listener: (context, state) {
              if (state is WatchlisteditInitial) {
                if (state.errorMsg != "") {
                  ScaffoldMessenger.of(context).showSnackBar(
                      showErrorDialogue(errorMessage: state.errorMsg));
                }
              }
            }, builder: (context, state) {
              if (state is WatchlisteditInitial) {
                return Expanded(
                  flex: 1,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 16),
                        height: 50,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Row(
                              children: [
                                Text(
                                    BlocProvider.of<WatchlisteditCubit>(context)
                                            .selectedCount
                                            .toString() +
                                        "/" +
                                        state.watchlistModel.symbolDataList
                                            .length
                                            .toString() +
                                        "",
                                    style: TextStyle(
                                        fontSize: 14,
                                        color: customColors().fontPrimary,
                                        fontWeight: FontWeight.w600)),
                                const SizedBox(
                                  width: 5,
                                ),
                                Text("Selected ",
                                    style: TextStyle(
                                        fontSize: 14,
                                        color: customColors().fontTertiary,
                                        fontWeight: FontWeight.w400)),
                              ],
                            ),
                            Row(
                              children: [
                                Text("Select All",
                                    style: TextStyle(
                                        fontSize: 14,
                                        color: customColors().fontPrimary,
                                        fontWeight: FontWeight.w400)),
                                Padding(
                                  padding: const EdgeInsets.only(left: 6.0),
                                  child: EmptyCustomCheckBox(
                                      callback:
                                          BlocProvider.of<WatchlisteditCubit>(
                                                  context)
                                              .selectAllSymbols),
                                )
                              ],
                            )
                          ],
                        ),
                      ),
                      Expanded(
                        child: MansageWatchListItems(
                            selectedItems: state.statusList,
                            items: state.watchlistModel.symbolDataList),
                      )
                    ],
                  ),
                );
              }
              return Center(
                child:
                    CircularProgressIndicator(color: customColors().dodgerBlue),
              );
            }),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Padding(
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    child: BasketButton(
                      bordercolor: customColors().primary,
                      bgcolor: customColors().backgroundPrimary,
                      text: "Delete",
                      textStyle: customTextStyle(
                          fontStyle: FontStyle.BodyL_Bold,
                          color: FontColor.Primary),
                      onpress: () =>
                          BlocProvider.of<WatchlisteditCubit>(context)
                              .deleteItems(),
                      buttonwidth: width * 0.45,
                    )),
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  child: BasketButton(
                    bordercolor: transparent,
                    bgcolor: customColors().primary,
                    text: "Add to Basket",
                    textStyle: customTextStyle(
                        fontStyle: FontStyle.BodyL_Bold,
                        color: FontColor.White),
                    onpress: () {
                      // customShowModalBottomSheet(
                      //     controller: _controller,
                      //     context: context,
                      //     inputWidget: SelectBasketWidget(
                      //       title: "Select a Basket",
                      //       basketList: [
                      //         {
                      //           "name":
                      //               "All wheather investing-B-sun Dec 12 2021"
                      //         },
                      //         {"name": "Top 250 stock"},
                      //         {"name": "Top 250 stock"},
                      //         {"name": "Top 250 stock"},
                      //         {"name": "Top 250 stock"},
                      //         {"name": "Trial 1"}
                      //       ],
                      //       controller: _controller,
                      //       basketnameFont: FontStyle.BodyL_SemiBold,
                      //     ));
                    },
                    buttonwidth: width * 0.45,
                  ),
                ),
              ],
            ),
          ]),
        ),
      ),
    );
  }
}
