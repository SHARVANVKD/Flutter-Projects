import 'package:bloc/bloc.dart';
import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/app_page_injectable.dart';
import 'package:selfie_mobile_flutter/selfie/repository_layer/watchlist_content.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';

part 'manage_watchlist_state.dart';

class ManagePresetWatchlistCubit extends Cubit<ManagePresetWatchlistState> {
  final ServiceLocator serviceLocator;
  final Map<String, dynamic> data;

  ManagePresetWatchlistCubit({required this.serviceLocator, required this.data}) : super(ManagePrestWatchlistInitial(presetWatchListItems, 0)){
      int count = 0;
      for (var item in presetWatchListItems) {
        item["properties"]["enabled"] ? ++count : null;
      }
      emit(ManagePrestWatchlistInitial(presetWatchListItems, count, initialIndex: 1));
  }

  openEditWatchList(BuildContext context){
    context.gNavigationService.openEditWatchlistPage(context, {"": 0});
  }

    updatelistCheck(int index){
      int count = (state as ManagePrestWatchlistInitial).selectedItemCount;
      bool currentState = !(state as ManagePrestWatchlistInitial).presetWatchlistItem[index]["properties"]["enabled"];
      
      if(count != 6 || !currentState){
        (state as ManagePrestWatchlistInitial).presetWatchlistItem[index]["properties"]["enabled"] = currentState;
        currentState ? ++count : --count;
        emit(ManagePrestWatchlistInitial((state as ManagePrestWatchlistInitial).presetWatchlistItem, count));
      }
    }

  onCreatePressed(BuildContext context){
  }

  onBackPressed(BuildContext context){
      serviceLocator.navigationService.back(context);
  }
}
