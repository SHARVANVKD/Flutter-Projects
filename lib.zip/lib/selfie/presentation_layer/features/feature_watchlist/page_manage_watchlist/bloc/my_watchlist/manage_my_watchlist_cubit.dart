import 'package:bloc/bloc.dart';
import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/app_page_injectable.dart';
import 'package:selfie_mobile_flutter/mds_controller.dart/mds_model.dart/instrument.dart';
import 'package:selfie_mobile_flutter/selfie/repository_layer/watchlist_content.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';
import 'package:selfie_mobile_flutter/utils/models/watchlist_model.dart';

part 'manage_my_watchlist_state.dart';

class ManageMyWatchlistCubit extends Cubit<ManageMyWatchlistState> {
  final ServiceLocator serviceLocator;
  final Map<String, dynamic> data;

  ManageMyWatchlistCubit({required this.serviceLocator, required this.data}) : super(ManageMyWatchListInitial(myWatchListItems, [])){
    emit(ManageMyWatchListInitial(myWatchListItems, []));
  }

  openEditWatchList(BuildContext context){
    context.gNavigationService.openEditWatchlistPage(context, {"": 0});
  }

  onCreatePressed(BuildContext context){

  }

  onBackPressed(BuildContext context){
      serviceLocator.navigationService.back(context);
  }
}
