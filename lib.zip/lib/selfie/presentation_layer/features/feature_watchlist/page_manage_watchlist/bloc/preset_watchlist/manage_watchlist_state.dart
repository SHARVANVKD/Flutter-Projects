part of 'manage_watchlist_cubit.dart';

@immutable
abstract class ManagePresetWatchlistState {}
class ManagePrestWatchlistInitial extends ManagePresetWatchlistState {
  final List presetWatchlistItem;
  final int selectedItemCount;
  final int initialIndex;
  ManagePrestWatchlistInitial(this.presetWatchlistItem, this.selectedItemCount, {this.initialIndex = 0});
}


