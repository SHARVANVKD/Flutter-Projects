part of 'manage_my_watchlist_cubit.dart';

@immutable
abstract class ManageMyWatchlistState {}
class ManageMyWatchListInitial extends ManageMyWatchlistState {
  final List<WatchlistModel> listWatchList;
  final List myWatchListItems;
  ManageMyWatchListInitial(this.myWatchListItems, this.listWatchList);
}


