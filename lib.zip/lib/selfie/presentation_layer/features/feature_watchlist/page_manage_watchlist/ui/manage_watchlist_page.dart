import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/constants/enums.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_watchlist/page_manage_watchlist/bloc/my_watchlist/manage_my_watchlist_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_watchlist/page_manage_watchlist/bloc/preset_watchlist/manage_watchlist_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/appbar/customAppbarInner.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/buttons/BasketButton.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/scrollable_bottomsheet/custom_bottom_sheet.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/scrollable_bottomsheet/scrollable_bottomsheet.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/watchlist/manage_watchlist/custom_reoderable_list.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/delete_watchlist.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/message_tile.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/custom_top_tab.dart';

class ManageWatchlistPage extends StatefulWidget {
  final ServiceLocator serviceLocator;
  ManageWatchlistPage({Key? key,required this.serviceLocator}) : super(key: key);

  @override
  _ManageWatchlistPageState createState() => _ManageWatchlistPageState();
}

class _ManageWatchlistPageState extends State<ManageWatchlistPage>
    with TickerProviderStateMixin {
  AnimationController? _controller;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _controller = BottomSheet.createAnimationController(this);
    _controller!.duration = const Duration(milliseconds: 400);
  }

  @override
  void dispose() {
    _controller!.dispose();
    super.dispose();
  }

  bool manage = false;
  @override
  Widget build(BuildContext context) {
    double height = MediaQuery.of(context).size.height;
    double width = MediaQuery.of(context).size.width;

    return SafeArea(
      child: Scaffold(
        appBar: PreferredSize(
            preferredSize: const Size.fromHeight(0.0),
            child: AppBar(
              elevation: 0,
              backgroundColor: customColors().backgroundPrimary,
            )),
        backgroundColor: customColors().backgroundPrimary,
        body: Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              CustomAppBarInner(
                  title: "Manage",
                  onBackPressed: () {
                    BlocProvider.of<ManageMyWatchlistCubit>(context)
                        .onBackPressed(context);
                  }),
              Expanded(
                  child: CustomTabBar(
                isScrollable: true,
                tabContent: const ["My Watchlist", "Preset Watchlist"],
                tabBarViewChildern: [
                  BlocBuilder<ManageMyWatchlistCubit, ManageMyWatchlistState>(
                    builder: (context, state) {
                      if (state is ManageMyWatchListInitial) {
                        return Column(
                          children: [
                            MessageTile(
                                context,
                                "Choose or create custom watchlists:",
                                "${state.myWatchListItems.length}/10 Created"),
                            Expanded(
                              child: CustomReoderableList(
                                  edit: () {
                                    BlocProvider.of<ManageMyWatchlistCubit>(
                                            context)
                                        .openEditWatchList(context);
                                  },
                                  delete: () {
                                    customShowModalBottomSheet(
                                      context: context,
                                      inputWidget: WatchListAction(
                                        actionType: ActionType.delete,
                                        negativeOnPres: () {
                                          Navigator.pop(context);
                                        },
                                        positiveOnPress: () {
                                          Navigator.pop(context);
                                        },
                                      ),
                                    );
                                  },
                                  items: state.myWatchListItems),
                            ),
                            Padding(
                                padding: const EdgeInsets.symmetric(
                                    vertical: 12, horizontal: 16),
                                child: BasketButton(
                                  bordercolor: transparent,
                                  bgcolor: customColors().primary,
                                  text: "Create Watchlist",
                                  textStyle: customTextStyle(
                                      fontStyle: FontStyle.BodyL_Bold,
                                      color: FontColor.White),
                                  onpress: () {
                                    customShowModalBottomSheet(
                                        controller: _controller,
                                        context: context,
                                        inputWidget: CreateWatchlist(serviceLocator: widget.serviceLocator,));
                                        // inputWidget: createWatchlist(context));
                                    // BlocProvider.of<ManageWatchlistCubit>(context)
                                    //     .onCreatePressed(context);
                                  },
                                )),
                          ],
                        );
                      }
                      return Container();
                    },
                  ),
                  BlocBuilder<ManagePresetWatchlistCubit,
                      ManagePresetWatchlistState>(
                    builder: (context, state) {
                      if (state is ManagePrestWatchlistInitial) {
                        return Column(
                          children: [
                            MessageTile(
                                context,
                                "Choose indices you would like to see in your watchlist:",
                                "${state.selectedItemCount}/6 Selected"),
                            Expanded(
                              child: presetWatchlistManageContent(
                                  context: context,
                                  items: state.presetWatchlistItem,
                                  onTap: (index) {
                                    BlocProvider.of<ManagePresetWatchlistCubit>(
                                            context)
                                        .updatelistCheck(index);
                                  }),
                            ),
                          ],
                        );
                      }
                      return Container();
                    },
                  ),
                ],
              )),
            ]),
      ),
    );
  }
}

Widget presetWatchlistManageContent(
    {required BuildContext context,
    required List items,
    required void Function(int) onTap}) {
  return ListView.builder(
      shrinkWrap: true,
      itemCount: items.length,
      itemBuilder: (context, index) {
        return Container(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Container(
            padding: const EdgeInsets.symmetric(vertical: 10),
            decoration: BoxDecoration(
                border: Border(
                    bottom:
                        BorderSide(color: customColors().backgroundTertiary))),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  items[index]["Name"],
                  style: TextStyle(
                      fontFamily: "OpenSansSemiBold",
                      fontSize: 14,
                      color: customColors().fontPrimary),
                ),
                items[index]["properties"]["enabled"]
                    ? IconButton(
                        onPressed: () {
                          onTap(index);
                        },
                        icon: Image.asset("assets/checkedicon.png"))
                    : IconButton(
                        onPressed: () {
                          onTap(index);
                        },
                        icon: Image.asset("assets/uncheckicon.png")),
              ],
            ),
          ),
        );
      });
}
