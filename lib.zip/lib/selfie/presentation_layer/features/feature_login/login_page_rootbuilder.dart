import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_login/login/login_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_more/page_funds/add_funds/ui/add_funds_page.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_more/page_funds/cubit/funds_cubit.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';
import 'login_page.dart';

class LoginPageRouteBuilder {
  final ServiceLocator _serviceLocator;

  LoginPageRouteBuilder(this._serviceLocator);

  Widget call(BuildContext context) {
    return MultiBlocProvider(
        providers: [
          BlocProvider(
              create: (context) => LoginCubit(serviceLocator: _serviceLocator)),
        ],
        child: MultiRepositoryProvider(
            providers: [
              RepositoryProvider.value(value: _serviceLocator.tradingApi),
            ],
            child: LoginPage(
              serviceLocator: _serviceLocator,
            )));
  }
}
