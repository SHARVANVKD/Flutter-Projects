import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/constants/prefefence_utils.dart';
import 'package:selfie_mobile_flutter/constants/urls.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_login/login/login_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/webview/webview_page.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/buttons/BasketButton.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/custom_snackbar/custom_snackbar.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/textfields/custom_text_form_field.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/textfields/formatters.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_login/login_components.dart/login_alert_component.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_login/login_components.dart/login_alert_component2.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_login/login_components.dart/switch_account_inner.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/scrollable_bottomsheet/scrollable_bottomsheet.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/message_tile.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';
import 'package:selfie_mobile_flutter/utils/user_settings.dart';

import '../../../widgets/others/message_tile.dart';

class LoginPage extends StatefulWidget {
  final ServiceLocator serviceLocator;
  const LoginPage({Key? key, required this.serviceLocator}) : super(key: key);

  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> with TickerProviderStateMixin {
  late GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  TextEditingController idcontroller = TextEditingController(text: username);
  TextEditingController passwordcontroller = TextEditingController();
  final focus1 = FocusNode();
  final focus2 = FocusNode();
  bool passwordMissmatch = false;

  int pageCount = 1;
  String userData = "";
  String userCode = "";

  late AnimationController controller;
  @override
  void initState() {
    getUserCode();
    controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 3),
    )..addListener(() {
        setState(() {});
      });
    super.initState();
  }

  getUserCode() async {
    String usercode = "";
    if (await PreferenceUtils.preferenceHasKey("userCode")) {
      idcontroller.text =
          (await PreferenceUtils.getDataFromShared("userCode"))!;
      idcontroller.selection = TextSelection.fromPosition(
          TextPosition(offset: idcontroller.text.length));
      FocusScope.of(context).requestFocus(focus2);
    }
    // print("usercode is in getusercode $usercode" );
    // return usercode;
  }

  @override
  Widget build(BuildContext context) {
    Size screenSize = MediaQuery.of(context).size;
    double mheight = MediaQuery.of(context).size.height * 1.22;
    return Scaffold(
      appBar: PreferredSize(
          preferredSize: const Size.fromHeight(0.0),
          child: AppBar(
            elevation: 0,
            backgroundColor: customColors().backgroundPrimary,
          )),
      resizeToAvoidBottomInset: true,
      body: BlocConsumer<LoginCubit, LoginState>(
        listener: (context, state) {
          if (state is LoginError) {
            ScaffoldMessenger.of(context).showSnackBar(
                showErrorDialogue(errorMessage: state.errorMessage));
          }
        },
        builder: (context, state) {
          return SingleChildScrollView(
            child: Stack(
              alignment: Alignment.bottomCenter,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    if (state is LoginLoading)
                      LinearProgressIndicator(
                        minHeight: 6.0,
                        color: customColors().primary.withOpacity(0.8),
                        backgroundColor:
                            customColors().primary.withOpacity(0.2),
                        // value: controller.value,
                      ),
                    Form(
                      key: _formKey,
                      child: ConstrainedBox(
                        constraints: const BoxConstraints(),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            Padding(
                              padding: EdgeInsets.only(top: mheight * .050),
                              child: Image.asset("assets/selfie_logo.png"),
                            ),
                            Padding(
                              padding: const EdgeInsets.only(top: 10.0),
                              child: Padding(
                                padding:
                                    const EdgeInsets.symmetric(horizontal: 16),
                                child: (passwordMissmatch)
                                    ? Container(
                                        padding:
                                            EdgeInsets.symmetric(vertical: 8),
                                        alignment: Alignment.center,
                                        width: screenSize.width,
                                        decoration: BoxDecoration(
                                            color: customColors()
                                                .danger
                                                .withOpacity(0.15)),
                                        child: Text(
                                          "Your user name or password is incorrect.",
                                          style: customTextStyle(
                                              fontStyle:
                                                  FontStyle.BodyM_SemiBold,
                                              color: FontColor.Danger),
                                        ),
                                      )
                                    : Padding(
                                        padding: const EdgeInsets.symmetric(
                                            horizontal: 16.0),
                                        child: Container(
                                          padding: const EdgeInsets.symmetric(
                                              vertical: 8),
                                          alignment: Alignment.center,
                                          width: screenSize.width,
                                          child: const Text(
                                            "",
                                          ),
                                        ),
                                      ),
                              ),
                            ),
                            Padding(
                                padding: const EdgeInsets.only(top: 5.0),
                                child: Container(
                                  alignment: Alignment.center,
                                  height: 49,
                                  child: (pageCount == 2 || pageCount == 3)
                                      ? Column(
                                          children: [
                                            Text(
                                              userData,
                                              style: customTextStyle(
                                                  fontStyle: FontStyle
                                                      .HeaderS_SemiBold,
                                                  color: FontColor.FontPrimary),
                                            ),
                                            const SizedBox(
                                              height: 5.0,
                                            ),
                                            Text(
                                              UserSettings
                                                  .userSettings
                                                  .userPersonalSettings
                                                  .username!,
                                              style: customTextStyle(
                                                  fontStyle:
                                                      FontStyle.BodyM_Regular,
                                                  color:
                                                      FontColor.FontSecondary),
                                            )
                                          ],
                                        )
                                      : Column(
                                          children: const [
                                            Text(""),
                                            Text(""),
                                          ],
                                        ),
                                )),

                            // ============= login START ==============
                            Padding(
                              padding: const EdgeInsets.only(
                                  top: 25.0, left: 16.0, right: 16.0),
                              child: (pageCount == 1)
                                  ? CustomTextFormField(
                                      controller: idcontroller,
                                      fieldName: "User ID",
                                      hintText: " Enter Trade Code",
                                      onChange: (val) {
                                        BlocProvider.of<LoginCubit>(context)
                                            .emit(LoginInitial());
                                      },

                                      // error: state is LoginError
                                      //     ? (state as LoginError).errorMessage
                                      //     : null,
                                      bordercolor:
                                          customColors().backgroundTertiary,
                                      // validator: Validator.account,
                                      inputFormatter: [
                                        UpperCaseTextFormatter()
                                      ],
                                      autoFocus: false,
                                      focusNode: focus1,
                                      onFieldSubmit: (value) async {
                                        if (passwordcontroller.text != "") {
                                          if (_formKey.currentState!
                                              .validate()) {
                                            passwordMissmatch =
                                                await BlocProvider.of<
                                                        LoginCubit>(context)
                                                    .sendLoginRequest(
                                              context: context,
                                              userId: idcontroller.text,
                                              password: passwordcontroller.text,
                                            );
                                          }
                                        } else {
                                          if (validationCheck()) return;
                                          FocusScope.of(context)
                                              .requestFocus(focus2);
                                        }
                                      },
                                      keyboardAction: () async {
                                        if (validationCheck()) return;
                                        if (_formKey.currentState!.validate()) {
                                          passwordMissmatch = await BlocProvider
                                                  .of<LoginCubit>(context)
                                              .sendLoginRequest(
                                                  context: context,
                                                  userId: idcontroller.text,
                                                  password:
                                                      passwordcontroller.text);
                                        }
                                      },
                                    )
                                  : Padding(
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 16.0),
                                      child: Container(
                                        height: 72.0,
                                      ),
                                    ),
                            ),

                            Padding(
                              padding: const EdgeInsets.only(
                                  top: 20, left: 16.0, right: 16.0),
                              child: CustomTextFormField(
                                autoFocus: false,
                                controller: passwordcontroller,
                                fieldName: "Password",
                                hintText: " Enter Password",
                                topEndWidget: (pageCount == 2)
                                    ? Text(
                                        "Password Expires in 10 days",
                                        style: customTextStyle(
                                            fontStyle: FontStyle.BodyM_Regular,
                                            color: FontColor.Danger),
                                      )
                                    : (pageCount == 3)
                                        ? Text(
                                            "Password Expired",
                                            style: customTextStyle(
                                                fontStyle:
                                                    FontStyle.BodyM_Regular,
                                                color: FontColor.Danger),
                                          )
                                        : null,
                                // error: state is LoginError
                                //     ? (state as LoginError).errorMessage
                                //     : null,
                                validator: Validator.password,
                                obscureTextStatus: true,
                                focusNode: focus2,
                                onChange: (val) {
                                  BlocProvider.of<LoginCubit>(context)
                                      .emit(LoginInitial());
                                },
                                onFieldSubmit: (value) async {
                                  if (_formKey.currentState!.validate()) {
                                    passwordMissmatch = await BlocProvider.of<
                                            LoginCubit>(context)
                                        .sendLoginRequest(
                                            context: context,
                                            userId: idcontroller.text,
                                            password: passwordcontroller.text);
                                  }
                                },
                                keyboardAction: () {
                                  if (_formKey.currentState!.validate()) {
                                    BlocProvider.of<LoginCubit>(context)
                                        .sendLoginRequest(
                                            context: context,
                                            userId: idcontroller.text,
                                            password: passwordcontroller.text);
                                  }
                                },
                              ),
                            ),
                            Padding(
                              padding: EdgeInsets.only(
                                  top: mheight * .020, right: 16.0, left: 16.0),
                              child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  GestureDetector(
                                    onTap: () {
                                      customBottomSheet(
                                        context: context,
                                        inputWidget: SwitchAccountInner(),
                                      );
                                    },
                                    child: (userData.isNotEmpty)
                                        ? Text(
                                            "Switch Account",
                                            style: customTextStyle(
                                                fontStyle:
                                                    FontStyle.BodyM_SemiBold,
                                                color: FontColor.Primary),
                                          )
                                        : const Text(""),
                                  ),
                                  InkWell(
                                    onTap: () {
                                      Navigator.push(
                                          context,
                                          PageRouteBuilder(
                                              transitionDuration:
                                                  Duration(seconds: 1),
                                              pageBuilder: (BuildContext
                                                      context,
                                                  Animation<double> animation,
                                                  Animation<double>
                                                      secondAnimation) {
                                                return SlideTransition(
                                                    position: Tween<Offset>(
                                                      begin: Offset(100, 0.0),
                                                      end: Offset.zero,
                                                    ).animate(animation),
                                                    child: CustomWebviewPage(
                                                        urlAddress: CommonUrls
                                                            .forgotPasswordUrl));
                                              }));
                                    },
                                    child: Text(
                                      "Forgot Password?",
                                      style: customTextStyle(
                                          fontStyle: FontStyle.BodyL_SemiBold,
                                          color: FontColor.Primary),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Padding(
                              padding: EdgeInsets.only(
                                  top: mheight * .040, left: 16.0, right: 16.0),
                              child: BasketButton(
                                bgcolor: state is LoginLoading
                                    ? customColors().primary.withOpacity(0.4)
                                    : customColors().primary,
                                text: "Login",
                                textStyle: customTextStyle(
                                    fontStyle: FontStyle.BodyL_Bold,
                                    color: FontColor.White),
                                onpress: () async {
                                  if (_formKey.currentState!.validate() &&
                                      state is! LoginLoading) {
                                    passwordMissmatch = await BlocProvider.of<
                                            LoginCubit>(context)
                                        .sendLoginRequest(
                                            context: context,
                                            userId: idcontroller.text,
                                            password: passwordcontroller.text);
                                  }
                                },
                              ),
                            ),
                            InkWell(
                              onTap: () {
                                customBottomSheet(
                                    context: context,
                                    inputWidget: (pageCount == 2)
                                        ? const LoginAlertComponent()
                                        : const LoginAlertComponent2());
                              },
                              child: Padding(
                                padding: const EdgeInsets.only(
                                    left: 16, right: 16.0, top: 10.0),
                                child: (pageCount == 2)
                                    ? Container(
                                        height: 48.0,
                                        alignment: Alignment.center,
                                        width: screenSize.width,
                                        decoration: BoxDecoration(
                                          border: Border.all(
                                              color: customColors().green4),
                                          borderRadius:
                                              BorderRadius.circular(4.0),
                                        ),
                                        child: Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.center,
                                          children: [
                                            SizedBox(
                                              width: 15.0,
                                              height: 17.0,
                                              child: Image.asset(
                                                  "assets/fingerprint.png"),
                                            ),
                                            const SizedBox(
                                              width: 10.0,
                                            ),
                                            Text(
                                              "Login with Fingerprint",
                                              style: customTextStyle(
                                                  fontStyle:
                                                      FontStyle.BodyL_SemiBold,
                                                  color: FontColor.Primary),
                                            ),
                                          ],
                                        ),
                                      )
                                    : (pageCount == 3)
                                        ? Container(
                                            height: 48.0,
                                            alignment: Alignment.center,
                                            width: screenSize.width,
                                            decoration: BoxDecoration(
                                              border: Border.all(
                                                  color: customColors().green4),
                                              borderRadius:
                                                  BorderRadius.circular(4.0),
                                            ),
                                            child: Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              children: [
                                                Image.asset(
                                                    "assets/pattern.png"),
                                                const SizedBox(
                                                  width: 10.0,
                                                ),
                                                Text(
                                                  "Login with Pattern",
                                                  style: customTextStyle(
                                                      fontStyle: FontStyle
                                                          .BodyL_SemiBold,
                                                      color: FontColor.Primary),
                                                ),
                                              ],
                                            ),
                                          )
                                        : Padding(
                                            padding: const EdgeInsets.symmetric(
                                                horizontal: 16.0),
                                            child: Container(
                                              height: 48,
                                            ),
                                          ),
                              ),
                            ),

                            Padding(
                              padding: EdgeInsets.only(top: 10),
                              child: Text(
                                "Practice Simulator",
                                style: customTextStyle(
                                    fontStyle: FontStyle.BodyL_SemiBold,
                                    color: FontColor.Primary),
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.only(top: 61.0),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Text(
                                    "Not registered yet?",
                                    style: customTextStyle(
                                        fontStyle: FontStyle.BodyM_Regular,
                                        color: FontColor.FontPrimary),
                                  ),
                                  const SizedBox(
                                    width: 4.0,
                                  ),
                                  Text(
                                    "Open an account",
                                    style: customTextStyle(
                                        fontStyle: FontStyle.BodyL_Bold,
                                        color: FontColor.Primary),
                                  )
                                ],
                              ),
                            ),
                            const Padding(
                              padding: EdgeInsets.only(top: 12.0),
                              child: Divider(
                                height: 1.0,
                                thickness: 1.0,
                                indent: 16.0,
                                endIndent: 16.0,
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.only(
                                  left: 16.0, right: 16.0, top: 8.0),
                              child: Text(
                                "NSE & BSE-SEBI Registration no.: INZ000031633 MCX - SEBI Registration no.: INZ000038238 | CDSL - SEBI Registration no.: IN- DP-431-2019",
                                textAlign: TextAlign.center,
                                style: customTextStyle(
                                    fontStyle: FontStyle.BodyS_Regular,
                                    color: FontColor.FontSecondary),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
                Padding(
                    padding: const EdgeInsets.only(top: 10.0),
                    child: skipButton(context, "$pageCount/3", () {
                      if (pageCount > 1) {
                        setState(() {
                          pageCount--;
                        });
                      }
                    }, () {
                      if (pageCount < 3) {
                        setState(() {
                          pageCount++;
                          if (pageCount == 1) {
                            userData = "";
                            userCode = "";
                            print("object $userData");
                          } else {
                            userData = "Jaydeep Nandhu";
                            userCode = "AAN268";
                          }
                        });
                      }
                    })),
              ],
            ),
          );
        },
      ),
    );
  }

  validationCheck() {
    if (idcontroller.text.isEmpty) {
      CustomSnackbar().validationSnackbar(
          context: context, message: "Trade code can not be empty");
      return true;
    }
    if (passwordcontroller.text.isEmpty) {
      CustomSnackbar().validationSnackbar(
          context: context, message: "Password can not be empty");
      return true;
    }
    return false;
  }
}

SnackBar showErrorDialogue({required String errorMessage}) {
  return SnackBar(
    backgroundColor: customColors().backgroundTertiary,
    duration: const Duration(microseconds: 1),
    content: Text(
      "",
      style: customTextStyle(
          fontStyle: FontStyle.BodyM_SemiBold, color: FontColor.Danger),
    ),
  );
}
// test(){
// Person haris =Person(name: "Haris", age: "22");
//                                       Person sathyajith = haris.copyWith();
//                                       print("haris.name = ${haris.name}, haris.age = ${haris.age}");
//                                       print("sathyajith.name = ${sathyajith.name}, sathyajith.age = ${sathyajith.age}");
//                                       sathyajith.name = "sathyajith";
//                                       print("haris.name = ${haris.name}, haris.age = ${haris.age}");
//                                       print("sathyajith.name = ${sathyajith.name}, sathyajith.age = ${sathyajith.age}");
// }
// class Person {
//   String name;
//   String age;
//   Person({required this.name, required this.age});

//   Person copyWith(){
//     return Person(name: this.name, age: this.age);
//   }
// }

// updatePerson(Person newPerson){
//   newPerson.name = "sathyajith";
// }