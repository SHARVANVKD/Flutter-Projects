part of 'login_cubit.dart';

@immutable
abstract class LoginState {}

class LoginLoading extends LoginState {}

class LoginInitial extends LoginState {
  final String userId;
  LoginInitial({this.userId = "AAA333"});
}

class LoginError extends LoginState {
  final int errorCode;
  final String errorMessage;

  LoginError({required this.errorCode, required this.errorMessage});
}

// class TFA_Initial extends LoginState {
//   int tfaTokenType = 0;
//   String userId;
//   String password;
//   TFA_Initial({this.tfaTokenType = 0, required this.userId, required this.password});
// }

// class TFA_Error extends LoginState {
//   final int errorCode;
//   final String errorMessage;

//   TFA_Error({required this.errorCode, required this.errorMessage});
// }

// class NetworkError extends LoginState {}

// class Error extends LoginState {
//   final int errorCode;
//   final String errorMessage;

//   Error({required this.errorCode, required this.errorMessage});
// }


