part of 'tfa_cubit.dart';

@immutable
abstract class TfaState {}

class TfaInitial extends TfaState {
  String userId;
  String password;
  int tfaType;

  TfaInitial({this.tfaType = 0, required this.userId, required this.password});
}

class TfaError extends TfaState {

  String errorMessage;
  TfaError({required this.errorMessage});
}

class TfaLoading extends TfaState {}


// class TFA_Initial extends LoginState {
//   int tfaTokenType = 0;
//   String userId;
//   String password;
//   TFA_Initial({this.tfaTokenType = 0, required this.userId, required this.password});
// }

// class TFA_Error extends LoginState {
//   final int errorCode;
//   final String errorMessage;

//   TFA_Error({required this.errorCode, required this.errorMessage});
// }