import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_login/login/tfa/tfa_auth_page.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_login/login/tfa/tfa_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_more/page_funds/add_funds/ui/add_funds_page.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_more/page_funds/cubit/funds_cubit.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';

class TfaAuthPageRouteBuilder {
  final ServiceLocator _serviceLocator;
  final Map<String, dynamic> data;
  TfaAuthPageRouteBuilder(this._serviceLocator, this.data);

  Widget call(BuildContext context) {
    return MultiBlocProvider(
        providers: [
          BlocProvider(
              create: (context) => TfacomponentCubit(
                  serviceLocator: _serviceLocator,
                  userId: data["userId"],
                  password: data["password"])),
          // BlocProvider(
          //     create: (context) =>
          //         FundsCubit(serviceLocator: _serviceLocator))
        ],
        child: MultiRepositoryProvider(
            providers: [
              RepositoryProvider.value(value: _serviceLocator.tradingApi),
            ],
            child: TfaAuthPage(
              serviceLocator: _serviceLocator,
            )));
  }
}
