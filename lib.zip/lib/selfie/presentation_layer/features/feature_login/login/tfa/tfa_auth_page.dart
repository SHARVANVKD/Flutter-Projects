import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/constants/formaters.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_login/login/login_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_login/login/tfa/tfa_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_login/login_page.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/buttons/BasketButton.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/textfields/custom_text_form_field.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/message_tile.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class TfaAuthPage extends StatefulWidget {
  final ServiceLocator serviceLocator;
  const TfaAuthPage({Key? key, required this.serviceLocator}) : super(key: key);

  @override
  _TfaAuthPageState createState() => _TfaAuthPageState();
}

class _TfaAuthPageState extends State<TfaAuthPage>
    with TickerProviderStateMixin {
  late GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  TextEditingController tfaController = TextEditingController();
  int groupValue = 0;
  int pageCount = 1;
  late AnimationController controller;

  @override
  void initState() {
    controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 3),
    )..addListener(() {
        setState(() {});
      });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    double mheight = MediaQuery.of(context).size.height * 1.22;
    return Stack(
      children: [
        Scaffold(
          appBar: PreferredSize(
              preferredSize: const Size.fromHeight(0.0),
              child: AppBar(
                elevation: 0,
                backgroundColor: customColors().backgroundPrimary,
              )),
          resizeToAvoidBottomInset: true,
          body: BlocConsumer<TfacomponentCubit, TfaState>(
            listener: (context, state) {
              if (state is TfaError) {
                ScaffoldMessenger.of(context).showSnackBar(
                    showErrorDialogue(errorMessage: state.errorMessage));
              }
            },
            builder: (context, state) {
              return Column(
                children: [
                  if (state is TfaLoading)
                    LinearProgressIndicator(
                      minHeight: 6.0,
                      color: customColors().primary.withOpacity(0.8),
                      backgroundColor: customColors().primary.withOpacity(0.2),
                      // value: controller.value,
                    ),
                  Expanded(
                    child: SingleChildScrollView(
                      child: Form(
                        key: _formKey,
                        child: ConstrainedBox(
                          constraints: const BoxConstraints(),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Padding(
                                padding: EdgeInsets.only(top: mheight * .110),
                                child: (pageCount == 1)
                                    ? Image.asset("assets/dob.png")
                                    : (pageCount == 2)
                                        ? Image.asset("assets/pan.png")
                                        : (pageCount == 3)
                                            ? Image.asset(
                                                "assets/secure_pin.png")
                                            : (pageCount == 4)
                                                ? Image.asset("assets/otp.png")
                                                : null,
                              ),

                              // ============= TFA START ==============

                              Padding(
                                padding: const EdgeInsets.only(
                                    left: 16.0, right: 16.0, top: 60.0),
                                child: (pageCount == 1)
                                    ? Container(
                                        alignment: Alignment.center,
                                        padding: const EdgeInsets.symmetric(
                                            horizontal: 16.0, vertical: 30.0),
                                        decoration: BoxDecoration(
                                            color: customColors()
                                                .backgroundTertiary),
                                        child: CustomTextFormField(
                                          controller: tfaController,
                                          fieldName: "DOB",
                                          hintText: "DD/MM/YYYY",
                                          // error: state is TFA_Error
                                          //     ? state.errorMessage
                                          //     : null,
                                          validator: Validator.defaultValidator,
                                          keyboardType: TextInputType.number,
                                          inputFormatter: [
                                            FilteringTextInputFormatter
                                                .digitsOnly,
                                            DateTextFormatter()
                                          ],
                                          onChange: (val) {},
                                          onFieldSubmit: (value) {
                                            if (_formKey.currentState!
                                                .validate()) {
                                              BlocProvider.of<
                                                          TfacomponentCubit>(
                                                      context)
                                                  .sendTfaRequest(
                                                      context: context,
                                                      tfaToken:
                                                          tfaController.text);
                                            }
                                          },
                                          keyboardAction: () {
                                            if (_formKey.currentState!
                                                .validate()) {
                                              BlocProvider.of<
                                                          TfacomponentCubit>(
                                                      context)
                                                  .sendTfaRequest(
                                                      context: context,
                                                      tfaToken:
                                                          tfaController.text);
                                            }
                                          },
                                        ),
                                      )
                                    : (pageCount == 2)
                                        ? Container(
                                            alignment: Alignment.center,
                                            padding: const EdgeInsets.symmetric(
                                                horizontal: 16.0,
                                                vertical: 30.0),
                                            decoration: BoxDecoration(
                                                color: customColors()
                                                    .backgroundTertiary),
                                            child: CustomTextFormField(
                                              controller: tfaController,
                                              fieldName: "PAN",
                                              hintText: "Enter Pan NUmber",
                                              // error: state is TFA_Error
                                              //     ? state.errorMessage
                                              //     : null,
                                              validator:
                                                  Validator.defaultValidator,
                                              keyboardType: TextInputType.text,
                                              inputFormatter: [
                                                FilteringTextInputFormatter
                                                    .singleLineFormatter,
                                              ],
                                              onChange: (val) {},
                                              onFieldSubmit: (value) {
                                                if (_formKey.currentState!
                                                    .validate()) {
                                                  BlocProvider.of<
                                                              TfacomponentCubit>(
                                                          context)
                                                      .sendTfaRequest(
                                                          context: context,
                                                          tfaToken:
                                                              tfaController
                                                                  .text);
                                                }
                                              },
                                              keyboardAction: () {
                                                if (_formKey.currentState!
                                                    .validate()) {
                                                  BlocProvider.of<
                                                              TfacomponentCubit>(
                                                          context)
                                                      .sendTfaRequest(
                                                          context: context,
                                                          tfaToken:
                                                              tfaController
                                                                  .text);
                                                }
                                              },
                                            ),
                                          )
                                        : (pageCount == 3)
                                            ? Container(
                                                alignment: Alignment.center,
                                                padding:
                                                    const EdgeInsets.symmetric(
                                                        horizontal: 16.0,
                                                        vertical: 30.0),
                                                decoration: BoxDecoration(
                                                    color: customColors()
                                                        .backgroundTertiary),
                                                child: CustomTextFormField(
                                                  bottomEndWidget: Padding(
                                                    padding:
                                                        const EdgeInsets.only(
                                                            top: 13.0),
                                                    child: Text(
                                                      "Forgot PIN?",
                                                      style: customTextStyle(
                                                          fontStyle: FontStyle
                                                              .BodyL_SemiBold,
                                                          color: FontColor
                                                              .Primary),
                                                    ),
                                                  ),
                                                  controller: tfaController,
                                                  fieldName: "Secure Pin",
                                                  hintText: "Enter Secure Pin",
                                                  // error: state is TFA_Error
                                                  //     ? state.errorMessage
                                                  //     : null,
                                                  validator: Validator
                                                      .defaultValidator,
                                                  keyboardType:
                                                      TextInputType.number,
                                                  inputFormatter: [
                                                    FilteringTextInputFormatter
                                                        .digitsOnly,
                                                  ],
                                                  onChange: (val) {},
                                                  onFieldSubmit: (value) {
                                                    if (_formKey.currentState!
                                                        .validate()) {
                                                      BlocProvider.of<
                                                                  TfacomponentCubit>(
                                                              context)
                                                          .sendTfaRequest(
                                                              context: context,
                                                              tfaToken:
                                                                  tfaController
                                                                      .text);
                                                    }
                                                  },
                                                  keyboardAction: () {
                                                    if (_formKey.currentState!
                                                        .validate()) {
                                                      BlocProvider.of<
                                                                  TfacomponentCubit>(
                                                              context)
                                                          .sendTfaRequest(
                                                              context: context,
                                                              tfaToken:
                                                                  tfaController
                                                                      .text);
                                                    }
                                                  },
                                                ),
                                              )
                                            : (pageCount == 4)
                                                ? Container(
                                                    alignment: Alignment.center,
                                                    padding: const EdgeInsets
                                                            .symmetric(
                                                        horizontal: 16.0,
                                                        vertical: 30.0),
                                                    decoration: BoxDecoration(
                                                        color: customColors()
                                                            .backgroundTertiary),
                                                    child: CustomTextFormField(
                                                      bottomStartWidget: Column(
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .start,
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .start,
                                                        children: [
                                                          const SizedBox(
                                                            height: 5.0,
                                                          ),
                                                          SizedBox(
                                                            width: 296.0,
                                                            height: 36.0,
                                                            child: Text(
                                                              "Secure Code has been sent to you register mobile number & Email-ID",
                                                              overflow:
                                                                  TextOverflow
                                                                      .visible,
                                                              maxLines: 2,
                                                              style: customTextStyle(
                                                                  fontStyle:
                                                                      FontStyle
                                                                          .BodyM_Regular,
                                                                  color: FontColor
                                                                      .FontSecondary),
                                                            ),
                                                          ),
                                                          const SizedBox(
                                                            height: 5.0,
                                                          ),
                                                          Row(
                                                            children: [
                                                              Text(
                                                                "Time remaining:",
                                                                style: customTextStyle(
                                                                    fontStyle:
                                                                        FontStyle
                                                                            .BodyM_Regular,
                                                                    color: FontColor
                                                                        .FontSecondary),
                                                              ),
                                                              const SizedBox(
                                                                width: 3.0,
                                                              ),
                                                              Text(
                                                                "4:50",
                                                                style: customTextStyle(
                                                                    fontStyle:
                                                                        FontStyle
                                                                            .BodyM_SemiBold,
                                                                    color: FontColor
                                                                        .FontPrimary),
                                                              ),
                                                              Padding(
                                                                padding:
                                                                    const EdgeInsets
                                                                            .only(
                                                                        left:
                                                                            90.0),
                                                                child: Text(
                                                                  "Resend Code",
                                                                  style: customTextStyle(
                                                                      fontStyle:
                                                                          FontStyle
                                                                              .BodyM_SemiBold,
                                                                      color: FontColor
                                                                          .FontTertiary),
                                                                ),
                                                              )
                                                            ],
                                                          )
                                                        ],
                                                      ),
                                                      controller: tfaController,
                                                      fieldName: "Secure Code",
                                                      hintText:
                                                          "Enter Secure Code",
                                                      // error: state is TFA_Error
                                                      //     ? state.errorMessage
                                                      //     : null,
                                                      validator: Validator
                                                          .defaultValidator,
                                                      keyboardType:
                                                          TextInputType.number,
                                                      inputFormatter: [
                                                        FilteringTextInputFormatter
                                                            .digitsOnly,
                                                      ],
                                                      onChange: (val) {},
                                                      onFieldSubmit: (value) {
                                                        if (_formKey
                                                            .currentState!
                                                            .validate()) {
                                                          BlocProvider.of<
                                                                      TfacomponentCubit>(
                                                                  context)
                                                              .sendTfaRequest(
                                                                  context:
                                                                      context,
                                                                  tfaToken:
                                                                      tfaController
                                                                          .text);
                                                        }
                                                      },
                                                      keyboardAction: () {
                                                        if (_formKey
                                                            .currentState!
                                                            .validate()) {
                                                          BlocProvider.of<
                                                                      TfacomponentCubit>(
                                                                  context)
                                                              .sendTfaRequest(
                                                                  context:
                                                                      context,
                                                                  tfaToken:
                                                                      tfaController
                                                                          .text);
                                                        }
                                                      },
                                                    ),
                                                  )
                                                : null,
                              ),
                              // ============= TFA END ==============
                              Padding(
                                  padding: EdgeInsets.only(
                                      top: mheight * .070,
                                      left: 16.0,
                                      right: 16.0),
                                  child: BasketButton(
                                    bgcolor: state is TfaLoading
                                        ? customColors()
                                            .primary
                                            .withOpacity(0.4)
                                        : customColors().primary,
                                    text: "Submit",
                                    textStyle: customTextStyle(
                                        fontStyle: FontStyle.BodyL_Bold,
                                        color: FontColor.White),
                                    onpress: () {
                                      if (_formKey.currentState!.validate() ||
                                          state is! TfaLoading) {
                                        BlocProvider.of<TfacomponentCubit>(
                                                context)
                                            .sendTfaRequest(
                                                context: context,
                                                tfaToken: tfaController.text);
                                      }
                                    },
                                  )),
                              Padding(
                                padding: const EdgeInsets.only(top: 10.0),
                                child: skipButton(context, "$pageCount/4", () {
                                  if (pageCount > 1) {
                                    setState(() {
                                      pageCount--;
                                    });
                                  }
                                }, () {
                                  if (pageCount < 4) {
                                    setState(() {
                                      pageCount++;
                                    });
                                  }
                                }),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              );
            },
          ),
        ),
        Positioned(
          bottom: mheight * .050,
          left: 0.0,
          right: 0.0,
          child: Padding(
            padding: EdgeInsets.only(top: mheight * .121),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Material(
                  child: Text(
                    "Not registered yet?",
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyM_Regular,
                        color: FontColor.FontPrimary),
                  ),
                ),
                const SizedBox(
                  width: 4.0,
                ),
                Padding(
                  padding: EdgeInsets.only(top: mheight * .004),
                  child: Material(
                    child: Text(
                      "Open an account",
                      style: customTextStyle(
                          fontStyle: FontStyle.BodyL_Bold,
                          color: FontColor.Primary),
                    ),
                  ),
                )
              ],
            ),
          ),
        )
      ],
    );
  }
}
