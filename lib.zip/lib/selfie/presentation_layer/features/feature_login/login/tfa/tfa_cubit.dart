import 'dart:io';

import 'package:bloc/bloc.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:meta/meta.dart';
import 'package:selfie_mobile_flutter/constants/error_mapper.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_login/login/login_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_more/page_funds/cubit/funds_cubit.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';
import 'package:selfie_mobile_flutter/user_controller/user_controller.dart';
import 'package:trading_api/common/dto_header.dart';
import 'package:trading_api/responses/login_response.dart';

part 'tfa_state.dart';

class TfacomponentCubit extends Cubit<TfaState> {
  String userId;
  String password;
  final ServiceLocator serviceLocator;
  TfacomponentCubit(
      {required this.userId,
      required this.password,
      required this.serviceLocator})
      : super(TfaInitial(userId: userId, password: password));

  ///handles 2 factor authentication
  ///```dart
  ///sendTfaRequest(context: context, tfaToken: "24/04/1979")
  ///```
  ///will return an error code in dto header
  ///
  ///or Error-Code equals 0 then 2 factor login success
  sendTfaRequest({required context, required String tfaToken}) async {
    emit(TfaLoading());
    try {
      LoginResponse loginResponse = await serviceLocator.tradingApi
          .tfaRequest(userId: userId, password: password, tfaToken: tfaToken);
      if (loginResponse.errorCode == 0) {
        Dtoheader dtoheader = loginResponse.intReqObj!.dtoheader!;
        if (dtoheader.errorCode == 0) {
          //handle login
          // UserController().loginResponse = loginResponse;
          // UserController().sessionKey = dtoheader.sessionKey!;
          // UserController().userName = loginResponse.intReqObj!.userName!;
          // BlocProvider.of<LoginCubit>(context).sendFundsRequest(context: context);
          serviceLocator.tradingApi.getBuyingPower();
          serviceLocator.tradingApi.profileRequest();
          // BlocProvider.of<FundsCubit>(context).sendFundsRequest(context: context);
          serviceLocator.navigationService.openWorkspacePage(context);
        } else if (errorMap.containsKey(dtoheader.errorCode)) {
          emit(TfaError(
              errorMessage: errorMap[dtoheader.errorCode.toString()]!));
        } else {
          emit(TfaError(errorMessage: "Login failed"));
        }
      } else {
        emit(TfaError(errorMessage: "Login failed"));
      }
    } on SocketException {
      emit(TfaError(errorMessage: "Network Exception"));
    } catch (e) {
      emit(TfaError(errorMessage: e.toString()));
    }
  }
}
