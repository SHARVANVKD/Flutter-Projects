import 'dart:io';
import 'package:bloc/bloc.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:meta/meta.dart';
import 'package:selfie_mobile_flutter/constants/error_mapper.dart';
import 'package:selfie_mobile_flutter/constants/prefefence_utils.dart';
import 'package:selfie_mobile_flutter/mds_controller.dart/mds_controller.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';
import 'package:selfie_mobile_flutter/user_controller/user_controller.dart';
import 'package:selfie_mobile_flutter/utils/server_time_calculator.dart';
import 'package:selfie_mobile_flutter/utils/user_settings.dart';
import 'package:trading_api/common/dto_header.dart';
import 'package:trading_api/responses/login_response.dart';

part 'login_state.dart';

const username = "AAA333";
const password = "a12345678";
const dob = "01/06/1985"; //1985-06-01

class LoginCubit extends Cubit<LoginState> {
  final ServiceLocator serviceLocator;

  LoginCubit({required this.serviceLocator})
      : super(LoginInitial(userId: username)) {}

  ///handles selfie user login
  ///```dart
  ///sendLoginRequest(context: context, userName: "VYJ252", password: "Lion1234")
  ///```
  ///will return an error code in dto header
  ///
  ///if Error-Code equals 1522 then handle 2 factor authentication
  ///
  ///or Error-Code equals 0 then LOGIN Success
  Future<bool> sendLoginRequest(
      {required context,
      required String userId,
      required String password}) async {
    emit(LoginLoading());
    print('$userId, $password');
    try {
      DateTime requestTime = DateTime.now();
      LoginResponse loginResponse = await serviceLocator.tradingApi
          .loginRequest(userId: userId, password: password);
      DateTime responseTime = DateTime.now();

      if (loginResponse.errorCode == 0) {
        Dtoheader dtoheader = loginResponse.intReqObj!.dtoheader!;
        if (dtoheader.errorCode == 1522 || dtoheader.errorCode == 1523) {
          //
          //handle Two factor auth
          await PreferenceUtils.storeDataToShared("userCode", userId);
          if (!(await PreferenceUtils.preferenceHasKey(userId))) {
            await PreferenceUtils.storeDataToShared(
                userId, UserSettings.userSettings.toJsonString());
          }
          String? userData = await PreferenceUtils.getDataFromShared(userId);
          UserSettings.userSettings.fromJsonString(userData!);
          UserSettings.userSettings.userPersonalSettings.username =
              loginResponse.intReqObj!.userName!;
          await PreferenceUtils.storeDataToShared(
              userId, UserSettings.userSettings.toJsonString());
          UserController().loginResponse = loginResponse;

          UserController().sessionKey = dtoheader.sessionKey;
          UserController().userName = loginResponse.intReqObj!.userName!;
          UserController.userController.userShortName = loginResponse
              .intReqObj!.userName!
              .split(" ")
              .map((el) => el.substring(0, 1))
              .join("")
              .toUpperCase();
          UserController.userController.userShortName =
              UserController.userController.userShortName.substring(
                  0,
                  UserController.userController.userShortName.length > 1
                      ? 2
                      : 1);
          UserController().userId = userId;
          // ProfileResponse profileResponse =
          //     await serviceLocator.tradingApi.profileRequest(userId: userId);
          // if (profileResponse.errorCode == "0") {
          //   UserController.userController.profileData = profileResponse;
          // }
          // print(profileResponse.toJson());
          emit(LoginInitial());
          await MDS_Controller().mdsLogin();
          serviceLocator.navigationService.openTfaAuthPage(
              context, {"userId": userId, "password": password});
          return true;
          // emit(TFA_Initial(userId: userId, password: password,));
        } else if (dtoheader.errorCode == 0) {
          //handle login
          await PreferenceUtils.storeDataToShared("userCode", userId);
          if (!(await PreferenceUtils.preferenceHasKey(userId))) {
            await PreferenceUtils.storeDataToShared(
                userId, UserSettings.userSettings.toJsonString());
          }
          String? userData = await PreferenceUtils.getDataFromShared(userId);
          UserSettings.userSettings.fromJsonString(userData!);
          UserSettings.userSettings.userPersonalSettings.username =
              loginResponse.intReqObj!.userName!;
          await PreferenceUtils.storeDataToShared(
              userId, UserSettings.userSettings.toJsonString());
          loginResponse.intReqObj!.serverTimeDifference = ServerTimeCalculator()
              .secondDifference(
                  serverTimeString:
                      loginResponse.intReqObj!.serverTime.toString(),
                  requestStartTime: requestTime,
                  requestEndTime: responseTime);
          UserController().loginResponse = loginResponse;
          UserController().sessionKey = dtoheader.sessionKey;
          UserController().userName = loginResponse.intReqObj!.userName!;
          UserController.userController.userShortName = loginResponse
              .intReqObj!.userName!
              .split(" ")
              .map((el) => el.substring(0, 1))
              .join("")
              .toUpperCase();
          UserController.userController.userShortName =
              UserController.userController.userShortName.substring(
                  0,
                  UserController.userController.userShortName.length > 1
                      ? 2
                      : 1);
          UserController().userId = userId;
          serviceLocator.tradingApi.getBuyingPower();
          serviceLocator.tradingApi.profileRequest();
          // ProfileResponse profileResponse =
          //     await serviceLocator.tradingApi.profileRequest(userId: userId);
          // if (profileResponse.errorCode == "0") {
          //   UserController.userController.profileData = profileResponse;
          // }
          // print(profileResponse.toJson());
          // emit(LoginInitial());
          await MDS_Controller().mdsLogin(username: userId, password: password);
          serviceLocator.navigationService.openWorkspacePage(context);
          return true;
        } else if (errorMap.containsKey(dtoheader.errorCode.toString())) {
          emit(LoginError(
              errorCode: dtoheader.errorCode,
              errorMessage: errorMap[dtoheader.errorCode.toString()]!));
          return true;
        } else {
          emit(LoginError(
              errorCode: loginResponse.errorCode!,
              errorMessage: "Login failed"));
          return false;
        }
      } else {
        emit(LoginError(
            errorCode: loginResponse.errorCode!, errorMessage: "Login failed"));
        return false;
      }
    } on SocketException {
      // emit(NetworkError());
      return true;
    } catch (e) {
      emit(LoginError(errorCode: 000, errorMessage: e.toString()));
      return true;
    }
  }

  sendFundsRequest({required context}) async {
    try {
      await serviceLocator.tradingApi.getBuyingPower();
    } on SocketException {
    } catch (e) {
      emit(LoginError(errorCode: 000, errorMessage: e.toString()));
    }
  }
}
