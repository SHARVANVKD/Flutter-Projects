import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/app_page_injectable.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order_window/order_window_components/order_window_title_component.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/buttons/BasketButton.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/message_tile.dart';

import 'package:selfie_mobile_flutter/theme/styles.dart';

class SwitchAccountInner extends StatefulWidget {
  int? selected;
  SwitchAccountInner({Key? key, this.selected = 0}) : super(key: key);

  @override
  State<SwitchAccountInner> createState() => _SwitchAccountInnerState();
}

class _SwitchAccountInnerState extends State<SwitchAccountInner> {
  int screenCount = 1;
  @override
  Widget build(BuildContext context) {
    return Stack(
      // alignment: Alignment.bottomCenter,
      children: [
        Column(
          children: [
            Padding(
              padding:
                  const EdgeInsets.symmetric(vertical: 12.0, horizontal: 16.0),
              child: Row(
                children: [
                  Text(
                    "Switch Account",
                    style: customTextStyle(
                        fontStyle: FontStyle.HeaderXS_SemiBold,
                        color: FontColor.FontPrimary),
                  )
                ],
              ),
            ),
            Container(
              height: 1,
              color: customColors().backgroundTertiary,
            ),
            (screenCount == 2)
                ? Padding(
                    padding: const EdgeInsets.only(top: 20.0),
                    child: ListView.builder(
                      shrinkWrap: true,
                      itemCount: switchAccounts.length,
                      itemBuilder: ((context, index) {
                        return Container(
                          child: Padding(
                            padding: const EdgeInsets.symmetric(vertical: 16.0),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                Padding(
                                  padding: const EdgeInsets.only(left: 16.0),
                                  child: CustomRadioButton(
                                      noLabel: true,
                                      value: index,
                                      groupValue: widget.selected!,
                                      onChanged: (int val) {
                                        setState(() {
                                          widget.selected = val;
                                        });
                                      }),
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(left: 10.0),
                                  child: Row(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(switchAccounts[index]["name"],
                                          style: customTextStyle(
                                              fontStyle:
                                                  FontStyle.BodyL_Regular,
                                              color: FontColor.FontPrimary)),
                                    ],
                                  ),
                                )
                              ],
                            ),
                          ),
                        );
                      }),
                    ),
                  )
                : Padding(
                    padding: const EdgeInsets.only(top: 44.0),
                    child: SizedBox(
                        height: 80.0,
                        width: 92.0,
                        child: Image.asset("assets/circles_confirm.png")),
                  ),
            Padding(
              padding:
                  const EdgeInsets.only(left: 16.0, right: 16.0, top: 45.0),
              child: BasketButton(
                bgcolor: customColors().primary,
                text: "Add Account",
                textStyle: customTextStyle(
                    fontStyle: FontStyle.BodyL_Bold, color: FontColor.White),
                onpress: () {
                  context.gNavigationService.openLoginPage(context);
                },
              ),
            ),
          ],
        ),
        Positioned(
          left: 200,
          child: Align(
            alignment: Alignment.center,
            child: skipButton(
              context,
              "$screenCount/2",
              () {
                if (screenCount > 1) {
                  setState(() {
                    screenCount--;
                  });
                }
              },
              () {
                if (screenCount < 2) {
                  setState(() {
                    screenCount++;
                  });
                }
              },
            ),
          ),
        ),
      ],
    );
  }
}

List<Map<String, dynamic>> switchAccounts = [
  {
    "name": "Jaydeep - AAN249",
  },
  {
    "name": "Mohit - KJM595",
  }
];
