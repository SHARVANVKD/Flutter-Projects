import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/message_tile.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class LoginAlertComponent extends StatefulWidget {
  const LoginAlertComponent({Key? key}) : super(key: key);

  @override
  State<LoginAlertComponent> createState() => _LoginAlertComponentState();
}

class _LoginAlertComponentState extends State<LoginAlertComponent> {
  int screenCount = 1;
  @override
  Widget build(BuildContext context) {
    return Stack(
      alignment: Alignment.topRight,
      children: [
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.only(left: 22.0, top: 12.0),
              child: Text(
                "Login to Selfie",
                style: customTextStyle(
                    fontStyle: FontStyle.HeaderS_SemiBold,
                    color: FontColor.FontPrimary),
              ),
            ),
            Padding(
                padding: const EdgeInsets.only(left: 110.0, top: 30.0),
                child: (screenCount == 1 ||
                        screenCount == 2 ||
                        screenCount == 3)
                    ? Column(
                        children: [
                          SizedBox(
                            height: 84.0,
                            width: 84.0,
                            child: Image.asset("assets/2.0x/fingerprint.png",
                                color: screenCount == 1
                                    ? null
                                    : screenCount == 3
                                        ? customColors().primary
                                        : customColors().danger),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(top: 10.0),
                            child: Text(
                              screenCount == 1 || screenCount == 3
                                  ? ""
                                  : "Try Again",
                              style: customTextStyle(
                                fontStyle: FontStyle.BodyM_SemiBold,
                                color: FontColor.Danger,
                              ),
                            ),
                          ),
                          const SizedBox(height: 14.0),
                          Text(
                            "Login with Fingerprint",
                            style: customTextStyle(
                              fontStyle: FontStyle.BodyL_Regular,
                              color: FontColor.FontSecondary,
                            ),
                          ),
                        ],
                      )
                    : null),
            Padding(
              padding: const EdgeInsets.only(
                left: 22.0,
              ),
              child: Row(
                children: [
                  GestureDetector(
                    onTap: () {
                      Navigator.pop(context);
                    },
                    child: Text(
                      "cancel",
                      style: customTextStyle(
                          fontStyle: FontStyle.BodyL_SemiBold,
                          color: FontColor.Primary),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
        Positioned(
          left: 200.0,
          child: Align(
            alignment: Alignment.center,
            child: skipButton(
              context,
              "$screenCount/3",
              () {
                if (screenCount > 1) {
                  setState(() {
                    screenCount--;
                  });
                }
              },
              () {
                if (screenCount < 3) {
                  setState(() {
                    screenCount++;
                  });
                }
              },
            ),
          ),
        ),
      ],
    );
  }
}
