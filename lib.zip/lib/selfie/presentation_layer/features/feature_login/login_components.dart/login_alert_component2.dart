import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/message_tile.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';
import 'package:pattern_lock/pattern_lock.dart';

class LoginAlertComponent2 extends StatefulWidget {
  const LoginAlertComponent2({Key? key}) : super(key: key);

  @override
  State<LoginAlertComponent2> createState() => _LoginAlertComponent2State();
}

class _LoginAlertComponent2State extends State<LoginAlertComponent2> {
  int screenCount = 1;
  @override
  Widget build(BuildContext context) {
    return Stack(
      alignment: Alignment.topRight,
      children: [
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.only(left: 22.0, top: 12.0),
              child: Text(
                "Login to Selfie",
                style: customTextStyle(
                    fontStyle: FontStyle.HeaderS_SemiBold,
                    color: FontColor.FontPrimary),
              ),
            ),
            Padding(
                padding: const EdgeInsets.only(left: 10.0, top: 10.0),
                child:
                    (screenCount == 1 || screenCount == 2 || screenCount == 3)
                        ? Column(
                            // crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                height: 165,
                                child: PatternLock(
                                  selectedColor: customColors().primary,
                                  pointRadius: 5,
                                  showInput: true,
                                  dimension: 3,
                                  relativePadding: 0.3,
                                  selectThreshold: 5,
                                  fillPoints: true,
                                  onInputComplete: (List<int> input) {
                                    print("pattern is $input");
                                  },
                                ),
                              ),
                              const SizedBox(
                                height: 5.0,
                              ),
                              Text(
                                screenCount == 1 || screenCount == 2
                                    ? ""
                                    : "Try Again",
                                style: customTextStyle(
                                  fontStyle: FontStyle.BodyM_SemiBold,
                                  color: FontColor.Danger,
                                ),
                              ),
                              Text(
                                "Login with Pattern",
                                style: customTextStyle(
                                  fontStyle: FontStyle.BodyL_Regular,
                                  color: FontColor.FontSecondary,
                                ),
                              ),
                            ],
                          )
                        : null),
            Padding(
              padding: const EdgeInsets.only(
                left: 22.0,
              ),
              child: GestureDetector(
                onTap: () {
                  Navigator.pop(context);
                },
                child: Text(
                  "cancel",
                  style: customTextStyle(
                      fontStyle: FontStyle.BodyL_SemiBold,
                      color: FontColor.Primary),
                ),
              ),
            ),
          ],
        ),
        Positioned(
          left: 200,
          child: Align(
            alignment: Alignment.center,
            child: skipButton(
              context,
              "$screenCount/3",
              () {
                if (screenCount > 1) {
                  setState(() {
                    screenCount--;
                  });
                }
              },
              () {
                if (screenCount < 3) {
                  setState(() {
                    screenCount++;
                  });
                }
              },
            ),
          ),
        ),
      ],
    );
  }
}
