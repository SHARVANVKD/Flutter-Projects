import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_stock/individual_stock_page/ui/individual_stock_page.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';

class OptionIndividualPageRouteBuilder {
  final ServiceLocator _serviceLocator;

  OptionIndividualPageRouteBuilder(this._serviceLocator);

  Widget call(BuildContext context) {
    return MultiRepositoryProvider(providers: [
      RepositoryProvider.value(value: _serviceLocator.tradingApi),
    ], child: const IndividualStockPage());
  }
}
