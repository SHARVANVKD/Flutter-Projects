import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_review_and_send/ui/remarks/ui/remark_page.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_review_and_send/ui/reviewandorderpage.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_review_and_send/ui/roll_order_review_page/ui/roll_order_review_page.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_watchlist/page_watchlist_edit/watchlist_edit_page.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/workspace/bloc/workspace_cubit.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';

class RollReviewAndOrderPageRouteBuilder {
  final ServiceLocator _serviceLocator;

  RollReviewAndOrderPageRouteBuilder(this._serviceLocator);

  Widget call(BuildContext context) {
    return MultiBlocProvider(
        providers: [
          BlocProvider(
              create: (context) =>
                  WorkSpaceCubit(serviceLocator: _serviceLocator)),
        ],
        child: MultiRepositoryProvider(providers: [
          RepositoryProvider.value(value: _serviceLocator.navigationService),
          RepositoryProvider<CubitsLocator>.value(value: _serviceLocator),
        ], child: RollOrderReviewPage()));
  }
}
