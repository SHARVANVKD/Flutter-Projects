import 'dart:io';

import 'package:bloc/bloc.dart';
import 'package:meta/meta.dart';
import 'package:selfie_mobile_flutter/services/api_gateway.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';
import 'package:selfie_mobile_flutter/user_controller/user_controller.dart';
import 'package:trading_api/responses/profile_response.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';

part 'profile_state.dart';

class ProfileCubit extends Cubit<ProfileState> {
  // final ServiceLocator serviceLocator;
  final TradingApiGateway? tradingApiGateway;
  ProfileCubit(
      {
      // required this.serviceLocator ,
      this.tradingApiGateway})
      : super(ProfileInitial());
  sendProfieRequest(
      {required context,
      required String userId,
      required ServiceLocator serviceLocator}) async {
    emit(ProfileLoading());
    try {
      // if(UserController().profileData!.profileResponseStatus==false){
      // ProfileResponse profileResponse = await serviceLocator.tradingApi.profileRequest(userId: userId);
      // if (profileResponse.errorCode == 0) {
      //   UserController().profileData=profileResponse;
      //   UserController().profileData!.profileResponseStatus=true;
      // }else {
      //   emit(ProfileError(
      //       errorCode: profileResponse.errorCode!, errorMessage: "Profile fetch failed"));
      // }

      // }
      context.gNavigationService.openProfilePage(context);
    } on SocketException {
    } catch (errorMessage) {
      emit(ProfileError(errorCode: 000, errorMessage: errorMessage.toString()));
    }
  }
}
