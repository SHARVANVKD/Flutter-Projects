part of 'profile_cubit.dart';

@immutable
abstract class ProfileState {}

class ProfileLoading extends ProfileState {}

class ProfileInitial extends ProfileState{
  final String userId;
  ProfileInitial({this.userId=""});
}

class ProfileError extends ProfileState{
  final int errorCode;
  final String errorMessage;
  ProfileError({required this.errorCode, required this.errorMessage});
}
