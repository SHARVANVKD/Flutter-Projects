import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/app_page_injectable.dart';
import 'package:selfie_mobile_flutter/global_methods/global_methods.dart';
import 'package:selfie_mobile_flutter/selfie/repository_layer/more_content.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/buttons/BasketButton.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/message_tile.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';
import 'package:selfie_mobile_flutter/user_controller/user_controller.dart';
import 'package:selfie_mobile_flutter/utils/local_storage.dart';

import '../../../widgets/custom_app_components/appbar/customAppbarInner.dart';
import '../../../widgets/others/options_widget.dart';

class ProfilePage extends StatefulWidget {
  const ProfilePage({Key? key}) : super(key: key);

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  bool powerAtorneyStatus = false;
  List<Map<String, dynamic>> activeSegmentList = profileActiveSegmentList1;
  List<Map<String, dynamic>> inactiveSegmentList = profileInactiveSegmentList1;
  List<Map<String, dynamic>> activeProductList = profileActiveProductList1;
  List<Map<String, dynamic>> inactiveProductList = profileInactiveProductList1;

  int screenCount = 1;
  @override
  void initState() {
    LocalStorage().getProfileData();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    Size screenSize = MediaQuery.of(context).size;
    // print(
    //     "masked string is ${maskStringWithStar(inputString: UserController.userController.profileData!.result3![0].phoneno!, EndIndex: UserController.userController.profileData!.result3![0].phoneno!.length - 4)}");
    return SafeArea(
      child: Scaffold(
        body: Stack(
          children: [
            SingleChildScrollView(
              child: Column(
                children: [
                  CustomAppBarInner(
                      title: "Profile",
                      onBackPressed: () {
                        context.gNavigationService.back(context);
                      }),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const TitleCardWidget(),
                      const ProfileItemsHeader(title: "CONTACT DETAILS"),
                      ProfileItems(
                          title: "Email",
                          value: UserController.userController.profileData!
                              .result3![0].emailid!),
                      // const ProfileItems(title: "Mobile", value: "******1122"),
                      ProfileItems(
                          title: "Mobile",
                          value: maskStringWithStar(
                                  inputString: UserController.userController
                                      .profileData!.result3![0].phoneno!,
                                  EndIndex: UserController
                                          .userController
                                          .profileData!
                                          .result3![0]
                                          .phoneno!
                                          .length -
                                      4) ??
                              "-"),
                      ProfileItems(
                          title: "Whatsapp No.",
                          value: maskStringWithStar(
                                  inputString: UserController.userController
                                      .profileData!.result3![0].phoneno!,
                                  EndIndex: UserController
                                          .userController
                                          .profileData!
                                          .result3![0]
                                          .phoneno!
                                          .length -
                                      4) ??
                              "-"),
                      const CustomDividerWithPadding(),
                      const ProfileItemsHeader(title: "BANK DETAILS"),
                      ProfileItems(
                          title: "Bank Name",
                          value: (UserController.userController.profileData!
                                  .result3![0].bankName!.isNotEmpty)
                              ? UserController.userController.profileData!
                                  .result3![0].bankName![0]
                              : '-'),
                      ProfileItems(
                          title: "Account Number",
                          value: (UserController.userController.profileData!
                                  .result3![0].bankAccountNumber!.isNotEmpty)
                              ? maskStringWithStar(
                                  inputString: UserController
                                      .userController
                                      .profileData!
                                      .result3![0]
                                      .bankAccountNumber![0],
                                  EndIndex: UserController
                                          .userController
                                          .profileData!
                                          .result3![0]
                                          .bankAccountNumber![0]
                                          .length -
                                      4)
                              : "-"),
                      const CustomDividerWithPadding(),
                      const ProfileItemsHeader(title: "CLIENT DETAILS"),
                      // const ProfileItems(
                      //     title: "Client ID", value: "24581 HFNC"),
                      ProfileItems(
                          title: "Client ID",
                          value: UserController.userController.profileData!
                              .result3![0].dpClientid!),
                      ProfileItems(
                          title: "DP ID",
                          value: (UserController.userController.profileData!
                                  .result3![0].dpid!.isNotEmpty)
                              ? UserController.userController.profileData!
                                  .result3![0].dpid![0]
                              : "-"),
                      const CustomDividerWithPadding(),
                      Padding(
                        padding: const EdgeInsets.only(
                            left: 16, right: 16, top: 16, bottom: 16),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              "Power of Attourney",
                              style: customTextStyle(
                                  fontStyle: FontStyle.BodyL_Regular,
                                  color: FontColor.FontSecondary),
                            ),
                            (UserController.userController.profileData!
                                        .result3![0].poasigned !=
                                    true)
                                ? Text("Inactive",
                                    style: customTextStyle(
                                        fontStyle: FontStyle.BodyL_SemiBold,
                                        color: FontColor.Danger))
                                : Text("Activated",
                                    style: customTextStyle(
                                        fontStyle: FontStyle.BodyL_SemiBold,
                                        color: FontColor.Success))
                          ],
                        ),
                      ),
                      Visibility(
                          visible: (UserController.userController.profileData!
                                  .result3![0].activesegments!.isNotEmpty ||
                              UserController.userController.profileData!
                                  .result3![0].inactivesegments!.isNotEmpty),
                          child: const CustomDividerWithPadding()),
                      Visibility(
                          visible: (UserController.userController.profileData!
                              .result3![0].activesegments!.isNotEmpty),
                          child: const ProfileItemsHeader(
                              title: "ACTIVE SEGMENTS")),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16.0),
                        child: Wrap(
                          runSpacing: 6,
                          spacing: 6,
                          children: List.generate(
                            UserController.userController.profileData!
                                .result3![0].activesegments!.length,
                            // activeSegmentList.length,
                            (index) => getProductTypeWidget(UserController
                                .userController
                                .profileData!
                                .result3![0]
                                .activesegments![index]),
                            // activeSegmentList[index]["name"]),
                          ).toList(),
                        ),
                      ),
                      Visibility(
                        visible: (UserController.userController.profileData!
                                .result3![0].inactivesegments!.isNotEmpty)
                            ? true
                            : false,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  const ProfileItemsHeader(
                                      title: "INACTIVE SEGMENTS"),
                                  Padding(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 16.0),
                                    child: Wrap(
                                      runSpacing: 6,
                                      spacing: 6,
                                      children: List.generate(
                                        UserController
                                            .userController
                                            .profileData!
                                            .result3![0]
                                            .inactivesegments!
                                            .length,
                                        (index) => getProductTypeWidget(
                                            UserController
                                                .userController
                                                .profileData!
                                                .result3![0]
                                                .inactivesegments![index]),
                                      ).toList(),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Padding(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 16.0),
                              child: SizedBox(
                                width: screenSize.width * .258,
                                child: Center(
                                  child: BasketButton(
                                    verticalPadding: 5.5,
                                    bordercolor: customColors().primary,
                                    text: "Activate Now",
                                    textStyle: customTextStyle(
                                        fontStyle: FontStyle.BodyM_SemiBold,
                                        color: FontColor.Primary),
                                    onpress: () {
                                      // Navigator.of(context).pop(true);
                                    },
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Visibility(
                        visible: (UserController.userController.profileData!
                                .result3![0].activesegments!.isNotEmpty ||
                            UserController.userController.profileData!
                                .result3![0].inactivesegments!.isNotEmpty),
                        child: const SizedBox(
                          height: 32,
                        ),
                      ),
                      Visibility(
                          visible: UserController.userController.profileData!
                                      .result3![0].activeProducts!.length !=
                                  0
                              ? true
                              : false,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const CustomDividerWithPadding(),
                              const ProfileItemsHeader(
                                  title: "ACTIVE PRODUCTS"),
                            ],
                          )),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16.0),
                        child: Wrap(
                          runSpacing: 6,
                          spacing: 6,
                          children: List.generate(
                            UserController.userController.profileData!
                                .result3![0].activeProducts!.length,
                            (index) => getProductTypeWidget(UserController
                                .userController
                                .profileData!
                                .result3![0]
                                .activeProducts![index]),
                          ).toList(),
                        ),
                      ),
                      if (UserController.userController.profileData!.result3![0]
                          .inactiveProducts!.isNotEmpty)
                        Column(
                          children: [
                            const SizedBox(
                              height: 16,
                            ),
                            const CustomDividerWithPadding(),
                            Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                crossAxisAlignment: CrossAxisAlignment.end,
                                children: [
                                  Expanded(
                                    child: Column(
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        const ProfileItemsHeader(
                                            title: "INACTIVE PRODUCTS"),
                                        Padding(
                                          padding: const EdgeInsets.symmetric(
                                              horizontal: 16.0),
                                          child: Wrap(
                                            runSpacing: 6,
                                            spacing: 6,
                                            children: List.generate(
                                                UserController
                                                    .userController
                                                    .profileData!
                                                    .result3![0]
                                                    .inactiveProducts!
                                                    .length,
                                                (index) => ProductTypeWidget(
                                                    text: UserController
                                                            .userController
                                                            .profileData!
                                                            .result3![0]
                                                            .inactiveProducts![
                                                        index],
                                                    textColor:
                                                        FontColor.FontTertiary,
                                                    boxColor: customColors()
                                                        .silverDust)).toList(),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 16.0),
                                    child: SizedBox(
                                      width: screenSize.width * .258,
                                      child: Center(
                                        child: BasketButton(
                                          verticalPadding: 5.5,
                                          bordercolor: customColors().primary,
                                          text: "Activate Now",
                                          textStyle: customTextStyle(
                                              fontStyle:
                                                  FontStyle.BodyM_SemiBold,
                                              color: FontColor.Primary),
                                          onpress: () {
                                            // Navigator.of(context).pop(true);
                                          },
                                        ),
                                      ),
                                    ),
                                  ),
                                ]),
                          ],
                        ),
                      const SizedBox(
                        height: 40,
                      )
                    ],
                  ),
                ],
              ),
            ),
            Align(
              alignment: Alignment.bottomCenter,
              child: skipButton(context, "$screenCount/2", () {
                if (screenCount > 1) {
                  setState(() {
                    screenCount--;
                    activeSegmentList = profileActiveSegmentList1;
                    inactiveSegmentList = profileInactiveSegmentList1;
                    activeProductList = profileActiveProductList1;
                    inactiveProductList = profileInactiveProductList1;
                  });
                }
              }, () {
                if (screenCount < 2) {
                  setState(() {
                    screenCount++;
                    activeSegmentList = profileActiveSegmentList2;
                    inactiveSegmentList = profileInactiveSegmentList2;
                    activeProductList = profileActiveProductList2;
                    inactiveProductList = profileInactiveProductList2;
                  });
                }
              }),
            ),
          ],
        ),
      ),
    );
  }
}

class ProfileItemsHeader extends StatelessWidget {
  final String title;
  const ProfileItemsHeader({
    Key? key,
    required this.title,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 16, right: 16, top: 16, bottom: 16),
      child: Text(title,
          style: customTextStyle(
              fontStyle: FontStyle.TagNameL_Bold,
              color: FontColor.FontPrimary)),
    );
  }
}

class TitleCardWidget extends StatelessWidget {
  const TitleCardWidget({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 16.0, right: 16, top: 12),
      child: InkWell(
        onTap: () => {},
        child: Container(
          decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(4.0),
              color: customColors().backgroundSecondary),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(
                child: Row(
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(
                          left: 12, right: 12, top: 16, bottom: 16),
                      child: CircleAvatar(
                        radius: 35,
                        backgroundColor: customColors().peachBackgrond,
                        child: Text(UserController.userController.userShortName,
                            textAlign: TextAlign.center,
                            style: customTextStyle(
                                fontStyle: FontStyle.HeaderXS_SemiBold,
                                color: FontColor.wTokenFontColor)),
                      ),
                    ),
                    const SizedBox(
                      width: 4,
                    ),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Align(
                            alignment: Alignment.centerLeft,
                            child: Text(
                                UserController.userController.loginResponse!
                                    .intReqObj!.userName
                                    .toString(),
                                // softWrap: false,
                                overflow: TextOverflow.clip,
                                maxLines: 1,
                                style: customTextStyle(
                                    fontStyle: FontStyle.HeaderXS_Bold,
                                    color: FontColor.FontPrimary)),
                          ),
                          const SizedBox(
                            height: 6,
                          ),
                          Align(
                            alignment: Alignment.centerLeft,
                            child: Text(
                                "Trade Code - ${UserController.userController.userId}",
                                style: customTextStyle(
                                    fontStyle: FontStyle.BodyM_SemiBold,
                                    color: FontColor.FontSecondary)),
                          )
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              // Padding(
              //   padding: const EdgeInsets.only(right: 19.0),
              //   child: Image.asset("assets/pen_square.png"),
              // ),
            ],
          ),
        ),
      ),
    );
  }
}

class ProfileItems extends StatelessWidget {
  final String title;
  final String value;
  const ProfileItems({
    Key? key,
    required this.title,
    required this.value,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 16.0, right: 16, bottom: 16),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            title,
            style: customTextStyle(
                fontStyle: FontStyle.BodyL_Regular,
                color: FontColor.FontSecondary),
          ),
          Text(value,
              style: customTextStyle(
                  fontStyle: FontStyle.BodyL_Regular,
                  color: FontColor.FontPrimary)),
        ],
      ),
    );
  }
}

class CustomDividerWithPadding extends StatelessWidget {
  const CustomDividerWithPadding({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 4),
      child: SizedBox(
        height: 0,
        child: Divider(
          thickness: 1.2,
          color: customColors().backgroundTertiary,
        ),
      ),
    );
  }
}
