part of 'option_and_future_cubit.dart';

@immutable
abstract class OptionAndFutureState {}

class OptionAndFutureInitial extends OptionAndFutureState {}
