import 'package:bloc/bloc.dart';
import 'package:meta/meta.dart';

part 'option_and_future_state.dart';

class OptionAndFutureCubit extends Cubit<OptionAndFutureState> {
  OptionAndFutureCubit() : super(OptionAndFutureInitial());
}
