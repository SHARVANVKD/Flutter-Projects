import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/app_page_injectable.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_stock/individual_stock_page/components/mbp/mbp_data.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/appbar/custom_option_and_future.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/message_tile.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/stock/mbp_status_list_item.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/search_filter.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/stock/stock_chart/linear_chart.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/stock/stock_chart/stock_analysis_chart.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/stock/stock_chart/stock_low_heigh_chart.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/stock/stock_execute_btn.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/stock/stock_page_header/stock_page_header.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class OptionAndFuturePage extends StatefulWidget {
  const OptionAndFuturePage({Key? key}) : super(key: key);

  @override
  State<OptionAndFuturePage> createState() => _OptionAndFuturePageState();
}

class _OptionAndFuturePageState extends State<OptionAndFuturePage> {
  @override
  Widget build(BuildContext context) {
    Size screenSize = MediaQuery.of(context).size;
    return Scaffold(
      appBar: PreferredSize(
          preferredSize: const Size.fromHeight(0.0),
          child: AppBar(
            elevation: 0,
            backgroundColor: customColors().backgroundPrimary,
          )),
      body: Column(
        children: [
          CustomOptionAndFutureAppBar(
            exchangeName: "NFO",
            date: '23 JAN 22',
            onBackPressed: () {
              context.gNavigationService.back(context);
            },
            onMoreActionPressed: () {},
            title: "BANKNIFTY OPT 38000 CE",
          ),
          Expanded(
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  StockPageHeaderSection(
                      price: 574.45,
                      percentage: 0.72,
                      currentValue: 4.95,
                      decrease: true,
                      optionChartButton: true,
                      chartPage: () {
                        context.gNavigationService.openStockChartPage(context);
                      }),
                  const SizedBox(height: 10),
                  SearchFilter(category: const [
                    "Overview",
                    "Research",
                    "Analysis",
                    "Positions",
                    "History"
                  ], buttonHandler: (tab) {}),
                  const SizedBox(height: 24),
                  Padding(
                    padding: const EdgeInsets.only(left: 16),
                    child: Text("Market by Price (MBP)",
                        style: customTextStyle(
                            fontStyle: FontStyle.HeaderXS_Bold,
                            color: FontColor.FontPrimary)),
                  ),
                  const Padding(
                    padding: EdgeInsets.all(16.0),
                    child: MBPData(),
                  ),
                  const StockLinearChart(),
                  const SizedBox(height: 20),
                  MBPStatusListItem(data: "2,872.00", index: 1, title: "Open"),
                  MBPStatusListItem(data: "2,328.90", index: 2, title: "Close"),
                  MBPStatusListItem(
                      data: "2,328.90",
                      index: 1,
                      title: "Average Traded Price"),
                  MBPStatusListItem(
                      data: "32,112,328", index: 2, title: "Volume"),
                  MBPStatusListItem(data: "8,123", index: 1, title: "OI"),
                  MBPStatusListItem(
                      data: "-831", index: 2, title: "Change in OI"),
                  MBPStatusListItem(
                      data: "18,332,120", index: 1, title: "Spot"),
                  MBPStatusListItem(data: "Long", index: 2, title: "Buildup"),
                  MBPStatusListItem(
                    data: "Bullish",
                    index: 1,
                    title: "View",
                    change: true,
                    type: Type.Bearish,
                  ),
                  MBPStatusListItem(data: "Yes", index: 2, title: "Illiquid"),
                  MBPStatusListItem(data: "No", index: 1, title: "Blocked "),
                  StockLowHeighChart(
                      thumbPosition: 0.3,
                      startTitile: "Today’s Low",
                      endTitle: "Today’s High"),
                  StockLowHeighChart(
                      thumbPosition: 0.3,
                      startValue: "3,001.45",
                      endValue: "3,289.09",
                      startTitile: "Lower Circuit",
                      endTitle: "Upper Circuit"),
                  const SizedBox(height: 40),
                  Padding(
                    padding: const EdgeInsets.only(left: 16),
                    child: Text("Geojit Sentiments",
                        style: customTextStyle(
                            fontStyle: FontStyle.HeaderXS_Bold,
                            color: FontColor.FontPrimary)),
                  ),
                  const StockAnalysisChart(),
                ],
              ),
            ),
          ),
        ],
      ),
      bottomNavigationBar: Container(
        height: 76,
        width: screenSize.width * 1,
        decoration: BoxDecoration(
          border: Border(
            top: BorderSide(
              color: customColors().backgroundTertiary,
              width: 1,
            ),
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16.0),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              Expanded(
                child: StockExecuteButton(
                  text: "Buy",
                  bgColor: customColors().success,
                  onTap: () {
                    context.gNavigationService.openOrderWindowPage(context,
                        {"title": "TATAPOWER", "type": "Cash", "order": "buy"});
                  },
                ),
              ),
              const SizedBox(
                width: 8.0,
              ),
              Expanded(
                child: StockExecuteButton(
                  text: "Sell",
                  bgColor: customColors().danger,
                  onTap: () {
                    context.gNavigationService.openOrderWindowPage(context, {
                      "title": "TATAPOWER",
                      "type": "Cash",
                      "order": "sell"
                    });
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
