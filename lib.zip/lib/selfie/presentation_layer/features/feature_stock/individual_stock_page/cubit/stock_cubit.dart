import 'package:bloc/bloc.dart';
import 'package:meta/meta.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';
part 'stock_state.dart';

class StockCubit extends Cubit<StockState> {
  StockCubit({required this.serviceLocator}) : super(StockInitial());

  ServiceLocator serviceLocator;
  bool isVisibleOverView = true;
  bool isVisibleHistory = false;
  bool isVisiblePositions = false;

  List<String> tabPages = [
    "Overview",
    "Research",
    "Analysis",
    "Positions",
    "History"
  ];

  tabPageFunction(int tabIndex) {
    switch (tabIndex) {
      case 0:
        {
          isVisibleOverView = true;
          isVisibleHistory = false;
          isVisiblePositions = false;
          emit(StockInitial());
        }
        break;

      case 3:
        {
          isVisibleOverView = false;
          isVisibleHistory = false;
          isVisiblePositions = true;
          emit(StockInitial());
        }
        break;
      case 4:
        {
          isVisibleOverView = false;
          isVisibleHistory = true;
          isVisiblePositions = false;
          emit(StockInitial());
        }
        break;
    }
  }
}
