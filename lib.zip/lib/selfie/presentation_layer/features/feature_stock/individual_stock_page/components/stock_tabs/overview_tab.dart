import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/app_page_injectable.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_stock/individual_stock_page/components/mbp/mbp_data.dart';
import 'package:selfie_mobile_flutter/selfie/repository_layer/list_data.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/announcement_list_container.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/company_news_list_item.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/dealst_list_container.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/stock/company_details_container/company_detail_tile.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/stock/mbp_status_list_item.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/stock/stock_chart/linear_chart.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/stock/stock_chart/stock_analysis_chart.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/stock/stock_chart/stock_low_heigh_chart.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class OverviewTabPage extends StatefulWidget {
  const OverviewTabPage({Key? key}) : super(key: key);

  @override
  State<OverviewTabPage> createState() => _OverviewTabPageState();
}

class _OverviewTabPageState extends State<OverviewTabPage> {
  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const SizedBox(height: 24),
        Padding(
          padding: const EdgeInsets.only(left: 16),
          child: Text("Market by Price (MBP)",
              style: customTextStyle(
                  fontStyle: FontStyle.HeaderXS_Bold,
                  color: FontColor.FontPrimary)),
        ),
        const Padding(
          padding: EdgeInsets.all(16.0),
          child: MBPData(),
        ),
        const StockLinearChart(),
        const SizedBox(height: 20),
        MBPStatusListItem(data: "2,872.00", index: 1, title: "Open"),
        MBPStatusListItem(data: "2,328.90", index: 2, title: "Close"),
        MBPStatusListItem(
            data: "2,328.90", index: 1, title: "Average Traded Price"),
        MBPStatusListItem(data: "32,112,328", index: 2, title: "Volume"),
        MBPStatusListItem(data: "1,798,123", index: 1, title: "Traded Qty."),
        MBPStatusListItem(
            data: "2,328.90", index: 2, title: "Last Traded Qty."),
        MBPStatusListItem(data: "No", index: 1, title: "Illiquid"),
        MBPStatusListItem(data: "No", index: 2, title: "Trade to Trade"),
        MBPStatusListItem(data: "INE467B01029", index: 1, title: "ISIN"),
        StockLowHeighChart(
            thumbPosition: 0.3,
            startTitile: "Today’s Low",
            endTitle: "Today’s High"),
        StockLowHeighChart(
            thumbPosition: 0.3,
            startTitile: "52 Weeks Low",
            endTitle: "52 Weeks High"),
        StockLowHeighChart(
            thumbPosition: 0.3,
            startTitile: "Lower Circuit",
            endTitle: "Upper Circuit"),
        const SizedBox(height: 40),
        Padding(
          padding: const EdgeInsets.only(left: 16),
          child: Text("Geojit Sentiments",
              style: customTextStyle(
                  fontStyle: FontStyle.HeaderXS_Bold,
                  color: FontColor.FontPrimary)),
        ),
        const StockAnalysisChart(),
        const CompanyDetails(),
        const SizedBox(height: 40),
        Padding(
          padding: const EdgeInsets.only(
            left: 16,
          ),
          child: Text("Announcements",
              style: customTextStyle(
                  fontStyle: FontStyle.HeaderXS_Bold,
                  color: FontColor.FontPrimary)),
        ),
        const AnnouncementListConatiner(),
        Padding(
          padding: const EdgeInsets.only(left: 16, top: 16, right: 16),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text("Deals",
                  style: customTextStyle(
                      fontStyle: FontStyle.HeaderXS_Bold,
                      color: FontColor.FontPrimary)),
              GestureDetector(
                onTap: () {
                  context.gNavigationService.openDealsPage(context);
                },
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(bottom: 3),
                      child: Text("View More  ",
                          style: customTextStyle(
                              fontStyle: FontStyle.BodyL_Bold,
                              color: FontColor.Primary)),
                    ),
                    Image.asset(
                      "assets/strokeright.png",
                    )
                  ],
                ),
              ),
            ],
          ),
        ),
        DealsListContainer(dealsList: dealsList),
        Padding(
          padding: const EdgeInsets.only(left: 16, bottom: 16, top: 20),
          child: Text("Company News",
              style: customTextStyle(
                  fontStyle: FontStyle.HeaderXS_Bold,
                  color: FontColor.FontPrimary)),
        ),
        ComapnyNewsListItem(
          image: "assets/imgone.png",
          newshead:
              "Stock in review: TCS, Zee Entertainment, Axis bank, ITC...",
          source: "ECONOMIC TIMES",
          status: "NEGATIVE",
          time: "1 HR AGO",
        ),
        const SizedBox(height: 8),
        ComapnyNewsListItem(
          image: "assets/imgtwo.png",
          newshead: "Metro Brands, HCL Tech, TCS in focus",
          source: "ECONOMIC TIMES",
          status: "POSITIVE",
          time: "1 HR AGO",
        ),
        const SizedBox(height: 8),
        ComapnyNewsListItem(
          image: "assets/imgthree.png",
          newshead:
              "Stocks to watch: Reliance Industries, Zee, Yess Bank, Dish...",
          source: "ECONOMIC TIMES",
          status: "NUETRAL",
          time: "1 HR AGO",
        ),
        Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              InkWell(
                onTap: () {},
                child: Text("Load More",
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyM_Bold,
                        color: FontColor.FontPrimary)),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
