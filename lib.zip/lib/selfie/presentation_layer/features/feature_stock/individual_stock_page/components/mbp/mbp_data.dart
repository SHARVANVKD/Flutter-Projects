import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/stock/stock_mbp/ask_data_widget.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/stock/stock_mbp/bid_data_widget.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/stock/stock_mbp/bid_title_widget.dart';

class MBPData extends StatelessWidget {
  const MBPData({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            BidTitleData(
              title1: "QUANTITY",
              title2: "BID",
            ),
            BidData(bidPrice: "15,400", bidQuantity: "2872.65", precentage: 60),
            BidData(bidPrice: "22,834", bidQuantity: "2872.65", precentage: 0),
            BidData(bidPrice: "4,400", bidQuantity: "2872.65", precentage: 20),
            BidData(bidPrice: "892", bidQuantity: "2872.65", precentage: 85),
            BidData(bidPrice: "26,980", bidQuantity: "2872.65", precentage: 50),
          ],
        ),
        const SizedBox(width: 25),
        Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            BidTitleData(
              title1: "ASK",
              title2: "QUANTITY",
            ),
            AskData(askPrice: "2872.65", askQuantity: "2,874", precentage: 20),
            AskData(askPrice: "2872.65", askQuantity: "5,092", precentage: 50),
            AskData(askPrice: "2872.65", askQuantity: "1,827", precentage: 10),
            AskData(askPrice: "2872.65", askQuantity: "22,192", precentage: 30),
            AskData(askPrice: "2872.65", askQuantity: "1,870", precentage: 10),
          ],
        )
      ],
    );
  }
}
