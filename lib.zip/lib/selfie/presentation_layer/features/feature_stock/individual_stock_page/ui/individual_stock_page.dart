import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/app_page_injectable.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_stock/individual_stock_page/components/stock_tabs/history_tab.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_stock/individual_stock_page/components/stock_tabs/overview_tab.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_stock/individual_stock_page/components/stock_tabs/positions_tab.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_stock/individual_stock_page/cubit/stock_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/appbar/custom_stock_appbar.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/scrollable_bottomsheet/scrollable_bottomsheet.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/search_filter.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/stock/option_chain_more_action_bottom_sheet/more_action_bottom_sheet.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/stock/selecting_watchlist_bottomsheet/selecting_watchlist.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/stock/stock_execute_btn.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/stock/stock_page_header/stock_page_header.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/watchlist/market_overview.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class IndividualStockPage extends StatefulWidget {
  const IndividualStockPage({Key? key}) : super(key: key);

  @override
  State<IndividualStockPage> createState() => _IndividualStockPageState();
}

class _IndividualStockPageState extends State<IndividualStockPage>
    with TickerProviderStateMixin {
  void initState() {
    super.initState();
    _controller = BottomSheet.createAnimationController(this);
    _controller!.duration = const Duration(milliseconds: 400);
  }

  @override
  void dispose() {
    _controller!.dispose();
    super.dispose();
  }

  AnimationController? _controller;

  @override
  Widget build(BuildContext context) {
    Size screenSize = MediaQuery.of(context).size;
    return Scaffold(
      appBar: PreferredSize(
          preferredSize: const Size.fromHeight(0.0),
          child: AppBar(
            elevation: 0,
            backgroundColor: customColors().backgroundPrimary,
          )),
      body: Column(
        children: [
          CustomStockAppBar(
            exchangeName: "NSE",
            onBackPressed: () {
              context.gNavigationService.back(context);
            },
            onMoreActionPressed: () {
              customShowModalBottomSheet(
                context: context,
                inputWidget: MoreActionBottomSheet(
                  onAddWatchList: () {
                    Navigator.pop(context);
                    customShowModalBottomSheet(
                      context: context,
                      inputWidget: const SelectingWatchlist(),
                    );
                  },
                ),
              );
            },
            onMarketOverviewPressed: () {
              customBottomSheet(
                  controller: _controller,
                  height: .9,
                  minimumHeight: .7,
                  context: context,
                  inputWidget: MarKetOverview());
            },
            title: "TCS",
          ),
          Expanded(
            child: SingleChildScrollView(
                child: BlocBuilder<StockCubit, StockState>(
              builder: (context, state) {
                return Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    StockPageHeaderSection(
                        price: 574.45,
                        percentage: 0.72,
                        currentValue: 4.95,
                        decrease: false,
                        optionChartButton: true,
                        chartPage: () {
                          context.gNavigationService
                              .openStockChartPage(context);
                        }),
                    const SizedBox(height: 10),
                    SearchFilter(
                      category: BlocProvider.of<StockCubit>(context).tabPages,
                      buttonHandler:
                          BlocProvider.of<StockCubit>(context).tabPageFunction,
                    ),
                    Visibility(
                        visible: BlocProvider.of<StockCubit>(context)
                            .isVisibleOverView,
                        child: const OverviewTabPage()),
                    Visibility(
                        visible: BlocProvider.of<StockCubit>(context)
                            .isVisiblePositions,
                        child: const PositionsTabPage()),
                    Visibility(
                        visible: BlocProvider.of<StockCubit>(context)
                            .isVisibleHistory,
                        child: const HistoryTabPage()),
                  ],
                );
              },
            )),
          ),
        ],
      ),
      bottomNavigationBar:
          BlocProvider.of<StockCubit>(context).isVisiblePositions
              ? const SizedBox()
              : Container(
                  height: 76,
                  width: screenSize.width * 1,
                  decoration: BoxDecoration(
                    border: Border(
                      top: BorderSide(
                        color: customColors().backgroundTertiary,
                        width: 1,
                      ),
                    ),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16.0),
                    child: Row(
                      children: [
                        Expanded(
                          child: StockExecuteButton(
                            text: "Buy",
                            bgColor: customColors().success,
                            onTap: () {
                              context.gNavigationService.openOrderWindowPage(
                                  context, {
                                "title": "TATAPOWER",
                                "type": "Cash",
                                "order": "buy"
                              });
                            },
                          ),
                        ),
                        const SizedBox(
                          width: 8.0,
                        ),
                        Expanded(
                          child: StockExecuteButton(
                            text: "Sell",
                            bgColor: customColors().danger,
                            onTap: () {
                              context.gNavigationService.openOrderWindowPage(
                                  context, {
                                "title": "TATAPOWER",
                                "type": "Cash",
                                "order": "sell"
                              });
                            },
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
    );
  }
}
