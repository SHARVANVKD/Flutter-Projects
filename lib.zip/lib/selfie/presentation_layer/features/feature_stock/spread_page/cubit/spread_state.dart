part of 'spread_cubit.dart';

@immutable
abstract class SpreadState {}

class SpreadInitial extends SpreadState {}
