import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_stock/index_detail_page/ui/index_detail_page.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';

class IndexDetailPageRouteBuilder {
  final ServiceLocator _serviceLocator;

  IndexDetailPageRouteBuilder(this._serviceLocator);

  Widget call(BuildContext context) {
    return MultiRepositoryProvider(providers: [
      RepositoryProvider.value(value: _serviceLocator.tradingApi),
    ], child: IndexDetailPage());
  }
}
