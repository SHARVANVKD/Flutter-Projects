import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/app_page_injectable.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/appbar/custom_stock_appbar.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/message_tile.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/stock/mbp_status_list_item.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/search_filter.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/stock/stock_chart/stock_low_heigh_chart.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/stock/stock_page_header/stock_page_header.dart';

import '../../../../../../theme/styles.dart';

class IndexDetailPage extends StatefulWidget {
  const IndexDetailPage({Key? key}) : super(key: key);

  @override
  State<IndexDetailPage> createState() => _IndexDetailPageState();
}

class _IndexDetailPageState extends State<IndexDetailPage> {
  @override
  Widget build(BuildContext context) {
    Size screenSize = MediaQuery.of(context).size;
    return Scaffold(
      appBar: PreferredSize(
          preferredSize: const Size.fromHeight(0.0),
          child: AppBar(
            elevation: 0,
            backgroundColor: customColors().backgroundPrimary,
          )),
      body: Column(
        children: [
          CustomStockAppBar(
            onBackPressed: () {
              context.gNavigationService.back(context);
            },
            exchangeName: "INDEX",
            isVisibleCahrtOption: false,
            onMoreActionPressed: () {},
            onMarketOverviewPressed: () {},
            title: "BANKNIFTY",
          ),
          Expanded(
            child: SingleChildScrollView(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  StockPageHeaderSection(
                      price: 378911.45,
                      percentage: 0.72,
                      currentValue: 4.95,
                      decrease: false,
                      optionChartButton: true,
                      chartPage: () {
                        context.gNavigationService.openStockChartPage(context);
                      }),
                  const SizedBox(height: 10),
                  SearchFilter(
                    category: const [
                      "Overview",
                      "Research",
                      "Analysis",
                      "Positions",
                      "History"
                    ],
                    buttonHandler: (tab) {},
                  ),
                  const SizedBox(height: 30),
                  MBPStatusListItem(data: "2,872.00", index: 1, title: "Open"),
                  MBPStatusListItem(data: "2,328.90", index: 2, title: "Close"),
                  const SizedBox(height: 30),
                  StockLowHeighChart(
                      thumbPosition: 0.3,
                      startTitile: "Today’s Low",
                      endTitle: "Today’s High"),
                  StockLowHeighChart(
                      thumbPosition: 0.3,
                      startTitile: "52 Weeks Low",
                      endTitle: "52 Weeks High"),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
