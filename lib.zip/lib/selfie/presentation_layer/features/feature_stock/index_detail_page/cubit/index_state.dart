part of 'index_cubit.dart';

@immutable
abstract class IndexState {}

class IndexInitial extends IndexState {}
