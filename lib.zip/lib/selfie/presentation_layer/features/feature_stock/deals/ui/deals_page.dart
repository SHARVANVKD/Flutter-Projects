import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/app_page_injectable.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_watchlist/symbol_search/model/symboldetails_model.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/Deals/individual_stock_page_deals.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/appbar/customAppbarInner.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/textfields/symbol_search_field.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/paytm_ad_widget.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/search_filter.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/symbol_search_item.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class DealsPage extends StatefulWidget {
  const DealsPage({Key? key}) : super(key: key);

  @override
  State<DealsPage> createState() => _DealsPageState();
}

class _DealsPageState extends State<DealsPage> {
  @override
  Widget build(BuildContext context) {
    Size _displaySize = MediaQuery.of(context).size;
    return Scaffold(
      appBar: PreferredSize(
          preferredSize: const Size.fromHeight(0.0),
          child: AppBar(
            elevation: 0,
            backgroundColor: customColors().backgroundPrimary,
          )),
      body: Column(
        children: [
          CustomAppBarInner(
              title: "Deals",
              onBackPressed: () {
                context.gNavigationService.back(context);
              }),
          Expanded(child: DealsComponent()),
        ],
      ),
    );
  }
}
