part of 'deals_cubit.dart';

@immutable
abstract class DealsState {}

class DealsInitial extends DealsState {}
