import 'package:bloc/bloc.dart';
import 'package:meta/meta.dart';

part 'deals_state.dart';

class DealsCubit extends Cubit<DealsState> {
  DealsCubit() : super(DealsInitial());
}
