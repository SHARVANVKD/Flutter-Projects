import 'package:bloc/bloc.dart';
import 'package:meta/meta.dart';

part 'stock_chart_state.dart';

class StockChartCubit extends Cubit<StockChartState> {
  StockChartCubit() : super(StockChartInitial());
}
