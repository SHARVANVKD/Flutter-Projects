import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/app_page_injectable.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/appbar/custom_stock_appbar.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/stock/stock_execute_btn.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class StockChartPage extends StatefulWidget {
  const StockChartPage({Key? key}) : super(key: key);

  @override
  State<StockChartPage> createState() => _StockChartPageState();
}

class _StockChartPageState extends State<StockChartPage> {
  @override
  Widget build(BuildContext context) {
    Size screenSize = MediaQuery.of(context).size;
    return Scaffold(
      appBar: PreferredSize(
          preferredSize: const Size.fromHeight(0.0),
          child: AppBar(
            elevation: 0,
            backgroundColor: customColors().backgroundPrimary,
          )),
      backgroundColor: customColors().backgroundSecondary,
      bottomNavigationBar: Container(
        height: 76,
        width: screenSize.width * 1,
        decoration: BoxDecoration(
          border: Border(
            top: BorderSide(
              color: customColors().backgroundTertiary,
              width: 1,
            ),
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16.0),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              Expanded(
                child: StockExecuteButton(
                  text: "Buy",
                  bgColor: customColors().success,
                  onTap: () {
                    context.gNavigationService.openOrderWindowPage(context,
                        {"title": "TATAPOWER", "type": "Cash", "order": "buy"});
                  },
                ),
              ),
              const SizedBox(
                width: 8.0,
              ),
              Expanded(
                child: StockExecuteButton(
                  text: "Sell",
                  bgColor: customColors().danger,
                  onTap: () {
                    context.gNavigationService.openOrderWindowPage(context, {
                      "title": "TATAPOWER",
                      "type": "Cash",
                      "order": "sell"
                    });
                  },
                ),
              ),
            ],
          ),
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            CustomStockAppBar(
              exchangeName: "NSE",
              onBackPressed: () {
                context.gNavigationService.back(context);
              },
              onMoreActionPressed: () {},
              onMarketOverviewPressed: () {},
              title: "TCS",
            ),
          ],
        ),
      ),
    );
  }
}
