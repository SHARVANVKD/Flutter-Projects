import 'dart:core';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/app_page_injectable.dart';
import 'package:selfie_mobile_flutter/constants/enums.dart';
import 'package:selfie_mobile_flutter/global_methods/global_methods.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/bloc_navigation/navigation_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_portfolio/my_portfolio/tab_component_holdings/bloc/holdings_component_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/repository_layer/portfolio_content.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/scrollable_bottomsheet/scrollable_bottomsheet.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/search_insights_filter/portfolio_holding_filter_bar.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/textfields/position_search_field.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/portfolio_bottom_sheet_panel/fixed_button.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/sort.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/portfolio/holdings/holding_bottom_sheets.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/portfolio/holdings/holdings_tile.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/portfolio/holdings/holdings_widgets.dart';
import 'package:selfie_mobile_flutter/user_controller/user_controller.dart';

import '../bloc/my_portfolio_screen_cubit.dart';
import 'holding_list_shimmer.dart';

class HoldingsComponent extends StatefulWidget {
  Function(bool) onScrollEvent;
  int length;
  HoldingsComponent({
    Key? key,
    required this.onScrollEvent,
    required this.length,
  }) : super(key: key);

  @override
  State<HoldingsComponent> createState() => _HoldingsComponentState();
}

class _HoldingsComponentState extends State<HoldingsComponent>
    with TickerProviderStateMixin {
  int screenCount = 1;
  ScrollController _scrollBottomBarController =
      new ScrollController(); // set controller on scrolling
  final _editcontroller = TextEditingController();
  bool isScrollingDown = false;

  // List<Map<String, dynamic>> holdings = UserController().portfoliolist;

  List<String> selectedsortitem = [];

  void initState() {
    // TODO: implement initState
    super.initState();
    _controller = BottomSheet.createAnimationController(this);
    _controller!.duration = const Duration(milliseconds: 400);
    myScroll();
  }

  @override
  void dispose() {
    _controller!.dispose();
    super.dispose();
  }

  void myScroll() async {
    _scrollBottomBarController.addListener(() {
      if (_scrollBottomBarController.position.userScrollDirection ==
          ScrollDirection.reverse) {
        if (!isScrollingDown) {
          isScrollingDown = true;
          widget.onScrollEvent(false); //hide appbar
        }
      }
      if (_scrollBottomBarController.position.userScrollDirection ==
          ScrollDirection.forward) {
        if (isScrollingDown) {
          isScrollingDown = false;
          widget.onScrollEvent(true); //show appbar
        }
      }
    });
  }

  AnimationController? _controller;

  bool notify = false;
  bool notifysearch = false;
  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => HoldingsComponentCubit(),
      child: BlocBuilder<HoldingsComponentCubit, HoldingsComponentState>(
          builder: (context, state) {
        return SingleChildScrollView(
          child: Column(
            children: [
              // BlocListener<HoldingsComponentCubit, HoldingsComponentInitial>(
              //       listener: (context, state) {
              //         if (state is OrderBookScreenInitial) {
              //           BlocProvider.of<OpenComponentCubit>(context)
              //               .updateData();
              //         }
              //       },
              //       child: Container(),
              //     ),
              // BlocListener<HoldingsComponentCubit, HoldingsComponentState>(
              //   listener: (context, state) {
              //     BlocProvider.of<HoldingsComponentCubit>(context).calculations(
              //         UserController().portfolioresponce.reportData,
              //         false,
              //         filterval);
              //   },
              //   child: Container(),
              // ),
              if (state is HoldingsComponentInitial)
                SingleChildScrollView(
                  child: Column(
                    children: [
                      if (state.portfolioResponce.isEmpty &&
                          !state.searchvisible)
                        Column(
                          children: [
                            Wrap(children: [
                              Container(
                                width: double.infinity,
                                child: holdingsContainer(
                                    context: context,
                                    amount: 0,
                                    percentage: 0.0,
                                    onClickIcon: () {}),
                              ),
                            ]),
                            const SizedBox(
                              height: 8,
                            ),
                            UserController()
                                    .portfolioresponce
                                    .reportData
                                    .isEmpty
                                ? Opacity(
                                    opacity: 0.4,
                                    child: AbsorbPointer(
                                      absorbing: false,
                                      child: SearchFilterHoldings(
                                        showBubble: notify,
                                        onFilterPress: () {},
                                        onSearchPress: () {},
                                        onSortPress: () {},
                                      ),
                                    ),
                                  )
                                : Opacity(
                                    opacity: 1.0,
                                    child: AbsorbPointer(
                                      absorbing: false,
                                      child: SearchFilterHoldings(
                                        showBubble: notify,
                                        onFilterPress: () {
                                          customShowModalBottomSheet(
                                              context: context,
                                              inputWidget: PortfolioSortList(
                                                currentval: state.filterval,
                                                filterlist:
                                                    state.filter_elements,
                                                selectedLocation:
                                                    SortFilterLocation.holding,
                                                onPressFilter:
                                                    (List<String> el) {
                                                  print("####");
                                                  state.filter_elements =
                                                      List.from(el);
                                                  BlocProvider.of<
                                                              HoldingsComponentCubit>(
                                                          context)
                                                      .updateFilterlist(el);

                                                  Navigator.pop(context);
                                                },
                                                onPressSort: (int index) {
                                                  BlocProvider.of<
                                                              HoldingsComponentCubit>(
                                                          context)
                                                      .updateSortList(index);
                                                  Navigator.pop(context);
                                                },
                                                onPressReset: () {
                                                  BlocProvider.of<
                                                              HoldingsComponentCubit>(
                                                          context)
                                                      .resetSortList();
                                                  filterarrayposition.clear();
                                                  Navigator.pop(context);
                                                },
                                              ));
                                        },
                                        onSearchPress: () {
                                          print("gggg");
                                          BlocProvider.of<
                                                      HoldingsComponentCubit>(
                                                  context)
                                              .openSearch();
                                        },
                                        onSortPress: () {
                                          customShowModalBottomSheet(
                                              context: context,
                                              inputWidget: PortfolioSortList(
                                                currentval: state.filterval,
                                                selectedLocation:
                                                    SortFilterLocation.holding,
                                                selectedTabIndex: 1,
                                                onPressFilter:
                                                    (List<String> elements) {},
                                                onPressSort: (int value) {
                                                  BlocProvider.of<
                                                              HoldingsComponentCubit>(
                                                          context)
                                                      .updateSortList(value);
                                                  Navigator.pop(context);
                                                },
                                                onPressReset: () {
                                                  print(UserController()
                                                      .portfolioresetresponce
                                                      .reportData[0]
                                                      .securityname);
                                                  BlocProvider.of<
                                                              HoldingsComponentCubit>(
                                                          context)
                                                      .resetSortList();
                                                  filterarrayposition.clear();
                                                  Navigator.pop(context);
                                                },
                                              ));
                                        },
                                      ),
                                    ),
                                  ),
                            const SizedBox(
                              height: 6,
                            ),
                            Padding(
                              padding: EdgeInsets.only(top: 100),
                              child: emptyContainerPortfolioHoldings(context),
                            )
                          ],
                        )
                      else if (state.searchvisible)
                        Column(
                          children: [
                            Padding(
                              padding:
                                  const EdgeInsets.symmetric(vertical: 8.0),
                              child: Position_Search_Field(
                                  onBackPressed: () {
                                    BlocProvider.of<HoldingsComponentCubit>(
                                            context)
                                        .openInitial();
                                  },
                                  hintText: "Search eg: infy",
                                  controller: _editcontroller,
                                  onSearch: (String keyword) {
                                    if (keyword.isEmpty) {
                                      BlocProvider.of<HoldingsComponentCubit>(
                                              context)
                                          .updateSearchList(keyword);
                                    } else {
                                      BlocProvider.of<HoldingsComponentCubit>(
                                              context)
                                          .updateSearchList(keyword);
                                    }
                                  }),
                            ),
                            ListView.builder(
                                physics: ScrollPhysics(),
                                itemCount: state.portfolioResponce.length,
                                shrinkWrap: true,
                                itemBuilder: (context, index) {
                                  return InkWell(
                                    onTap: () {
                                      customBottomSheet(
                                        fixedBottomWidget: FixedButton(
                                          elevation: true,
                                          addMoreOnTap: () {
                                            context.gNavigationService
                                                .openOrderWindowPage(context, {
                                              "title": "TATAPOWER",
                                              "type": "Cash",
                                              "order": "buy"
                                            });
                                          },
                                          squareOffOnTap: () {
                                            context.gNavigationService
                                                .openOrderWindowPage(context, {
                                              "title": "TATAPOWER",
                                              "type": "Cash",
                                              "order": "sell"
                                            });
                                          },
                                          future: false,
                                          ocoOnTap: () {
                                            context.gNavigationService
                                                .openOCOOrderPage(
                                              context,
                                              {
                                                "title": "OCO Order",
                                                "symbol": "ITC Long",
                                                "qty": "100",
                                                "price": "278.80"
                                              },
                                            );
                                          },
                                        ),
                                        height: .678,
                                        maxHeight: .85,
                                        ifport: true,
                                        context: context,
                                        portfoliolist: state
                                            .portfolioResponce[index]
                                            .toJson(),
                                        ltp: double.parse(state
                                            .portfolioResponce[index].mktrate),
                                        percentage: state
                                            .portfolioResponce[index]
                                            .plPercentage,
                                        change: double.parse(state
                                            .portfolioResponce[index].pl
                                            .toStringAsFixed(2)
                                            .toString()),
                                        inputWidget: HoildinBottomSheet(
                                          index: index,
                                          reportData: state.portfolioResponce,
                                          pl: state.pl.toString(),
                                          pl_percentage:
                                              state.pl_Percentage.toString(),
                                          todays_pl: state.todays_pl.toString(),
                                        ),
                                      );
                                    },
                                    child: HoldingsListTile(
                                      reportData: state.portfolioResponce,
                                      index: index,
                                    ),
                                  );
                                }),
                          ],
                        )
                      else if (state.searchvisible == false)
                        Column(
                          children: [
                            const SizedBox(
                              height: 6,
                            ),
                            Wrap(children: [
                              Container(
                                width: double.infinity,
                                child: holdingsContainer(
                                    context: context,
                                    amount: state.pl,
                                    percentage: state.pl_Percentage.isNaN
                                        ? 0.0
                                        : state.pl_Percentage,
                                    onClickIcon: () {
                                      BlocProvider.of<NavigationCubit>(context)
                                          .updateWatchList(5);
                                    }),
                              ),
                            ]),
                            const SizedBox(
                              height: 8,
                            ),
                            Opacity(
                              opacity: 1.0,
                              child: AbsorbPointer(
                                absorbing: false,
                                child: SearchFilterHoldings(
                                  showBubble: notify,
                                  onFilterPress: () {
                                    customShowModalBottomSheet(
                                        context: context,
                                        inputWidget: PortfolioSortList(
                                          currentval: state.filterval,
                                          filterlist: state.filter_elements,
                                          selectedLocation:
                                              SortFilterLocation.holding,
                                          onPressFilter: (List<String> el) {
                                            print("####");
                                            state.filter_elements =
                                                List.from(el);
                                            BlocProvider.of<
                                                        HoldingsComponentCubit>(
                                                    context)
                                                .updateFilterlist(el);

                                            Navigator.pop(context);
                                          },
                                          onPressSort: (int index) {
                                            BlocProvider.of<
                                                        HoldingsComponentCubit>(
                                                    context)
                                                .updateSortList(index);
                                            Navigator.pop(context);
                                          },
                                          onPressReset: () {
                                            BlocProvider.of<
                                                        HoldingsComponentCubit>(
                                                    context)
                                                .resetSortList();
                                            filterarrayposition.clear();
                                            Navigator.pop(context);
                                          },
                                        ));
                                  },
                                  onSearchPress: () {
                                    BlocProvider.of<HoldingsComponentCubit>(
                                            context)
                                        .openSearch();
                                  },
                                  onSortPress: () {
                                    customShowModalBottomSheet(
                                        context: context,
                                        inputWidget: PortfolioSortList(
                                          currentval: state.filterval,
                                          selectedLocation:
                                              SortFilterLocation.holding,
                                          selectedTabIndex: 1,
                                          onPressFilter:
                                              (List<String> elements) {},
                                          onPressSort: (int value) {
                                            BlocProvider.of<
                                                        HoldingsComponentCubit>(
                                                    context)
                                                .updateSortList(value);
                                            Navigator.pop(context);
                                          },
                                          onPressReset: () {
                                            BlocProvider.of<
                                                        HoldingsComponentCubit>(
                                                    context)
                                                .resetSortList();
                                            filterarrayposition.clear();
                                            Navigator.pop(context);
                                          },
                                        ));
                                  },
                                ),
                              ),
                            ),
                            const SizedBox(
                              height: 6,
                            ),
                            ListView.builder(
                                physics: ScrollPhysics(),
                                itemCount: state.portfolioResponce.length,
                                shrinkWrap: true,
                                itemBuilder: (context, index) {
                                  return InkWell(
                                    onTap: () {
                                      customBottomSheet(
                                        fixedBottomWidget: FixedButton(
                                          elevation: true,
                                          addMoreOnTap: () {
                                            context.gNavigationService
                                                .openOrderWindowPage(context, {
                                              "title": "TATAPOWER",
                                              "type": "Cash",
                                              "order": "buy"
                                            });
                                          },
                                          squareOffOnTap: () {
                                            context.gNavigationService
                                                .openOrderWindowPage(context, {
                                              "title": "TATAPOWER",
                                              "type": "Cash",
                                              "order": "sell"
                                            });
                                          },
                                          future: false,
                                          ocoOnTap: () {
                                            context.gNavigationService
                                                .openOCOOrderPage(
                                              context,
                                              {
                                                "title": "OCO Order",
                                                "symbol": "ITC Long",
                                                "qty": "100",
                                                "price": "278.80"
                                              },
                                            );
                                          },
                                        ),
                                        height: .678,
                                        maxHeight: .85,
                                        ifport: true,
                                        context: context,
                                        portfoliolist: state
                                            .portfolioResponce[index]
                                            .toJson(),
                                        ltp: double.parse(state
                                            .portfolioResponce[index].mktrate),
                                        percentage: state
                                            .portfolioResponce[index]
                                            .plPercentage,
                                        change: double.parse(state
                                            .portfolioResponce[index].pl
                                            .toStringAsFixed(2)
                                            .toString()),
                                        inputWidget: HoildinBottomSheet(
                                          index: index,
                                          reportData: state.portfolioResponce,
                                          pl: state.pl.toString(),
                                          pl_percentage:
                                              state.pl_Percentage.toString(),
                                          todays_pl: state.todays_pl.toString(),

                                          // UserController()
                                          //     .portfolioresponce
                                          //     .reportData[index]
                                          //     .toJson(),
                                        ),
                                      );
                                    },
                                    child: HoldingsListTile(
                                      reportData: state.portfolioResponce,
                                      index: index,
                                    ),
                                  );
                                }),
                          ],
                        )
                    ],
                  ),
                )
              else if (state is Holdingloadingstate)
                SingleChildScrollView(
                  child: Column(
                    children: [
                      HoldingListShimmer(),
                    ],
                  ),
                )
              else
                Column(
                  children: [
                    Padding(
                      padding: EdgeInsets.only(top: 100),
                      child: emptyContainerPortfolioHoldings(context),
                    )
                  ],
                )
            ],
          ),
        );
      }),
    );
  }

  void filterdata(String name) {
    List<Map<String, dynamic>> list = [];

    holdingsList.forEach((element) {
      if (element.containsValue(name)) {
        list.add(element);
      }

      setState(() {
        holdingsList = List.from(list);
      });
    });
  }
}
