part of 'holdings_component_cubit.dart';

@immutable
abstract class HoldingsComponentState {}

class HoldingsComponentInitial extends HoldingsComponentState {
  final List<Map<String, dynamic>> holdingList;
  final bool sortvisible;
  final int filterval;
  final bool searchvisible;
  double pl;
  double pl_Percentage;
  List<String>? filter_elements;
  double todays_pl;
  PortfolioResponce portfolio = PortfolioResponce(
      reportData: [], intradaydata: [], errorCode: "0", columnData: "0");
  List<String>? filterarrayposition = [];
  List<ReportDatum> portfolioResponce = [];

  HoldingsComponentInitial(
      {this.sortvisible = true,
      this.searchvisible = false,
      this.filterval = 0,
      this.filterarrayposition,
      required this.holdingList,
      this.pl = 0.0,
      this.pl_Percentage = 0.0,
      this.todays_pl = 0.0,
      required this.portfolioResponce,
      required this.portfolio,
      this.filter_elements});
}

class HoldingInitstate extends HoldingsComponentState {}

class Holdingloadingstate extends HoldingsComponentState {}
// class HoldingsComponentSearch extends HoldingsComponentState {
//   HoldingsComponentSearch();
// }
