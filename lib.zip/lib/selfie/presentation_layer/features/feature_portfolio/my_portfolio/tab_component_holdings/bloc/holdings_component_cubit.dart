import 'package:bloc/bloc.dart';
import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/repository_layer/portfolio_content.dart';
import 'package:selfie_mobile_flutter/user_controller/user_controller.dart';
import 'package:trading_api/responses/portfolio_responce.dart';

import '../../../../../../widgets/others/sort.dart';

part 'holdings_component_state.dart';

class HoldingsComponentCubit extends Cubit<HoldingsComponentState> {
  HoldingsComponentCubit() : super(Holdingloadingstate()) {
    calculations(
        UserController().portfolioresponce.reportData, false, -1, false);
  }

  openSearch() {
    emit(HoldingsComponentInitial(
        holdingList: UserController().portfoliolist,
        portfolioResponce: UserController().portfolioresponce.reportData,
        searchvisible: true,
        portfolio: UserController().portfolioresponce));
  }

  openInitial() {
    calculations(
        UserController().portfolioresponce.reportData, false, -1, false);
  }

  updateSearchList(String key) {
    List<ReportDatum>? searchabledata = [];
    List<ReportDatum> list = UserController().portfolioresponce.reportData;
    searchabledata.clear();
    list.forEach(((element) {
      if (element.securitycode.startsWith(key.toUpperCase())) {
        searchabledata.add(element);
      }
    }));
    // list.forEach((element) {
    //   if (element.containsValue(key)) {
    //     searchabledata.add(element);
    //   }
    // });
    calculations(searchabledata, true, -1, false);
  }

  openSortList() {
    emit(HoldingsComponentInitial(
        holdingList: holdingsList2,
        sortvisible: true,
        portfolioResponce: UserController().portfolioresponce.reportData,
        portfolio: UserController().portfolioresponce));
  }

  updateFilterlist(List<String> productlist) {
    List<ReportDatum> list = UserController().portfolioresponce.reportData;
    List<ReportDatum> finallist = [];

    list.forEach((element) {
      for (int i = 0; i < productlist.length; i++) {
        if (element.producttype == productlist[i].toUpperCase()) {
          finallist.add(element);
        }
      }
    });

    print("myfinal list " + finallist.length.toString());
    if (filterarrayposition.isEmpty) {
      calculations(list, false, filterval, false);
    } else {
      calculations(finallist, false, filterval, true);
    }
  }

  updateSortList(int index) {
    List<ReportDatum> list = UserController().portfolioresponce.reportData;
    switch (index) {
      case 0:
        list.sort(((a, b) => (a.securitycode).compareTo(b.securitycode)));
        break;
      case 1:
        list.sort(((a, b) => (a.securitycode).compareTo(b.securitycode)));
        list = list.reversed.toList();
        break;
      case 2:
        list.sort(((a, b) => a.pl.compareTo(b.pl)));
        break;
      case 3:
        list.sort(((a, b) => a.pl.compareTo(b.pl)));
        list = list.reversed.toList();
        break;
      case 4:
        list.sort(((a, b) => a.plPercentage.compareTo(b.plPercentage)));
        break;
      case 5:
        list.sort(((a, b) => a.plPercentage.compareTo(b.plPercentage)));
        list = list.reversed.toList();
        break;
      case 6:
        list.sort(((a, b) => a.invested_amount.compareTo(b.invested_amount)));
        break;
      case 7:
        list.sort(((a, b) => (a.invested_amount).compareTo(b.invested_amount)));
        list = list.reversed.toList();
        break;
    }
    calculations(list, false, index, false);
  }

  resetSortList() {
    calculations(
        UserController().portfolioresetresponce.reportData, false, -1, false);
  }

  double totlap_l = 0.0;
  double total_percentage = 0.0;
  double totalinvested = 0.0;
  double todays_pl = 0.0;
  double avg = 0.0;
  double ltp = 0.0;

  calculations(List<ReportDatum> reportlist, bool searchvisible, int filterval,
      bool filter) {
    totlap_l = 0.0;
    total_percentage = 0.0;
    totalinvested = 0.0;
    todays_pl = 0.0;
    avg = 0.0;
    ltp = 0.0;

    List.generate(reportlist.length, (int index) {
      avg = double.parse(reportlist[index].toJson()["AVGRATE"]);

      ltp = double.parse(reportlist[index].toJson()["MKTRATE"]);

      int qty = int.parse(reportlist[index].toJson()["AVAILABLENETQTY"]);

      double profitloss = qty * (ltp - avg);

      totlap_l = totlap_l + double.parse(reportlist[index].pl.toString());

      totalinvested = totalinvested +
          double.parse(reportlist[index].invested_amount.toString());

      total_percentage = (totlap_l * 100) / totalinvested;

      todays_pl =
          todays_pl + double.parse(reportlist[index].todays_pl.toString());
    });

    emit(HoldingsComponentInitial(
        holdingList: holdingsList,
        pl: totlap_l,
        pl_Percentage: total_percentage,
        todays_pl: todays_pl,
        portfolioResponce: reportlist,
        searchvisible: searchvisible,
        filterval: filterval,
        portfolio: UserController().portfolioresponce));
  }

  search(String keyword) {
    List<Map<String, dynamic>> holdings = [];
    List<Map<String, dynamic>> searchholdings = [];
    List.generate(UserController().portfolioresponce.reportData.length,
        (int index) {
      holdings
          .add(UserController().portfolioresponce.reportData[index].toJson());
    });

    for (int i = 0; i < holdings.length; i++) {
      if (holdings[i].containsValue(keyword)) {
        searchholdings.add(holdings[i]);
      }
    }
    emit(HoldingsComponentInitial(
        holdingList: searchholdings,
        portfolioResponce: UserController().portfolioresponce.reportData,
        portfolio: UserController().portfolioresponce));
  }

  init() {
    calculations([], false, -1, false);
  }
}
