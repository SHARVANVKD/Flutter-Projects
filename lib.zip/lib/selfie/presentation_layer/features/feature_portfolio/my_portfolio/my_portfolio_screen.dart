import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/app_page_injectable.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_portfolio/my_portfolio/bloc/my_portfolio_screen_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_portfolio/my_portfolio/tab_component_holdings/bloc/holdings_component_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_portfolio/my_portfolio/tab_component_holdings/holdings_component.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_portfolio/smartfolio/samrtfolio_page.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/appbar/customAppbarMain.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/scrollable_bottomsheet/scrollable_bottomsheet.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/custom_top_tab.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/portfolio/position/position_inner.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/watchlist/market_overview.dart';
import 'package:selfie_mobile_flutter/text/portfolio.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';
import 'package:selfie_mobile_flutter/user_controller/user_controller.dart';

class MyPortfolioScreen extends StatefulWidget {
  const MyPortfolioScreen({Key? key}) : super(key: key);

  @override
  State<MyPortfolioScreen> createState() => _MyPortfolioScreenState();
}

class _MyPortfolioScreenState extends State<MyPortfolioScreen>
    with TickerProviderStateMixin {
  bool _showAppbar = true;

  void initState() {
    // TODO: implement initState
    super.initState();
    _controller = BottomSheet.createAnimationController(this);
    _controller!.duration = const Duration(milliseconds: 400);
  }

  @override
  void dispose() {
    _controller!.dispose();
    super.dispose();
  }

  AnimationController? _controller;
  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) =>
          MyPortfolioScreenCubit(apiGateway: context.gTradingApiGateway),
      child: BlocBuilder<MyPortfolioScreenCubit, MyPortfolioScreenState>(
          builder: (context, state) {
        return Column(mainAxisAlignment: MainAxisAlignment.start, children: [
          AnimatedContainer(
            margin: const EdgeInsets.only(top: 8.0),
            height: !_showAppbar ? 0 : 58,
            curve: Curves.easeInOut,
            duration: const Duration(milliseconds: 400),
            child: CustomAppBarMain(
              title: portfolioIndexTitle,
              endIcon: InkWell(
                onTap: () {
                  customBottomSheet(
                      controller: _controller,
                      height: .9,
                      minimumHeight: .7,
                      context: context,
                      inputWidget: MarKetOverview());
                },
                child: const Padding(
                  padding: EdgeInsets.only(right: 16),
                  child: ImageIcon(
                    AssetImage("assets/frame.png"),
                    size: 24,
                  ),
                ),
              ),
              onTapTitle: () {},
            ),
          ),
          const SizedBox(height: 8),
          if (state is MyPortfolioScreenInitial)
            state.portfolio_responce_map.isNotEmpty
                ? Expanded(
                    child: CustomTabBar(
                      tabContent: [
                        "Holdings (${state.portfolio_responce_map.length})",
                        "Position (${UserController().positionlist.length})",
                        "Smartfolio (3)"
                      ],
                      tabBarViewChildern: [
                        RefreshIndicator(
                          onRefresh: () async {
                            BlocProvider.of<MyPortfolioScreenCubit>(context)
                                .sendRequestforData(
                                    userid: UserController().userName,
                                    loginid: UserController().userId);
                          },
                          child: HoldingsComponent(
                            onScrollEvent: (bool showAppBar) {
                              // setState(() {
                              //   _showAppbar = showAppBar;
                              // });
                            },
                            length: state.portfolio_responce_map.length,
                          ),
                        ),
                        RefreshIndicator(
                            onRefresh: () async {
                              BlocProvider.of<MyPortfolioScreenCubit>(context)
                                  .sendRequestforData(
                                      userid: UserController().userName,
                                      loginid: UserController().userId);
                            },
                            child: PositionInnerWidget()),
                        SmartfolioPage()
                      ],
                    ),
                  )
                : Expanded(
                    child: CustomTabBar(
                      tabContent: [
                        "Holdings (0)",
                        "Position (0)",
                        "Smartfolio (0)"
                      ],
                      tabBarViewChildern: [
                        HoldingsComponent(
                          length: 0,
                          onScrollEvent: (bool showAppBar) {
                            // setState(() {
                            //   _showAppbar = showAppBar;
                            // });
                          },
                        ),
                        const PositionInnerWidget(),
                        SmartfolioPage()
                      ],
                    ),
                  ),
        ]);
      }),
    );
  }
}
