import 'package:bloc/bloc.dart';
import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/services/api_gateway.dart';
import 'package:selfie_mobile_flutter/user_controller/user_controller.dart';
import 'package:trading_api/responses/portfolio_responce.dart';
import 'package:trading_api/responses/position_responce.dart';

part 'portfolio_screen_state.dart';

class MyPortfolioScreenCubit extends Cubit<MyPortfolioScreenState> {
  TradingApiGateway apiGateway;
  PortfolioResponce? _responce;
  List<Map<String, dynamic>> portfolio_responce_map = [];
  List<Map<String, dynamic>> position_responce_map = [];
  MyPortfolioScreenCubit({required this.apiGateway})
      : super(MyPortfolioScreenInitial()) {
    sendRequestforData(
        userid: UserController().userName, loginid: UserController().userId);
  }

  changeTabIndex(int index, List<Map<String, dynamic>> portfolio_responce_map) {
    emit(MyPortfolioScreenInitial(
        tabIndex: index, portfolio_responce_map: portfolio_responce_map));
  }

  sendRequestforData({required String userid, required String loginid}) async {
    UserController().portfoliolist.clear();
    UserController().positionlist.clear();
    _responce =
        await apiGateway.portfoliorequest(username: userid, loginid: loginid);

    // positionResponce = await apiGateway.positionrequest(
    //     username: UserController().userName, loginid: UserController().userId);

    int length = _responce!.reportData.length;

    UserController().portfolioresponce = _responce!;

    UserController().portfolioresetresponce =
        UserController().portfolioresponce.copyWith();

    for (int i = 0;
        i < UserController().portfolioresponce.reportData.length;
        i++) {
      portfolio_responce_map
          .add(UserController().portfolioresponce.reportData[i].toJson());
    }

    for (int i = 0;
        i < UserController().portfolioresponce.intradaydata.length;
        i++) {
      position_responce_map
          .add(UserController().portfolioresponce.intradaydata[i].toJson());
    }

    UserController().portfoliolist = portfolio_responce_map;

    UserController().positionlist = position_responce_map;

    emit(MyPortfolioScreenInitial(
        portfolio_responce_map: portfolio_responce_map,
        position_responce_map: position_responce_map,
        portfolioResponce: _responce));
  }

  updateData() {
    emit(MyPortfolioScreenInitial(
        portfolio_responce_map: portfolio_responce_map,
        position_responce_map: position_responce_map,
        portfolioResponce: _responce));
  }
}
