part of 'my_portfolio_screen_cubit.dart';

@immutable
abstract class MyPortfolioScreenState {}

class MyPortfolioScreenInitial extends MyPortfolioScreenState {
  int tabIndex;
  PortfolioResponce? portfolioResponce;
  List<Map<String, dynamic>> portfolio_responce_map;
  List<Map<String, dynamic>> position_responce_map;
  double pl;
  MyPortfolioScreenInitial(
      {this.portfolio_responce_map = const [],
      this.position_responce_map = const [],
      this.tabIndex = 0,
      this.portfolioResponce,
      this.pl = 0.0});
}
