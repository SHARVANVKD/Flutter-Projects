import 'package:bloc/bloc.dart';
import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_portfolio/my_portfolio/bloc/position_screen_state.dart';
import 'package:selfie_mobile_flutter/services/api_gateway.dart';
import 'package:selfie_mobile_flutter/user_controller/user_controller.dart';
import 'package:trading_api/responses/portfolio_responce.dart';

class MyPositionScreenCubit extends Cubit<PositionScreenState> {
  TradingApiGateway apiGateway;
  PortfolioResponce? positionResponce;
  List<Map<String, dynamic>> position_responce_map = [];
  MyPositionScreenCubit({required this.apiGateway})
      : super(MyPositionScreenloading()) {
    position_responce_map = UserController().positionlist;
    positionResponce = UserController().portfolioresponce;
    // sendRequestforData(
    //     orderingusercode: UserController().userId,
    //     loginid: UserController().userId);
    // emit(MyPositionScreenInitial(
    //     position_responce_map: position_responce_map,
    //     positionResponce: positionResponce));
    calculations(UserController().portfolioresponce.intradaydata, false, -1);
  }

  openSearch() {
    calculations(UserController().portfolioresponce.intradaydata, true, -1);
  }

  openInitial() {
    calculations(UserController().portfolioresponce.intradaydata, false, -1);
  }

  updateSortList(int index) {
    List<Intradaydatum> list = UserController().portfolioresponce.intradaydata;
    switch (index) {
      case 0:
        list.sort(((a, b) => (a.securitycode).compareTo(b.securitycode)));
        break;
      case 1:
        list.sort(((a, b) => (a.securitycode).compareTo(b.securitycode)));
        list = list.reversed.toList();
        break;
      case 2:
        list.sort(((a, b) => a.pl.compareTo(b.pl)));
        break;
      case 3:
        list.sort(((a, b) => a.pl.compareTo(b.pl)));
        list = list.reversed.toList();
        break;
      case 4:
        list.sort(((a, b) => a.plPercentage.compareTo(b.plPercentage)));
        break;
      case 5:
        list.sort(((a, b) => a.plPercentage.compareTo(b.plPercentage)));
        list = list.reversed.toList();
        break;
      case 6:
        list.sort(((a, b) => a.invested_amount.compareTo(b.invested_amount)));
        break;
      case 7:
        list.sort(((a, b) => (a.invested_amount).compareTo(b.invested_amount)));
        list = list.reversed.toList();
        break;
    }
    calculations(list, false, index);
  }

  updateFilterList(List<String> filterlist) {
    List<Intradaydatum> list = UserController().portfolioresponce.intradaydata;

    List<Intradaydatum> finallist = [];

    list.forEach((element) {
      for (int i = 0; i < filterlist.length; i++) {
        if (filterlist.contains("Open")) {
          print("hi");
          if (int.parse(element.netqty) != 0) {
            finallist.add(element);
          }
        }
        if (element.producttype == filterlist[i].toUpperCase()) {
          finallist.add(element);
        }
      }
    });
    calculations(finallist, false, -1);
  }

  updateSearchList(String key) {
    List<Intradaydatum>? searchabledata = [];
    List<Intradaydatum> list = UserController().portfolioresponce.intradaydata;
    list.forEach(((element) {
      if (element.securitycode.startsWith(key.trim().toUpperCase())) {
        searchabledata.add(element);
      }
    }));
    // list.forEach((element) {
    //   if (element.containsValue(key)) {
    //     searchabledata.add(element);
    //   }
    // });
    calculations(searchabledata, true, -1);
  }

  resetSortList() {
    calculations(
        UserController().portfolioresetresponce.intradaydata, false, -1);
  }

  calculations(
      List<Intradaydatum> intradaydata, bool searchvisible, int index) async {
    double totlap_l = 0.0;
    double total_percentage = 0.0;
    double totalinvested = 0.0;
    double total_todayspl = 0.0;

    List.generate(UserController().positionlist.length, (index) {
      double avg = double.parse(UserController()
          .portfolioresponce
          .intradaydata[index]
          .toJson()["AVGRATE"]);

      double ltp = double.parse(UserController()
          .portfolioresponce
          .intradaydata[index]
          .toJson()["LASTTRADEPRICE"]);

      int qty = int.parse(UserController()
          .portfolioresponce
          .intradaydata[index]
          .toJson()["NETQTY"]);

      double mktrate = double.parse(UserController()
          .portfolioresponce
          .intradaydata[index]
          .toJson()["LASTTRADEPRICE"]);

      double closerate = double.parse(UserController()
          .portfolioresponce
          .intradaydata[index]
          .toJson()["CLOSINGRATE"]);

      totalinvested = totalinvested +
          double.parse(UserController()
              .portfolioresponce
              .intradaydata[index]
              .invested_amount
              .toString());

      totlap_l = totlap_l +
          double.parse(UserController()
              .portfolioresponce
              .intradaydata[index]
              .pl
              .toString());

      total_percentage = ((totlap_l * 100) / totalinvested).isNaN
          ? 0.00
          : ((totlap_l * 100) / totalinvested);
      total_todayspl = total_todayspl +
          double.parse(UserController()
              .portfolioresponce
              .intradaydata[index]
              .todays_pl
              .toString());
    });

    emit(MyPositionScreenInitial(
        position_responce_map: position_responce_map,
        positionResponce: positionResponce,
        pl: totlap_l,
        total_todyas_pl: total_todayspl,
        change_pl_percentage: total_percentage,
        intradaydata: intradaydata,
        searchvisible: searchvisible,
        filterval: index));
  }
}
