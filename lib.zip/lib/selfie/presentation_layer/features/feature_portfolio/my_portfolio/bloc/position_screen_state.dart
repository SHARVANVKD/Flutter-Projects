import 'package:trading_api/responses/portfolio_responce.dart';

abstract class PositionScreenState {}

class MyPositionScreenInitial extends PositionScreenState {
  PortfolioResponce? positionResponce;
  List<Map<String, dynamic>> position_responce_map;
  int filterval;
  double pl;
  double total_todyas_pl;
  double todays_pl_percentage;
  List<Intradaydatum> intradaydata;
  double change_pl_percentage;
  bool searchvisible;
  MyPositionScreenInitial(
      {this.positionResponce,
      this.position_responce_map = const [],
      this.searchvisible = false,
      this.pl = 0.0,
      this.total_todyas_pl = 0.0,
      this.todays_pl_percentage = 0.0,
      required this.intradaydata,
      this.change_pl_percentage = 0.0,
      this.filterval = -1});
}

class MyPositionScreenloading extends PositionScreenState {}
