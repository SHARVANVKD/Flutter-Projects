import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/buttons/BasketButton.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/scrollable_bottomsheet/bottomsheet_basket_widget.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/scrollable_bottomsheet/scrollable_bottomsheet.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/portfolio/portfolio_position_list_item_selected.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class Portfolio_Position_LongPress extends StatefulWidget {
  const Portfolio_Position_LongPress({Key? key}) : super(key: key);

  @override
  _Portfolio_Position_LongPressState createState() =>
      _Portfolio_Position_LongPressState();
}

class _Portfolio_Position_LongPressState
    extends State<Portfolio_Position_LongPress> {
  List<Map<String, dynamic>> PositionSampleList = [
    {
      "name": "BANKNIFTY",
      "OrderType": "INTRADAY",
      "QUANTITY": 10,
      "avg": 300.12,
      "Ltp": 300.34,
      "badge": "N",
      "ORDTYPECOLOR": customColors().islandAqua,
      "sidebarcolor": red200,
      "PANDL": "-234.66",
      "pandlcolor": FontColor.Danger,
      "PANDLPER": "-6.80%",
      "POSITION": "NO",
      "date": "23 FEB 38000 CE",
      "contract": "",
      "topview": ""
    },
    {
      "name": "TCS NOV 1800 CE",
      "OrderType": "MTF",
      "QUANTITY": 10,
      "avg": 300.12,
      "Ltp": 300.34,
      "badge": "Y",
      "ORDTYPECOLOR": customColors().islandAqua,
      "sidebarcolor": green200,
      "PANDL": "+10,982.22",
      "pandlcolor": FontColor.Success,
      "PANDLPER": "-6.80%",
      "POSITION": "NO",
      "contract": "",
      "topview": ""
    },
    {
      "name": "TCS",
      "OrderType": "INTRADAY",
      "QUANTITY": 10,
      "avg": 300.12,
      "Ltp": 300.34,
      "badge": "Y",
      "ORDTYPECOLOR": customColors().islandAqua,
      "sidebarcolor": green200,
      "PANDL": "+10,982.22",
      "pandlcolor": FontColor.Success,
      "PANDLPER": "-6.80%",
      "POSITION": "NO",
      "contract": "",
      "topview": ""
    },
    {
      "name": "ACC",
      "OrderType": "INTRADAY",
      "QUANTITY": 10,
      "avg": 300.12,
      "Ltp": 300.34,
      "badge": "Y",
      "ORDTYPECOLOR": customColors().islandAqua,
      "sidebarcolor": green200,
      "PANDL": "+10,982.22",
      "pandlcolor": FontColor.Success,
      "PANDLPER": "-6.80%",
      "POSITION": "NO",
      "contract": "",
      "topview": ""
    },
    {
      "name": "INFY",
      "OrderType": "INTRADAY",
      "QUANTITY": 10,
      "avg": 300.12,
      "Ltp": 300.34,
      "badge": "Y",
      "ORDTYPECOLOR": customColors().islandAqua,
      "sidebarcolor": green200,
      "PANDL": "+10,982.22",
      "pandlcolor": FontColor.Success,
      "PANDLPER": "-6.80%",
      "POSITION": "NO",
      "contract": "",
      "topview": ""
    },
    {
      "name": "INFY NOV 1800 CE",
      "OrderType": "INTRADAY",
      "QUANTITY": 10,
      "avg": 300.12,
      "Ltp": 300.34,
      "badge": "Y",
      "ORDTYPECOLOR": customColors().islandAqua,
      "sidebarcolor": green200,
      "PANDL": "+10,982.22",
      "pandlcolor": FontColor.Success,
      "PANDLPER": "-6.80%",
      "POSITION": "NO",
      "contract": "",
      "topview": ""
    },
    {
      "name": "ACC NOV 1800 CE",
      "OrderType": "INTRADAY",
      "QUANTITY": 10,
      "avg": 300.12,
      "Ltp": 300.34,
      "badge": "Y",
      "ORDTYPECOLOR": customColors().islandAqua,
      "sidebarcolor": green200,
      "PANDL": "+10,982.22",
      "pandlcolor": FontColor.Success,
      "PANDLPER": "-6.80%",
      "POSITION": "NO",
      "contract": "",
      "topview": ""
    },
    {
      "name": "TATAMOTORS NOV 1800 CE",
      "OrderType": "INTRADAY",
      "QUANTITY": 10,
      "avg": 300.12,
      "Ltp": 300.34,
      "badge": "Y",
      "ORDTYPECOLOR": customColors().islandAqua,
      "sidebarcolor": green200,
      "PANDL": "+10,982.22",
      "pandlcolor": FontColor.Success,
      "PANDLPER": "-6.80%",
      "POSITION": "NO",
      "contract": "",
      "topview": ""
    },
  ];

  List<String> checklist = [];

  int checkcount = 0;
  AnimationController? _controller;

  @override
  Widget build(BuildContext context) {
    double mheight = MediaQuery.of(context).size.height * 1.222;
    Size screenSize = MediaQuery.of(context).size;

    return Scaffold(
      appBar: PreferredSize(
          preferredSize: const Size.fromHeight(0.0),
          child: AppBar(
            elevation: 0,
            backgroundColor: customColors().backgroundPrimary,
          )),
      bottomNavigationBar: SizedBox(
        height: screenSize.height * 0.13,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Divider(
              thickness: 1.0,
              color: customColors().backgroundTertiary,
            ),
            Padding(
              padding: const EdgeInsets.only(
                  left: 16.0, right: 16.0, top: 8.0, bottom: 12.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Expanded(
                    flex: 2,
                    child: BasketButton(
                        onpress: () {
                          checkcount != 0
                              ? customShowModalBottomSheet(
                                  controller: _controller,
                                  context: context,
                                  inputWidget: SelectBasketWidget(
                                    title: "Select or Create new Basket",
                                    basketList: [
                                      {
                                        "name":
                                            "All weather investing-B-sun Dec 12 2021"
                                      },
                                      {"name": "Top 250 stock"},
                                      {"name": "Trial 1"}
                                    ],
                                    controller: _controller,
                                  ))
                              : "";
                        },
                        text: "Add to Basket",
                        bgcolor: checkcount == 0
                            ? customColors().backgroundPrimary.withOpacity(0.4)
                            : customColors().backgroundPrimary,
                        bordercolor: checkcount == 0
                            ? customColors().primary.withOpacity(0.4)
                            : customColors().primary,
                        textStyle: checkcount == 0
                            ? customTextStyle(fontStyle: FontStyle.BodyL_Bold)
                                .copyWith(
                                    color:
                                        customColors().primary.withOpacity(0.4))
                            : customTextStyle(
                                fontStyle: FontStyle.BodyL_Bold,
                                color: FontColor.Primary)),
                  ),
                  Expanded(
                    flex: 2,
                    child: Padding(
                      padding: const EdgeInsets.only(left: 8.0),
                      child: BasketButton(
                          text: "Square Off",
                          bgcolor: checkcount == 0
                              ? customColors().danger.withOpacity(0.4)
                              : customColors().danger,
                          bordercolor: checkcount == 0
                              ? customColors().danger.withOpacity(0.1)
                              : customColors().danger,
                          textStyle: customTextStyle(
                              fontStyle: FontStyle.BodyL_Bold,
                              color: FontColor.White)),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
      body: Column(
        children: [
          Container(
            width: MediaQuery.of(context).size.width,
            decoration: BoxDecoration(
                border: Border(
                    bottom: BorderSide(
                        width: 2.0, color: customColors().backgroundTertiary))),
            child: Padding(
              padding: EdgeInsets.only(
                top: mheight * .04,
              ),
              child: Center(
                child: Row(
                  children: [
                    IconButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        icon: ImageIcon(AssetImage("assets/arrow_left.png"),
                            size: 24)),
                    Expanded(
                      child: SizedBox(
                        width: double.maxFinite,
                        child: Row(
                          children: [
                            Text(
                              checkcount.toString() +
                                  "/" +
                                  PositionSampleList.length.toString(),
                              style: customTextStyle(
                                  fontStyle: FontStyle.BodyL_SemiBold,
                                  color: FontColor.FontPrimary),
                            ),
                            Padding(
                              padding: const EdgeInsets.only(left: 8.0),
                              child: Text(
                                "Selected",
                                style: customTextStyle(
                                    fontStyle: FontStyle.BodyL_SemiBold,
                                    color: FontColor.FontSecondary),
                              ),
                            )
                          ],
                        ),
                      ),
                    ),
                    Row(
                      children: [
                        Text(
                          "All",
                          style: customTextStyle(
                              fontStyle: FontStyle.BodyL_Regular,
                              color: FontColor.FontPrimary),
                        ),
                        Checkbox(
                          activeColor: customColors().primary,
                          onChanged: (value) {
                            checkall();
                          },
                          value: checklist.length == PositionSampleList.length
                              ? true
                              : false,
                        ),
                      ],
                    ),
                    // Visibility(
                    //   visible: _clearbtn,
                    //   child: IconButton(
                    //     icon: ImageIcon(const AssetImage("assets/close.png"),
                    //         color: customColors().fontPrimary),
                    //     onPressed: () => widget.controller.clear(),
                    //   ),
                    // ),
                  ],
                ),
              ),
            ),
          ),
          Expanded(
            child: SingleChildScrollView(
              child: Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.only(top: 5.0),
                    child: ListView.builder(
                        itemCount: PositionSampleList.length,
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        itemBuilder: (context, index) {
                          return PortfolioPositionListItemSelected(
                            positionsamples: PositionSampleList[index],
                            checklist: checklist,
                            upcount: updatecount,
                          );
                        }),
                  ),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  void checkall() {
    setState(() {
      if (checklist.isEmpty) {
        for (int i = 0; i < PositionSampleList.length; i++) {
          checklist.add(PositionSampleList[i]["name"]);
        }
      } else {
        checklist.clear();
      }
      checkcount = checklist.length;
    });
  }

  void updatecount(int count) {
    setState(() {
      checkcount = count;
    });
  }
}
