import 'package:bloc/bloc.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_portfolio/position_long_press/bloc/position_long_press_state.dart';

class PositionLongpressCubit extends Cubit<PositionLongPressState> {
  PositionLongpressCubit() : super(PositionLongPressInitial());
}
