
import 'package:flutter/material.dart';

@immutable
abstract class PositionLongPressState {}

class PositionLongPressInitial extends PositionLongPressState {
  PositionLongPressInitial();
}
