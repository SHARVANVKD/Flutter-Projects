import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/repository_layer/portfolio_content.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/buttons/BasketButton.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/portfolio/portfolio_card/invetment_card.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/portfolio/portfolio_card/profit_and_loss_details.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/portfolio/smartfolio_list_item.dart';

import '../../../../../theme/styles.dart';
import '../../../../widgets/others/empty_container.dart';
import '../../../../widgets/others/message_tile.dart';

class SmartfolioPage extends StatefulWidget {
  const SmartfolioPage({Key? key}) : super(key: key);

  @override
  State<SmartfolioPage> createState() => _SmartfolioPageState();
}

class _SmartfolioPageState extends State<SmartfolioPage> {
  int screenCount = 1;
  double todayAmount = 0.0;
  String todayPercentage = "0";
  bool todayStatus = true;
  double totalAmount = 0.0;
  String totalPercentage = "0";
  bool totalStatus = true;
  double investedamount = 0.0;
  double currentamount = 0.0;
  @override
  Widget build(BuildContext context) {
    Size screenSize = MediaQuery.of(context).size;
    return Container(
        padding: const EdgeInsets.symmetric(vertical: 16),
        child: Stack(
          children: [
            SingleChildScrollView(
              child: Column(
                children: [
                  Column(
                    children: [
                      Container(
                        padding: const EdgeInsets.only(bottom: 10),
                        child: Padding(
                          padding:
                              const EdgeInsets.symmetric(horizontal: 16.0),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Expanded(
                                child: InvestmentDetailCard(
                                  amount: investedamount,
                                  title: "INVESTED",
                                  height: screenSize.height * 0.12,
                                ),
                              ),
                              const SizedBox(
                                width: 12,
                              ),
                              Expanded(
                                child: InvestmentDetailCard(
                                  amount: currentamount,
                                  title: "CURRENT",
                                  height: screenSize.height * 0.12,
                                ),
                              )
                            ],
                          ),
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 16.0),
                        child: ProfitAndLossDetails(
                          smartfolio: true,
                          todayAmount: todayAmount,
                          todayPercentage: todayPercentage,
                          todayStatus: todayStatus,
                          totalAmount: totalAmount,
                          totalPercentage: totalPercentage,
                          totalStatus: totalStatus,
                          height: screenSize.height * 0.14,
                        ),
                      )
                    ],
                  ),
                  const SizedBox(
                    height: 12,
                  ),
                  screenCount == 1
                      ? Padding(
                          padding: const EdgeInsets.only(top: 30),
                          child: emptyContainerSmartfolio(context),
                        )
                      : ListView.builder(
                          primary: false,
                          shrinkWrap: true,
                          itemCount: SmartfoliContent.length,
                          itemBuilder: (context, index) {
                            return InkWell(
                              child: SmartfolioListItem(
                                smartfolioListContent:
                                    SmartfoliContent.elementAt(index),
                              ),
                              onTap: () {},
                            );
                          }),
                ],
              ),
            ),
            Align(
              alignment: Alignment.bottomCenter,
              child: skipButton(context, "$screenCount/2", () {
                if (screenCount > 1) {
                  setState(() {
                    screenCount--;
                    todayAmount = 0;
                    todayPercentage = "0";
                    todayStatus = true;
                    totalAmount = 0;
                    totalPercentage = "0";
                    totalStatus = true;
                    investedamount = 0;
                    currentamount = 0;
                  });
                }
              }, () {
                if (screenCount < 2) {
                  setState(() {
                    screenCount++;
                    totalAmount = 143733;
                    todayPercentage = "32.10";
                    todayStatus = false;
                    todayAmount = 978.33;
                    totalPercentage = "32.10";
                    totalStatus = true;
                    investedamount = 5178298;
                    currentamount = 6978.33;
                  });
                }
              }),
            ),
          ],
        ));
  }
}

emptyContainerSmartfolio(BuildContext context) {
  return Column(
    mainAxisAlignment: MainAxisAlignment.center,
    children: [
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: EmptyContainer(
            height: 152,
            width: double.infinity,
            color: customColors().backgroundTertiary),
      ),
      Padding(
        padding: const EdgeInsets.only(top: 20.0),
        child: Align(
            alignment: Alignment.center,
            child: Text(
              "No Smartfolio Investments",
              style: customTextStyle(
                  fontStyle: FontStyle.BodyL_SemiBold,
                  color: FontColor.FontPrimary),
            )),
      ),
      Padding(
        padding: const EdgeInsets.only(top: 4),
        child: Align(
            alignment: Alignment.center,
            child: Container(
              margin: const EdgeInsets.symmetric(horizontal: 37.0),
              child: Text(
                "Invest in hassle free, data driven baskets, specially curated by experts.",
                softWrap: true,
                textAlign: TextAlign.center,
                style: customTextStyle(
                    fontStyle: FontStyle.BodyM_Regular,
                    color: FontColor.FontSecondary),
              ),
            )),
      ),
      const SizedBox(
        height: 34,
      ),
      BasketButton(
        bordercolor: customColors().primary,
        bgcolor: customColors().primary,
        text: "Open Smartfolio",
        textStyle: customTextStyle(
            fontStyle: FontStyle.BodyL_Bold, color: FontColor.White),
        onpress: () {},
        buttonwidth: 160,
      ),
      const SizedBox(
        height: 38,
      )
    ],
  );
}
