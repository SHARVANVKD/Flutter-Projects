import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/bloc_navigation/navigation_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/repository_layer/portfolio_content.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/appbar/customAppbarInner.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/scrollable_bottomsheet/scrollable_bottomsheet.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/search_insights_filter/portfolio_holding_filter_bar.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/search_insights_filter/search_inisights_type_filter.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/sort.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/portfolio/port_smart_header.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/portfolio/samrtfolio_holding_item.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/portfolio/smart_drop_box.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class SmartfolioHoldings extends StatefulWidget {
  List<Map<String, dynamic>> items;
  int selecteditem;
  SmartfolioHoldings(
      {Key? key, required this.items, required this.selecteditem})
      : super(key: key);

  @override
  State<SmartfolioHoldings> createState() => _SmartfolioHoldingsState();
}

class _SmartfolioHoldingsState extends State<SmartfolioHoldings> {
  @override
  Widget build(BuildContext context) {
    double height = MediaQuery.of(context).size.height;
    double width = MediaQuery.of(context).size.width;
    return Scaffold(
        appBar: PreferredSize(
            preferredSize: const Size.fromHeight(0.0),
            child: AppBar(
              elevation: 0,
              backgroundColor: customColors().backgroundPrimary,
            )),
        body: Column(
          children: [
            CustomAppBarInner(
              title: "Smartfolio Holdings",
              endIcon: EndIcon.Empty,
              onBackPressed: () {
                BlocProvider.of<NavigationCubit>(context).updateWatchList(1);
              },
            ),
            InkWell(
              onTap: () {
                customShowModalBottomSheet(
                    context: context,
                    inputWidget: SmartfolioHoldingListWidget(
                      holdingList: [
                        {"name": "Ace", "icon": "assets/ace.png"},
                        {"name": "24K", "icon": "assets/icon_24k.png"},
                        {"name": "Prime", "icon": "assets/icon_prime.png"}
                      ],
                    ));
              },
              child: Smart_Drop_Box(
                imgpath: widget.items.elementAt(widget.selecteditem)["icon"],
                title: widget.items.elementAt(widget.selecteditem)["hedder"],
              ),
            ),
            const SizedBox(
              height: 10,
            ),
            Expanded(
              child: SingleChildScrollView(
                child: Column(
                  children: [
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 12),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          Expanded(
                              child: Padding(
                            padding: const EdgeInsets.all(6.0),
                            child: Port_Smart_Header(
                              bgcolor: customColors().backgroundSecondary,
                              title: "TOTAL P&L",
                              total: "+301,043,733",
                              totalcolor: FontColor.Success,
                            ),
                          )),
                          Expanded(
                              child: Padding(
                            padding: const EdgeInsets.all(6.0),
                            child: Port_Smart_Header(
                              bgcolor: customColors().backgroundSecondary,
                              title: "REALIZED P&L",
                              total: "-43,000",
                              totalcolor: FontColor.Danger,
                            ),
                          )),
                        ],
                      ),
                    ),
                    const SizedBox(
                      height: 16,
                    ),
                    const Padding(
                      padding: EdgeInsets.symmetric(horizontal: 4.0),
                      child: SearchFilterHoldings(
                        showFilter: false,
                        showInsights: false,
                      ),
                    ),
                    const SizedBox(
                      height: 4,
                    ),
                    Container(
                      child: ListView.builder(
                          physics: NeverScrollableScrollPhysics(),
                          primary: true,
                          shrinkWrap: true,
                          itemCount: SmartfolioholdingContent.length,
                          itemBuilder: (context, index) {
                            return SmartfolioHoldingItem(
                              portfoliolist:
                                  SmartfolioholdingContent.elementAt(index),
                            );
                          }),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ));
  }
}
