import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/repository_layer/portfolio_content.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/search_insights_filter/portfolio_holding_filter_bar.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/portfolio/holdings/holdings_tile.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/portfolio/portfolio_card/holdings_card.dart';

class EquityPage extends StatefulWidget {
  const EquityPage({Key? key}) : super(key: key);

  @override
  State<EquityPage> createState() => _EquityPageState();
}

class _EquityPageState extends State<EquityPage> {
  @override
  Widget build(BuildContext context) {
    Size screenSize = MediaQuery.of(context).size;
    return SingleChildScrollView(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          const SizedBox(height: 20),
          HoldingsCard(
            amount: 3043000,
            percentage: "10.10",
            status: true,
            height: screenSize.height * 0.13,
            equity: "y",
          ),
          const SizedBox(height: 24),
          SearchFilterHoldings(),
          // ListView.builder(
          //     physics: const NeverScrollableScrollPhysics(),
          //     itemCount: holdingsEquity.length,
          //     shrinkWrap: true,
          //     itemBuilder: (context, index) {
          //       return HoldingsListTile(
          //         portfoliolist: holdingsEquity[index],
          //       );
          //     }),
        ],
      ),
    );
  }
}
