import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/app_page_injectable.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/bloc_navigation/navigation_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/appbar/customAppbarInner.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/card_items/card_item.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/portfolio/portfolio_card/invetment_card.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/portfolio/portfolio_card/profit_and_loss_details.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class HoldingPage extends StatefulWidget {
  const HoldingPage({Key? key}) : super(key: key);

  @override
  State<HoldingPage> createState() => _HoldingPageState();
}

class _HoldingPageState extends State<HoldingPage> {
  @override
  Widget build(BuildContext context) {
    Size screenSize = MediaQuery.of(context).size;
    return Scaffold(
      appBar: PreferredSize(
          preferredSize: const Size.fromHeight(0.0),
          child: AppBar(
            elevation: 0,
            backgroundColor: customColors().backgroundPrimary,
          )),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 5),
                child: CustomAppBarInner(
                    title: "Holding Overview",
                    onBackPressed: () {
                      BlocProvider.of<NavigationCubit>(context)
                          .updateWatchList(1);
                    }),
              ),
              const SizedBox(height: 5),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    InvestmentDetailCard(
                      amount: 5178298,
                      title: "INVESTED",
                      height: screenSize.height * 0.12,
                      width: screenSize.width * 0.44,
                    ),
                    const Expanded(child: SizedBox(width: 12)),
                    InvestmentDetailCard(
                      amount: 6978.33,
                      title: "CURRENT",
                      width: screenSize.width * 0.44,
                      height: screenSize.height * 0.12,
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 12),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: ProfitAndLossDetails(
                  todayAmount: 978.33,
                  todayStatus: false,
                  todayPercentage: "32.10",
                  totalAmount: 143733,
                  totalPercentage: "32.10",
                  totalStatus: true,
                  height: screenSize.height * 0.14,
                ),
              ),
              const SizedBox(height: 20),
              CardItem(
                color: customColors().mattPurple,
                current: "2.7 Lac",
                profitLoss: "101.12",
                invested: "1.51 Lac",
                holdingPercentage: "60",
                category: "Equity",
                onPress: () {
                  BlocProvider.of<NavigationCubit>(context).updateWatchList(6);
                  // context.gNavigationService.openEquityPage(
                  //     context, {"tabIndex": 0, "pageName": "Equity"});
                },
                stockcount: "120",
                stockType: "Stocks",
                icon: "assets/filled_arrow.png",
              ),
              const SizedBox(height: 17),
              CardItem(
                color: customColors().dodgerBlue,
                invested: "51.23 K",
                current: "90.2 K",
                profitLoss: "10.43",
                holdingPercentage: "60",
                category: "ETFs",
                change: "N",
                onPress: () {
                  BlocProvider.of<NavigationCubit>(context).updateWatchList(6);
                  // context.gNavigationService.openEquityPage(
                  //     context, {"tabIndex": 1, "pageName": "ETFs"});
                },
                stockcount: "120",
                stockType: "ETFs",
                icon: "assets/filled_arrow.png",
              ),
              const SizedBox(height: 17),
              CardItem(
                color: customColors().pacificBlue,
                invested: "1.51 Lac",
                current: "90.2 K",
                profitLoss: "7.88",
                isProfit: false,
                holdingPercentage: "60",
                category: "Bonds",
                onPress: () {
                  BlocProvider.of<NavigationCubit>(context).updateWatchList(6);
                  // context.gNavigationService.openEquityPage(
                  //     context, {"tabIndex": 2, "pageName": "Bonds"});
                },
                stockcount: "130",
                stockType: "Bonds",
                icon: "assets/filled_arrow.png",
              ),
              const SizedBox(height: 17),
              CardItem(
                color: customColors().islandAqua,
                invested: "1.51 Lac",
                current: "2.75 Lac",
                profitLoss: "101.12",
                holdingPercentage: "60",
                category: "Mutual Funds",
                onPress: () {
                  BlocProvider.of<NavigationCubit>(context).updateWatchList(6);
                  // context.gNavigationService.openEquityPage(
                  //     context, {"tabIndex": 3, "pageName": "Mutual Funds"});
                },
                stockcount: "20",
                stockType: "Funds",
                icon: "assets/filled_arrow.png",
              ),
              const SizedBox(height: 17),
            ],
          ),
        ),
      ),
    );
  }
}
