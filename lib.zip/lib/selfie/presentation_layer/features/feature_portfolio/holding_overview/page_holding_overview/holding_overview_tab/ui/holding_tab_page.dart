import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/app_page_injectable.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/bloc_navigation/navigation_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_portfolio/holding_overview/page_holding_overview/holding_overview_pages/bonds/bonds_page.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_portfolio/holding_overview/page_holding_overview/holding_overview_pages/equity/equity_page.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_portfolio/holding_overview/page_holding_overview/holding_overview_pages/etfs/etfs_page.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_portfolio/holding_overview/page_holding_overview/holding_overview_pages/mutual_funds/mutual_fund.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/appbar/customAppbarInner.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/custom_top_tab.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/portfolio/mutual_fund_notify_box.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class HoldingTabPage extends StatefulWidget {
  final Map<String, dynamic> mapArguments;
  HoldingTabPage({Key? key, required this.mapArguments}) : super(key: key);

  @override
  State<HoldingTabPage> createState() => _HoldingTabPageState();
}

const List<String> holdingTabItem = ["Equity", "ETFs", "Bonds", "Mutual Funds"];

class _HoldingTabPageState extends State<HoldingTabPage> {
  bool _equityTab = true;
  bool _etfsTab = false;
  bool _bondTab = false;
  bool _mutualfundTab = false;

  int initialIndex = 0;
  String tabName = "Equity";

  void initState() {
    // TODO: implement initState
    super.initState();
    initialIndex = widget.mapArguments["tabIndex"];
    tabName = widget.mapArguments["pageName"];
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
          preferredSize: const Size.fromHeight(0.0),
          child: AppBar(
            elevation: 0,
            backgroundColor: customColors().backgroundPrimary,
          )),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          CustomAppBarInner(
              title: "Holdings",
              onBackPressed: () {
                // context.gNavigationService.back(context);
                BlocProvider.of<NavigationCubit>(context).updateWatchList(5);
              }),
          Expanded(
            child: CustomTabBar(
              isScrollable: true,
              tabContent: holdingTabItem,
              selected: initialIndex,
              tabBarViewChildern: const [
                EquityPage(),
                ETFSPage(),
                BondsPage(),
                MutualFundPage(),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
