import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/repository_layer/portfolio_content.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/search_insights_filter/portfolio_holding_filter_bar.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/search_insights_filter/search_inisights_type_filter.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/portfolio/holdings/holdings_etf_tile.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/portfolio/portfolio_card/holdings_card.dart';

class ETFSPage extends StatefulWidget {
  const ETFSPage({Key? key}) : super(key: key);

  @override
  State<ETFSPage> createState() => _ETFSPageState();
}

class _ETFSPageState extends State<ETFSPage> {
  @override
  Widget build(BuildContext context) {
    Size screenSize = MediaQuery.of(context).size;
    return SingleChildScrollView(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          const SizedBox(height: 20),
          HoldingsCard(
            amount: 99070.88,
            percentage: "10.10",
            status: true,
            height: screenSize.height * 0.13,
          ),
          const SizedBox(height: 24),
          SearchFilterHoldings(showInsights: false),
          ListView.builder(
              physics: const NeverScrollableScrollPhysics(),
              itemCount: holdingsETF.length,
              shrinkWrap: true,
              itemBuilder: (context, index) {
                return HoldingsETF_Tile(
                  Portfoliolist: holdingsETF[index],
                );
              }),
        ],
      ),
    );
  }
}
