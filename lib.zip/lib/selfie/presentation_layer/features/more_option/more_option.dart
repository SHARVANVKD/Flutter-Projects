import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/constants/formaters.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_profile/cubit/profile_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/repository_layer/more_content.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';
import 'package:selfie_mobile_flutter/app_page_injectable.dart';
import 'dart:async';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:selfie_mobile_flutter/user_controller/user_controller.dart';

var updateAvailable = false;

class MoreOptionPage extends StatefulWidget {
  const MoreOptionPage({Key? key}) : super(key: key);

  @override
  State<MoreOptionPage> createState() => _MoreOptionPageState();
}

class _MoreOptionPageState extends State<MoreOptionPage> {
  PackageInfo _packageInfo = PackageInfo(
    appName: 'Unknown',
    packageName: 'Unknown',
    version: 'Unknown',
    buildNumber: 'Unknown',
    buildSignature: 'Unknown',
  );

  @override
  void initState() {
    super.initState();
    _initPackageInfo();
  }

  Future<void> _initPackageInfo() async {
    final info = await PackageInfo.fromPlatform();
    setState(() {
      _packageInfo = info;
    });
  }

  @override
  Widget build(BuildContext context) {
    List<Map<String, dynamic>> moreList =
        MoreListClass().morelistGenerate(context);

    return SingleChildScrollView(
      child: Column(
        children: <Widget>[
          BlocConsumer<ProfileCubit, ProfileState>(listener: (context, state) {
            if (state is ProfileError) {
              ScaffoldMessenger.of(context).showSnackBar(
                  showErrorDialogue(errorMessage: state.errorMessage));
            }
          }, builder: (context, state) {
            return Padding(
              padding:
                  const EdgeInsets.symmetric(horizontal: 16, vertical: 8.0),
              child: InkWell(
                onTap: () {
                  context.gNavigationService.openProfilePage(context);

                  // BlocProvider.of<ProfileCubit>(context).sendProfieRequest(context: context,userId: UserController.userController.userId);
                },
                child: Container(
                  padding:
                      const EdgeInsets.symmetric(vertical: 16, horizontal: 12),
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(4.0),
                      color: customColors().backgroundSecondary),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          CircleAvatar(
                            radius: 35,
                            backgroundColor: customColors().peachBackgrond,
                            child: Text(
                                UserController.userController.userShortName,
                                textAlign: TextAlign.center,
                                style: customTextStyle(
                                    fontStyle: FontStyle.HeaderXS_SemiBold,
                                    color: FontColor.wTokenFontColor)),
                          ),
                          const SizedBox(
                            width: 16,
                          ),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Align(
                                alignment: Alignment.centerLeft,
                                child: Text(
                                    UserController.userController.loginResponse!
                                        .intReqObj!.userName
                                        .toString(),
                                    style: customTextStyle(
                                        fontStyle: FontStyle.BodyL_Bold,
                                        color: FontColor.FontPrimary)),
                              ),
                              const SizedBox(
                                height: 6,
                              ),
                              Align(
                                alignment: Alignment.centerLeft,
                                child: Text(
                                    UserController.userController.userId,
                                    style: customTextStyle(
                                        fontStyle: FontStyle.BodyM_SemiBold,
                                        color: FontColor.FontSecondary)),
                              ),
                            ],
                          ),
                        ],
                      ),
                      const Icon(Icons.chevron_right_rounded),
                    ],
                  ),
                ),
              ),
            );
          }),
          ListView.builder(
              physics: const NeverScrollableScrollPhysics(),
              shrinkWrap: true,
              itemCount: moreList.length,
              itemBuilder: (context, index) {
                return Padding(
                  padding: const EdgeInsets.only(left: 16.0, right: 16),
                  child: Column(
                    children: [
                      InkWell(
                        onTap: moreList[index]["navigation"],
                        child: Padding(
                          padding: const EdgeInsets.only(
                              top: 20.0, bottom: 20, left: 8, right: 8),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Row(
                                children: [
                                  Container(
                                    height: 16.0,
                                    width: 16.0,
                                    decoration: BoxDecoration(
                                      image: DecorationImage(
                                        image: AssetImage(
                                            moreList[index]["leading_image"]),
                                        fit: BoxFit.fill,
                                      ),
                                    ),
                                  ),
                                  const SizedBox(
                                    width: 16,
                                  ),
                                  Text(moreList[index]["title"],
                                      style: customTextStyle(
                                          fontStyle: FontStyle.BodyL_SemiBold,
                                          color: FontColor.FontPrimary))
                                ],
                              ),
                              const Icon(Icons.chevron_right_rounded)
                            ],
                          ),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(bottom: 4.0),
                        child: Divider(
                          thickness: 1.2,
                          color: customColors().backgroundTertiary,
                        ),
                      ),
                    ],
                  ),
                );
              }),
          Padding(
            padding:
                const EdgeInsets.only(left: 16, right: 16, bottom: 14, top: 8),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text("App Version - ${_packageInfo.version}",
                        style: customTextStyle(
                            fontStyle: FontStyle.BodyM_SemiBold,
                            color: FontColor.FontPrimary)),
                    Padding(
                      padding: const EdgeInsets.only(top: 5.0),
                      child: Text(
                          "New Updated version available - ${_packageInfo.version}",
                          style: customTextStyle(
                              fontStyle: FontStyle.TagNameL_SemiBold,
                              color: FontColor.FontSecondary)),
                    ),
                  ],
                ),
                Text("Update Now",
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyS_SemiBold,
                        color: FontColor.Primary)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

SnackBar showErrorDialogue({required String errorMessage}) {
  return SnackBar(
    backgroundColor: customColors().backgroundSecondary,
    duration: const Duration(milliseconds: 1000),
    content: Text(
      "$errorMessage",
      style: customTextStyle(
          fontStyle: FontStyle.BodyM_SemiBold, color: FontColor.Danger),
    ),
  );
}
