import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/app_page_injectable.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/buttons/BasketButton.dart';

import '../../../../../theme/styles.dart';
import '../../../../widgets/others/message_tile.dart';

class ConirmPage extends StatefulWidget {
  const ConirmPage({Key? key}) : super(key: key);

  @override
  State<ConirmPage> createState() => _ConirmPageState();
}

class _ConirmPageState extends State<ConirmPage> {
  bool succes = false;
  int screenCount = 1;
  String title = "Order Rejected";
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: PreferredSize(
            preferredSize: const Size.fromHeight(0.0),
            child: AppBar(
              elevation: 0,
              backgroundColor: customColors().backgroundPrimary,
            )),
        body: Stack(
          children: [
            Column(children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  IconButton(
                      icon: ImageIcon(const AssetImage("assets/close.png"),
                          color: customColors().fontPrimary),
                      onPressed: () {
                        context.gNavigationService.back(context);
                      }),
                ],
              ),
              Expanded(
                child: Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Image.asset("assets/circles_confirm.png"),
                      const SizedBox(
                        height: 24,
                      ),
                      Text(
                        title,
                        style: customTextStyle(
                            fontStyle: FontStyle.HeaderS_Bold,
                            color: FontColor.FontPrimary),
                      )
                    ],
                  ),
                ),
              ),
              Visibility(
                visible: succes,
                child: Container(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          Expanded(
                            child: BasketButton(
                              textStyle: customTextStyle(
                                  fontStyle: FontStyle.BodyL_Bold,
                                  color: FontColor.Primary),
                              bgcolor: customColors().backgroundPrimary,
                              bordercolor: customColors().primary,
                              text: "Repeat Order",
                            ),
                          ),
                          const SizedBox(
                            width: 8,
                          ),
                          Expanded(
                            child: BasketButton(
                              textStyle: customTextStyle(
                                  fontStyle: FontStyle.BodyL_Bold,
                                  color: FontColor.Primary),
                              bgcolor: customColors().backgroundPrimary,
                              bordercolor: customColors().primary,
                              text: "Open Order",
                            ),
                          )
                        ],
                      ),
                      const SizedBox(
                        height: 8,
                      ),
                      BasketButton(
                        textStyle: customTextStyle(
                            fontStyle: FontStyle.BodyL_Bold,
                            color: FontColor.White),
                        bgcolor: customColors().primary,
                        text: "Go to Position",
                      )
                    ],
                  ),
                ),
              ),
              Visibility(
                visible: !succes,
                child: Container(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(16.0),
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(4),
                            color: customColors().danger.withOpacity(.10)),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text("Insufficient Funds",
                                style: customTextStyle(
                                    fontStyle: FontStyle.BodyL_Bold,
                                    color: FontColor.Danger)),
                            Text(
                                "Required margin is 500.50 but available margin is 125.00",
                                style: customTextStyle(
                                    fontStyle: FontStyle.BodyM_Regular,
                                    color: FontColor.FontPrimary)),
                          ],
                        ),
                      ),
                      const SizedBox(
                        height: 16,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          const SizedBox(
                            width: 8,
                          ),
                          Expanded(
                              child: BasketButton(
                            textStyle: customTextStyle(
                                fontStyle: FontStyle.BodyL_Bold,
                                color: FontColor.Primary),
                            bgcolor: customColors().backgroundPrimary,
                            bordercolor: customColors().primary,
                            text: "Order Again",
                          )),
                          const SizedBox(
                            width: 8,
                          ),
                          Expanded(
                            child: BasketButton(
                              textStyle: customTextStyle(
                                  fontStyle: FontStyle.BodyL_Bold,
                                  color: FontColor.White),
                              bgcolor: customColors().primary,
                              bordercolor: customColors().primary,
                              text: "Add Funds",
                            ),
                          )
                        ],
                      ),
                    ],
                  ),
                ),
              )
            ]),
            Align(
              alignment: Alignment.bottomCenter,
              child: skipButton(context, "$screenCount/2", () {
                if (screenCount > 1) {
                  setState(() {
                    screenCount--;
                    succes = false;
                    title = "Order Rejected";
                  });
                }
              }, () {
                if (screenCount < 2) {
                  setState(() {
                    screenCount++;
                    succes = true;
                    title = "Order Confirmed";
                  });
                }
              }),
            ),
          ],
        ));
  }
}
