import 'package:flutter/material.dart';
import 'package:percent_indicator/linear_percent_indicator.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class ImageUploadBuilder extends StatelessWidget {
  const ImageUploadBuilder({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    return Column(
      children: [
        Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Container(
                      height: 44,
                      width: 44,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(4),
                          color: customColors().backgroundSecondary),
                      child: Image.asset("assets/imagebox.png"),
                    ),
                    const SizedBox(
                      width: 16,
                    ),
                    Text(
                      "Image 1.jpg",
                      style: customTextStyle(
                          fontStyle: FontStyle.BodyL_SemiBold,
                          color: FontColor.FontPrimary),
                    )
                  ],
                ),
                Image.asset(
                  "assets/delete.png",
                  color: customColors().fontPrimary,
                )
              ],
            ),
            const SizedBox(
              height: 10,
            ),
            Container(
              height: 1,
              color: customColors().backgroundTertiary,
            ),
          ],
        ),
        const SizedBox(
          height: 10,
        ),
        Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  height: 44,
                  width: 44,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(4),
                      color: customColors().backgroundSecondary),
                  child: Image.asset("assets/imagebox.png"),
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    LinearPercentIndicator(
                      width: width * 0.65,
                      padding: const EdgeInsets.all(0),
                      animation: true,
                      animationDuration: 1000,
                      lineHeight: 12,
                      backgroundColor: customColors().backgroundTertiary,
                      progressColor: customColors().pacificBlue,
                      percent: .35,
                      barRadius: Radius.circular(3),
                      alignment: MainAxisAlignment.end,
                    ),
                    const SizedBox(
                      height: 8,
                    ),
                    Text(
                      "Time Remaining 23 sec.",
                      style: customTextStyle(
                          fontStyle: FontStyle.BodyS_Regular,
                          color: FontColor.FontSecondary),
                    )
                  ],
                ),
                Image.asset(
                  "assets/cross.png",
                  color: customColors().fontPrimary,
                )
              ],
            ),
            const SizedBox(
              height: 10,
            ),
            Container(
              height: 1,
              color: customColors().backgroundTertiary,
            ),
          ],
        ),
      ],
    );
  }
}
