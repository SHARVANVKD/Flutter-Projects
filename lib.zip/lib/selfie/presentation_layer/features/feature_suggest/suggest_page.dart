import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_suggest/components/image_upload_builder.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_suggest/components/max_legth_textformfield.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_suggest/components/suggest_feature_success_bottomsheet.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/appbar/custom_help_appbar.dart';

import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/scrollable_bottomsheet/scrollable_bottomsheet.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/textfields/custom_text_form_field.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/textfields/custom_text_form_field_with_maxlength.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/dotted_border_upload_image.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/message_tile.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class SuggestPage extends StatefulWidget {
  SuggestPage({Key? key}) : super(key: key);

  @override
  State<SuggestPage> createState() => _SuggestPageState();
}

class _SuggestPageState extends State<SuggestPage> {
  TextEditingController _featureController = TextEditingController();
  TextEditingController _explanationController = TextEditingController();

  int screenCount = 1;
  int numberlength = 0;

  @override
  Widget build(BuildContext context) {
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    return Scaffold(
      resizeToAvoidBottomInset: false,
      appBar: PreferredSize(
          preferredSize: Size.fromHeight(0.0),
          child: AppBar(
            elevation: 0,
          )),
      body: Stack(
        children: [
          CustomHelpAppbar(
            iconPress: () {
              Navigator.pop(context);
            },
            title: "Suggest Features",
          ),
          Padding(
            padding: const EdgeInsets.only(left: 16, right: 16, top: 60),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                CustomTextFormField(
                  controller: _featureController,
                  fieldName: "Feature",
                  hintText: "Ex. - Funds",
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 10, bottom: 8),
                  child: Text(
                    "Explanation",
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyL_Regular,
                        color: FontColor.FontPrimary),
                  ),
                ),
                CustomTextFormFieldWithMaxLength(
                    controller: _explanationController,
                    maxLength: 50,
                    hintText: "Let us know in detail."),
                const SizedBox(
                  height: 20,
                ),
                DottedBorderUploadImage(),
                screenCount == 2
                    ? const SizedBox(
                        height: 20,
                      )
                    : const SizedBox(),
                screenCount == 2
                    ? const ImageUploadBuilder()
                    : const SizedBox(),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(bottom: 80),
            child: Align(
              alignment: Alignment.bottomCenter,
              child: skipButton(context, "$screenCount/2", () {
                if (screenCount > 1) {
                  setState(() {
                    screenCount--;
                  });
                }
              }, () {
                if (screenCount < 2) {
                  setState(() {
                    screenCount++;
                  });
                }
              }),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(bottom: 20),
            child: Align(
              alignment: Alignment.bottomCenter,
              child: InkWell(
                onTap: () {
                  customShowModalBottomSheet(
                    context: context,
                    inputWidget: const SuggestSuccessBottomSheet(),
                  );
                },
                child: Container(
                  height: 48,
                  width: 156,
                  decoration: BoxDecoration(
                      color: customColors().primary,
                      borderRadius: BorderRadius.circular(4.0)),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        "Submit",
                        style: customTextStyle(
                            fontStyle: FontStyle.BodyL_Bold,
                            color: FontColor.White),
                      )
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
