import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

// class NotificationTabItem extends StatefulWidget {
//   List<String> category;
//   Color? bagroundColor;

//   NotificationTabItem(
//       {required this.category,
//       required this.buttonHandler,
//       this.bagroundColor});
//   final Function buttonHandler;

//   State<StatefulWidget> createState() => NotificationTabItemState();
// }

// class NotificationTabItemState extends State<NotificationTabItem> {
//   int selectedIndex = 0;
//   @override
//   Widget build(BuildContext context) {
//     return Container(
//       color: customColors().backgroundSecondary,
//       height: 56,
//       child: ListView.builder(
//         itemCount: widget.category.length,
//         scrollDirection: Axis.horizontal,
//         itemBuilder: (context, position) {
//           return InkWell(
//             child: Column(
//               children: [
//                 const Expanded(child: SizedBox()),
//                 Center(
//                   child: Container(
//                       padding: const EdgeInsets.only(
//                           bottom: 18.0, right: 18, left: 18),
//                       decoration: BoxDecoration(
//                           border: Border(
//                               bottom: BorderSide(
//                                   color: selectedIndex == position
//                                       ? customColors().primary
//                                       : transparent,
//                                   width: 2))),
//                       child: Text(
//                         widget.category.elementAt(position),
//                         style: customTextStyle(
//                             fontStyle: FontStyle.BodyL_SemiBold,
//                             color: selectedIndex == position
//                                 ? FontColor.Primary
//                                 : FontColor.FontSecondary),
//                       )),
//                 ),
//               ],
//             ),
//             onTap: () {
//               setState(() {
//                 selectedIndex = position;
//                 widget.buttonHandler(selectedIndex); //
//               });
//             },
//           );
//         },
//       ),
//     );
//   }
// }

class NotificationTabItem extends StatefulWidget {
  List<String> category;

  NotificationTabItem({
    required this.category,
    required this.buttonHandler,
  });
  final Function buttonHandler;

  State<StatefulWidget> createState() => NotificationTabItemState();
}

class NotificationTabItemState extends State<NotificationTabItem> {
  int selectedIndex = 0;
  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Padding(
        padding: const EdgeInsets.only(left: 16),
        child: Row(
          children: [
            Row(
              children: [
                SizedBox(
                  height: 43,
                  width: widget.category.length.toDouble() * 105,
                  child: ListView.builder(
                    itemCount: widget.category.length,
                    scrollDirection: Axis.horizontal,
                    itemBuilder: (context, index) {
                      return Padding(
                        padding: const EdgeInsets.only(right: 4.0, bottom: 8),
                        child: GestureDetector(
                          onTap: () {
                            setState(() {
                              selectedIndex = index;
                              widget.buttonHandler(selectedIndex);
                            });
                          },
                          child: Container(
                            height: 32,
                            padding: const EdgeInsets.symmetric(
                                horizontal: 20, vertical: 7),
                            decoration: BoxDecoration(
                              color: selectedIndex == index
                                  ? customColors().primary
                                  : customColors().backgroundPrimary,
                              borderRadius:
                                  const BorderRadius.all(Radius.circular(25)),
                              border: Border.all(
                                color: selectedIndex == index
                                    ? customColors().primary
                                    : customColors().backgroundTertiary,
                              ),
                            ),
                            child: Padding(
                              padding: const EdgeInsets.only(top: 2),
                              child: Text(
                                widget.category.elementAt(index),
                                style: selectedIndex == index
                                    ? customTextStyle(
                                        fontStyle: FontStyle.BodyM_Bold,
                                        color: FontColor.White)
                                    : customTextStyle(
                                        fontStyle: FontStyle.BodyM_Regular,
                                        color: FontColor.FontPrimary),
                              ),
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
            const SizedBox(
              width: 20,
            ),
          ],
        ),
      ),
    );
  }
}
