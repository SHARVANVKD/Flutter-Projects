import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_more/page_notification/Bottom_sheet_components/notification_filter.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_more/page_notification/header_tab/header_tab.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_more/page_notification/model/notification_model.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/appbar/custom_help_appbar.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/scrollable_bottomsheet/scrollable_bottomsheet.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/more/all_notification.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class NotificationPage extends StatefulWidget {
  const NotificationPage({Key? key}) : super(key: key);

  @override
  State<NotificationPage> createState() => _NotificationPageState();
}

class _NotificationPageState extends State<NotificationPage> {
  int _itemCount = AllNotificationDetailsModel.searchResults.length;
  List<String> categoryItems = [
    "All",
    "IPO",
    "Fund Transfer",
    "Alerts",
    "Fundamental Research",
  ];

  _filterSymbols(int category) {
    setState(() {
      switch (category) {
        case 0:
          {
            _itemCount = AllNotificationDetailsModel.searchResults.length;
            break;
          }
        case 1:
          {
            _itemCount = 0;
            break;
          }
        case 2:
          {
            _itemCount = 0;
            break;
          }
        case 3:
          {
            _itemCount = 0;
            break;
          }
        case 4:
          {
            _itemCount = 0;
            break;
          }
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    Size _displaySize = MediaQuery.of(context).size;
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(0.0),
        child: AppBar(
          elevation: 0,
        ),
      ),
      body: Column(
        children: [
          CustomHelpAppbar(
            iconPress: () {
              Navigator.pop(context);
            },
            title: "Notifications",
          ),
          NotificationTabItem(
            category: categoryItems,
            buttonHandler: _filterSymbols,
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 13),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  "Today",
                  style: customTextStyle(
                      fontStyle: FontStyle.HeaderXS_Bold,
                      color: FontColor.FontPrimary),
                ),
                InkWell(
                  onTap: () {
                    customShowModalBottomSheet(
                      context: context,
                      inputWidget: const NotificationFilter(),
                    );
                  },
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Image.asset("assets/filter.png"),
                      const SizedBox(
                        width: 7,
                      ),
                      Text(
                        "Filter",
                        style: customTextStyle(
                            fontStyle: FontStyle.BodyL_Regular,
                            color: FontColor.FontSecondary),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(
              horizontal: 16,
            ),
            child: ListView.builder(
              shrinkWrap: true,
              itemCount: _itemCount,
              itemBuilder: (BuildContext context, int index) {
                return AllNotifcationListContainer(
                  titleSymbol:
                      AllNotificationDetailsModel.searchResults[index].symbol,
                  tiltle: AllNotificationDetailsModel.searchResults[index].name,
                  date: AllNotificationDetailsModel.searchResults[index].date,
                  subtitle:
                      AllNotificationDetailsModel.searchResults[index].details,
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
