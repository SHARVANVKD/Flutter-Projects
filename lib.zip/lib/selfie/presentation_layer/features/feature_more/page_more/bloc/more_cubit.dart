import 'package:bloc/bloc.dart';
import 'package:flutter/material.dart';

part 'more_state.dart';

class MoreCubit extends Cubit<MoreState> {
  MoreCubit() : super(MoreInitial());

//  openEditWatchList(BuildContext context, String title){
  // serviceLocator.navigationService.openWatchlistManagePage(context);
  // }

}
