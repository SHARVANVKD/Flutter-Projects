import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:provider/provider.dart';
import 'package:selfie_mobile_flutter/app_theme.dart';
import 'package:selfie_mobile_flutter/constants/prefefence_utils.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_more/page_more/bloc/more_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/alert_dialogs.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/appbar/customAppbarMain.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/restart_widget.dart';
import 'package:selfie_mobile_flutter/theme/custom_theme.dart';
import 'package:selfie_mobile_flutter/theme/model_theme.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';
import 'package:selfie_mobile_flutter/user_controller/user_controller.dart';
import 'package:selfie_mobile_flutter/utils/user_settings.dart';
import 'package:selfie_mobile_flutter/app_page_injectable.dart';

class MoreScreen extends StatefulWidget {
  const MoreScreen({Key? key}) : super(key: key);

  @override
  _MoreScreenState createState() => _MoreScreenState();
}

class _MoreScreenState extends State<MoreScreen> {
  int groupValue = 1;

  @override
  void initState() {
    super.initState();
    CustomTheme.modelTheme.mode == CustomMode.Light
        ? groupValue = 1
        : CustomTheme.modelTheme.mode == CustomMode.Mid
            ? groupValue = 2
            : groupValue = 3;
  }

  @override
  Widget build(BuildContext context) {
    double height = MediaQuery.of(context).size.height;
    double width = MediaQuery.of(context).size.width;

    return BlocProvider(
      create: (context) => MoreCubit(),
      child:
          Column(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        Padding(
          padding: const EdgeInsets.only(top: 8.0),
          child: SizedBox(
              height: 58,
              child: CustomAppBarMain(
                title: "More",
                onTapTitle: () {},
              )),
        ),
        // Text("Name", style: customTextStyle( fontStyle: FontStyle.BodyM_SemiBold, color: TextColor.FontSecondary)),
        Expanded(
            child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: Align(
                  alignment: Alignment.topLeft,
                  child: Text(
                    "Theme",
                    style: customTextStyle(
                        fontStyle: FontStyle.HeaderS_SemiBold,
                        color: FontColor.FontPrimary),
                  )),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  themeComponent(
                      context: context,
                      text: "LIGHT",
                      value: 1,
                      groupValue: groupValue,
                      onTap: () {
                        switchTheme(CustomMode.Light);
                      },
                      theme: lightModel),
                  themeComponent(
                      context: context,
                      text: "MEDIUM",
                      value: 2,
                      groupValue: groupValue,
                      onTap: () {
                        switchTheme(CustomMode.Mid);
                      },
                      theme: midModel),
                  themeComponent(
                      context: context,
                      text: "DARK",
                      value: 3,
                      groupValue: groupValue,
                      onTap: () {
                        switchTheme(CustomMode.Dark);
                      },
                      theme: darkModel),
                ],
              ),
            ),
          ],
        )),
      ]),
    );
  }

  switchTheme(CustomMode mode) async {
    await showAlertDilogue(
        context: context,
        content: "Restart the application to save changes",
        positiveButtonName: "Restart",
        negativeButtonName: "Cancel",
        onPositiveButtonClick: () async {
          await updateTheme(mode);
          Navigator.pop(context);
        },
        onNegativeButtonClick: () {
          Navigator.pop(context);
        });
  }

  updateTheme(CustomMode mode) async {
    switch (mode) {
      case CustomMode.Dark:
        {
          setState(() {
            groupValue = 3;
          });
          break;
        }
      case CustomMode.Mid:
        {
          setState(() {
            groupValue = 2;
          });
          break;
        }
      case CustomMode.Light:
        {
          setState(() {
            groupValue = 1;
          });
          break;
        }
    }
    UserSettings.userSettings.currentTheme = getThemeModeString(mode);
    await PreferenceUtils.storeDataToShared(UserController.userController.userId, UserSettings.userSettings.toJsonString());
    RestartWidget.restartApp(context);
  }
}

themeComponent(
    {required BuildContext context,
    required String text,
    required int value,
    required int groupValue,
    required void Function() onTap,
    required ModelTheme theme}) {
  return Expanded(
    child: GestureDetector(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          color: groupValue == value
              ? customColors().dodgerBlue
              : customColors().backgroundSecondary,
          borderRadius: const BorderRadius.all(Radius.circular(4)),
        ),
        margin: const EdgeInsets.symmetric(horizontal: 2),
        padding: const EdgeInsets.all(2),
        child: Column(
          children: [
            Container(
              decoration: BoxDecoration(
                color: theme.backgroundPrimary,
                borderRadius: const BorderRadius.all(Radius.circular(4)),
              ),
              height: 80,
              child: Padding(
                padding: const EdgeInsets.all(6.0),
                child: Column(
                  children: [
                    const SizedBox(
                      height: 6,
                    ),
                    Container(
                      height: 30,
                      decoration: BoxDecoration(
                        color: theme.backgroundSecondary,
                        borderRadius:
                            const BorderRadius.all(Radius.circular(2)),
                      ),
                    ),
                    const SizedBox(
                      height: 6,
                    ),
                    Container(
                      height: 10,
                      decoration: BoxDecoration(
                        color: theme.backgroundTertiary,
                        borderRadius:
                            const BorderRadius.all(Radius.circular(2)),
                      ),
                    ),
                    const SizedBox(
                      height: 6,
                    ),
                    Align(
                      alignment: Alignment.topLeft,
                      child: Container(
                        width: 35,
                        height: 6,
                        decoration: BoxDecoration(
                          color: theme.fontSecondary,
                          borderRadius:
                              const BorderRadius.all(Radius.circular(2)),
                        ),
                      ),
                    )
                  ],
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 8),
              child: Align(
                  alignment: Alignment.topLeft,
                  child: Text(
                    text,
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyM_Bold,
                        color: groupValue == value
                            ? FontColor.White
                            : FontColor.FontPrimary),
                  )),
            )
          ],
        ),
      ),
    ),
  );
}
