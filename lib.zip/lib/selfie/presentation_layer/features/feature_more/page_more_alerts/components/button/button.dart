import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/buttons/BasketButton.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class AlertBottomSheetButton extends StatelessWidget {
  bool elevation;
  bool modify;
  Function()? cancelAlert;
  Function()? modifyAlert;
  Function()? reactivate;
  AlertBottomSheetButton(
      {Key? key,
      this.modify = false,
      this.elevation = false,
      this.cancelAlert,
      this.reactivate,
      this.modifyAlert})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
        decoration: BoxDecoration(
          border: elevation
              ? Border(
                  top: BorderSide(color: customColors().backgroundTertiary),
                )
              : null,
        ),
        // height: MediaQuery.of(context).size.height * 0.17,
        child: modify
            ? Row(
                children: [
                  Expanded(
                    child: BasketButton(
                      bordercolor: customColors().green4,
                      text: "Cancel Alert",
                      textStyle: customTextStyle(
                          fontStyle: FontStyle.BodyL_Bold,
                          color: FontColor.Primary),
                      onpress: cancelAlert,
                    ),
                  ),
                  const SizedBox(
                    width: 8,
                  ),
                  Expanded(
                    child: BasketButton(
                        bordercolor: transparent,
                        bgcolor: customColors().primary,
                        text: "Modify Alert",
                        textStyle: customTextStyle(
                            fontStyle: FontStyle.BodyL_Bold,
                            color: FontColor.White),
                        onpress: modifyAlert),
                  )
                ],
              )
            : Row(
                children: [
                  Expanded(
                    child: BasketButton(
                      bordercolor: transparent,
                      bgcolor: customColors().primary,
                      text: "Reactivate",
                      textStyle: customTextStyle(
                          fontStyle: FontStyle.BodyL_Bold,
                          color: FontColor.White),
                      onpress: reactivate,
                    ),
                  )
                ],
              ));
  }
}
