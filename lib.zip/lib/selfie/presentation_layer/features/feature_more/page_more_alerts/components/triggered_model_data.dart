import 'package:flutter/cupertino.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class TriggeredModel {
  static final List<TriggeredModel> searchResults = [
    TriggeredModel(
      exchange: "BSE",
      amount: "2388.55",
      date: "28/01/2022",
      ltp: "2400.00",
      status: "TRIGGERED",
      symbol: "HDFCBANK",
      statusColor: FontColor.Ultraviolet,
    ),
    TriggeredModel(
      exchange: "NSE",
      amount: "2388.55",
      date: "28/01/2022",
      ltp: "2400.00",
      status: "TRIGGERED",
      symbol: "AXISBANK",
      statusColor: FontColor.Ultraviolet,
    ),
    TriggeredModel(
      exchange: "NSE",
      amount: "2388.55",
      date: "28/01/2022",
      ltp: "2400.00",
      status: "TRIGGERED",
      symbol: "TCS",
      statusColor: FontColor.Ultraviolet,
    ),
  ];

  TriggeredModel({
    required this.symbol,
    required this.date,
    required this.amount,
    required this.exchange,
    required this.ltp,
    required this.status,
    required this.statusColor,
  });
  String exchange;
  String date;
  String symbol;
  String ltp;
  String status;
  String amount;
  FontColor statusColor;
}
