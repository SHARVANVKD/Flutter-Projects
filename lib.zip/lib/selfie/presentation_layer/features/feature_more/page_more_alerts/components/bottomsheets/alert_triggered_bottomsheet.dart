import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_more/page_more_alerts/components/button/button.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/options_widget.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class AlertTriggeredBottomSheet extends StatelessWidget {
  AlertTriggeredBottomSheet({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "Alert Triggered",
            style: customTextStyle(
              fontStyle: FontStyle.HeaderS_SemiBold,
              color: FontColor.FontPrimary,
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 20),
            child: Row(
              children: [
                getProductTypeWidget("BSE"),
              ],
            ),
          ),
          const SizedBox(
            height: 4,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "HDFCBANK",
                    style: customTextStyle(
                        fontStyle: FontStyle.HeaderS_SemiBold,
                        color: FontColor.FontPrimary),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(top: 4),
                    child: RichText(
                      text: TextSpan(
                          text: "LTP ",
                          style: customTextStyle(
                            fontStyle: FontStyle.BodyM_Regular,
                            color: FontColor.FontSecondary,
                          ),
                          children: <TextSpan>[
                            TextSpan(
                              text: "is greater than ",
                              style: customTextStyle(
                                fontStyle: FontStyle.BodyM_SemiBold,
                                color: FontColor.FontSecondary,
                              ),
                            ),
                            TextSpan(
                              text: "2400.00",
                              style: customTextStyle(
                                fontStyle: FontStyle.BodyM_SemiBold,
                                color: FontColor.FontPrimary,
                              ),
                            ),
                          ]),
                    ),
                  ),
                ],
              ),
              Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(right: 6),
                        child: Image.asset(
                          "assets/calendar.png",
                          color: customColors().fontTertiary,
                          height: 13,
                          width: 13,
                        ),
                      ),
                      Text(
                        "28/01/2022",
                        style: customTextStyle(
                            fontStyle: FontStyle.BodyL_Regular,
                            color: FontColor.FontSecondary),
                      ),
                    ],
                  ),
                  Padding(
                    padding: const EdgeInsets.only(top: 4),
                    child: RichText(
                      text: TextSpan(
                          text: "LTP: ",
                          style: customTextStyle(
                            fontStyle: FontStyle.HeaderXS_Bold,
                            color: FontColor.FontSecondary,
                          ),
                          children: <TextSpan>[
                            TextSpan(
                              text: "2400.00",
                              style: customTextStyle(
                                fontStyle: FontStyle.HeaderXS_Bold,
                                color: FontColor.FontPrimary,
                              ),
                            ),
                          ]),
                    ),
                  ),
                ],
              )
            ],
          ),
          Padding(
            padding: const EdgeInsets.only(top: 16, bottom: 16),
            child: Divider(
              height: 1,
              color: customColors().backgroundTertiary,
            ),
          ),
          AlertBottomSheetButton(
            modify: false,
            reactivate: () {
              Navigator.pop(context);
            },
          )
        ],
      ),
    );
  }
}
