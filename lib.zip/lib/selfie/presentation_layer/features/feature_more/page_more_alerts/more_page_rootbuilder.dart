import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_more/page_more_alerts/more_alerts_page.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';

class MorePageRouteBuilder {
  final ServiceLocator serviceLocator;

  MorePageRouteBuilder(this.serviceLocator);

  Widget call(BuildContext context) {
    return MultiRepositoryProvider(
        providers: [RepositoryProvider.value(value: serviceLocator.tradingApi)],
        child: MoreAlertsPage());
  }
}
