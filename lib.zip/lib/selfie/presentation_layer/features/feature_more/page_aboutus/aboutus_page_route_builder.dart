import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_more/page_aboutus/aboutus_page.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/workspace/bloc/workspace_cubit.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';

class AboutPageRouteBuilder {
  final ServiceLocator serviceLocator;

  AboutPageRouteBuilder(this.serviceLocator);

  Widget call(BuildContext context) {
    return MultiBlocProvider(
      providers: [
        BlocProvider(
            create: (context) => WorkSpaceCubit(serviceLocator: serviceLocator))
      ],
      child: AboutPage(),
    );
  }
}
