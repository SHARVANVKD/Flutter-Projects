import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/appbar/custom_help_appbar.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class AboutPage extends StatelessWidget {
  const AboutPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    return Scaffold(
      appBar: PreferredSize(
          preferredSize: const Size.fromHeight(0.0),
          child: AppBar(
            elevation: 0,
            backgroundColor: customColors().backgroundPrimary,
          )),
      body: SafeArea(
        child: Column(
          children: [
            SizedBox(height: 11,),
            CustomHelpAppbar(
              iconPress: () {
                Navigator.pop(context);
              },
              title: "About Us",
            ),
            SizedBox(
            height: 2,
          ),
            Text(
              'We kick-started operations on the 15th of August, 2010\nwith the goal of breaking all barriers that traders\nand investors face in India in terms of cost, support, and\ntechnology. We named the company Zerodha,\na combination of Zero and "Rodha", the Sanskrit word for\nbarrier.',
              style: customTextStyle(
                  fontStyle: FontStyle.BodyM_Regular,
                  color: FontColor.FontPrimary),
            ),
            Padding(
              padding: EdgeInsets.only(top: height * 0.030),
              child: Text(
                'Today, our disruptive pricing models and in-house\ntechnology have made us the biggest stock broker in India\nin terms of active retail clients.',
                style: customTextStyle(
                    fontStyle: FontStyle.BodyM_Regular,
                    color: FontColor.FontPrimary),
              ),
            ),
            Padding(
              padding: EdgeInsets.only(top: height * 0.030),
              child: Text(
                'Over 8+ million clients place millions of orders every day\nthrough our powerful ecosystem of investment platforms,\ncontributing over 15% of all Indian retail trading volumes.',
                style: customTextStyle(
                    fontStyle: FontStyle.BodyM_Regular,
                    color: FontColor.FontPrimary),
              ),
            ),
            Padding(
              padding: EdgeInsets.only(top: height * 0.030),
              child: Text(
                'In addition, we run a number of popular open online\neducational and community initiatives to empower retail\ntraders and investors.',
                style: customTextStyle(
                    fontStyle: FontStyle.BodyM_Regular,
                    color: FontColor.FontPrimary),
              ),
            ),
            Padding(
              padding: EdgeInsets.only(top: height * 0.030),
              child: Text(
                'Rainmatter, our fintech fund and incubator, has invested\nin several fintech startups with the goal of growing the \nndian capital markets.',
                style: customTextStyle(
                    fontStyle: FontStyle.BodyM_Regular,
                    color: FontColor.FontPrimary),
              ),
            ),
            Padding(
              padding: EdgeInsets.only(top: height * 0.030, right: 4),
              child: Text(
                'And yet, we are always up to something new every day.\nCatch up on the latest updates on our blog or see what\nthe media is saying about us.',
                style: customTextStyle(
                    fontStyle: FontStyle.BodyM_Regular,
                    color: FontColor.FontPrimary),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
