import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_more/page_settings/components/theme_bottom_sheet.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/appbar/custom_help_appbar.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/scrollable_bottomsheet/scrollable_bottomsheet.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

import 'package:selfie_mobile_flutter/app_page_injectable.dart';

class Settings extends StatelessWidget {
  ServiceLocator serviceLocator;
  Settings({Key? key, required this.serviceLocator}) : super(key: key);

  List<Map<String, dynamic>> item = [
    {
      "name": "Theme",
      "details": "Choose a theme based on your visual\npreferences"
    },
    {"name": "Notifications", "details": "Manage push and sound notification"},
    {
      "name": "Defualt Order Setting",
      "details": "Set up your preset to execute order quickly"
    },
    {
      "name": "Security",
      "details": "Password Change, Set up 2FA, Forgot\nPassword"
    },
    {
      "name": "Others",
      "details": "Index Visibility, Fingerprint & Face Unclock"
    },
  ];

  pageNavigation({required int index, required BuildContext context}) {
    switch (index) {
      case 0:
        {
          customShowModalBottomSheet(
            context: context,
            inputWidget: const ThemeChangeBottomSheet(),
          );
        }
        break;
      case 1:
        {
          serviceLocator.navigationService.openSettingsNotifactionPage(context);
        }
        break;
      case 2:
        {
          context.gNavigationService.openDefaultOrderSettingsPage(context);
        }
        break;
      case 3:
        {
          
        }
        break;
      case 4:
        {
          serviceLocator.navigationService.openSettingOthersPage(context);
        }
        break;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(0.0),
        child: AppBar(
          elevation: 0,
          backgroundColor: customColors().backgroundPrimary,
        ),
      ),
      body: SafeArea(
        child: Column(
          children: [
            CustomHelpAppbar(
              iconPress: () {
                Navigator.pop(context);
              },
              title: "Settings",
            ),
            Column(
              children: [
                Padding(
                  padding: const EdgeInsets.only(top: 10),
                  child: ListView.builder(
                    shrinkWrap: true,
                    itemCount: item.length,
                    itemBuilder: (context, index) => InkWell(
                      onTap: () {
                        pageNavigation(context: context, index: index);
                      },
                      child: Padding(
                        padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
                        child: Column(
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      item[index]["name"],
                                      style: customTextStyle(
                                          fontStyle: FontStyle.BodyL_SemiBold,
                                          color: FontColor.FontPrimary),
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.only(top: 5),
                                      child: Text(
                                        item[index]["details"],
                                        style: customTextStyle(
                                            fontStyle: FontStyle.BodyM_Regular,
                                            color: FontColor.FontSecondary),
                                      ),
                                    ),
                                  ],
                                ),
                                Row(
                                  children: [
                                    InkWell(
                                      onTap: () {
                                        pageNavigation(
                                          context: context,
                                          index: index,
                                        );
                                      },
                                      child: SizedBox(
                                        child: Image.asset(
                                          "assets/arrowright.png",
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                            Padding(
                              padding: const EdgeInsets.only(
                                top: 16,
                              ),
                              child: Divider(
                                height: 1,
                                color: customColors().backgroundTertiary,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
