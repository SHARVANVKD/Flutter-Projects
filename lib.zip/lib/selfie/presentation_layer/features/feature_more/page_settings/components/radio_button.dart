import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order_window/order_window_components/order_window_title_component.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class ThemeRadioButton extends StatefulWidget {
  Function(int) radioBtn;
  int groupValue;
  int value;
  String category;
  ThemeRadioButton(
      {Key? key,
      required this.groupValue,
      required this.category,
      required this.radioBtn,
      required this.value})
      : super(key: key);

  @override
  State<ThemeRadioButton> createState() => _ThemeRadioButtonState();
}

class _ThemeRadioButtonState extends State<ThemeRadioButton> {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 13),
      child: Row(
        children: [
          CustomRadioButton(
              innerVisible: false,
              value: widget.value,
              groupValue: widget.groupValue,
              noLabel: true,
              onChanged: widget.radioBtn),
          const SizedBox(width: 12),
          Text(
            widget.category,
            style: customTextStyle(
                fontStyle: FontStyle.BodyL_Regular,
                color: FontColor.FontPrimary),
          ),
        ],
      ),
    );
  }
}
