part of 'contact_geojit_cubit.dart';

@immutable
abstract class ContactGeojitState {}

class ContactGeojitInitial extends ContactGeojitState {
  final List<Map<String, dynamic>> callbackrequestList;

  ContactGeojitInitial({required this.callbackrequestList});
}
