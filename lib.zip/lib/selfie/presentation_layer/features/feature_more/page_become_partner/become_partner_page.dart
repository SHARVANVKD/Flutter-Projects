import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/appbar/custom_help_appbar.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class BecomePartnerPage extends StatelessWidget {
  const BecomePartnerPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    return Scaffold(
      appBar: PreferredSize(
          preferredSize: const Size.fromHeight(0.0),
          child: AppBar(
            elevation: 0,
            backgroundColor: customColors().backgroundPrimary,
          )),
      body: SafeArea(
        child: Column(
          children: [
            CustomHelpAppbar(
              iconPress: () {
                Navigator.pop(context);
              },
              title: "Become a Partner",
            ),
            Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Padding(
                  padding: EdgeInsets.only(top: height * 0.12),
                  child:
                      Center(child: Image.asset('assets/circles_confirm.png')),
                ),
                Padding(
                  padding: EdgeInsets.only(top: height * 0.050),
                  child: Text(
                    "Become a Geojit Business Partner and\nearn more than",
                    textAlign: TextAlign.center,
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyL_Regular,
                        color: FontColor.FontPrimary),
                  ),
                ),
                Padding(
                  padding: EdgeInsets.only(top: height * 0.025),
                  child: Text(
                    "1 Lakh/Month*",
                    textAlign: TextAlign.center,
                    style: customTextStyle(
                        fontStyle: FontStyle.HeaderS_SemiBold,
                        color: FontColor.FontPrimary),
                  ),
                ),
                Padding(
                  padding: EdgeInsets.only(
                      left: 16.0, right: 16.0, top: height * 0.15),
                  child: Container(
                    height: 48,
                    width: MediaQuery.of(context).size.width,
                    decoration: BoxDecoration(
                        color: customColors().primary,
                        borderRadius: BorderRadius.circular(4.0)),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          "Become a Partner",
                          style: customTextStyle(
                              fontStyle: FontStyle.BodyL_Bold,
                              color: FontColor.White),
                        )
                      ],
                    ),
                  ),
                ),
                Padding(
                  padding: EdgeInsets.only(top: height * 0.040),
                  child: Text(
                    "Learn More",
                    textAlign: TextAlign.center,
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyL_SemiBold,
                        color: FontColor.Primary),
                  ),
                ),
              ],
            )
          ],
        ),
      ),
    );
  }
}
