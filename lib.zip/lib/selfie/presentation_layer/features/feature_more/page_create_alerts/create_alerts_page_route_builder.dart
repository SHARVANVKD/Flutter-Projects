import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_more/page_create_alerts/create_alerts_page.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/workspace/bloc/workspace_cubit.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';

class CreateAlertsPageRouteBuilder {
  final ServiceLocator serviceLocator;
  String title;
  String symbol;
  String ltp;
  CreateAlertsPageRouteBuilder(
      this.serviceLocator, this.title, this.symbol, this.ltp);

  Widget call(BuildContext context) {
    return MultiBlocProvider(
        providers: [
          BlocProvider(
              create: (context) =>
                  WorkSpaceCubit(serviceLocator: serviceLocator))
        ],
        child: CreateAlertsPage(
          title: title,
          symbolname: symbol,
          ltp: ltp,
        ));
  }
}
