part of 'raise_a_ticket_cubit.dart';

@immutable
abstract class RaiseATicketState {}

class RaiseATicketInitial extends RaiseATicketState {}
