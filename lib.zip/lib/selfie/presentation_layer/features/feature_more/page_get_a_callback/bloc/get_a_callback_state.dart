part of 'get_a_callback_cubit.dart';

@immutable
abstract class GetACallbackState {}

class GetACallbackInitial extends GetACallbackState {}
