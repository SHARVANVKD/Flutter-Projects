import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:provider/provider.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_more/page_get_a_callback/bloc/get_a_callback_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_more/page_get_a_callback/ui/get_a_callback_page.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';

class GetACallbackRoutePageBuilder{
  final ServiceLocator serviceLocator;

  GetACallbackRoutePageBuilder(this.serviceLocator);
  Widget call(BuildContext context){
    return MultiProvider(providers: [
      BlocProvider(create: ((context) => GetACallbackCubit(serviceLocator: serviceLocator))),
    ],
    child: MultiRepositoryProvider(providers: [
      RepositoryProvider.value(value: serviceLocator.navigationService),
      RepositoryProvider<CubitsLocator>.value(value: serviceLocator)
    ],child: const GetACallbackPage(),
    ),);
  }
}