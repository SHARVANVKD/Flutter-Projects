import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:intl/intl.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_more/page_get_a_callback/bloc/get_a_callback_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/appbar/customAppbarInner.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/buttons/BasketButton.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/scrollable_bottomsheet/bottom_sheet_calander.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/scrollable_bottomsheet/scrollable_bottomsheet.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/textfields/custom_text_form_field_with_maxlength.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/default_order_settings/default_order_settings_values.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/more/bottomsheet_call_confirmed_widget.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/more/bottomsheet_selection_widget.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/message_tile.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class GetACallbackPage extends StatefulWidget {
  const GetACallbackPage({Key? key}) : super(key: key);

  @override
  State<GetACallbackPage> createState() => _GetACallbackPageState();
}

class _GetACallbackPageState extends State<GetACallbackPage> {
  int currentProductIndex = 0;
  int currentTopicIndex = 0;
  int currentTimeIndex = 0;
  int screenCount=1;
  String timeString="";

  DateTime? date; 

  TextEditingController messageController = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
          preferredSize: const Size.fromHeight(0.0),
          child: AppBar(
            elevation: 0,
            backgroundColor: customColors().backgroundPrimary,
          )),
      body: Stack(
        children: [
          SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                CustomAppBarInner(
                    title: "Get A Call Back",
                    onBackPressed: () {
                      BlocProvider.of<GetACallbackCubit>(context)
                          .onBackPressed(context);
                    }),
                Padding(
                  padding:
                      const EdgeInsets.only(left: 16.0, right: 16, bottom: 4),
                  child: Text(
                    "Topic*",
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyL_Regular,
                        color: FontColor.FontPrimary),
                  ),
                ),
                Padding(
                  padding:
                      const EdgeInsets.only(left: 16.0, right: 16, bottom: 16),
                  child: InkWell(
                      onTap: () {
                        customShowModalBottomSheet(
                            context: context,
                            inputWidget: BottomsheetSelectionWidget(
                              selectionList: topicList,
                              onfilterpress: (val) {
                                currentTopicIndex=val;
                                setState(() {
                                  
                                });
                              },
                              currentval: currentTopicIndex,
                              title: "Topic",
                            ));
                      },
                      child: CustomDropDownWithBottomSheetWidget(
                          text: topicList[currentTopicIndex]["name"])),
                ),
                Padding(
                  padding:
                      const EdgeInsets.only(left: 16.0, right: 16, bottom: 4),
                  child: Text(
                    "Pick a Product",
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyL_Regular,
                        color: FontColor.FontPrimary),
                  ),
                ),
                Padding(
                  padding:
                      const EdgeInsets.only(left: 16.0, right: 16, bottom: 16),
                  child: InkWell(
                      onTap: () {
                        customShowModalBottomSheet(
                            context: context,
                            inputWidget: BottomsheetSelectionWidget(
                              selectionList: pickAProductList,
                              onfilterpress: (val) {
                                currentProductIndex=val;
                                setState(() {
                                  
                                });
                              },
                              currentval: currentProductIndex,
                              title: "Pick A Product",
                            )
                            );
                      },
                      child: CustomDropDownWithBottomSheetWidget(
                          text: pickAProductList[currentProductIndex]["name"])),
                ),
                Padding(
                  padding:
                      const EdgeInsets.only(left: 16.0, right: 16, bottom: 4),
                  child: Text(
                    "Set Time",
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyL_Regular,
                        color: FontColor.FontPrimary),
                  ),
                ),
                Padding(
                    padding: const EdgeInsets.only(
                        left: 16.0, right: 16, bottom: 16),
                    child: InkWell(
                      onTap: () {
                        customShowModalBottomSheet(
                            context: context,
                            inputWidget: BottomsheetSelectionWidget(
                              selectionList: timeList,
                              onfilterpress: (val) {
                                currentTimeIndex=val;
                                setState(() {

                                  timeString=timeList[val]["name"];
                                });
                              },
                              currentval:currentTimeIndex,
                              title: "Set Time",
                            ));
                      },
                      child: CustomTimeSelectionWithBottomSheetWidget(timeTitle: timeString,fontColor:(timeString!="")?FontColor.FontPrimary:FontColor.FontTertiary ),
                    )),
                Padding(
                  padding:
                      const EdgeInsets.only(left: 16.0, right: 16, bottom: 4),
                  child: Text(
                    "Set Date" ,
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyL_Regular,
                        color: FontColor.FontPrimary),
                  ),
                ),
                Padding(
                  padding:
                      const EdgeInsets.only(left: 16.0, right: 16, bottom: 16),
                  child: InkWell(
                      onTap: () {
                        customShowModalBottomSheet(
                          context: context,
                          inputWidget: CustommCalandarSheet(
                            onDone: (_date) {
                              date = _date;
                                setState(() {});
                            },
                          ),
                        );
                      },
                      child: CustomDateSelectionWithBottomSheetWidget(selectedDate: date,)),
                ),
                Padding(
                  padding:
                      const EdgeInsets.only(left: 16.0, right: 16, bottom: 4),
                  child: Text(
                    "Message",
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyL_Regular,
                        color: FontColor.FontPrimary),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 16.0, right: 16,bottom: 10),
                  child: CustomTextFormFieldWithMaxLength(
                    controller: messageController,
                    maxLength: 500,hintText: "Let us know how can we help you."),
                  ),
                  SizedBox(
                    height: 94,
                  )
              ],
            ),
          ),
         
          Align(
            alignment: Alignment.bottomCenter,
            child: skipButton(context, "$screenCount/2", () {
              if (screenCount > 1) {
                setState(() {
                  messageController.text ="";

                  screenCount--;
                });
              }
            }, () {
              if (screenCount < 2) {
                setState(() {
                  messageController.text ="I am not able to chnage password in my system, and app is getting crashed multiple times.";
                  screenCount++;
                });
              }
            }),
          ),
        ],
      ),
      bottomNavigationBar: Column(
            // mainAxisAlignment: MainAxisAlignment.end,
            mainAxisSize: MainAxisSize.min,
            children: [
              Align(
                alignment: Alignment.bottomCenter,
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: BasketButton(
                      textStyle: customTextStyle(
                          fontStyle: FontStyle.BodyL_Bold,
                          color: FontColor.White),
                      text: "Get a Call Back",
                      bgcolor: customColors().primary,
                      onpress: () {
                        customShowModalBottomSheet(
                context: context,
                inputWidget: CallConfirmedBottosheetWidget(),
                );
                      }),
                ),
              ),
            ],
          ),
    );
  }
}



class CustomDropDownWithBottomSheetWidget extends StatelessWidget {
  final String text;
  final FontColor? fontColor;
  CustomDropDownWithBottomSheetWidget({
    Key? key,
    required this.text,
    this.fontColor,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
        decoration: BoxDecoration(
            border:
                Border.all(width: 1, color: customColors().backgroundTertiary),
            borderRadius: BorderRadius.circular(4.0)),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 14.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                text,
                style: customTextStyle(
                    fontStyle: FontStyle.BodyL_Regular,
                    color: fontColor??FontColor.FontPrimary),
              ),
              Row(
                children: [
                  
                  const SizedBox(
                    width: 11,
                  ),
                  Image.asset("assets/down_arrow.png",color: customColors().fontPrimary),
                ],
              )
            ],
          ),
        ));
  }
}

class CustomTimeSelectionWithBottomSheetWidget extends StatelessWidget {
  final String? timeTitle;
  final FontColor? fontColor;
   CustomTimeSelectionWithBottomSheetWidget({
    Key? key, this.timeTitle, this.fontColor=FontColor.FontTertiary,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
        decoration: BoxDecoration(
            border:
                Border.all(width: 1, color: customColors().backgroundTertiary),
            borderRadius: BorderRadius.circular(4.0)),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 14.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                "${(timeTitle!=null&&timeTitle!="")?timeTitle:"10:00 AM"}",
                style: customTextStyle(
                    fontStyle: FontStyle.BodyL_Regular,
                    color: fontColor),
              ),
               Row(
                  children: [
                    Image.asset("assets/clock.png"),
                  ],
                
              )
            ],
          ),
        ));
  }
}

class CustomDateSelectionWithBottomSheetWidget extends StatelessWidget {
  final DateTime? selectedDate;
  const CustomDateSelectionWithBottomSheetWidget({
    Key? key,
    this.selectedDate
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 40,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(4),
        border: Border.all(color: customColors().backgroundTertiary),
      ),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 11),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              DateFormat("dd/MM/yyyy").format(selectedDate??DateTime.now()).toString(),
              style: customTextStyle(
                fontStyle: FontStyle.BodyL_Regular,
                color: FontColor.FontPrimary,
              ),
            ),
            Image.asset("assets/calendar.png",color: customColors().fontPrimary,)
          ],
        ),
      ),
    );
  }
}
