import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_more/page_market_simulator/bloc/market_simulator_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/appbar/customAppbarInner.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class MarketSimulatorPage extends StatelessWidget {
  const MarketSimulatorPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: PreferredSize(
            preferredSize: const Size.fromHeight(0.0),
            child: AppBar(
              elevation: 0,
              backgroundColor: customColors().backgroundPrimary,
            )),
        body: SingleChildScrollView(
            child: Column(verticalDirection: VerticalDirection.down, children: [
          CustomAppBarInner(
              title: "Market Simulator",
              onBackPressed: () {
                BlocProvider.of<MarketSimulatorCubit>(context)
                    .onBackPressed(context);
              }),
          Center(child: Text("Page will open soon!.")),
        ])));
  }
}
