import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:provider/provider.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_more/page_market_simulator/bloc/market_simulator_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_more/page_market_simulator/ui/market_simulator_page.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';

class MarketSimulatorPageRouteBuilder{
  final ServiceLocator serviceLocator;

  MarketSimulatorPageRouteBuilder(this.serviceLocator);
  Widget call(BuildContext context){
    return MultiProvider(providers: [
      BlocProvider(create: (((context) => MarketSimulatorCubit(serviceLocator: serviceLocator))))
    ],
    child: MultiRepositoryProvider(providers: [
      RepositoryProvider.value(value: serviceLocator.navigationService),
      RepositoryProvider<CubitsLocator>.value(value: serviceLocator)
    ], child: MarketSimulatorPage()),
    );
  }
}