part of 'market_simulator_cubit.dart';

@immutable
abstract class MarketSimulatorState {}

class MarketSimulatorInitial extends MarketSimulatorState {}
