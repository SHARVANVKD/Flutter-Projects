import 'dart:io';

import 'package:bloc/bloc.dart';
import 'package:flutter/material.dart';
import 'package:meta/meta.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';
import 'package:selfie_mobile_flutter/user_controller/user_controller.dart';
import 'package:trading_api/requests/buying_power_request.dart';
import 'package:trading_api/responses/buying_power_response.dart';

part 'funds_state.dart';

class FundsCubit extends Cubit<FundsState> {
  final ServiceLocator serviceLocator;
  FundsCubit({required this.serviceLocator}) : super(FundsInitial());
  // sendFundsRequest({required context})async {
  //   emit(FundsLoading());
  //   try{
  //     BuyingPowerRequest buyingPowerRequest=BuyingPowerRequest(tradeCode: UserController().userId);
  //   BuyingPowerResponse buyingPowerResponse=await serviceLocator.tradingApi.getBuyingPower(request: buyingPowerRequest.toJson());
  //   if(buyingPowerResponse.errorCode=="0"){
  //     UserController().buyingPower=buyingPowerResponse;
  //     }
  //   }on SocketException{
  //   }catch(e){
  //     emit(FundsError(errorCode: 000, errorMessage: e.toString()));
  //   }
  // }
  onWithdrawPressed(BuildContext context) {}
}
