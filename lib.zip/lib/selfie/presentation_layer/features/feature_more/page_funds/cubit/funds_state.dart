part of 'funds_cubit.dart';

@immutable
abstract class FundsState {}

class FundsInitial extends FundsState {}
class FundsLoading extends FundsState {}

class FundsError extends FundsState{
  final int errorCode;
  final String errorMessage;

  FundsError({required this.errorCode,required this.errorMessage});
}
