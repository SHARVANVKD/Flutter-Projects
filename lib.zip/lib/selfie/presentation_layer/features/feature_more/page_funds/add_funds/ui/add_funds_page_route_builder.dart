import 'package:flutter/cupertino.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_more/page_funds/add_funds/ui/add_funds_page.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';

class AddFundsPageRouteBuilder {
  final ServiceLocator serviceLocator;

  AddFundsPageRouteBuilder(this.serviceLocator);
  Widget Call(BuildContext context) {
    return MultiBlocProvider(
        providers: [],
        child: MultiRepositoryProvider(
            providers: [],
            child: AddFundsPage(serviceLocator: serviceLocator)));
  }
}
