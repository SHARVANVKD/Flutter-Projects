import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order_window/order_window_components/order_window_title_component.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class BankComponent extends StatefulWidget {
  int selected;
  final Function(int) onChanged;

  BankComponent({Key? key, required this.onChanged, required this.selected})
      : super(key: key);

  @override
  State<BankComponent> createState() => _BankComponentState();
}

class _BankComponentState extends State<BankComponent> {
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 12.0, horizontal: 16.0),
          child: Row(
            children: [
              Text(
                "Segment",
                style: customTextStyle(
                    fontStyle: FontStyle.HeaderXS_SemiBold,
                    color: FontColor.FontPrimary),
              ),
            ],
          ),
        ),
        Container(
          height: 1,
          color: customColors().backgroundTertiary,
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16.0),
          child: ListView.builder(
            itemCount: bankoptions.length,
            shrinkWrap: true,
            itemBuilder: (context, index) {
              return InkWell(
                onTap: () {
                  setState(() {
                    widget.selected = index;
                  });
                  widget.onChanged(index);
                  Navigator.of(context).pop();
                },
                child: Container(
                  padding: const EdgeInsets.symmetric(vertical: 16.0),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      CustomRadioButton(
                          noLabel: true,
                          value: index,
                          groupValue: widget.selected,
                          onChanged: (int val) {
                            setState(() {
                              widget.selected = val;
                            });
                            widget.onChanged(index);
                            Navigator.of(context).pop();
                          }),
                      Expanded(
                        child: Padding(
                          padding: const EdgeInsets.only(left: 12.0),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              Text(
                                bankoptions[index],
                                style: customTextStyle(
                                    fontStyle: FontStyle.BodyL_Regular,
                                    color: FontColor.FontPrimary),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }
}

List<String> bankoptions = [
  "HDFC Bank LTD - 9381",
  "ICICI Bank LTD - 1121",
  "SBI Bank LTD - 1121",
];
