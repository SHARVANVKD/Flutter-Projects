import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_more/page_more_alerts/components/bottomsheets/create_alert_bottomsheet.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order_window/order_window_components/order_window_title_component.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_profile/profile.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/buttons/BasketButton.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/scrollable_bottomsheet/scrollable_bottomsheet.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/textfields/custom_text_form_field.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/default_order_settings/default_order_settings_values.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class AllocationTab extends StatefulWidget {
  List<Map<String, dynamic>> radioList = [
    {'name': 'Equity Cash', 'amount': '10,04,288.75'},
    {'name': 'Equity Cash + MTF', 'amount': '10,000'},
    {'name': 'Equity F&O', 'amount': '15,000'},
    {'name': 'Currency F&O', 'amount': '₹0'},
    {'name': 'MCX F&O', 'amount': '10,000'},
    {'name': 'NCDEX F&O', 'amount': '7,900'}
  ];

  int timeCondition1 = 0;
  int timeCondition2 = 0;
  AllocationTab({
    Key? key,
  }) : super(key: key);

  @override
  State<AllocationTab> createState() => _AllocationTabState();
}

class _AllocationTabState extends State<AllocationTab> {
  TextEditingController amountCntrl = TextEditingController();

  @override
  Widget build(BuildContext context) {
    // );
    return Column(
      children: [
        Expanded(
            child: SingleChildScrollView(
          child: Column(
            children: [
              //first Amount Session
              Container(
                decoration: BoxDecoration(
                    borderRadius: const BorderRadius.all(Radius.circular(4)),
                    color: customColors().backgroundSecondary),
                child: Container(
                  padding: const EdgeInsets.all(16),
                  color: transparent,
                  child: CustomTextFormField(
                    controller: amountCntrl,
                    fieldName: 'Amount',
                    hintText: '₹ 50,000',
                  ),
                ),
              ),

              //allocation From inkwell

              InkWell(
                onTap: () {
                  customShowModalBottomSheet(
                    context: context,
                    inputWidget: AllocationSections(
                        orderSettingsSheetType:
                            OrderSettingsSheetType.CONDITION,
                        selected: widget.timeCondition1,
                        onChanged: (int val, String heads) {
                          if (heads == 'Allocation From')
                            setState(() {
                              widget.timeCondition1 = val;
                            });
                          Navigator.pop(context);
                        },
                        list: widget.radioList,
                        head: 'Allocation From'),
                  );
                },
                child: Container(
                  margin: const EdgeInsets.only(
                      top: 24, bottom: 25, left: 16, right: 16),
                  child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Allocate From',
                          style: customTextStyle(
                            fontStyle: FontStyle.BodyL_Regular,
                            color: FontColor.FontPrimary,
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(bottom: 8.0, top: 8),
                          child: Container(
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(4),
                                border: Border.all(
                                    color: customColors().backgroundTertiary)),
                            child: Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Row(
                                children: [
                                  Container(
                                      padding: const EdgeInsets.all(12),
                                      decoration: BoxDecoration(
                                        color: customColors().dodgerBlue,
                                        borderRadius: BorderRadius.circular(4),
                                      ),
                                      child: Icon(
                                        Icons.arrow_forward,
                                        color: customColors().backgroundPrimary,
                                      )),
                                  const SizedBox(width: 13),
                                  Column(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Padding(
                                        padding:
                                            const EdgeInsets.only(bottom: 8.0),
                                        child: Text(
                                          widget.radioList[
                                              widget.timeCondition1]['name'],
                                          style: customTextStyle(
                                            fontStyle: FontStyle.BodyM_Bold,
                                            color: FontColor.FontPrimary,
                                          ),
                                        ),
                                      ),
                                      SizedBox(
                                        width: 158.0,
                                        child: Text(
                                          widget.radioList[
                                              widget.timeCondition1]['amount'],
                                          style: customTextStyle(
                                              fontStyle:
                                                  FontStyle.BodyM_Regular,
                                              color: FontColor.FontPrimary),
                                          maxLines: 3,
                                        ),
                                      ),
                                    ],
                                  ),
                                  const SizedBox(
                                    width: 67,
                                  ),
                                  Icon(
                                    Icons.keyboard_arrow_down,
                                    color: customColors().primary,
                                  )
                                ],
                              ),
                            ),
                          ),
                        )
                      ]),
                ),
              ),

              //allocation from inkwell

              InkWell(
                onTap: () {
                  // showBottomSheetTo(context);
                  customShowModalBottomSheet(
                    context: context,
                    inputWidget: AllocationSections(
                      orderSettingsSheetType: OrderSettingsSheetType.CONDITION,
                      selected: widget.timeCondition2,
                      onChanged: (int val, String heads) {
                        if (heads == 'Allocation To')
                          setState(() {
                            widget.timeCondition2 = val;
                          });
                        Navigator.pop(context);
                      },
                      list: widget.radioList,
                      head: 'Allocation To',
                    ),
                  );
                },
                child: Container(
                  margin:
                      const EdgeInsets.only(bottom: 25, left: 16, right: 16),
                  child: Expanded(
                    child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Allocate To',
                            style: customTextStyle(
                              fontStyle: FontStyle.BodyL_Regular,
                              color: FontColor.FontPrimary,
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(bottom: 8.0, top: 8),
                            child: Container(
                              decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(4),
                                  border: Border.all(
                                      color:
                                          customColors().backgroundTertiary)),
                              child: Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Row(
                                  children: [
                                    Container(
                                        padding: const EdgeInsets.all(12),
                                        decoration: BoxDecoration(
                                          color: customColors().mattPurple,
                                          borderRadius:
                                              BorderRadius.circular(4),
                                        ),
                                        child: Icon(
                                          Icons.arrow_back,
                                          color:
                                              customColors().backgroundPrimary,
                                        )),
                                    const SizedBox(width: 13),
                                    Column(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Padding(
                                          padding: const EdgeInsets.only(
                                              bottom: 8.0),
                                          child: Text(
                                            widget.radioList[
                                                widget.timeCondition2]['name'],
                                            style: customTextStyle(
                                              fontStyle: FontStyle.BodyM_Bold,
                                              color: FontColor.FontPrimary,
                                            ),
                                          ),
                                        ),
                                        SizedBox(
                                          width: 158.0,
                                          child: Text(
                                            'Balance: ₹4,04,288.75',
                                            style: customTextStyle(
                                                fontStyle:
                                                    FontStyle.BodyM_Regular,
                                                color: FontColor.FontPrimary),
                                            maxLines: 3,
                                          ),
                                        ),
                                      ],
                                    ),
                                    const SizedBox(
                                      width: 67,
                                    ),
                                    Icon(
                                      Icons.keyboard_arrow_down,
                                      color: customColors().primary,
                                    )
                                  ],
                                ),
                              ),
                            ),
                          )
                        ]),
                  ),
                ),
              )
            ],
          ),
        )),

        //button Reallocate

        Padding(
          padding: const EdgeInsets.only(left: 16, right: 16),
          child: Container(
            color: customColors().backgroundPrimary,
            child: Expanded(
                child: BasketButton(
              bordercolor: transparent,
              bgcolor: customColors().primary,
              text: "Reallocate",
              textStyle: customTextStyle(
                  fontStyle: FontStyle.BodyL_Bold, color: FontColor.White),
              onpress: () {
                String allcationFromName =
                    widget.radioList[widget.timeCondition1]['name'];
                String allocationFromAmount =
                    widget.radioList[widget.timeCondition1]['amount'];
                String allcationToName =
                    widget.radioList[widget.timeCondition2]['name'];
                customShowModalBottomSheet(
                  context: context,
                  //inputWidget: CreateAlertBottomShett(),
                  inputWidget: CreateSuccessBottomSheet(
                    allcationFromName: allcationFromName,
                    allcationToName: allcationToName,
                    allocationFromAmount: allocationFromAmount,
                  ),
                );
              },
            )),
          ),
        ),
      ],
    );
  }
}

//class for bottomsheet Allocation From and To

class AllocationSections extends StatefulWidget {
  final List<Map<String, dynamic>> list;
  final OrderSettingsSheetType orderSettingsSheetType;
  final int selected;
  final Function(int, String) onChanged;
  final String head;
  AllocationSections({
    Key? key,
    required this.orderSettingsSheetType,
    required this.selected,
    required this.onChanged,
    required this.list,
    required this.head,
  }) : super(key: key);

  @override
  State<AllocationSections> createState() => _AllocationSections();
}

class _AllocationSections extends State<AllocationSections> {
  _AllocationSections();
  int selected = 0;

  @override
  void initState() {
    super.initState();
    setState(() {
      selected = widget.selected;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.start,
      children: [
        Container(
          alignment: Alignment.topLeft,
          padding: EdgeInsets.all(16.0),
          child: Text(
            widget.head,
            style: customTextStyle(
                fontStyle: FontStyle.HeaderXS_SemiBold,
                color: FontColor.FontPrimary),
          ),
        ),
        CustomDividerWithPadding(),
        Container(
          padding: EdgeInsets.only(top: 8, bottom: 8, left: 16, right: 16),
          child: ListView.builder(
            physics: const NeverScrollableScrollPhysics(),
            shrinkWrap: true,
            itemCount: widget.list.length,
            addRepaintBoundaries: true,
            itemBuilder: (context, index) {
              return InkWell(
                onTap: () {
                  String head = widget.head;
                  setState(() {
                    selected = index;
                  });
                  widget.onChanged(index, head);
                },
                child: Container(
                  padding: const EdgeInsets.symmetric(vertical: 16.0),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      CustomRadioButton(
                          noLabel: true,
                          value: index,
                          groupValue: selected,
                          onChanged: (int val) {
                            String head = widget.head;
                            setState(() {
                              selected = val;
                              print(val);
                            });
                            widget.onChanged(index, head);
                          }),
                      const SizedBox(width: 12.0),
                      Expanded(
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(widget.list[index]['name'],
                                style: customTextStyle(
                                    fontStyle: FontStyle.BodyL_SemiBold,
                                    color: FontColor.FontPrimary)),
                            if (widget.head == 'Allocation From')
                              Text(widget.list[index]['amount'],
                                  style: customTextStyle(
                                      fontStyle: FontStyle.BodyL_SemiBold,
                                      color: FontColor.FontPrimary)),
                          ],
                        ),
                      )
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }
}

//class for Bottomsheet Sucess Alert

class CreateSuccessBottomSheet extends StatelessWidget {
  String allcationFromName;
  String allocationFromAmount;
  String allcationToName;
  CreateSuccessBottomSheet(
      {Key? key,
      required this.allcationFromName,
      required this.allcationToName,
      required this.allocationFromAmount})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        SizedBox(
          height: 40,
        ),
        Image.asset("assets/Tick.png"),
        SizedBox(
          height: 16,
        ),
        //(widget.list[index]['name']
        Text(
          "Allocation Successful",
          style: customTextStyle(
              fontStyle: FontStyle.HeaderS_SemiBold,
              color: FontColor.FontPrimary),
        ),
        SizedBox(
          height: 10,
        ),
        Padding(
          padding: EdgeInsets.only(top: 20, bottom: 30, left: 16, right: 16),
          child:
              Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            Column(
              children: [
                Text(
                  allcationFromName,
                  style: customTextStyle(
                      fontStyle: FontStyle.BodyM_SemiBold,
                      color: FontColor.FontPrimary),
                ),
                Text(
                  '+$allocationFromAmount',
                  style: customTextStyle(
                      fontStyle: FontStyle.BodyM_Bold,
                      color: FontColor.FontPrimary),
                )
              ],
            ),
            Container(
              width: 32,
              height: 32,
              decoration: BoxDecoration(
                  color: Color.fromARGB(255, 233, 220, 198),
                  borderRadius: BorderRadius.circular(100)),
              child: Icon(
                (Icons.arrow_forward),
                color: Color(0xffE7A640),
              ),
            ),
            Column(
              children: [
                Text(
                  allcationToName,
                  style: customTextStyle(
                      fontStyle: FontStyle.BodyM_SemiBold,
                      color: FontColor.FontPrimary),
                ),
                Text(
                  '-$allocationFromAmount',
                  style: customTextStyle(
                      fontStyle: FontStyle.BodyM_Bold,
                      color: FontColor.FontPrimary),
                )
              ],
            ),
          ]),
        )
      ],
    );
  }
}
