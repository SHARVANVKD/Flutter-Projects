import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:provider/provider.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_more/page_funds/cubit/funds_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_more/page_funds/ui/funds_page.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';

class FundsPageRouteBuilder{
  final ServiceLocator serviceLocator;
  FundsPageRouteBuilder(this.serviceLocator);
  Widget call(BuildContext context){
    return MultiProvider(
      providers: [
        BlocProvider(create: ((context) => FundsCubit(serviceLocator: serviceLocator)))
      // RepositoryProvider.value(value: serviceLocator.navigationService),
    ],
    child: MultiRepositoryProvider(providers: [
      RepositoryProvider.value(value: serviceLocator.navigationService),
      RepositoryProvider<CubitsLocator>.value(value: serviceLocator)
    ],child: FundsPage(serviceLocator: serviceLocator),),
    );
  }
}