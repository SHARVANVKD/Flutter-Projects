import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_more/page_invite_friend/invite_friend_page.dart';

import 'package:selfie_mobile_flutter/selfie/presentation_layer/workspace/bloc/workspace_cubit.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';

class InviteFriendPageRouteBuilder {
  final ServiceLocator serviceLocator;

  InviteFriendPageRouteBuilder(this.serviceLocator);

  Widget call(BuildContext context) {
    return MultiBlocProvider(
      providers: [
        BlocProvider(
            create: (context) => WorkSpaceCubit(serviceLocator: serviceLocator))
      ],
      child: InviteFriendPage(),
    );
  }
}
