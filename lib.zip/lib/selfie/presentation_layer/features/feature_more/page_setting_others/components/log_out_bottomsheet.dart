import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/custom_radio_button.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class LogOutBottomSheet extends StatefulWidget {
  final void Function(int) onpress;
  LogOutBottomSheet({Key? key, required this.onpress}) : super(key: key);

  @override
  State<LogOutBottomSheet> createState() => _LogOutBottomSheetState();
}

class _LogOutBottomSheetState extends State<LogOutBottomSheet> {
  List<String> listItem = [
    '2 hours',
    '4 hours',
    '8 hours',
  ];

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisAlignment: MainAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          child: Text(
            "Login Time Out",
            style: customTextStyle(
                fontStyle: FontStyle.HeaderXS_SemiBold,
                color: FontColor.FontPrimary),
          ),
        ),
        Container(
          height: 1,
          color: customColors().backgroundTertiary,
        ),
        const SizedBox(
          height: 10,
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 0, 0, 10),
          child: ListView.builder(
              shrinkWrap: true,
              itemCount: listItem.length,
              itemBuilder: (context, index) {
                return MyRadioListTile<int>(
                  value: index,
                  groupValue: gValue,
                  title: Text(
                    listItem[index],
                    style: customTextStyle(
                      fontStyle: FontStyle.BodyL_Regular,
                      color: FontColor.FontPrimary,
                    ),
                  ),
                  onChanged: (value) {
                    setState(() {
                      gValue = value!;
                      widget.onpress(value);
                    });
                  },
                );
              }),
        ),
        const SizedBox(
          height: 20,
        ),
      ],
    );
  }
}

int gValue = 0;
