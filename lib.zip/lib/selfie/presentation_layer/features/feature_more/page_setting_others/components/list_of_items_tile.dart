import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class ListOfItemTile extends StatelessWidget {
  String title;
  bool change;
  Function(bool)? onChange;

  ListOfItemTile(
      {Key? key, required this.title, this.change = false, this.onChange})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Padding(
              padding: const EdgeInsets.only(top: 10, bottom: 10),
              child: Text(
                title,
                style: customTextStyle(
                    fontStyle: FontStyle.BodyL_SemiBold,
                    color: FontColor.FontPrimary),
              ),
            ),
            SizedBox(
              height: 20,
              width: 37,
              child: Switch(
                value: change,
                onChanged: onChange,
                activeColor: customColors().primary,
                inactiveTrackColor: customColors().backgroundTertiary,
                activeTrackColor: customColors().backgroundTertiary,
              ),
            ),
          ],
        ),
      ],
    );
  }
}
