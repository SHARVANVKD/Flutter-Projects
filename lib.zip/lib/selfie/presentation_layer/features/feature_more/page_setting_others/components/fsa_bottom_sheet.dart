import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order_window/order_window_components/order_window_title_component.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/custom_radio_button.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class FsaBottomSheet extends StatefulWidget {
  int? onpress;
  FsaBottomSheet({Key? key, this.onpress = 0}) : super(key: key);

  @override
  State<FsaBottomSheet> createState() => _FsaBottomSheetState();
}

class _FsaBottomSheetState extends State<FsaBottomSheet> {
  List<String> listItem = [
    'DOB',
    'PAN CARD',
    'SECURE CODE',
    'OTP',
  ];
  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisAlignment: MainAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          child: Text(
            "Flip Secure Authenticatiom",
            style: customTextStyle(
                fontStyle: FontStyle.HeaderXS_SemiBold,
                color: FontColor.FontPrimary),
          ),
        ),
        Container(
          height: 1,
          color: customColors().backgroundTertiary,
        ),
        const SizedBox(
          height: 10,
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 0, 0, 10),
          child: ListView.builder(
            shrinkWrap: true,
            itemCount: listItem.length,
            itemBuilder: ((context, index) {
              return Padding(
                padding: const EdgeInsets.symmetric(vertical: 16.0),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    CustomRadioButton(
                        noLabel: true,
                        value: index,
                        groupValue: widget.onpress!,
                        onChanged: (int val) {
                          setState(() {
                            widget.onpress = val;
                          });
                        }),
                    Padding(
                      padding: const EdgeInsets.only(left: 10.0),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(listItem[index],
                              style: customTextStyle(
                                  fontStyle: FontStyle.BodyL_Regular,
                                  color: FontColor.FontPrimary)),
                        ],
                      ),
                    )
                  ],
                ),
              );
            }),
          ),
        ),
        const SizedBox(
          height: 20,
        ),
      ],
    );
  }
}
