import 'dart:io';
import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/constants/prefefence_utils.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_more/page_setting_others/components/fsa_bottom_sheet.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_more/page_setting_others/components/list_of_items_tile.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_more/page_setting_others/components/log_out_bottomsheet.dart';

import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/appbar/custom_help_appbar.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/scrollable_bottomsheet/scrollable_bottomsheet.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';
import 'package:selfie_mobile_flutter/user_controller/user_controller.dart';
import 'package:selfie_mobile_flutter/utils/user_settings.dart';

class SettingOthersPage extends StatefulWidget {
  const SettingOthersPage({Key? key}) : super(key: key);

  @override
  State<SettingOthersPage> createState() => _SettingOthersPageState();
}

class _SettingOthersPageState extends State<SettingOthersPage> {
  bool fingerprint = UserSettings.userSettings.otherSettings.fingerPrint;
  bool faceUnclock = UserSettings.userSettings.otherSettings.faceUnclock;
  bool passwordUnlock = UserSettings.userSettings.otherSettings.passwordUnloack;
  bool patternUnlock = UserSettings.userSettings.otherSettings.patternUnloack;
  bool indexVisibility =
      UserSettings.userSettings.otherSettings.indexVisibility;
  int defaultVal = UserSettings.userSettings.otherSettings.loginTimeout;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(0.0),
        child: AppBar(
          elevation: 0,
        ),
      ),
      body: SafeArea(
        child: Column(
          children: [
            CustomHelpAppbar(
              iconPress: () {
                Navigator.pop(context);
              },
              title: "Others",
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 20, 16, 0),
              child: Column(
                children: [
                  if (Platform.isAndroid) ...[
                    InkWell(
                      onTap: () {
                        setState(() {
                          passwordUnlock = !passwordUnlock;
                        });
                      },
                      child: Padding(
                        padding: const EdgeInsets.only(top: 0, bottom: 20),
                        child: ListOfItemTile(
                          change: passwordUnlock,
                          title: "Password Unlock",
                          onChange: (bool val) {
                            setState(() {
                              passwordUnlock = !passwordUnlock;
                            });
                          },
                        ),
                      ),
                    ),
                    Divider(
                      height: 1,
                      color: customColors().backgroundTertiary,
                    ),
                    InkWell(
                      onTap: () {
                        setState(() async {
                          UserSettings.userSettings.otherSettings
                              .patternUnloack = patternUnlock = !patternUnlock;
                          await PreferenceUtils.storeDataToShared(
                              UserController.userController.userId,
                              UserSettings.userSettings.toJsonString());
                        });
                      },
                      child: Padding(
                        padding: const EdgeInsets.only(top: 20, bottom: 20),
                        child: ListOfItemTile(
                          change: patternUnlock,
                          title: "Pattern Unlock",
                          onChange: (bool val) async {
                            setState(() {
                              // patternUnlock = !patternUnlock;
                              UserSettings.userSettings.otherSettings
                                      .patternUnloack =
                                  patternUnlock = !patternUnlock;
                            });
                            await PreferenceUtils.storeDataToShared(
                                UserController.userController.userId,
                                UserSettings.userSettings.toJsonString());
                          },
                        ),
                      ),
                    ),
                    Divider(
                      height: 1,
                      color: customColors().backgroundTertiary,
                    ),
                  ] else if (Platform.isIOS) ...[
                    InkWell(
                      onTap: () {
                        setState(() async {
                          // faceUnclock = !faceUnclock;
                          UserSettings.userSettings.otherSettings.faceUnclock =
                              faceUnclock = !faceUnclock;
                          await PreferenceUtils.storeDataToShared(
                              UserController.userController.userId,
                              UserSettings.userSettings.toJsonString());
                        });
                      },
                      child: Padding(
                        padding: const EdgeInsets.only(top: 20, bottom: 20),
                        child: ListOfItemTile(
                          change: faceUnclock,
                          title: "Face Unlock",
                          onChange: (bool val) async {
                            setState(() {
                              // faceUnclock = !faceUnclock;
                              UserSettings.userSettings.otherSettings
                                  .faceUnclock = faceUnclock = !faceUnclock;
                            });
                            await PreferenceUtils.storeDataToShared(
                                UserController.userController.userId,
                                UserSettings.userSettings.toJsonString());
                          },
                        ),
                      ),
                    ),
                    Divider(
                      height: 1,
                      color: customColors().backgroundTertiary,
                    ),
                  ],
                  InkWell(
                    onTap: () async {
                      setState(() {
                        UserSettings.userSettings.otherSettings.fingerPrint =
                            fingerprint = !fingerprint;
                      });
                      await PreferenceUtils.storeDataToShared(
                          UserController.userController.userId,
                          UserSettings.userSettings.toJsonString());
                    },
                    child: Padding(
                      padding: const EdgeInsets.only(top: 20, bottom: 20),
                      child: ListOfItemTile(
                        change: fingerprint,
                        title: "Finger Print",
                        onChange: (bool val) async {
                          setState(() {
                            UserSettings.userSettings.otherSettings
                                .fingerPrint = fingerprint = !fingerprint;
                          });
                          await PreferenceUtils.storeDataToShared(
                              UserController.userController.userId,
                              UserSettings.userSettings.toJsonString());
                        },
                      ),
                    ),
                  ),
                  Divider(
                    height: 1,
                    color: customColors().backgroundTertiary,
                  ),
                  InkWell(
                    onTap: () async {
                      setState(() {
                        UserSettings
                                .userSettings.otherSettings.indexVisibility =
                            indexVisibility = !indexVisibility;
                      });
                      await PreferenceUtils.storeDataToShared(
                          UserController.userController.userId,
                          UserSettings.userSettings.toJsonString());
                    },
                    child: Padding(
                      padding: const EdgeInsets.only(top: 20, bottom: 20),
                      child: ListOfItemTile(
                        change: indexVisibility,
                        title: "Index Visibility",
                        onChange: (bool val) async {
                          setState(() {
                            UserSettings.userSettings.otherSettings
                                    .indexVisibility =
                                indexVisibility = !indexVisibility;
                          });
                          await PreferenceUtils.storeDataToShared(
                              UserController.userController.userId,
                              UserSettings.userSettings.toJsonString());
                        },
                      ),
                    ),
                  ),
                  Divider(
                    height: 1,
                    color: customColors().backgroundTertiary,
                  ),
                  InkWell(
                    onTap: () {
                      customBottomSheet(
                          context: context, inputWidget: FsaBottomSheet());
                    },
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(top: 30, bottom: 30),
                          child: Text(
                            "Flip Secure Authentication",
                            style: customTextStyle(
                                fontStyle: FontStyle.BodyL_SemiBold,
                                color: FontColor.FontPrimary),
                          ),
                        ),
                        Image.asset(
                          "assets/arrow_down.png",
                          color: customColors().primary,
                        )
                        // InkWell(
                        //   onTap: () {
                        //     customShowModalBottomSheet(
                        //       context: context,
                        //       inputWidget: LogOutBottomSheet(
                        //         onpress: (val) async {
                        //           setState(() {
                        //             UserSettings.userSettings.otherSettings
                        //                 .loginTimeout = defaultVal = val;
                        //           });
                        //           await PreferenceUtils.storeDataToShared(
                        //               UserController.userController.userId,
                        //               UserSettings.userSettings.toJsonString());
                        //         },
                        //       ),
                        //     );
                        //   },
                        //   // child: Row(
                        //   //   children: [
                        //   //     Text(
                        //   //       gValue == 0
                        //   //           ? "2 hours"
                        //   //           : gValue == 1
                        //   //               ? "4 hours"
                        //   //               : gValue == 2
                        //   //                   ? " 8 hours"
                        //   //                   : "2 hours",
                        //   //       style: customTextStyle(
                        //   //           fontStyle: FontStyle.BodyL_SemiBold,
                        //   //           color: FontColor.Primary),
                        //   //     ),
                        //   //     Padding(
                        //   //       padding: const EdgeInsets.only(left: 8),
                        //   //       child: Image.asset(
                        //   //         "assets/arrow_down.png",
                        //   //         color: customColors().primary,
                        //   //       ),
                        //   //     )
                        //   //   ],
                        //   // ),
                        // ),
                      ],
                    ),
                  ),
                  Divider(
                    height: 1,
                    color: customColors().backgroundTertiary,
                  ),
                  InkWell(
                    onTap: () {
                      customShowModalBottomSheet(
                        context: context,
                        inputWidget: LogOutBottomSheet(
                          onpress: (val) async {
                            setState(() {
                              UserSettings.userSettings.otherSettings
                                  .loginTimeout = defaultVal = val;
                            });
                            await PreferenceUtils.storeDataToShared(
                                UserController.userController.userId,
                                UserSettings.userSettings.toJsonString());
                            Navigator.pop(context);
                          },
                        ),
                      );
                    },
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(top: 30, bottom: 30),
                          child: Text(
                            "Login Time Out",
                            style: customTextStyle(
                                fontStyle: FontStyle.BodyL_SemiBold,
                                color: FontColor.FontPrimary),
                          ),
                        ),
                        InkWell(
                          onTap: () {
                            customShowModalBottomSheet(
                              context: context,
                              inputWidget: LogOutBottomSheet(
                                onpress: (val) async {
                                  setState(() {
                                    UserSettings.userSettings.otherSettings
                                        .loginTimeout = defaultVal = val;
                                  });
                                  await PreferenceUtils.storeDataToShared(
                                      UserController.userController.userId,
                                      UserSettings.userSettings.toJsonString());
                                },
                              ),
                            );
                          },
                          child: Row(
                            children: [
                              Text(
                                gValue == 0
                                    ? "2 hours"
                                    : gValue == 1
                                        ? "4 hours"
                                        : gValue == 2
                                            ? " 8 hours"
                                            : "2 hours",
                                style: customTextStyle(
                                    fontStyle: FontStyle.BodyL_SemiBold,
                                    color: FontColor.Primary),
                              ),
                              Padding(
                                padding: const EdgeInsets.only(left: 8),
                                child: Image.asset(
                                  "assets/arrow_down.png",
                                  color: customColors().primary,
                                ),
                              )
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Divider(
                    height: 1,
                    color: customColors().backgroundTertiary,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
