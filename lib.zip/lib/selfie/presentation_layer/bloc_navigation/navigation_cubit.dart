import 'package:bloc/bloc.dart';
import 'package:meta/meta.dart';

part 'navigation_state.dart';

class NavigationCubit extends Cubit<NavigationState> {
  NavigationCubit() : super(WatchlistIndexState());

  updateWatchList(int index){
    emit(WatchlistIndexState(index: index));
  }

  openWatchList(){
    emit(WatchlistIndexState());
  }

  openPortfolio(){
    emit(PortfoliState());
  }

  openHoldingsOverview(){
    emit(HoldingOverviewState());
  }

  openHoldingsEquity(){
    emit(HoldingEquityState());
  }

  openSmartfolioHoldings(){
    emit(SmartfoliHoldingState());
  }

  openOrders(){
    emit(OrdersState());
  }

  opnIdea(){
    emit(IdeaState());
  }
  openMore(){
    emit(openMore());
  }

}
