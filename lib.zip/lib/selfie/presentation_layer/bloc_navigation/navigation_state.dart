part of 'navigation_cubit.dart';

@immutable
abstract class NavigationState {}

class WatchlistIndexState extends NavigationState {
  int index;
  WatchlistIndexState({this.index = 0});
}

class PortfoliState extends NavigationState {}
class SmartfoliHoldingState extends NavigationState {}
class HoldingOverviewState extends NavigationState {}
class HoldingEquityState extends NavigationState {}
class OrdersState extends NavigationState {}
class IdeaState extends NavigationState {}
class MoreState extends NavigationState {}


