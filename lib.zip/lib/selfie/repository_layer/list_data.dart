import 'package:selfie_mobile_flutter/theme/styles.dart';

List<Map<String, dynamic>> announcementlist = [
  {
    "name": "Bonus",
    "disc": "Ratio 2:3",
    "expdate": "18/09/22",
    "recdate": "22/09/22",
    "isAnounced": true,
    "itemColor": customColors().mattPurple.withOpacity(0.15),
    "icon": "assets/plus_circle.png",
  },
  {
    "name": "Dividend",
    "disc": "Rs 10 per share",
    "expdate": "16/20/22",
    "recdate": "24/20/22",
    "isAnounced": true,
    "itemColor": customColors().crisps.withOpacity(0.15),
    "icon": "assets/server.png",
  },
  {
    "name": "Split",
    "disc": "FV from Rs 10 to Rs 20 per share",
    "expdate": "01/11/22",
    "recdate": "08/11/22",
    "isAnounced": true,
    "itemColor": customColors().pacificBlue.withOpacity(0.15),
    "icon": "assets/scissors.png",
  },
  {
    "name": "Result",
    "disc": "For Quarter 1",
    "expdate": "54",
    "recdate": "25/12/22",
    "isAnounced": false,
    "itemColor": customColors().dodgerBlue.withOpacity(0.15),
    "icon": "assets/calendar_icon.png",
  },
];
List<Map<String, dynamic>> bulkDealsList = [
  {
    "name": "Rakesh Jhunjhuwala",
    "bulkorblock": "Bulk",
    "Buyorsell": "Buy",
    "qty": "2,123,123",
    "date": "18 Sep",
    "avgprice": "1987.27",
    "bulkorblockcolor": customColors().mattPurple.withOpacity(0.15),
    "bulkorblockFontColort": FontColor.Purple,
    "buyorsellFontColort": FontColor.SecretGarden,
    "buyorsellcolor": customColors().secretGarden.withOpacity(0.15),
  },
  {
    "name": "Yes Bank",
    "bulkorblock": "Block",
    "Buyorsell": "Sell",
    "qty": "1,800,000",
    "date": "3 Mar",
    "avgprice": "1987.27",
    "bulkorblockcolor": customColors().dodgerBlue.withOpacity(0.15),
    "bulkorblockFontColort": FontColor.DodgerBlue,
    "buyorsellFontColort": FontColor.Danger,
    "buyorsellcolor": customColors().danger.withOpacity(0.15),
  },
  {
    "name": "Soft Bank",
    "bulkorblock": "Block",
    "Buyorsell": "Sell",
    "qty": "50,000",
    "date": "17 Jan",
    "avgprice": "1987.27",
    "bulkorblockcolor": customColors().dodgerBlue.withOpacity(0.15),
    "bulkorblockFontColort": FontColor.DodgerBlue,
    "buyorsellFontColort": FontColor.Danger,
    "buyorsellcolor": customColors().danger.withOpacity(0.15),
  },
];
//gk
List<Map<String, dynamic>> dealsList = [
  {
    "name": "Mohit Yagnik",
    "bulkorblock": "BULK",
    "Buyorsell": "BUY",
    "qty": "2,123,123",
    "date": "18 Sep",
    "avgprice": "1987.27",
    "bulkorblockcolor": customColors().mattPurple.withOpacity(0.15),
    "bulkorblockFontColort": FontColor.Purple,
    "buyorsellFontColort": FontColor.SecretGarden,
    "buyorsellcolor": customColors().secretGarden.withOpacity(0.15),
  },
  {
    "name": "Nithin Jose",
    "bulkorblock": "BLOCK",
    "Buyorsell": "SELL",
    "qty": "1,800,000",
    "date": "3 Mar",
    "avgprice": "1987.27",
    "bulkorblockcolor": customColors().dodgerBlue.withOpacity(0.15),
    "bulkorblockFontColort": FontColor.DodgerBlue,
    "buyorsellFontColort": FontColor.Danger,
    "buyorsellcolor": customColors().danger.withOpacity(0.15),
  },
  {
    "name": "Soft Bank",
    "bulkorblock": "BLOCK",
    "Buyorsell": "SELL",
    "qty": "50,000",
    "date": "17 Jan",
    "avgprice": "1987.27",
    "bulkorblockcolor": customColors().dodgerBlue.withOpacity(0.15),
    "bulkorblockFontColort": FontColor.DodgerBlue,
    "buyorsellFontColort": FontColor.Danger,
    "buyorsellcolor": customColors().danger.withOpacity(0.15),
  },
];

List<Map<String, dynamic>> stockHistoryList = [
  {
    "name": "TCS",
    "quantity": "10",
    "amount": "234.66",
    "date": "01/12/2021",
    "actions": ["SELL", "INTRADAY"]
  },
  {
    "name": "TCS",
    "quantity": "20",
    "amount": "240.12",
    "date": "01/12/2021",
    "actions": ["BUY", "MTF"]
  },
];
