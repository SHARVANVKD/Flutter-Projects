import 'package:mds/subject_list.dart';
import 'package:selfie_mobile_flutter/mds_controller.dart/mds_controller.dart';

class Instrument {
  final String scripcode;
  final String symbol; //eg TATAMOTORS
  final String securityName; //eg TATA MOTORS LTD
  final String series; //eg EQ, CM, MF
  final int venueIndex; //eg 1= NSE, 2=BSE
  final int type; //eg intrument type

  final String otherScripCode;
  final String otherSeries;

  String lastTrdTime;
  String contractDate;
  double openPrice;
  double dayHighPrice;
  double dayLowPrice;
  double avgTrdPrice;
  double upperCheckLmt;
  double lowerCheckLmt;
  double spotPrice;
  double high52Week;
  double low52Week;
  double bestBuyPrice;
  double bestSellPrice;
  double lastTrdPrice;
  double changePrice;
  double strikePrice;
  double percChange;
  int lastTrdQty;
  int totalBuyQty;
  int totalSellQty;
  int totalTrdQty;
  int subscriptionCount;
  int precision;
  List<double> bestBuyPrices;
  List<double> bestSellPrices;
  List<int> bestBuyQtys;
  List<int> bestSellQtys;
  int change;
  String weekly = "";

  Instrument({
    required this.scripcode,
    required this.symbol,
    required this.securityName,
    required this.series,
    required this.venueIndex,
    required this.type,
    this.otherScripCode = "",
    this.otherSeries = "",
    this.lastTrdTime = "00-00-0000 00:00:00",
    this.contractDate = "00:00:00",
    this.openPrice = 0.00,
    this.dayHighPrice = 0.00,
    this.dayLowPrice = 0.00,
    this.avgTrdPrice = 0.00,
    this.upperCheckLmt = 0.00,
    this.lowerCheckLmt = 0.00,
    this.spotPrice = 0.00,
    this.high52Week = 0.00,
    this.low52Week = 0.00,
    this.bestBuyPrice = 0.00,
    this.bestSellPrice = 0.00,
    this.strikePrice = 0.00,
    this.lastTrdPrice = 0.00,
    this.changePrice = 0.00,
    this.percChange = 0.00,
    this.lastTrdQty = 0,
    this.totalBuyQty = 0,
    this.totalSellQty = 0,
    this.totalTrdQty = 0,
    this.subscriptionCount = 0,
    this.precision = 2,
    this.bestBuyPrices = const [],
    this.bestSellPrices = const [],
    this.bestBuyQtys = const [],
    this.bestSellQtys = const [],
    this.change = 0,
  }) {
    this.precision = getPrecision(venueIndex);
  }

  String getRicAddress(int type) {
    return generateRIC_Address(
        scripCode: this.scripcode, venueIndex: this.venueIndex, type: type);
  }
}
