import 'dart:async';
import 'package:mds/mds.dart';
import 'package:mds/subject_list.dart';
import 'package:selfie_mobile_flutter/mds_controller.dart/mds_model.dart/instrument.dart';

enum FeedSubscriptionType { watch, MBP, MBP_OTH }

// "1.6.1.236116", GOLDM MCX
// "1.6.1.237883", GOLDM MCX

class FlairResponseModel {
  final String ric;
  final Instrument instrument;
  FlairResponseModel(this.ric, this.instrument);
}

class FeedResponseInstance {
  final String key;
  final Instrument instrument;
  FeedResponseInstance({required this.key, required this.instrument});
}

class MDS_Controller {
  late MDS_Login mds;

  // List<String> subscriptionList = [

  // ];

  Map<String, int> subscriptionMap = {};

  final controller = StreamController<FlairResponseModel>.broadcast();
  Stream<FlairResponseModel> get stream => controller.stream;
  Map<String, Instrument> feedData = {};

  static final MDS_Controller mdsController =
      MDS_Controller._privateConstructor();

  MDS_Controller._privateConstructor() {
    mds = MDS_Login.createMdsLogin(
        url: "http://freeflair.geojit.net:443/m/r"); //freeflair - flair
    mds.stream.listen((Map<String, Object> event) {
      if (event.containsKey("76")) {
        // print("poll update for ${event["76"]}");
        String key = event["76"].toString(); //1.6.1.237883
        Instrument? value = feedData[key];
        if (value == null) return;

        if (event.containsKey("10")) {
          double prevLtp = value.lastTrdPrice;
          double ltp = double.parse(event["10"].toString());
          if (ltp > prevLtp)
            value.change = 1;
          else if (ltp < prevLtp) value.change = -1;
          value.lastTrdPrice = ltp;
        }
        if (event.containsKey("11")) {
          value.changePrice = double.parse(event["11"].toString());
        }
        if (event.containsKey("12")) {
          value.percChange = double.parse(event["12"].toString());
        }
        if (event.containsKey("20")) {
          value.lastTrdQty = int.parse(event["12"].toString());
        }
        // print("poll processed for ${event["76"]}");
        controller.sink.add(FlairResponseModel(key, value));
      }
    });
    // initStream();
  }

  factory MDS_Controller() {
    return mdsController;
  }

  /// Login to flair with provided username and password
  /// ```dart
  /// mdsLogin("Username", "Password");
  /// ```
  Future<void> mdsLogin(
      {String username = "VYJ252", String password = "Lion1234"}) async {
    await mds.flair(username, password);
  }

  // Stream<List<Instrument>> getStreamInstance() {
  //   return stream;
  // }

  startPolling() {
    mds.poll = true;
  }

  stopPolling() {
    mds.poll = false;
  }

  subscrbe(String ricAdd) {
    if (subscriptionMap.containsKey(ricAdd)) {
      int i = (subscriptionMap[ricAdd] ?? 1) + 1;
      subscriptionMap[ricAdd] = i;
      return;
    }
    subscriptionMap[ricAdd] = 1;
    mds.sendSubscriptionRequest([ricAdd]);
  }

  unsubscribe(String ricAdd) {
    if (!subscriptionMap.containsKey(ricAdd)) return;
    int i = (subscriptionMap[ricAdd] ?? 1) - 1;
    if (i < 1) {
      subscriptionMap.remove(ricAdd);
      mds.sendUnsubscriptionRequest([ricAdd]);
      return;
    }
    subscriptionMap[ricAdd] = 1;
    return;
  }

  /// returns formatted double value with fixedFraction point
  /// ```dart
  /// formatDouble(123.0123);
  /// ```
  /// returns [123.01]
  /// ```dart
  /// formatDouble(123.0, fractionPoint: 3);
  /// ```
  /// returns [123.000]
  String formatDouble(double value, {int fractionPoint = 2}) {
    return value.toStringAsFixed(fractionPoint);
  }

  /// subscibe to RIC in list [data] if not present in list [subscriptionList]
  /// as a batch.
  /// ```dart
  /// batchSubscrbe(["1.1.1.2135", "1.2.1.23116", "1.1.2.76211"]);
  /// ```
  batchSubscrbe(List<String> data) {
    List<String> subList = [];
    for (var item in data) {
      if (!subscriptionMap.containsKey(item)) {
        subscriptionMap[item] = 1;
        subList.add(item);
        continue;
      }
      int i = (subscriptionMap[item] ?? 1);
      subscriptionMap[item] = i + 1;
      subList.add(item);
    }
    mds.sendSubscriptionRequest(subList);
  }

  /// unsubscribe to RIC in list [data]
  /// as a batch.
  /// ```dart
  /// batchUnsubscribe(["1.1.1.2135", "1.2.1.23116", "1.1.2.76211"]);
  /// ```
  batchUnsubscribe(List<String> list) {
    List<String> unsubList = [];
    for (var item in list) {
      //continue to initial point of loop if match found
      if (!subscriptionMap.containsKey(item)) continue;
      if (subscriptionMap.containsKey(item)) {
        int i = (subscriptionMap[item] ?? 1) - 1;
        if (i < 1) {
          subscriptionMap.remove(item);
          unsubList.add(item);
          continue;
        }
        subscriptionMap[item] = i;
      }
    }
    mds.sendUnsubscriptionRequest(unsubList);
  }
}

/// Create RIC address
///
/// scripcode = venueScripCode eg: "1465"
///
/// venueIndex = exchange eg: NSE = "0", BSE = "1"
///
/// type = subscriptionType eg: Watchlist = "1", MBP = "2"
/// ```dart
/// generateRIC_Address(scripCode: "2135", venueIndex: 1, type: 1);
/// ``
String generateRIC_Address(
    {required String scripCode, required int venueIndex, required int type}) {
  return "1" +
      "." +
      venueIndex.toString() +
      "." +
      type.toString() +
      "." +
      scripCode;
}
