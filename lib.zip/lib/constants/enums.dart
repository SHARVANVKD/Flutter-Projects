enum ActionType {
  delete,
  save,
}

enum SortFilterLocation { position, holding }

enum Exchange { askEveryTime, NSE, BSE }

enum Order { regular, BO }

enum OrderType { market, limit, stopLossLimit, stopLossMarket }

enum Product { cash, intraday, BTST, MTF }

enum TimeCondition { day, IOC, conditional, GTD }

enum Condition { greaterThan, lessThan }

enum OrderStatus { completed, pending, conditional }

enum SymbolSearchStatus { watchlist, alert, basket }

getExchangeString(Exchange exchange) {
  switch (exchange) {
    case Exchange.askEveryTime:
      return "Ask Everytime";
    case Exchange.NSE:
      return "NSE";
    case Exchange.BSE:
      return "BSE";
    default:
  }
}

getOrderString(Order order) {
  switch (order) {
    case Order.regular:
      return "Regular";
    case Order.BO:
      return "BO";
    default:
  }
}

getOrderTypeString(OrderType orderType) {
  switch (orderType) {
    case OrderType.market:
      return "Market";
    case OrderType.limit:
      return "Limit";
    case OrderType.stopLossLimit:
      return "Stop Loss Limit";
    case OrderType.stopLossMarket:
      return "Stop Loss Market";
  }
}

getProductString(Product product) {
  switch (product) {
    case Product.cash:
      return "Cash";
    case Product.intraday:
      return "Intraday";
    case Product.BTST:
      return "BTST";
    case Product.MTF:
      return "MTF";
  }
}

getTimeConditionString(TimeCondition timeCondition) {
  switch (timeCondition) {
    case TimeCondition.GTD:
      return "GTD";
    case TimeCondition.IOC:
      return "IOC";
    case TimeCondition.day:
      return "Day";
    case TimeCondition.conditional:
      return "Conditional";
  }
}

getConditionString(Condition condition) {
  switch (condition) {
    case Condition.greaterThan:
      return "Greater Than";
    case Condition.lessThan:
      return "Less Than";
  }
}
