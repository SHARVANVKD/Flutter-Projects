class Texts {
  static String bottomBarItem1 = "Watchlist";
  static String bottomBarItem2 = "Portfolio";
  static String bottomBarItem3 = "Order";
  static String bottomBarItem4 = "Idea";
  static String bottomBarItem5 = "More";
}
