Map<String, String> errorMap = {
    "loginProgress" : "Please Wait.....Login in Progress",
    "RemLogAttempt" : "Login attempts remaining: ",
    "1" : "If request list is null",
    "2" : "error related to query execution and parsing",
    "3" : "If required field in the request is missing",
    "4" : "If data not found for the requested parameters",
    "5" : "Exception related to Tibrv message",
    "6" : "Exception in taking values from Tibrv request",
    "7" : "Tibrv Request timeout for the SearchAPI ( server is not responding )",
    "404" : "The requested resource could not be found.",
    "500" : "Internal server error.",
    "501" : "Reporting service failure : unable to process request.Please try after some time.",
    "1001" : "No message body found",
    "1002" : "No message header found",
    "1003" : "Message header does not contain error code",
    "1004" : "Message header does not contain error category",
    "1005" : "Request timeout",
    "1006" : "Frond end naming exception",
    "1007" : "Front end jms exception",
    "1008" : "Unknown exception",
    "1101" : "Fast encoding exception",
    "1102" : "Fast decoding exception",
    "1103" : "Dto to message mapping exception",
    "1104" : "Message to dto mapping exception",
    "1201" : "Ioc invalid",
    "1202" : "Message type should not be null",
    "1203" : "Message type not found",
    "1204" : "Creation time should not be null",
    "1205" : "Creation time not found",
    "1206" : "Login id should not be null",
    "1207" : "Login id not found",
    "1208" : "Session key should not be null",
    "1109" : "Session key not found",
    "1210" : "Login password should not be null",
    "1211" : "Login password not found",
    "1212" : "Error code not found",
    "1213" : "Error category not found",
    "1214" : "Quantity should not be less than one",
    "1215" : "Venue scripecode should not be null",
    "1216" : "Venue scripecode not found",
    "1217" : "Price should not be less than zero",
    "1218" : "Triger price should not be less than zero",
    "1219" : "Stop price should not be less than zero",
    "1220" : "Lower limit price should not be less than zero",
    "1221" : "Disclosed quantity should not be less than zero",
    "1222" : "Min fill quantity should not be less than zero",
    "1223" : "User code should not be null",
    "1224" : "User code not found",
    "1225" : "Pro client should not be null",
    "1226" : "Pro client not found",
    "1227" : "Product type should not be null",
    "1228" : "Product type not found",
    "1229" : "Market type should not be null",
    "1230" : "Market type not found",
    "1231" : "Venue code should not be null",
    "1232" : "Venue code not found",
    "1233" : "Security code should not be null",
    "1234" : "Security code not found",
    "1235" : "Buy sell should not be null",
    "1236" : "Buy sell not found",
    "1237" : "Price condition should not be null",
    "1238" : "Price condition not found",
    "1239" : "Invalid message type",
    "1240" : "Topic name can not be null",
    "1241" : "User access key not be null",
    "1242" : "New password not be null",
    "1243" : "Old password not be null",
    "1244" : "Channel should not be null",
    "1245" : "Channel not found",
    "1246" : "Emailid should not be null",
    "1247" : "Emailid not found",
    "1248" : "Trans id should not be null",
    "1249" : "Trans id not found",
    "1250" : "Entering user code should not be null",
    "1251" : "Entering user code not found",
    "1252" : "Ordering user code should not be null",
    "1253" : "Ordering user code not found",
    "1254" : "Order status should not be null",
    "1255" : "Order status not found",
    "1256" : "External trans id not found",
    "1257" : "Custodian id not found",
    "1258" : "Invalid stop loss trigged",
    "1259" : "Method name should not be null",
    "1260" : "Method name not found",
    "1261" : "TifCD should not be null",
    "1262" : "TifCD not found",
    "1263" : "Segment should not be null",
    "1264" : "Segment not found",
    "1265" : "Required amount should not be zero",
    "1300" : "Invalid to product type",
    "1301" : "Invalid from product type",
    "1302" : "Invalid product type conversion",
    "1303" : "Request ID not found",
    "1304" : "Strike Price not found",
    "1305" : "Either quantity or price should be given",
    "1501" : "Authentication exception",
    "1502" : "Sorry : You are not authorized or Invalid User Code / Password.",
    "1503" : "Sorry : You are not authorized or Invalid User Code / Password.",
    "1504" : "User disabled. Please contact customer care: ",
    "1505" : "Not an internet client",
    "1506" : "Web login is not allowed for retail clients",
    "1507" : "Not session type dealer",
    "1508" : "User disabled. Please contact customer care: ",
    "1516" : "Not an online client.",
    "1519" : "Service is not available",
    "1522" : "Secure Authentication Required",
    "1523" : "Tfa token entered is wrong. Please re-enter.",
    "1525" : "Invalid Twofactor Regeneration attempt",
    "1526" : "User Data Not Found",
    "1527" : "Mobile user agreement not accepted : please visit customer care site or contact our Branch/ Call Centre for activation",
    "1601" : "Change password exception",
    "1602" : "Wrong old password",
    "1603" : "New password same as old",
    "1604" : "Session expired",
    "1605" : "Password is previously used.",
    "1701" : "Reset password exception",
    "1702" : "Mail id not matching",
    "1801" : "Logout exception",
    "1703" : "Forgot Password Exception",
    "1704" : "MSM ID not matching",
    "1705" : "User does not exist",
    "1706" : "Forgot Password time period not elapsed",
    "1707" : "Not an internet client",
    "2101" : "Not a valid order request",
    "2102" : "Invalid user session",
    "2103" : "User session does not exist",
    "2105" : "IOC is not allowed in Pre-open.",
    "2106" : "Disclose quantity is not allowed in Pre-open.",
    "2107" : "Stop loss is not allowed in Pre-open.",
    "2108" : "Invalid unit",
    "2109" : "Tif date should be greater than current date",
    "2110" : "Tif date should be less than expiration date",
    "2111" : "Tif date should be less than allowed limit",
    "2116" : "GTD orders not allowed in this venue",
    "2935" : "INVALID OFFLINE ORDER TIME",
    "3204" : "OFFLINE ORDER PERSISTANCE FAILED",
    "3205" : "OFFLINE ORDER SEARCH FAILED",
    "2519" : "INVALID STATUS FOR OFFLINE MODIFY",
    "2520" : "INVALID STATUS FOR OFFLINE CANCEL",
    "2521" : "INVALID PROCLIENT TYPE",
    "2501" : "Ordering user does not exist",
    "2503" : "Entering user does not exist",
    "2504" : "Entering user status is false",
    "2505" : "Trading not allowed",
    "2506" : "Ordering not allowed",
    "2507" : "No venue membership for ordering user",
    "2508" : "No venue membership for entering user",
    "2509" : "Margin trade not allowed",
    "2510" : "Origin order not found",
    "2511" : "Can not cancel before confirmation",
    "2512" : "Order status is neither confirmed or partially executed",
    "2513" : "Modify pending",
    "2514" : "Trans id does not exist",
    "2515" : "Entering user does not have the authorization to order for the client",
    "2522" : "Pre-Open Order at Online Time.",
    "2523" : "Online Order at Pre-Open Time.",
    "2701" : "Security not active",
    "2702" : "Security is withdrawn",
    "2703" : "Security is buy suspended",
    "2704" : "Security is sell suspended",
    "2705" : "Security is market buy suspended",
    "2706" : "Security is market sell suspended",
    "2707" : "Invalid security status",
    "2708" : "Trading denied",
    "2709" : "No security details found",
    "2710" : "Invalid Tick size",
    "2713" : "Amount less than : minimum amount required for fresh subscription.",
    "2714" : "Amount less than minumum subscription amount for an additional order",
    "2715" : "Depository mode not allowed",
    "2716" : "Physical mode not allowed",
    "2717" : "ORDER_QTY_NOT_MULTIPLE_OF_MARKETLOT",
    "2720" : "Invalid tick size for trigger price",
    "2901" : "Minimum order value is null",
    "2902" : "Less than minimum order",
    "2903" : "Not enough buying power",
    "2904" : "Not enough holding",
    "2905" : "Adding new record into portfolio failed",
    "2906" : "Updating portfolio failed",
    "2907" : "Adding new record into portfolio unsettled failed",
    "2908" : "Updating portfolio unsettled failed",
    "2909" : "Updating user table failed",
    "2910" : "Client wise exposure check failed",
    "2911" : "Dealer wise exposure check failed",
    "2912" : "Greater than maximum order",
    "2913" : "Invalid client category found",
    "2914" : "Invalid booked price",
    "2915" : "No response from span module",
    "2916" : "Invalid ISIIN found",
    "2917" : "EC_NOT_ACTIVE",
    "2918" : "Market wide limit reached",
    "2919" : "You are not registered for this product : Register immediately at your branch to avail this service.",
    "2920" : "Trade to trade denied for this client",
    "2921" : "Buy is denied for this client",
    "2922" : "Sell is denied for this client",
    "2923" : "Market buy is denied for this client",
    "2924" : "Market sell is denied for this client",
    "2925" : "Client is having withdrawn as order permission",
    "2927" : "Order State conflict",
    "2928" : "Invalid Transaction Password",
    "2929" : "Order quantity greater than per order buy quantity",
    "2930" : "Order quantity greater than per order sell quantity",
    "2931" : "Order quantity greater than per day quantity",
    "2932" : "Price out of range",
    "2933" : "Security not active for the product type",
    "2934" : "Requested PortFolio not found",
    "2935" : "Invalid Offline Order Time",
    "2936" : "Invalid Product Conversion Request Status",
    "2937" : "Request quantity greater than available quantity.",
    "2938" : "Invalid Product Conversion Request ID",
    "2939" : "Invalid order time.",
    "2940" : "Intraday Sell Denied For Trade to Trade Security.",
    "2941" : "Order Permission Denied For This Client In This Channel.",
    "2942" : "Venue wise Online Order Check Failed.",
    "2944" : "Invalid Custodian Id",
    "2945" : "Not Enough BTST Exposure For The Security",
    "2946" : "Not Enough MTF Exposure For The Security",
    "2947" : "NOT_ENOUGH_MTF_EXPOSURE_FOR_THE_CLIENT",
    "2948" : "DEALER_WISE_DAILY_EXPOSURE_LIMIT_REACHED",
    "2949" : "DEALER_WISE_EXPOSURE_EXPIRY_LIMIT_REACHED",
    "2953" : "Not enough smartplus exposure for the security",
    "2955" : "No response from OMS",
    "2957" : "Invalid profit price difference in smartplus",
    "2958" : "Invalid STL price difference in smartplus",
    "2959" : "Available buying power is negative",
    "2965" : "Security wise trading member limit reached",
    "2966" : "Security wise user limit reached",
    "2967" : "Square-off only permission for the venue",
    "2968" : "Due to continuous debit more than T+6 days in this exchange- only square-off permitted",
    "2960" : "Maximum open exposure permitted for this product is Rs.Lakhs",
    "2961" : "Maximum open exposure permitted in a single scrip for this product is Rs.0 Lakhs",
    "2962" : "Startagy combination not defined",
    "3001" : "new user does not exist",
    "3002" : "No venue membership for new user",
    "3003" : "Ordering is not allowed for new user",
    "3004" : "Trading is not allowed for new user",
    "3005" : "New user has unauthorized",
    "3006" : "Margin Trade is not allowed for new user",
    "3007" : "new user has denied client type",
    "3201" : "New order persistance failed",
    "3202" : "Modify order persistance failed",
    "3201" : "Cancel order persistance failed",
    "4001" : "Null pointer exception",
    "4002" : "Jms exception",
    "4003" : "Topic not found exception",
    "4004" : "Last traded price not available",
    "4005" : "Back end Run time exception occurred .. please try after some time",
    "4006" : "Unknown exception",
    "4007" : "Persistance exception",
    "4008" : "Duplicate message received",
    "4009" : "Resource lock exception",
    "5000" : "Back end message mapping failed",
    "5100" : "Order reply persist failed",
    "5101" : "Order lookup failed",
    "5102" : "Orphan execution persist failed",
    "5200" : "User node is null",
    "6001" : "Sql conn error",
    "6002" : "Sql query error",
    "6003" : "Xml conversion error",
    "6004" : "Data not found",
    "6005" : "Data retrieving error",
    "6006" : "Create exception",
    "6007" : "Naming exception",
    "6008" : "End of resultset",
    "6009" : "Remote exception",
    "6021" : "Error code not found",
    "6022" : "Error category not found",
    "6023" : "App name should not be null",
    "6024" : "App name not found",
    "6025" : "Entering user code should not be null",
    "6026" : "Entering user code not found",
    "6027" : "Ordering user code should not be null",
    "6028" : "Ordering user code not found",
    "6029" : "Status should not be null",
    "6030" : "Status not found",
    "6031" : "Trans id should not be null",
    "6032" : "Trans id not found",
    "6033" : "Legno should not be null",
    "6034" : "Legno not found",
    "6035" : "Entering user code and ordering user code not found",
    "6036" : "Method name should not be null",
    "6037" : "Method name not found",
    "6038" : "Venue code should not be null",
    "6039" : "Venue code not found",
    "6040" : "Security code should not be null",
    "6041" : "Security code not found",
    "6042" : "Product type should not be null",
    "6043" : "Product type not found",
    "6044" : "User code should not be null",
    "6045" : "User code not found",
    "6046" : "Session key should not be null",
    "6047" : "Session key not found",
    "81001" : "Back end error in web server",
    "81002" : "Invalid Web session",
    "81003" : "empty request string passed as argument in HTTP request from client",
    "81004" : "Error while decoding request from string",
    "81005" : "No response received from OMS",
    "81006" : "Error while encoding response to string",
    "81007" : "Unknown Exception while requesting to OMS",
    "81008" : "OMS API exception while requesting to OMS",
    "81009" : "OMS API FrontEnd Exception while requesting to OMS",
    "81010" : "Report Type not found in report request",
    "81011" : "Co-relation id not found in request",
    "81012" : "Field in request not found in server dictionary",
    "81013" : "Request header is empty",
    "81014" : "Request header having unknown format or malformed header",
    "81015" : "Unknown Request DTO type.",
    "81016" : "Required parameter not found.",
    "81017" : "Duplicate request Message",
    "81018" : "Request DTO is null",
    "81020" : "Denied host",
    "81103" : "Order Type Mis match",
    "81101" : "Wrong quantity.",
    "81102" : "Invalid security.",
    "70000" : "Invalid Message Format",
    "70001" : "Invalid account number",
    "70002" : "Function not supported",
    "70003" : "Funds Insufficient",
    "70004" : "Transaction not allowed on account",
    "70005" : "Withdrawal limit exceeded",
    "70006" : "Transfer Limit Exceeded",
    "70007" : "All cheque not in same book",
    "70008" : "Could not stop all cheque",
    "70009" : "All cheque not of same acct",
    "70010" : "Please contact admin",
    "70011" : "Please contact admin",
    "70012" : "Cutover in progress",
    "70013" : "Host not available",
    "70014" : "Host not available",
    "70015" : "System malfunction",
    "70016" : "Host not available",
    "70017" : "Duplicate transaction",
    "70018" : "Failed",
    "100001" : "Invalid Signature or certificate details",
    "200001" : "Invalid or Inactive Corporate Id",
    "300001" : "Corporate is not allowed for selected Message",
    "500001" : "Invalid Length (Response ISO message)",
    "900001" : "Invalid Fund Transfer Enquiry",
    "110000" : "Invalid Length (Input Corporate message)",
    "120000" : "Invalid Debit Account No",
    "130000" : "Message already transfered",
    "140000" : "Remark field is empty",
    "150000" : "Invalid IFSC Code",
    "160000" : "Missing RTGS Corporate setup details",
    "170000" : "Invalid RTGS Message Characters",
    "180000" : "RTGS Rejection - QPH",
    "190000" : "RTGS Rejection - PI",
    "200000" : "RTGS Rejction - Other bank",
    "70034" : "Block Amount not available",
    "210000" : "RTGS Message Generation - System Error",
    "220000" : "Action Message - Mandatory Fields Missing",
    "230000" : "Action Message - Invalid Beneficiary Account",
    "240000" : "DD Message - Invalid DD Payable City",
    "250000" : "Message Invalid Values",
    "270001" : "Invalid ISIN Or AccountCode",
    "270002" : "Quantity requested for BOO not Available",
    "270003" : "Operation is not allowed when the object is open.",
    "270004" : "Unknown errors :270004",
    "70041" : "Physical link error",
    "70042" : "Query Time out Exception",
    "70043" : "Invalid URL",
    "70044" : "Invalid Request Message",
    "70045" : "Unknown Errors  :70045",
    "260000" : "Error Not Defined",
    "280000" : "NEFT - Senders Customer ID cannot be blank",
    "65101" : "Validation Failed:Unregistered Acctno/ClientId/BrokerId  OR BrokerTransactionId is duplicated.",
    "220000" : "Validation Failed:Mandatory Fields not obtained.",
    "70014" : "Service Down.",
    "65110" : "Duplicate Broker Msg Id.",
    "65111" : "Invalid scheme type.",
    "65184" : "Requested Block operation failed since Account is closed/frozen.",
    "65186" : "Block does not exist.",
    "65902" : "Invalid transaction (Invalid function code within network management messages).",
    "65907" : "Card issuer inoperative .",
    "70042" : "Timed Out.Transaction doesnot occur.",
    "65000" : "Unprocessed.",
    "65800" : "Requested Amount  greater than existing Lien or Max Permissible trading limit.",
    "65801" : "Duplicate entry in File.",
    "65802" : "Day Begin not Done.",
    "70046" : "Invalid Message Type.",
    "70047" : "Header record count is not matching with detail no. of records.",
    "70048" : "Header request quantity is not matching with Detail no. of records quantity.",
    "70049" : "Invalid DP Id..",
    "70050" : "Invalid Client Id.",
    "70051" : "Invalid ISIN Code.",
    "70052" : "Insufficient Balance",
    "70053" : "Database Error in Bank",
    "70054" : "Free balance not available.",
    "70055" : "ISIN is in Auto corporate Action.",
    "70056" : "Client is not Applied for Online Instruction",
    "70057" : "No Records Found",
    "70058" : "Account Suspended for Debit",
    "70059" : "Invalid DP Id.",
    "70060" : "Invalid Sysid",
    "70061" : "The Client Id is not linked to Geojit in Bank",
    "70062" : "Invalid Joining Date",
    "70063" : "Invalid Target CMBP Id.",
    "70064" : "Market type is not valid.",
    "70065" : "Invalid Settlement No.",
    "70066" : "TIFD could not be executed because Inst. are not accepted within one hour of Pay in deadline.",
    "70067" : "Execution Date can not be a Holiday.",
    "70068" : "Execution Date cannot be less than today\'s date.",
    "70069" : "Execution Date Eroor Because Last Batch Upload for this date has got Completed.",
    "70070" : "This Client is in Defaulter List Cannot execute the Transaction.",
    "70071" : "Invalid Slip Series.",
    "70072" : "Client is not given POA for this CM.",
    "70073" : "Slip is not issued to POA.",
    "70074" : "Slip No. already used for this Settlement No",
    "70075" : "Invalid Request Parameter.",
    "70076" : "Unable to connect to TCP Host.",
    "70077" : "Error when generating Response",
    "70078" : "Invalid Action Type.",
    "70079" : "Invalid Messge length",
    "70080" : "Exception",
    "70106" : "Server Name not passed",
    "70081" : "Server name and URL mismatch",
    "70082" : "Server Name and Host IP mismatch",
    "70083" : "Unique Reference Id Not Passed",
    "70084" : "Invalid Block Reason Code",
    "70085" : "Block Reason Code must not be more than 5 characters",
    "70086" : "Invalid Block Amount Indicator",
    "70087" : "Block id cannot be more than 25 chars",
    "70088" : "Brokerage Tran ref number cannot be more than 50 chars",
    "70089" : "Invalid Login Parameter. Sorry For Inconvenience",
    "70090" : "Unable To Process Your Request. Contact Bank",
    "70091" : "Invalid host IP Address",
    "70092" : "The Account Number For Share Trading is not Your Active Account. Please Contact Bank",
    "70093" : "Amount blocked successfully",
    "70094" : "Amount unblocked successfully",
    "70095" : "Invalid message Id",
    "70096" : "Invalid Block Tran Number",
    "70097" : "Invalid Block Expiry Date",
    "70098" : "This Account is Deregistered with the Broker. Cannot Process Your request",
    "70099" : "The Previous Operation on Lien Marking/Unmarking was not Successful Corresponding to This Broker Transaction Number. So Cannot process with Balance Inquiry'",
    "70100" : "The Total Available Balance is Not Available at the Moment. Try After Some Time.",
    "70101" : "Invalid Url. Sorry For the Inconvenience",
    "70102" : "Block Reference Number Not Passed",
    "70103" : "Broker Transaction Number has to be Unique For Marking/Unmarking Lien",
    "70104" : "Record does not exist",
    "70105" : "Non availability of a process at Bank\'s end to accept the request from client side",
    "70107" : "Reason Code Not Found in TABLEcorresponding to the Broker",
    "70108" : "Please Pass a Valid Reason code Assigned To You.",
    "70109" : "Broker Name Not Found in TABLE corresponding to the Server Name",
    "70110" : "You are Not Authorized To Perform Transaction For the Customer.The Customer is Not Registered With You",
    "70111" : "Block amount limit exceeds the days range",
    "70112" : "Amount you are trying to block is greater than available balance",
    "70113" : "No. of Block requests for the day exceeded",
    "20216" : "Your Credit Request Approval Limit Exceeded",
    "20202" : "Your Credit Request Approval Limit Exceeded",
    "81001" : "Back end error in web server",
    "2972" : "Exceeded maximum product conversion limit for client",
    "2973" : "Security not available for client type ",
    "2974" : "No user product mapped for client",
    "2975" : "Exceeded dealerwise exchangewise open order limit",
    "2976" : "Client daily exposure limit reached",
    "2977" : "Client expiry exposure limit reached",
    "2978" : "Branch daily exposure limit reached",
    "2979" : "Branch expiry exposure limit reached",
    "2980" : "Exceeded branchwise exchangewise open order limit",
    "2981" : "Greater than maximum order branchwise",
    "2982" : "Branch wise maximum order value is null",
    "2983" : "Branch wise minimum order value is null",
    "2984" : "Less than minimum order branch wise",
    "2985" : "Greater than maximum order dealer wise",
    "2986" : "Dealer wise maximum order value is null",
    "2987" : "Dealer wise minimum order value is null",
    "2988" : "Less than minimum order dealer wise",
    "2989" : "Order quantity greater than maximum order quantity branch wise",
    "2990" : "Order quantity greater than maximum order quantity dealerwise",
    "SessionErrorPage" : "FLIPWEB/faces/ErrorPages/ErrorPage.jsp",
    "validPassword" : "Password changed successfully.Please Relogin.",
    "disabledLogin" : "User disabled. Please contact support team.",
    "validForgotPwdReq" : "Forgot password request submitted successfully",
    "InvaliedScripCode" : "Invalid Security Name",
    "OrderSentToExchange" : "Order Sent To Exchange",
    "ModifySucessfull" : "Order successfully modified",
    "ModifyOrderSendingFailed" : "Modify Order Sending Failed",
    "NewOrderFailure" : "New Order Sending Failed due to no response message received from OMS",
    "BackEndError" : "Back end exception occurred.. Try again",
    "LoginFailureMsg" : "Authentication server is not responding.",
    "newOrdFailure" : "New Order Sending Failed due to",
    "modOrdFailure" : "Modify Order failed due to",
    "cancelOrdFailure" : "Order Cancelling failed",
    "cancelOrder" : "Order Cancelling failed due to Run time Error",
    "CancelSuccessful" : "Order Sucessfully Cancelled",
    "1992" : "Welcome to Geojit BNPP Family. Your MyGeojit registration is complete. An activation email has been sent to your mailbox. Kindly follow the instructions in the email to activate your MyGeojit Account.'",
    "1993" : "Email is already registered.",
    "1994" : "Account Activated. Please login.",
    "1995" : "Invalid account.",
    "1996" : "Sorry for inconvinience. Error in sending activation mail. Please register again.",
    "1997" : "Your new account is not activated.",
    "100" : "No Option Chain found",
    "1529" : "KYC Not updated. Please update the KYC.",
    "1530" : "We excitedly welcome you to FLIP X. \nPlease log on to FLIP X on 1st April trading hours for a whole new trading Xperience'",
    "1531" : "New version of application is available. Please download!",
};

// String getErrorMessage(String val){
  // switch(val){
//     case "loginProgress" : return "Please Wait.....Login in Progress";
//     case "RemLogAttempt" : return "Login attempts remaining: ";
//     case "1" : return "If request list is null";
//     case "2" : return "error related to query execution and parsing";
//     case "3" : return "If required field in the request is missing";
//     case "4" : return "If data not found for the requested parameters";
//     case "5" : return "Exception related to Tibrv message";
//     case "6" : return "Exception in taking values from Tibrv request";
//     case "7" : return "Tibrv Request timeout for the SearchAPI ( server is not responding )";
//     case "404" : return "The requested resource could not be found.";
//     case "500" : return "Internal server error.";
//     case "501" : return "Reporting service failure : return unable to process request.Please try after some time.";
//     case "1001" : return "No message body found";
//     case "1002" : return "No message header found";
//     case "1003" : return "Message header does not contain error code";
//     case "1004" : return "Message header does not contain error category";
//     case "1005" : return "Request timeout";
//     case "1006" : return "Frond end naming exception";
//     case "1007" : return "Front end jms exception";
//     case "1008" : return "Unknown exception";
//     case "1101" : return "Fast encoding exception";
//     case "1102" : return "Fast decoding exception";
//     case "1103" : return "Dto to message mapping exception";
//     case "1104" : return "Message to dto mapping exception";
//     case "1201" : return "Ioc invalid";
//     case "1202" : return "Message type should not be null";
//     case "1203" : return "Message type not found";
//     case "1204" : return "Creation time should not be null";
//     case "1205" : return "Creation time not found";
//     case "1206" : return "Login id should not be null";
//     case "1207" : return "Login id not found";
//     case "1208" : return "Session key should not be null";
//     case "1109" : return "Session key not found";
//     case "1210" : return "Login password should not be null";
//     case "1211" : return "Login password not found";
//     case "1212" : return "Error code not found";
//     case "1213" : return "Error category not found";
//     case "1214" : return "Quantity should not be less than one";
//     case "1215" : return "Venue scripecode should not be null";
//     case "1216" : return "Venue scripecode not found";
//     case "1217" : return "Price should not be less than zero";
//     case "1218" : return "Triger price should not be less than zero";
//     case "1219" : return "Stop price should not be less than zero";
//     case "1220" : return "Lower limit price should not be less than zero";
//     case "1221" : return "Disclosed quantity should not be less than zero";
//     case "1222" : return "Min fill quantity should not be less than zero";
//     case "1223" : return "User code should not be null";
//     case "1224" : return "User code not found";
//     case "1225" : return "Pro client should not be null";
//     case "1226" : return "Pro client not found";
//     case "1227" : return "Product type should not be null";
//     case "1228" : return "Product type not found";
//     case "1229" : return "Market type should not be null";
//     case "1230" : return "Market type not found";
//     case "1231" : return "Venue code should not be null";
//     case "1232" : return "Venue code not found";
//     case "1233" : return "Security code should not be null";
//     case "1234" : return "Security code not found";
//     case "1235" : return "Buy sell should not be null";
//     case "1236" : return "Buy sell not found";
//     case "1237" : return "Price condition should not be null";
//     case "1238" : return "Price condition not found";
//     case "1239" : return "Invalid message type";
//     case "1240" : return "Topic name can not be null";
//     case "1241" : return "User access key not be null";
//     case "1242" : return "New password not be null";
//     case "1243" : return "Old password not be null";
//     case "1244" : return "Channel should not be null";
//     case "1245" : return "Channel not found";
//     case "1246" : return "Emailid should not be null";
//     case "1247" : return "Emailid not found";
//     case "1248" : return "Trans id should not be null";
//     case "1249" : return "Trans id not found";
//     case "1250" : return "Entering user code should not be null";
//     case "1251" : return "Entering user code not found";
//     case "1252" : return "Ordering user code should not be null";
//     case "1253" : return "Ordering user code not found";
//     case "1254" : return "Order status should not be null";
//     case "1255" : return "Order status not found";
//     case "1256" : return "External trans id not found";
//     case "1257" : return "Custodian id not found";
//     case "1258" : return "Invalid stop loss trigged";
//     case "1259" : return "Method name should not be null";
//     case "1260" : return "Method name not found";
//     case "1261" : return "TifCD should not be null";
//     case "1262" : return "TifCD not found";
//     case "1263" : return "Segment should not be null";
//     case "1264" : return "Segment not found";
//     case "1265" : return "Required amount should not be zero";
//     case "1300" : return "Invalid to product type";
//     case "1301" : return "Invalid from product type";
//     case "1302" : return "Invalid product type conversion";
//     case "1303" : return "Request ID not found";
//     case "1304" : return "Strike Price not found";
//     case "1305" : return "Either quantity or price should be given";
//     case "1501" : return "Authentication exception";
//     case "1502" : return "Sorry : return You are not authorized or Invalid User Code / Password.";
//     case "1503" : return "Sorry : return You are not authorized or Invalid User Code / Password.";
//     case "1504" : return "User disabled. Please contact customer care: ";
//     case "1505" : return "Not an internet client";
//     case "1506" : return "Web login is not allowed for retail clients";
//     case "1507" : return "Not session type dealer";
//     case "1508" : return "User disabled. Please contact customer care: ";
//     case "1516" : return "Not an online client.";
//     case "1519" : return "Service is not available";
//     case "1522" : return "Secure Authentication Required";
//     case "1523" : return "Tfa token entered is wrong. Please re-enter.";
//     case "1525" : return "Invalid Twofactor Regeneration attempt";
//     case "1526" : return "User Data Not Found";
//     case "1527" : return "Mobile user agreement not accepted : return please visit customer care site or contact our Branch/ Call Centre for activation";
//     case "1601" : return "Change password exception";
//     case "1602" : return "Wrong old password";
//     case "1603" : return "New password same as old";
//     case "1604" : return "Session expired";
//     case "1605" : return "Password is previously used.";
//     case "1701" : return "Reset password exception";
//     case "1702" : return "Mail id not matching";
//     case "1801" : return "Logout exception";
//     case "1703" : return "Forgot Password Exception";
//     case "1704" : return "MSM ID not matching";
//     case "1705" : return "User does not exist";
//     case "1706" : return "Forgot Password time period not elapsed";
//     case "1707" : return "Not an internet client";
//     case "2101" : return "Not a valid order request";
//     case "2102" : return "Invalid user session";
//     case "2103" : return "User session does not exist";
//     case "2105" : return "IOC is not allowed in Pre-open.";
//     case "2106" : return "Disclose quantity is not allowed in Pre-open.";
//     case "2107" : return "Stop loss is not allowed in Pre-open.";
//     case "2108" : return "Invalid unit";
//     case "2109" : return "Tif date should be greater than current date";
//     case "2110" : return "Tif date should be less than expiration date";
//     case "2111" : return "Tif date should be less than allowed limit";
//     case "2116" : return "GTD orders not allowed in this venue";
//     case "2935" : return "INVALID OFFLINE ORDER TIME";
//     case "3204" : return "OFFLINE ORDER PERSISTANCE FAILED";
//     case "3205" : return "OFFLINE ORDER SEARCH FAILED";
//     case "2519" : return "INVALID STATUS FOR OFFLINE MODIFY";
//     case "2520" : return "INVALID STATUS FOR OFFLINE CANCEL";
//     case "2521" : return "INVALID PROCLIENT TYPE";
//     case "2501" : return "Ordering user does not exist";
//     case "2503" : return "Entering user does not exist";
//     case "2504" : return "Entering user status is false";
//     case "2505" : return "Trading not allowed";
//     case "2506" : return "Ordering not allowed";
//     case "2507" : return "No venue membership for ordering user";
//     case "2508" : return "No venue membership for entering user";
//     case "2509" : return "Margin trade not allowed";
//     case "2510" : return "Origin order not found";
//     case "2511" : return "Can not cancel before confirmation";
//     case "2512" : return "Order status is neither confirmed or partially executed";
//     case "2513" : return "Modify pending";
//     case "2514" : return "Trans id does not exist";
//     case "2515" : return "Entering user does not have the authorization to order for the client";
//     case "2522" : return "Pre-Open Order at Online Time.";
//     case "2523" : return "Online Order at Pre-Open Time.";
//     case "2701" : return "Security not active";
//     case "2702" : return "Security is withdrawn";
//     case "2703" : return "Security is buy suspended";
//     case "2704" : return "Security is sell suspended";
//     case "2705" : return "Security is market buy suspended";
//     case "2706" : return "Security is market sell suspended";
//     case "2707" : return "Invalid security status";
//     case "2708" : return "Trading denied";
//     case "2709" : return "No security details found";
//     case "2710" : return "Invalid Tick size";
//     case "2713" : return "Amount less than : return minimum amount required for fresh subscription.";
//     case "2714" : return "Amount less than minumum subscription amount for an additional order";
//     case "2715" : return "Depository mode not allowed";
//     case "2716" : return "Physical mode not allowed";
//     case "2717" : return "ORDER_QTY_NOT_MULTIPLE_OF_MARKETLOT";
//     case "2720" : return "Invalid tick size for trigger price";
//     case "2901" : return "Minimum order value is null";
//     case "2902" : return "Less than minimum order";
//     case "2903" : return "Not enough buying power";
//     case "2904" : return "Not enough holding";
//     case "2905" : return "Adding new record into portfolio failed";
//     case "2906" : return "Updating portfolio failed";
//     case "2907" : return "Adding new record into portfolio unsettled failed";
//     case "2908" : return "Updating portfolio unsettled failed";
//     case "2909" : return "Updating user table failed";
//     case "2910" : return "Client wise exposure check failed";
//     case "2911" : return "Dealer wise exposure check failed";
//     case "2912" : return "Greater than maximum order";
//     case "2913" : return "Invalid client category found";
//     case "2914" : return "Invalid booked price";
//     case "2915" : return "No response from span module";
//     case "2916" : return "Invalid ISIIN found";
//     case "2917" : return "EC_NOT_ACTIVE";
//     case "2918" : return "Market wide limit reached";
//     case "2919" : return "You are not registered for this product : return Register immediately at your branch to avail this service.";
//     case "2920" : return "Trade to trade denied for this client";
//     case "2921" : return "Buy is denied for this client";
//     case "2922" : return "Sell is denied for this client";
//     case "2923" : return "Market buy is denied for this client";
//     case "2924" : return "Market sell is denied for this client";
//     case "2925" : return "Client is having withdrawn as order permission";
//     case "2927" : return "Order State conflict";
//     case "2928" : return "Invalid Transaction Password";
//     case "2929" : return "Order quantity greater than per order buy quantity";
//     case "2930" : return "Order quantity greater than per order sell quantity";
//     case "2931" : return "Order quantity greater than per day quantity";
//     case "2932" : return "Price out of range";
//     case "2933" : return "Security not active for the product type";
//     case "2934" : return "Requested PortFolio not found";
//     case "2935" : return "Invalid Offline Order Time";
//     case "2936" : return "Invalid Product Conversion Request Status";
//     case "2937" : return "Request quantity greater than available quantity.";
//     case "2938" : return "Invalid Product Conversion Request ID";
//     case "2939" : return "Invalid order time.";
//     case "2940" : return "Intraday Sell Denied For Trade to Trade Security.";
//     case "2941" : return "Order Permission Denied For This Client In This Channel.";
//     case "2942" : return "Venue wise Online Order Check Failed.";
//     case "2944" : return "Invalid Custodian Id";
//     case "2945" : return "Not Enough BTST Exposure For The Security";
//     case "2946" : return "Not Enough MTF Exposure For The Security";
//     case "2947" : return "NOT_ENOUGH_MTF_EXPOSURE_FOR_THE_CLIENT";
//     case "2948" : return "DEALER_WISE_DAILY_EXPOSURE_LIMIT_REACHED";
//     case "2949" : return "DEALER_WISE_EXPOSURE_EXPIRY_LIMIT_REACHED";
//     case "2953" : return "Not enough smartplus exposure for the security";
//     case "2955" : return "No response from OMS";
//     case "2957" : return "Invalid profit price difference in smartplus";
//     case "2958" : return "Invalid STL price difference in smartplus";
//     case "2959" : return "Available buying power is negative";
//     case "2965" : return "Security wise trading member limit reached";
//     case "2966" : return "Security wise user limit reached";
//     case "2967" : return "Square-off only permission for the venue";
//     case "2968" : return "Due to continuous debit more than T+6 days in this exchange- only square-off permitted";
//     case "2960" : return "Maximum open exposure permitted for this product is Rs.Lakhs";
//     case "2961" : return "Maximum open exposure permitted in a single scrip for this product is Rs.0 Lakhs";
//     case "2962" : return "Startagy combination not defined";
//     case "3001" : return "new user does not exist";
//     case "3002" : return "No venue membership for new user";
//     case "3003" : return "Ordering is not allowed for new user";
//     case "3004" : return "Trading is not allowed for new user";
//     case "3005" : return "New user has unauthorized";
//     case "3006" : return "Margin Trade is not allowed for new user";
//     case "3007" : return "new user has denied client type";
//     case "3201" : return "New order persistance failed";
//     case "3202" : return "Modify order persistance failed";
//     case "3201" : return "Cancel order persistance failed";
//     case "4001" : return "Null pointer exception";
//     case "4002" : return "Jms exception";
//     case "4003" : return "Topic not found exception";
//     case "4004" : return "Last traded price not available";
//     case "4005" : return "Back end Run time exception occurred .. please try after some time";
//     case "4006" : return "Unknown exception";
//     case "4007" : return "Persistance exception";
//     case "4008" : return "Duplicate message received";
//     case "4009" : return "Resource lock exception";
//     case "5000" : return "Back end message mapping failed";
//     case "5100" : return "Order reply persist failed";
//     case "5101" : return "Order lookup failed";
//     case "5102" : return "Orphan execution persist failed";
//     case "5200" : return "User node is null";
//     case "6001" : return "Sql conn error";
//     case "6002" : return "Sql query error";
//     case "6003" : return "Xml conversion error";
//     case "6004" : return "Data not found";
//     case "6005" : return "Data retrieving error";
//     case "6006" : return "Create exception";
//     case "6007" : return "Naming exception";
//     case "6008" : return "End of resultset";
//     case "6009" : return "Remote exception";
//     case "6021" : return "Error code not found";
//     case "6022" : return "Error category not found";
//     case "6023" : return "App name should not be null";
//     case "6024" : return "App name not found";
//     case "6025" : return "Entering user code should not be null";
//     case "6026" : return "Entering user code not found";
//     case "6027" : return "Ordering user code should not be null";
//     case "6028" : return "Ordering user code not found";
//     case "6029" : return "Status should not be null";
//     case "6030" : return "Status not found";
//     case "6031" : return "Trans id should not be null";
//     case "6032" : return "Trans id not found";
//     case "6033" : return "Legno should not be null";
//     case "6034" : return "Legno not found";
//     case "6035" : return "Entering user code and ordering user code not found";
//     case "6036" : return "Method name should not be null";
//     case "6037" : return "Method name not found";
//     case "6038" : return "Venue code should not be null";
//     case "6039" : return "Venue code not found";
//     case "6040" : return "Security code should not be null";
//     case "6041" : return "Security code not found";
//     case "6042" : return "Product type should not be null";
//     case "6043" : return "Product type not found";
//     case "6044" : return "User code should not be null";
//     case "6045" : return "User code not found";
//     case "6046" : return "Session key should not be null";
//     case "6047" : return "Session key not found";
//     case "81001" : return "Back end error in web server";
//     case "81002" : return "Invalid Web session";
//     case "81003" : return "empty request string passed as argument in HTTP request from client";
//     case "81004" : return "Error while decoding request from string";
//     case "81005" : return "No response received from OMS";
//     case "81006" : return "Error while encoding response to string";
//     case "81007" : return "Unknown Exception while requesting to OMS";
//     case "81008" : return "OMS API exception while requesting to OMS";
//     case "81009" : return "OMS API FrontEnd Exception while requesting to OMS";
//     case "81010" : return "Report Type not found in report request";
//     case "81011" : return "Co-relation id not found in request";
//     case "81012" : return "Field in request not found in server dictionary";
//     case "81013" : return "Request header is empty";
//     case "81014" : return "Request header having unknown format or malformed header";
//     case "81015" : return "Unknown Request DTO type.";
//     case "81016" : return "Required parameter not found.";
//     case "81017" : return "Duplicate request Message";
//     case "81018" : return "Request DTO is null";
//     case "81020" : return "Denied host";
//     case "81103" : return "Order Type Mis match";
//     case "81101" : return "Wrong quantity.";
//     case "81102" : return "Invalid security.";
//     case "70000" : return "Invalid Message Format";
//     case "70001" : return "Invalid account number";
//     case "70002" : return "Function not supported";
//     case "70003" : return "Funds Insufficient";
//     case "70004" : return "Transaction not allowed on account";
//     case "70005" : return "Withdrawal limit exceeded";
//     case "70006" : return "Transfer Limit Exceeded";
//     case "70007" : return "All cheque not in same book";
//     case "70008" : return "Could not stop all cheque";
//     case "70009" : return "All cheque not of same acct";
//     case "70010" : return "Please contact admin";
//     case "70011" : return "Please contact admin";
//     case "70012" : return "Cutover in progress";
//     case "70013" : return "Host not available";
//     case "70014" : return "Host not available";
//     case "70015" : return "System malfunction";
//     case "70016" : return "Host not available";
//     case "70017" : return "Duplicate transaction";
//     case "70018" : return "Failed";
//     case "100001" : return "Invalid Signature or certificate details";
//     case "200001" : return "Invalid or Inactive Corporate Id";
//     case "300001" : return "Corporate is not allowed for selected Message";
//     case "500001" : return "Invalid Length (Response ISO message)";
//     case "900001" : return "Invalid Fund Transfer Enquiry";
//     case "110000" : return "Invalid Length (Input Corporate message)";
//     case "120000" : return "Invalid Debit Account No";
//     case "130000" : return "Message already transfered";
//     case "140000" : return "Remark field is empty";
//     case "150000" : return "Invalid IFSC Code";
//     case "160000" : return "Missing RTGS Corporate setup details";
//     case "170000" : return "Invalid RTGS Message Characters";
//     case "180000" : return "RTGS Rejection - QPH";
//     case "190000" : return "RTGS Rejection - PI";
//     case "200000" : return "RTGS Rejction - Other bank";
//     case "70034" : return "Block Amount not available";
//     case "210000" : return "RTGS Message Generation - System Error";
//     case "220000" : return "Action Message - Mandatory Fields Missing";
//     case "230000" : return "Action Message - Invalid Beneficiary Account";
//     case "240000" : return "DD Message - Invalid DD Payable City";
//     case "250000" : return "Message Invalid Values";
//     case "270001" : return "Invalid ISIN Or AccountCode";
//     case "270002" : return "Quantity requested for BOO not Available";
//     case "270003" : return "Operation is not allowed when the object is open.";
//     case "270004" : return "Unknown errors :270004";
//     case "70041" : return "Physical link error";
//     case "70042" : return "Query Time out Exception";
//     case "70043" : return "Invalid Return URL";
//     case "70044" : return "Invalid Request Message";
//     case "70045" : return "Unknown Errors  :70045";
//     case "260000" : return "Error Not Defined";
//     case "280000" : return "NEFT - Senders Customer ID cannot be blank";
//     case "65101" : return "Validation Failed:Unregistered Acctno/ClientId/BrokerId  OR BrokerTransactionId is duplicated.";
//     case "220000" : return "Validation Failed:Mandatory Fields not obtained.";
//     case "70014" : return "Service Down.";
//     case "65110" : return "Duplicate Broker Msg Id.";
//     case "65111" : return "Invalid scheme type.";
//     case "65184" : return "Requested Block operation failed since Account is closed/frozen.";
//     case "65186" : return "Block does not exist.";
//     case "65902" : return "Invalid transaction (Invalid function code within network management messages).";
//     case "65907" : return "Card issuer inoperative .";
//     case "70042" : return "Timed Out.Transaction doesnot occur.";
//     case "65000" : return "Unprocessed.";
//     case "65800" : return "Requested Amount  greater than existing Lien or Max Permissible trading limit.";
//     case "65801" : return "Duplicate entry in File.";
//     case "65802" : return "Day Begin not Done.";
//     case "70046" : return "Invalid Message Type.";
//     case "70047" : return "Header record count is not matching with detail no. of records.";
//     case "70048" : return "Header request quantity is not matching with Detail no. of records quantity.";
//     case "70049" : return "Invalid DP Id..";
//     case "70050" : return "Invalid Client Id.";
//     case "70051" : return "Invalid ISIN Code.";
//     case "70052" : return "Insufficient Balance";
//     case "70053" : return "Database Error in Bank";
//     case "70054" : return "Free balance not available.";
//     case "70055" : return "ISIN is in Auto corporate Action.";
//     case "70056" : return "Client is not Applied for Online Instruction";
//     case "70057" : return "No Records Found";
//     case "70058" : return "Account Suspended for Debit";
//     case "70059" : return "Invalid DP Id.";
//     case "70060" : return "Invalid Sysid";
//     case "70061" : return "The Client Id is not linked to Geojit in Bank";
//     case "70062" : return "Invalid Joining Date";
//     case "70063" : return "Invalid Target CMBP Id.";
//     case "70064" : return "Market type is not valid.";
//     case "70065" : return "Invalid Settlement No.";
//     case "70066" : return "TIFD could not be executed because Inst. are not accepted within one hour of Pay in deadline.";
//     case "70067" : return "Execution Date can not be a Holiday.";
//     case "70068" : return "Execution Date cannot be less than today\'s date.";
//     case "70069" : return "Execution Date Eroor Because Last Batch Upload for this date has got Completed.";
//     case "70070" : return "This Client is in Defaulter List Cannot execute the Transaction.";
//     case "70071" : return "Invalid Slip Series.";
//     case "70072" : return "Client is not given POA for this CM.";
//     case "70073" : return "Slip is not issued to POA.";
//     case "70074" : return "Slip No. already used for this Settlement No";
//     case "70075" : return "Invalid Request Parameter.";
//     case "70076" : return "Unable to connect to TCP Host.";
//     case "70077" : return "Error when generating Response";
//     case "70078" : return "Invalid Action Type.";
//     case "70079" : return "Invalid Messge length";
//     case "70080" : return "Exception";
//     case "70106" : return "Server Name not passed";
//     case "70081" : return "Server name and return URL mismatch";
//     case "70082" : return "Server Name and Host IP mismatch";
//     case "70083" : return "Unique Reference Id Not Passed";
//     case "70084" : return "Invalid Block Reason Code";
//     case "70085" : return "Block Reason Code must not be more than 5 characters";
//     case "70086" : return "Invalid Block Amount Indicator";
//     case "70087" : return "Block id cannot be more than 25 chars";
//     case "70088" : return "Brokerage Tran ref number cannot be more than 50 chars";
//     case "70089" : return "Invalid Login Parameter. Sorry For Inconvenience";
//     case "70090" : return "Unable To Process Your Request. Contact Bank";
//     case "70091" : return "Invalid host IP Address";
//     case "70092" : return "The Account Number For Share Trading is not Your Active Account. Please Contact Bank";
//     case "70093" : return "Amount blocked successfully";
//     case "70094" : return "Amount unblocked successfully";
//     case "70095" : return "Invalid message Id";
//     case "70096" : return "Invalid Block Tran Number";
//     case "70097" : return "Invalid Block Expiry Date";
//     case "70098" : return "This Account is Deregistered with the Broker. Cannot Process Your request";
//     case "70099" : return "The Previous Operation on Lien Marking/Unmarking was not Successful Corresponding to This Broker Transaction Number. So Cannot process with Balance Inquiry'";
//     case "70100" : return "The Total Available Balance is Not Available at the Moment. Try After Some Time.";
//     case "70101" : return "Invalid Url. Sorry For the Inconvenience";
//     case "70102" : return "Block Reference Number Not Passed";
//     case "70103" : return "Broker Transaction Number has to be Unique For Marking/Unmarking Lien";
//     case "70104" : return "Record does not exist";
//     case "70105" : return "Non availability of a process at Bank\'s end to accept the request from client side";
//     case "70107" : return "Reason Code Not Found in TABLEcorresponding to the Broker";
//     case "70108" : return "Please Pass a Valid Reason code Assigned To You.";
//     case "70109" : return "Broker Name Not Found in TABLE corresponding to the Server Name";
//     case "70110" : return "You are Not Authorized To Perform Transaction For the Customer.The Customer is Not Registered With You";
//     case "70111" : return "Block amount limit exceeds the days range";
//     case "70112" : return "Amount you are trying to block is greater than available balance";
//     case "70113" : return "No. of Block requests for the day exceeded";
//     case "20216" : return "Your Credit Request Approval Limit Exceeded";
//     case "20202" : return "Your Credit Request Approval Limit Exceeded";
//     case "81001" : return "Back end error in web server";
//     case "2972" : return "Exceeded maximum product conversion limit for client";
//     case "2973" : return "Security not available for client type ";
//     case "2974" : return "No user product mapped for client";
//     case "2975" : return "Exceeded dealerwise exchangewise open order limit";
//     case "2976" : return "Client daily exposure limit reached";
//     case "2977" : return "Client expiry exposure limit reached";
//     case "2978" : return "Branch daily exposure limit reached";
//     case "2979" : return "Branch expiry exposure limit reached";
//     case "2980" : return "Exceeded branchwise exchangewise open order limit";
//     case "2981" : return "Greater than maximum order branchwise";
//     case "2982" : return "Branch wise maximum order value is null";
//     case "2983" : return "Branch wise minimum order value is null";
//     case "2984" : return "Less than minimum order branch wise";
//     case "2985" : return "Greater than maximum order dealer wise";
//     case "2986" : return "Dealer wise maximum order value is null";
//     case "2987" : return "Dealer wise minimum order value is null";
//     case "2988" : return "Less than minimum order dealer wise";
//     case "2989" : return "Order quantity greater than maximum order quantity branch wise";
//     case "2990" : return "Order quantity greater than maximum order quantity dealerwise";
//     case "SessionErrorPage" : return "FLIPWEB/faces/ErrorPages/ErrorPage.jsp";
//     case "validPassword" : return "Password changed successfully.Please Relogin.";
//     case "disabledLogin" : return "User disabled. Please contact support team.";
//     case "validForgotPwdReq" : return "Forgot password request submitted successfully";
//     case "InvaliedScripCode" : return "Invalid Security Name";
//     case "OrderSentToExchange" : return "Order Sent To Exchange";
//     case "ModifySucessfull" : return "Order successfully modified";
//     case "ModifyOrderSendingFailed" : return "Modify Order Sending Failed";
//     case "NewOrderFailure" : return "New Order Sending Failed due to no response message received from OMS";
//     case "BackEndError" : return "Back end exception occurred.. Try again";
//     case "LoginFailureMsg" : return "Authentication server is not responding.";
//     case "newOrdFailure" : return "New Order Sending Failed due to";
//     case "modOrdFailure" : return "Modify Order failed due to";
//     case "cancelOrdFailure" : return "Order Cancelling failed";
//     case "cancelOrder" : return "Order Cancelling failed due to Run time Error";
//     case "CancelSuccessful" : return "Order Sucessfully Cancelled";
//     case "1992" : return "Welcome to Geojit BNPP Family. Your MyGeojit registration is complete. An activation email has been sent to your mailbox. Kindly follow the instructions in the email to activate your MyGeojit Account.'";
//     case "1993" : return "Email is already registered.";
//     case "1994" : return "Account Activated. Please login.";
//     case "1995" : return "Invalid account.";
//     case "1996" : return "Sorry for inconvinience. Error in sending activation mail. Please register again.";
//     case "1997" : return "Your new account is not activated.";
//     case "100" : return "No Option Chain found";
//     case "1529" : return "KYC Not updated. Please update the KYC.";
//     case "1530" : return "We excitedly welcome you to FLIP X. \nPlease log on to FLIP X on 1st April trading hours for a whole new trading Xperience'";
//     case "1531" : return "New version of application is available. Please download!";
//     default : return "somethiing went wrong";
//   }
// }