class CommonUrls{
  static String forgotPasswordUrl ="https://my.geojit.com/#/forgotpassword";
}